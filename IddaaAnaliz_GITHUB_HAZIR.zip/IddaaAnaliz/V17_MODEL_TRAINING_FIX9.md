V17 FIX9 - MODEL TRAINING PIPELINE

Problem identified from runtime logs/UI:
- ESPN historical data and match import were working.
- 25k+ training-sized match count could exist while the model status remained not-ready.
- Training was coupled to the final historical-worker completion path; app restart/old WorkManager state could leave the model cache/meta empty.

Changes:
1. Added ESPNModelTrainingWorker.
   - Reads completed ESPN matches from Room.
   - Does not require the 365-day worker to be currently running.
   - Starts when at least 80 completed matches exist.
   - Reuses existing ESPNKendiModelTrainer; after training verifies meta + rating rows.
   - Refreshes ESPNKendiModelRepository after training.
   - Uses unique WorkManager name to prevent concurrent training jobs.
2. Application startup now checks historical DB directly and queues the training worker when the model is missing or behind the available match count.
3. ESPNHistoryWorker now queues the model training worker after the 365-day scan instead of doing the heavy training inline.
4. ESPNModelDurum UI refreshes the repository cache every 3 seconds so that a completed background training is reflected without restarting the app.

No changes were made to the core rating algorithm itself.
