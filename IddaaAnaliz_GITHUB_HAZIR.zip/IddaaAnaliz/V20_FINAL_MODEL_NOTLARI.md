# V20 — FINAL MODEL / İDDAA + ESPN

## Kaynaklar
- Canlı bülten ve oranlar: mevcut İddaa akışı.
- Tarihsel futbol sonuçları: mevcut ESPN 365 günlük akışı.
- Yeni dış API/provider eklenmedi.
- Eski ProgSport/SofaScore sınıfları geriye dönük uyumluluk için tutulabilir; aktif futbol olasılık zincirinde kullanılmaz.

## Matematiksel model
- Global latent Elo: tüm futbol geçmişinden ortak rating ölçeği.
- Kontrollü Elo güncellemesi + gol farkı çarpanı.
- Genel hücum/savunma latent log-strength.
- İç saha / deplasman özel hücum-savarunma gücü; küçük örneklemde genel güce shrink edilir.
- Rakip gücü düzeltmesi.
- Son 5 / 10 / 20 formu ayrı izlenir; gerçek modelde son 20 içindeki exponential recency decay kullanılır; yarı ömür 5 maçtır.
- Form trendi ve ağırlıklı gol farkı kullanılır.
- Lig seviyesi elle sınıflandırılmaz; tarihsel gol ortamından öğrenilen küçük bağlamsal düzeltme olarak tutulur.
- Poisson + Dixon-Coles skor uzayı.
- Dixon-Coles rho tarihsel düşük skorların likelihood grid'i ile sınırlı aralıkta öğrenilir.
- Bütün ana futbol marketleri aynı skor dağılımından türetilir.
- İlk yarı sonucu için ayrı zaman ölçekli Poisson dağılımı kullanılır.
- Doğru skor / tahmini skor marketleri skor hücrelerinden türetilir.

## Oyuncu / PPDA
- Gerçek oyuncu yokluk listesi verilirse, pozisyon ve dakika ağırlıklı oyuncu etkisi log-lambda'ya sınırlı düzeltme olarak uygulanır.
- Normal XI ve beklenen XI farkı için replacement-aware kadro fonksiyonu eklendi.
- PPDA yalnızca PPDA + lig ortalaması + standart sapma gerçek verisi mevcutsa uygulanır; z-score ile normalize edilir.
- Eksik PPDA/oyuncu verisi uydurulmaz.

## Probability / Confidence / Edge / EV
- Probability modelin olay olasılığıdır.
- Confidence yalnızca örneklem + model kalite/stabilite sinyalidir; odds, Edge, EV veya probability magnitude'dan türetilmez.
- Fair odds = 1 / probability.
- Edge = model probability - no-vig market probability.
- EV = probability * decimal odds - 1.
- Edge/EV model probability'yi değiştirmez.
- Düşük olasılıklı yüksek oranlı seçimler sırf EV/Edge nedeniyle Strong olamaz.

## Calibration
- Yerleşmiş geçmiş futbol tahminlerinden sıcaklık (temperature scaling) parametresi grid search ile öğrenilir.
- Kalibrasyon tahmin dağılımına softmax/logit sıcaklık ölçeğinde uygulanır ve dağılım tekrar normalize edilir.
- Saatlik KalibrasyonWorker yeni sonuçlardan kalibrasyon state'ini günceller.

## Günün Güçlüleri
- İlk görüldüğü anda kilitli seçim yok.
- Her güncel taramada bütün uygun seçimler tekrar sıralanır.
- Probability ana sıralama eksenidir; confidence kalite metriğidir; Edge/EV tie-break seviyesindedir.
- Aynı maçtan birden fazla seçim listeyi doldurmaz; maç başına en iyi tek seçim tutulur.
- Top 12 güncel snapshot olarak saklanır.

## Performans
- Merkezi model snapshot/cache mevcut kaldı.
- Maç analiz cache'i değişmeyen market/model fingerprint'i ile kullanılır.
- Aynı maçtaki bütün futbol marketlerinde skor dağılımı yalnızca bir kez hesaplanır.
- Veri değişmedikçe merkezi model tekrar kurulmaz.

## Derleme kontrolü
- Bu ortamda Android SDK/Gradle dağıtımı bulunmadığından tam Android assembleDebug çalıştırılamadı.
- Yapılan doğrulama: Kotlin kaynaklarında imza/brace tutarlılığı, duplicate sınıf kontrolleri ve saf matematik katmanlarının `kotlinc` ile derlenmesi.
