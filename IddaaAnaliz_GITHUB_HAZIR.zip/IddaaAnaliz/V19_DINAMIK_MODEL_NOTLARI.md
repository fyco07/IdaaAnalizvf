# V19 — Dinamik merkezi model düzeltmesi

- Veri kaynakları korunur: İddaa + ESPN. Yeni provider eklenmedi.
- Merkezi futbol modeli: kontrollü Elo + hücum/savunma + rakip gücü + son 5/10/20 form.
- Recency: maç sırası yarı ömür 5 maç; son maçlar daha yüksek ağırlık alır.
- `form20`, `weightedForm`, `trend` eklendi.
- Lig seviyesi elle atanmaz; tarihsel gol ortamından küçük ve sınırlı bir lig düzeltmesi çıkarılır.
- Günün Güçlüleri ilk görülen seçim olarak kilitlenmez; güncel snapshot tamamen yenilenir.
- Probability ana sıralama ekseni; confidence ayrı kalite metriği; edge/EV ayrı ekonomik metriktir.
- Güçlü adaylığında pozitif Edge/EV zorunluluğu kaldırıldı.
- MacAnaliz cache 512 kayıt / 15 dakika; oran+model snapshot fingerprint ile doğrulanır.
- Model DB sonucu değişmedikçe zorla yeniden kurulmaz.
- Android uçtan uca derlemesi bu ortamda Gradle 9.5 dağıtımı internet istediği için doğrulanamadı; Android Studio'da compile edilmelidir.


## Kaynaklar
- Canlı bülten ve oranlar: mevcut İddaa akışı korunur.
- Tarihsel futbol sonuçları: mevcut ESPN tarihsel akışı korunur.
- Yeni üçüncü taraf veri/API eklenmedi.
- ESPN verisi merkezi geçmiş havuzuna girer; tahmin tarafında bu havuzdan öğrenilen merkezi takım modeli kullanılır.
