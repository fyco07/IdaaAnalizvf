# V10 ESPN tarihsel veri düzeltmesi

- ESPN scoreboard `events` geliyor olmasına rağmen `tamamlanan=0` sorunu için raw parser sadeleştirildi.
- Geçmiş maç kabulü için iki takım + iki geçerli skor yeterli; status ikincil doğrulama.
- Team name fallback'leri eklendi.
- Kadın / U17-U23 / youth / junior / academy / reserve / university / college / jong filtreleri korunuyor.
- 365 günlük tarama 0 maçla biterse aynı sürümde sonsuz yeniden başlama engellendi.
- Parser sürümü 10; V10 ilk çalışmada eski boş-tarama kilidini bir kez temizleyip 0. günden başlar.
- Uygulama açılışında boş tarama kilidi varsa tekrar 365 gün başlatılmaz.
- Logda `MAC_KAYIT` ve `PARSE_DETAY ok=...` görülmeli.
