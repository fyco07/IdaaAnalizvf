# ESPN parser/network fix V5

- Tarihsel ESPN ham veri kabulünde kadın/gençlik/rezerv isim filtresi kaldırıldı; filtre eğitim katmanına bırakıldı.
- Geçerli `competitors >= 2`, takım adı ve skor bulunan event artık parser tarafından kaydedilir.
- `team.displayName`, `team.name`, `team.shortDisplayName`, `team.location` ve competitor düzeyindeki ad alanları için fallback eklendi.
- Score için `score` ve `displayValue` fallback'i eklendi.
- Parse skip durumlarında neden loglanıyor (`id_yok`, `date_yok`, `competitions_yok`, `competitors_2den_az`, `takim_adi_yok`, `skor_yok`).
- Ağ erişimi olmayan emülatörde `UnknownHostException` uygulama çökmesine yol açmadan Worker retry mekanizmasında kalır.
- AndroidManifest INTERNET izni mevcut; WorkManager ESPN işinde CONNECTED network constraint mevcut.
