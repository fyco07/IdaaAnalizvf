V17 FIX7 - VERI AKISI VE KAYIT DÜZELTMESİ

- Merkezi İddaa bülteni Room yazımı tek @Transaction altında toplandı.
- Merkezi ESPN tarihsel aktarımı tek transaction altında toplandı.
- Merkezi havuz istatistikleri eklendi ve loglanıyor: mac/takim/lig/sezon/market/oran/kaynak/sonuc/tahmin.
- Merkezi senkron artık sessizce swallow edilmiyor; hata MERKEZI_SENKRON_HATASI olarak loglanıyor.
- ESPN tarihsel WorkManager başlatma mantığı güçlendirildi: iş aktif değilse yeniden enqueue edilir ve WORK_ENQUEUED_V17 logu üretilir.
- Aktif iş varsa ikinci zincir oluşturulmaz.
- ExistingWorkPolicy.REPLACE yalnızca aktif iş yokken kullanılır; kayıtlı nextOffset ile kaldığı yerden devam eder.

Log hedefleri:
IDDAA_BULTEN_KAYIT_TAMAMLANDI
SENKRON_OZET
WORK_ENQUEUED_V17 / WORK_ZATEN_AKTIF
