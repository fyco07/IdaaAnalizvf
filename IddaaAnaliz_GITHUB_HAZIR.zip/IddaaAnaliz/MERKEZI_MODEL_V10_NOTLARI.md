# Merkezi Model V10

Bu sürüm V9'un üzerine, mevcut çalışan yapıyı bozmadan canlı futbol tahminini tek bir merkezi modele zorlar.

## Canlı futbol zinciri
IDDAA marketleri -> Merkezi Veri Havuzu -> tamamlanmış geçmiş maçlar -> takım modeli (Elo/hücum/savunma/form/rakip gücü) -> lambda -> Poisson skor dağılımı -> market olasılığı -> Edge/EV -> Güçlü Seçimler.

## V10 güvenlikleri
- Canlı futbol için ayrı ESPN model deposu fallback olarak kapatıldı.
- `ESPNKendiModelTahmincisi` çağrılsa bile boş sonuç döndürür; gerçek canlı model `MerkeziFutbolTahmincisi`dir.
- Canlı futbol takım eşleştirmesi sadece merkezi havuzdaki exact normalize isim/ID üzerinden yapılır.
- Bir takım bile eşleşmezse futbol modeli tahmin üretmez.
- Fuzzy/token eşleşmeleri canlı tahmin zincirinde kullanılmaz.
- Güçlü seçimler: model olasılığı >= 0.85, güven >= 88, edge >= 0.03, EV >= 0.04, model-piyasa mutlak farkı <= 0.15, oran <= 3.50, maksimum 12 seçim/gün ve maç başına tek seçim.
- Tarihsel merkezi havuz verisi normal akışta silinmez.
- V10 açılışında merkezi modelin hazır olup olmadığı ve tarihsel örneklem sayısı açık loglanır.

## Beklenen loglar
- `V10_BOOT ... CENTRAL_MODEL_ONLY=true`
- `V10_BOOT_MODEL_READY ...`
- `V10_MERKEZI_KULLANILIYOR ...`
- `TAKIM_MODEL ...`
- `MERKEZI_LAMBDA ...`
- `MERKEZI_MAC_BATCH ...`

Eski `ESPN_MODEL_TAHMIN` / `ESPN_MODEL_REPO` logları V10 canlı futbol tahmininde görülmemelidir. Görülürse yanlış/eskiden derlenmiş APK kurulmuştur veya başka bir çağrı zinciri aktif kalmıştır.
