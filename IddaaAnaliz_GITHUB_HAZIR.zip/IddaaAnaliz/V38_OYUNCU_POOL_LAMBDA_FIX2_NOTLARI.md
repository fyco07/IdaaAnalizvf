# V38 – Oyuncu havuzu + lambda düzeltmesi

- Roster mevcut ama bireysel istatistiği olmayan oyuncu artık 0 kalite değildir; 50 nötr prior kullanılır. Kalite kanıt sayısı yine yalnızca gerçek kullanım/üretim verisini sayar.
- Böylece eksik oyuncu istatistiği takımın kalite ortalamasını yapay olarak aşağı çekmez. 50 prior lambda düzeltmesi üretmez.
- ESPN kadro kapsaması, roster kapsaması üzerinden hesaplanır. Sakatlık/ceza endpointinin geçici yokluğu kapsama oranını 70'e düşürmez; durum tazeliği ayrı gösterilir.
- TeamId tabanlı yerel oyuncu havuzu, ağ ve sezon metni sorunlarında 0 oyuncu ile ezilmez. Son bilinen havuz geçici fallback olarak korunur.
- TeamId fallback kullanılırken eski cacheKey'e ait durum snapshot'ı da okunabilir.
- Gereksiz MAX_CACHE ve kullanılmayan JsonElement helper kaldırıldı; Locale deprecated kullanımı kaldırıldı.
- Merkezi lambda zinciri aynı MatchModelAdjustments üzerinden çalışır: roster quality delta -> lambdalar(..., adjustments).
