# V38 Build Fix

Derleme logunda raporlanan Kotlin hataları giderildi.

- `mergeMetrics` üye/extension çakışması kaldırıldı; `mergePlayerEvidence(player, metrics)` adlı normal yardımcı fonksiyon kullanılıyor.
- `parseRoster` açık tipli `LinkedHashMap<String, PlayerBase>` ve açık Gson `JsonObject` kontrolleriyle yeniden yazıldı; `size/get/isJsonPrimitive/asString` zincirinden kaynaklanan tür çıkarımı hataları kaldırıldı.
- Derleme akışında zaten iki değer null olduğunda dönüldüğü için `ok = true` sadeleştirildi.
- Kullanılmayan `JsonElement.asJsonObjectOrNull` kaldırıldı.
- `Locale("tr", "TR")` yerine `Locale.ROOT` kullanıldı.

VersionCode=56
VersionName=1.0-V38-OYUNCU-POOL-LAMBDA-BUILD-FIX
