# V9 - Takım Sayıları

Kendi Modeli kartına iki ayrı metrik eklendi:

- İncelenen takım: tamamlanmış ESPN tarihsel verisinde karşılaşılan benzersiz takım sayısı.
- Öğrenilen takım: final modelinde rating üretilen takım sayısı (`ESPNModelMeta.egitimTakimSayisi`).

İncelenen takım sayısı Room DAO üzerinden benzersiz takım isimlerinden hesaplanır ve ekran açıldığında bir kez IO üzerinde okunur. Eğitim tamamlandığında SharedPreferences durumuna da yazılır.

Veritabanı şeması değiştirilmedi; yeni Room migration gerekmez.

Gradle derlemesi bu ortamda doğrulanamadı: Gradle 9.5.0 indirme isteği services.gradle.org DNS erişiminde başarısız oldu.
