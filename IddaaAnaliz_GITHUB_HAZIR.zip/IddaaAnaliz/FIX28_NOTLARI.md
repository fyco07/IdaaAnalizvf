# FIX28 — Sonuç zinciri ve stale APK temizliği

- versionCode: 28
- versionName: 1.0-FIX28
- app/build kaldırıldı; önceki APK/dex çıktıları pakete dahil değil.
- MainActivity.onCreate içinde sonuç çözümleyicisi doğrudan IO coroutine ile başlatılır.
- Application.onCreate sürümü loglar.
- Manuel YENİLE korunur; bülten için otomatik yenileme eklenmedi.
- Beklenen ilk loglar:
  - FIX28_APPLICATION_ONCREATE
  - FIX28_ACTIVITY_ONCREATE
  - FIX28_DOGRUDAN_SONUC_BASLADI
  - FIX28_DOGRUDAN_SONUC_BITTI
