# İddaaAnaliz V20 — Final Model

Bu paket mevcut **İddaa + ESPN** veri akışını korur. Yeni dış API/provider eklenmemiştir.

## Ana model
- Merkezi tarihsel havuzdan küresel latent Elo takım gücü.
- Kontrollü Elo güncellemesi; sonuç + gol farkı etkisi sınırlandırılmıştır.
- Genel hücum/savunma latent gücü.
- İç saha/deplasman ayrı hücum/savunma profilleri.
- Küçük örneklemde shrinkage.
- Rakip gücü düzeltmesi.
- Son 5/10/20 performans göstergeleri; gerçek modelde son 20 içindeki exponential recency decay, half-life = 5 maç.
- Son 5 ile önceki döneme göre trend.
- Lig ortamı tarihsel gol üretiminden öğrenilen küçük bağlamsal düzeltmedir; elle tier atanmaz.
- Genel hücum/savunma nötr küresel gol ortamına göre normalize edilir; home/away profilleri ayrı normalize edilir.

## Skor ve market matematiği
- Ortak Poisson skor dağılımı.
- Dixon-Coles düşük skor düzeltmesi.
- Dixon-Coles rho tarihsel veriden konservatif şekilde öğrenilir.
- Tüm ana futbol marketleri aynı skor uzayından türetilir.
- MS 1/X/2, Çifte Şans, KG, Alt/Üst, takım golü, toplam gol aralıkları, tek/çift, birleşik marketler ve doğru skor desteklenir.
- İlk yarı sonucu, tam maç lambda'nın zaman ölçekli ayrı dağılımından hesaplanır.
- Doğru skor, doğrudan skor matrisi hücresinden alınır.

## Oyuncu / PPDA
- Oyuncu rating/etki motoru korunur.
- Eksik oyuncunun maç günü hücum/savunma etkisi log-lambda'ya sınırlı düzeltme olarak uygulanabilir.
- Normal XI / beklenen XI farkı replacement-aware olarak hesaplanabilir.
- PPDA gerçek değer + lig ortalaması + standart sapma geldiğinde z-score ile normalize edilip küçük log-lambda etkisi verir.
- Mevcut ESPN tarihsel sonuç akışında xG/PPDA/oyuncu maç istatistikleri merkezi tarihsel tabloya taşınmadığından bu alanlar için sahte veri üretilmez; veri sağlandığında aynı model düzeltme katmanı kullanılır.

## Probability / Confidence / Edge / EV
- Probability: model olay olasılığı.
- Confidence: yalnızca model/veri kalitesi ve örneklem/stabilite.
- Edge/EV, confidence'ı yükseltmez ve model probability'yi değiştirmez.
- Fair odds = 1 / calibrated probability.
- Edge = calibrated probability - no-vig market probability.
- EV = calibrated probability × odds - 1.
- Düşük probability'li yüksek oranlı seçimler yalnızca yüksek Edge/EV nedeniyle Güçlü olamaz.

## Kalibrasyon
- Yerleşmiş futbol tahminlerinden 100+ veri olduğunda temperature scaling parametresi grid search ile öğrenilir.
- Kalibrasyon parametresi merkezi snapshot'a yazılır.
- Kalibrasyon sonucu değiştiğinde model cache'i geçersizleşir ve güçlü liste yeniden değerlendirilir.

## Günün Güçlüleri
- İlk görüldüğü anda kilitleme yoktur.
- Tüm uygun seçimler yeniden taranır.
- Bir maçtan tek güçlü seçim tutulur.
- Top 12 güncel model probability ana ekseninde, confidence kalite filtresi olarak sıralanır; Edge/EV yalnızca küçük tie-break seviyesindedir.
- Yeni daha güçlü seçim mevcut daha düşük seçimlerin yerini alabilir.

## Performans
- Merkezi model snapshot/cache.
- Değişmeyen maç + değişmeyen model için analiz cache'i.
- Aynı maçın bütün marketleri tek skor dağılımı ile hesaplanır.
- ESPN tarihsel veri değişmemişse merkezi havuza tekrar tekrar yazılmaz.
- Güçlüler ekranı önce hazır snapshot'ı kullanır; gerekli olduğunda yeniden tarama yapar.

## Doğrulama
Bu paket içinde saf Kotlin matematik katmanları ve merkezi model için ayrı statik/simülasyon testleri yapıldı.
Android `assembleDebug` bu çalışma ortamında doğrulanamadı; Android SDK ve Gradle 9.5 dağıtımı mevcut değil ve Gradle indirme adresine ağ erişimi bulunmuyor. Bu nedenle paket "Android Studio içinde açıldığında kesin derlenmiştir" diye işaretlenmemelidir.
