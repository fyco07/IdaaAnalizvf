# V22 Log Fix Notları

Kaynak logta görülen sorunlar için düzeltmeler:

- Telefonda çalışan eski FIX34/code34 sürümünden ayrışmak için V22 code37 / `1.0-V22-FINAL-DYNAMIC` kullanılır.
- ESPN sonuç kaynağı tek aktif sonuç kaynağıdır. SofaScore sonuç fallback çağrıları kaldırıldı.
- İddaa market config kalıcı SharedPreferences cache'e alındı; geçici DNS hatasında her maç başına `get_market_config` tekrarları engellendi.
- Market config bültenden önce tek kez hazırlanır.
- Config yoksa güvenli tanınabilen maç sonucu / karşılıklı gol / çifte şans marketleri outcome'lardan tanınarak merkezi olasılık zincirinin tamamen boş kalması engellenir.
- MainActivity'deki ON_CREATE/ON_RESUME otomatik sonuç taraması kaldırıldı; WorkManager tek kanonik zincir oldu. Butondan manuel sonuç kontrolü hâlâ çalışır.
- Günün Güçlüleri tamamlandıktan sonra ikinci otomatik sonuç taraması tetiklenmez.
