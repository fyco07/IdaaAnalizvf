# V17 FIX12

Latest log showed the pipeline is working and candidate predictions are being persisted, but thousands of team lookup calls still produce TAKIM_BULUNAMADI. FIX12 focuses on lookup efficiency and safe caching without changing the model math.

Changes:
- precomputed token index for team ratings
- precomputed 3-character fuzzy candidate index
- query/miss caches
- cache/index reset on repository refresh/clear
- reduced full 4k-rating scans during Günün Güçlüleri

The existing conservative matching rules remain; no aggressive automatic team aliases are introduced.
