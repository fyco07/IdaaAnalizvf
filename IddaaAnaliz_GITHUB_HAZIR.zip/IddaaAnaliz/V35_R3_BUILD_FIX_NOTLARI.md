# V35 R3 - ESPN kadro derleme hatası düzeltmesi

## Hata
ESPNKadroSaglayici.kt içinde `fetchInjuries()` `JsonObject?` döndürmesine rağmen bazı çağrılarda doğrudan `map` ile liste gibi kullanılıyordu.

Hatalar:
- Unresolved reference: map
- Unresolved reference: it
- JsonObject -> List<PlayerBaseStatus] type mismatch

## Düzeltme
Tüm ilgili akışlarda:
`fetchInjuries()` -> `parseInjuries()` -> `List<PlayerBaseStatus>`

üzerinden ilerleniyor. DB snapshot için status rows ayrı oluşturuluyor.

Önceki V35 R2 havuz/stale fallback mantığı korunmuştur.
