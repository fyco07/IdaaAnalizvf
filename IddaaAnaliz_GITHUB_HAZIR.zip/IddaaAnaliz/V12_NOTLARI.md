# V12 - Merkezi Takım Eşleşmesi + Güçlüler Red Nedenleri

## Yapılan düzeltmeler
- Canlı futbol modelinde takım modeli artık `merkezi_team` tablosundan dönen `teamId` ile snapshot arasında çapraz kaynak kimlik çakışmasına bağlanmıyor.
- Takım eşleşmesi yalnızca `FUTBOL:team:<tam normalize takım adı>` anahtarı üzerinden snapshot içinden yapılıyor.
- Fuzzy/token eşleşme kullanılmıyor.
- U19/U21/Kadın gibi kategori farkları takım adının normalize anahtarında korunuyor; belirsiz eşleşme reddediliyor.
- Günün Güçlüleri filtresi artık toplamda yalnızca `0 aday` demek yerine elenme nedenlerini ayrı ayrı logluyor.

## Yeni log
`GUNUN_GUCLULERI_RED_NEDENLERI KARAR_OYNA_DEGIL=... EDGE_EV_EKSİK=... EDGE_EV_ESIK=... MODEL_OLASILIK_ESIK=... GUVEN_ESIK=... ORAN_ARALIGI=... ORNEKLEM_ESIK=... MODEL_PIYASA_FARKI=... GECTI=...`

## Beklenen kontrol
Bir sonraki testte `MODEL_DISARIDA ... ready=true` satırlarının önemli bölümünün yerine `TAKIM_MODEL` gelmesi beklenir. Takım bulunamayan gerçek durumlar artık açıkça `MERKEZI_TAKIM_ESLESME_EKSİK home=... away=... homeKey=... awayKey=...` olarak görünür.

## Derleme notu
Bu ortamda Gradle dağıtımı için internet bağlantısı olmadığı için gerçek Gradle derlemesi tamamlanamadı; dosyalar kaynak seviyesinde kontrol edilip paketlenmiştir.
