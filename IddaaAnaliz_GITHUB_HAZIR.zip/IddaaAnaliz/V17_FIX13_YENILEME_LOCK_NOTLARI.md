# V17 FIX13 – Yenileme / Güçlüler Tarama Kilidi

- Otomatik yenileme sayacı güçlü seçim taraması TAMAMLANDIKTAN sonra başlar.
- `strongestLoading` veya `strongestJob.isActive` varken otomatik `loadData()` çağrılmaz.
- Manuel YENİLEME mevcut güçlü taramayı iptal etmez; tarama bitince tek sefer çalışır.
- Otomatik yenileme `forceStrongest=false` ile çalışır; bülten imzası değişmediyse aynı tarama tekrar başlatılmaz.
- Amaç: Günün Güçlüleri listesi dolmadan 1200+ maçın baştan analiz edilmesini engellemek.
