# FIX6 – ESPN Kadro Index / League Routing

Tespit: 23.09.2026 logunda ESPN tarihsel havuzu 31.704 maç olmasına rağmen kadro takım index'i yalnızca 380 anahtar üretiyor ve Seattle Sounders, Real Salt Lake, Birmingham Legion, Brooklyn FC gibi takımlar `candidates=0` kalıyor. Aynı logda yüzlerce `KADRO_LIG_SLUG_ATLANDI` kaydı var; özellikle `2026-27-german-bundesliga`, `2026-27-keuken-kampioen-divisie`, `2026-nwsl-challenge-cup` gibi season/competition slug biçimleri yanlışlıkla eleniyordu.

Düzeltmeler:
1. Tarihsel takım index'i önce takım ID bazında bilinen gerçek ESPN league slug kanıtını topluyor.
2. Aynı teamId'nin `regular-season`/playoff gibi geçersiz lig alanına sahip eski kayıtları, aynı teamId'nin başka geçerli kaydındaki league slug ile indexlenebiliyor.
3. Kalıcı ESPN roster havuzu metaları (`espn_takim_kadro_cache`) doğrudan takım index'ine dahil ediliyor.
4. `espnLeagueSlug` artık normalize edilen sezon öneklerini doğru temizliyor; ör. `2026-27-german-bundesliga` -> `ger.1`.
5. Yaygın ikinci seviye ligler ve kadınlar/NWSL için kontrollü teknik slug eşlemeleri genişletildi.
6. Tarihsel çift eşleşmesinde farklı liglerden takım birleştiren fallback kaldırıldı. Aynı gerçek ESPN ligi bulunamazsa güvenli scoreboard fallback kullanılır.
7. Takım adaylarında tam normalize ad eşleşmesi alias eşleşmesinden önce gelir.
8. Başarılı tarihsel takım eşleşmesi loglanır: `KADRO_TARIHSEL_ESLESME_OK`.

Web doğrulaması: ESPN Site API takım roster endpointleri `/apis/site/v2/sports/soccer/{league}/teams/{id}/roster` biçiminde league slug gerektirir; bu nedenle league routing'in doğru olması kadro zincirinin ön koşuludur.
