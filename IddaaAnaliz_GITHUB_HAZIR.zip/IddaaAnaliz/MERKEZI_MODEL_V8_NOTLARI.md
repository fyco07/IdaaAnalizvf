# V8 – Merkezi Veri Havuzu -> Takım Ratingi -> Form -> Rakip Gücü -> Model

Yeni akış: İDDAA/ESPN verisi önce merkezi havuza yazılır. Futbol modelinin canlı girdisi yalnızca `merkezi_match` + `merkezi_result` tarihçesidir.

Takım ratingi Elo tabanlı, hücum/savunma gücü geçmiş gol verilerinden; form son 5/10 maçtan; rakip gücü maç sırasındaki rakip Elo ortalamasından çıkarılır. Gelecek maç olasılıkları bu katmanlardan lambda ve ortak Poisson skor dağılımı ile üretilir. Oran, Edge, EV veya favori durumu model olasılığının girdisi değildir.

Takım eşleşmesinde fuzzy/token eşleştirme kullanılmaz; normalleştirilmiş tam takım kimliği eşleşir. U19/U21/Kadın/MG gibi farklı adlandırmalar eşleşmiyorsa maç model dışı kalır.

Normal veri yenileme hiçbir tarihsel kaydı silmez.
