# V40 Match Analysis Fix

## Fixed
- Central football analysis no longer hard-stops only because one/both teams are missing from the historical snapshot.
- Missing teams use a neutral prior tied to their exact live name; no fuzzy/nearest-team substitution is used.
- Safe team aliases keep controlled prefix/suffix variants (including SM) but never single-token aliases.
- Central predictor uses the same market title classifier as the main analysis and canonicalizes known `st/sov` market types when config cache is absent.
- French Ligue 2 ESPN season slugs are recognized by the roster provider.
- Repeated unknown-league roster logs are throttled to one entry per league key.
- Neutral/zero-history model confidence is 0 instead of a misleading nonzero value; low-sample football selections cannot become strong picks.
- The analysis screen has a bounded roster wait and treats roster data as optional; main model analysis is not blocked by missing roster data.
- Cross-market normalized comparisons for `Üst` were corrected to `ust` after normalization.
- Unused private predictor helpers/parameters were removed where safe.

## Verification performed
- Core model regression: `4 de Mayo` does not resolve to `2 de Mayo`.
- Alias regression: `Caen` can resolve to historical `SM Caen` through the controlled prefix alias.
- Neutral prediction regression: an unknown team gets its own neutral team ID and remains tied to its own name.
- Central predictor regression: match result, total over/under, and handicap markets produce probabilities even when market config is not available and the model teams are neutral/low-history.
- ZIP integrity checked with `unzip -t`.

## Build note
A full Gradle Android build was not executed in the offline container because Gradle 9.5.0 is not installed locally and `services.gradle.org` is unreachable from the container. Run `Clean Project` and `Rebuild Project` in Android Studio on the development machine.
