# V13 - Immutable Ready Snapshot + Canonical Team Key

- Hazır bir merkezi model snapshot’ı, eşzamanlı/eksik rebuild tarafından artık ezilmez.
- Model analizi sırasında `ready=true` ile farklı snapshot state yarışının önüne geçildi.
- Tarihsel maçların mevcut homeTeamId/awayTeamId değerleri modele doğrudan kimlik olarak alınmıyor; takım adı normalize edilerek tek canonical key kullanılıyor: `FUTBOL:team:<normalize>`.
- Böylece İDDAA/ESPN çapraz kaynak numeric ID farkları `MERKEZI_RATING_ESLESMEDI` üretmemeli.
- Fuzzy/token eşleştirme eklenmedi. U19/U21/Kadın ayrımları normalize isimde korunuyor.
- Hazır olmayan yeni snapshot varsa önceki hazır snapshot korunuyor.
- `MacAnalizServisi` tek ready snapshot bilgisiyle kontrol edip tekrar kontrol yarışını azaltıyor; log sürümü V13 olarak ayrıştırıldı.

## Beklenen log
`MERKEZI_MODEL_SNAPSHOT_KORUNDU` yalnızca eksik rebuild hazır snapshot'ı ezmeye çalıştığında görülür.
`V13_MERKEZI_KULLANILIYOR` her merkezi futbol analizinde görünmelidir.
`MERKEZI_RATING_ESLESMEDI` gerçek takım veri eksikliğine düştüğünde görülmelidir; özellikle çapraz kaynak ID farklarından kaynaklanan kayıplar azalmalıdır.
