# V35-R1 — Oyuncu Havuzu Derleme Düzeltmesi

## Derleme hatasının nedeni
`fetchInjuries()` `JsonObject?` döndürüyor. V35 içinde bu nesne doğrudan `.map {}` ile kullanılıyordu. Bu nedenle Kotlin derleyicisi:
- `Unresolved reference: map`
- `Unresolved reference: it`
- `JsonObject` -> `List<PlayerBaseStatus>` tip uyuşmazlığı
hatalarını veriyordu.

## Düzeltme
İki cached injury-refresh yolunda `parseInjuries(injuries)` ile `List<PlayerBaseStatus>` üretiliyor. DAO'ya bu liste yazılıyor ve `applyStatuses()` / `teamKadroFromPool()` aynı parse edilmiş listeyi kullanıyor.

## Veri havuzu davranışı
- Roster: Room kalıcı havuz + 8 saat TTL (`ROSTER_TTL_MS`)
- Injury/status: 20 dakika TTL (`INJURY_TTL_MS`)
- Roster taze ise her maç için roster tekrar indirilmez; yalnızca taze olmayan durum verisi sorgulanır.
- Roster süresi dolunca roster + injury + leaders yenilenir ve havuz güncellenir.

## Sürüm
- versionCode: 52
- versionName: `1.0-V35-R1-OYUNCU-POOL-QUALITY`
