# V40 POOL FIX13

## Kök neden
ESPNHistoryWorker tarihsel maçları önce ayrı `espn_tarihsel` Room tablosuna yazıyordu. MerkeziVeriHavuzu.espnTarihselYaz() ise esas olarak uygulama başlangıcında bir kez çağrıldığı için worker sonradan yeni tarihsel kayıtlar eklese bile merkezi havuzun `merkezi_match/merkezi_result/merkezi_team` tabloları güncellenmiyordu. Logda bu durum `macDB=658`, `sonucDB=0`, `FUTBOL_MODEL_HAZIR history=0 takim=0 ready=false` ile doğrulandı.

## Düzeltme
- `MerkeziVeriHavuzu.espnTarihselParcaYaz(rows)` eklendi.
- Her başarılı tarihsel ESPN chunk'ı kaynak DB'ye yazıldıktan hemen sonra merkezi havuza incremental upsert ediliyor.
- Merkezi sonuç sayısı minimum eğitim eşiğine ulaştığında model ilk kez otomatik hazırlanıyor.
- 365 günlük tarama sonunda tam merkezi senkron + zorunlu final model rebuild yapılıyor.
- Tarihsel scoreboard çağrısı `skorTahtasiGenelGuvenli()` üzerinden aynı ESPN sağlayıcısının üçüncü host fallback'ini de kullanıyor (`www.espn.com`).
- `skorTahtasiGuvenli()` artık aynı güvenli generic yolu kullanıyor; tarihsel worker da üç hostlu fallback'ten faydalanıyor.

## Korunanlar
- Merkezi model matematiği korunur.
- İddaa oranında `odd` birincil oynanabilir oran olarak korunur; `wodd` yalnızca fallback'tir.
- Güçlü seçim sample gate korunur.
- Market üretim ve UI düzeltmeleri korunur.
