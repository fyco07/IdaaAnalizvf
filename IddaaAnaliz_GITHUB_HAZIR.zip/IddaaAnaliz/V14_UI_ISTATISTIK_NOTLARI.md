# V14 UI İstatistik Düzeltmesi

- Ana ekrandaki "Öğrenilen takım" değeri artık merkezi futbol model snapshot'ındaki ratingli takım sayısından alınır.
- Ana ekrandaki "Model eğitimi" değeri artık merkezi model snapshot'ındaki tarihsel maç sayısını da kullanır.
- Böylece ESPN meta/cache alanları 0 veya eski olsa bile, merkezi model hazırsa kartta 0/0 gösterilmez.
- Sonuç kalibrasyonu ayrı kavramdır: çözülmüş tahmin yoksa sonuçtan öğrenme 0 kalabilir; bu değer modelin tarihsel eğitiminden ayrı tutulur.
- Analiz mantığı ve veri kaynakları değiştirilmedi.
