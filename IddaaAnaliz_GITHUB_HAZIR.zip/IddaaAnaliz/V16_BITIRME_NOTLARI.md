# V16 Bitirme

- Güçlüler genel Karar.OYNAMA/SINIRDA sonucuna bağlı değildir; yalnızca VERI_YETERSIZ gerçek veri yetersizliği olarak elenir.
- Güçlüler eşikleri: model olasılığı >= 0.65, güven >= 65, örneklem >= 20, Edge >= %1, EV >= %2.
- Model olasılığı, Edge/EV veya oran tarafından üretilmez; Edge/EV yalnızca piyasa değer kapısı ve sıralamada kullanılır.
- Her kabul edilen Güçlüler adayı için ayrıntılı GUNUN_GUCLULERI_ADAY logu eklendi.
- Sürüm 1.0-FIX33 / versionCode 33.
- Merkezi veri havuzu ve mevcut geçmiş veri silme davranışına dokunulmadı.
