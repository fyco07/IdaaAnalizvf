# V40 Stability / Data Integrity Fixes

This build hardens the active production chain around team identity, analysis completion, and result settlement.

## Fixed
- Prevented generic single-word team aliases from resolving `4 de Mayo` to `2 de Mayo`.
- Added numeric-token guards so teams with different numeric/category markers cannot be treated as the same team.
- Added league-aware team resolution when name variants are ambiguous.
- Kept match identity keyed by sport + event id in caches and strong-selection grouping.
- Separated optional ESPN roster enrichment from the base match analysis so a roster/API stall cannot leave the detail screen spinning forever.
- Added bounded timeouts to match-detail roster enrichment, strong-selection roster enrichment, main bulletin loads, and manual result scans.
- Added short ESPN result HTTP timeouts and host fallback.
- Fixed cancellation propagation through result/cache/worker layers so cancellation cannot be swallowed and leave UI/worker state stuck.
- Result checks now remain available while the strong-selection scan is running.
- Hardened result matching against numeric team-name mismatches and epoch seconds/milliseconds differences.
- Added fast learning-record lookup to avoid sorting the entire learning store during every UI card recomposition.

## Important behavior
When a historical/team mapping is ambiguous or unavailable, the model now returns no central football probability instead of silently substituting another team. This is intentional: wrong data is more damaging than missing data.

## Verification
- Kotlin compile check: `MarketSonucCozucu.kt` + `EpochZamani.kt` passed with targeted stubs.
- Kotlin compile check: `MerkeziFutbolModelHavuzu.kt` passed with targeted DAO/Android stubs.
- Regression test: `4 de Mayo` does not resolve to `2 de Mayo`; `2 de Mayo` resolves to itself.
- The full Android Gradle build could not be executed in this environment because the Gradle wrapper attempted to download Gradle 9.5.0 and outbound DNS/network access is unavailable here.
