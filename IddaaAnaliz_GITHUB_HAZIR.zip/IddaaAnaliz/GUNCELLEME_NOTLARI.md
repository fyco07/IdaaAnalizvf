# V6 Olasılık Modeli Güncellemesi

## Eklenenler
- Ortak futbol skor uzayı ve Poisson tabanlı skor dağılımı eklendi.
- MS 1/X/2, KG Var/Yok, Üst/Alt ve desteklenen handikap marketleri aynı skor dağılımından türetiliyor.
- Ayrık sonuçlar normalize edilerek toplamları 1.0 tutuluyor (Kolmogorov olasılık çerçevesi).
- Edge tek başına güven puanını belirlemiyor. Düşük olasılıklı uzun oranlara ayrıca güven cezası uygulanıyor.
- En iyi seçim sıralamasında güven önceliklendirildi; yalnızca yüksek EV/Edge nedeniyle uzun oranların otomatik öne çıkması engellendi.
- Mevcut öğrenme motoru korunarak yeni model çıktısı onun kalibrasyonuna girdi olarak bırakıldı.

## Önemli
Bu paket kaynak kodudur. Android Studio ile açılıp Gradle Sync/Build yapılmalıdır. Bu ortamda internet erişimi olmadığı için Gradle 9.5 dağıtımı indirilemedi ve yerel derleme doğrulanamadı.
