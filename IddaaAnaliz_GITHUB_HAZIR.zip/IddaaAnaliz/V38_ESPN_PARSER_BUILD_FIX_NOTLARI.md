# V38 – ESPN parser build fix

## Build hatası
ESPNKadroSaglayici.kt satır 1135 civarında `labels`/`values` değişkenleri JsonElement olarak kaldığı için `size`, indeksleme, `isJsonPrimitive` ve `asString` derleme hataları oluşuyordu.

## Düzeltme
`readParallelArrays()` içinde aday JSON alanları açıkça `JsonArray` olarak dönüştürülüyor. Böylece `size()` ve `get(index)` kullanımları tip güvenli hale getirildi.

## Ek küçük temizlik
- Önceden iki null kontrolünden sonra ulaşılabilen `ok = ...` ifadesi `ok = true` yapıldı.
- Kullanılmayan `asJsonObjectOrNull` extension kaldırıldı.

## Sürüm
versionCode=56
versionName=1.0-V38-ESPN-PARSER-BUILD-FIX

IDE uyarıları (deprecated Locale, paket isimlendirmesi vb.) build'i engellemez; bu pakette derlemeyi doğrudan kıran parser tipi hatası hedeflendi.
