# V11 Merkezi Hazırlık Senkronizasyonu

- V10 kaynak tabanı korunmuştur.
- Merkezi futbol model hazırlığı Mutex ile serileştirildi.
- 80 tamamlanmış futbol maçı olmadan hazır olmayan snapshot yayınlanmaz.
- Günün Güçlüleri futbol taraması model hazır olana kadar en fazla 60 sn bekler.
- Tek maç analiz servisi de aynı hazır olma kontrolünü kullanır.
- Model hazır değilse tahmin üretilmez; dış/ESPN eski model fallback'i yoktur.
- Geçmiş merkezi veri silinmez.
- Güçlü seçim filtresindeki kullanılmayan değişken temizlendi.
