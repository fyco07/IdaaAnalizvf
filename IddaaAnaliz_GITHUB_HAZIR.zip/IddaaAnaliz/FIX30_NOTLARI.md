# FIX30 – SofaScore Sonuç API düzeltmesi

Temel hata: Sonuç sağlayıcı `www.sofascore.com/api/v1/` adresini kullanıyordu.
SofaScore API çağrıları `api.sofascore.com/api/v1/` taban adresine çevrildi.

Ek olarak her sonuç isteği URL ile loglanır:
SONUC_HTTP_ISTEK sport=... gun=... url=...

404 durumunda URL de loglanır:
SONUC_HTTP_HATASI kod=404 event=... url=...

Sonuç çözümleme zinciri korunmuştur:
TahminSonucWorker -> TahminSonucCozumleyici -> SofascoreSonucSaglayici -> MarketSonucCozucu -> TahminOgrenmeRepository.

Manuel YENİLE korunur; bülten için otomatik yenileme eklenmez.
