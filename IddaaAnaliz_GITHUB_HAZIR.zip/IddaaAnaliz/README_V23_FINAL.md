# İddaaAnaliz V23 FINAL

Bu proje Android Studio'da doğrudan açılacak gerçek proje köküdür.

Kaynak akışı: İDDAA + ESPN.

Canlı futbol modeli: Merkezi Veri Havuzu → takım rating/form → Poisson/Dixon-Coles → market olasılıkları → Probability / Confidence / Edge / EV → dinamik Günün Güçlüleri.
