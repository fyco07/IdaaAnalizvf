# V40 FIX5 – Gerçek Örneklem Kapısı

Log auditinde Güçlü Seçimler filtresinin `modelSampleCount == 0` olduğunda güven puanından sahte örneklem (20/30) türettiği tespit edildi. Bu nedenle nötr prior kullanan maçlar güçlü aday filtresini geçebiliyordu.

Düzeltme: `GunlukGucluSecimAnalizcisi.valueFiltresiRedNedeni()` artık yalnızca `AnalizSonucu.modelSampleCount` değerini kullanır. `0` örneklem doğrudan `ORNEKLEM_ESIK` ile elenir. `currentModelSampleCount()` kaldırıldı.

Ana model, market üretimi ve kadro zinciri değiştirilmedi.
