# Kendi Modeli 2.2 – Güncel Form Katmanı

- 365 günlük geçmiş maçlar eğitimde kullanılmaya devam eder.
- Ana hücum/savunma ratingine kontrollü güncel form düzeltmesi eklenmiştir.
- Son 20 maç incelenir; son 5 maç en yüksek, 6-10 orta, 11-20 daha düşük ağırlıktadır.
- Form sinyali puan performansı (%55), gol farkı (%25) ve rakip gücü (%20) ile hesaplanır.
- İç saha ve deplasman maçları ayrı form sinyali olarak izlenir.
- Form ana ratingi ezmez; sınırlı katsayılarla hücum/savunmaya eklenir.
- Tahmin katmanı mevcut attack/defense ratinglerini kullanmaya devam eder; yeni ayrı DB migrasyonu gerektirmez.
- Model versiyonu KENDI_MODEL_2.2_FORM olarak yükseltilmiştir.
