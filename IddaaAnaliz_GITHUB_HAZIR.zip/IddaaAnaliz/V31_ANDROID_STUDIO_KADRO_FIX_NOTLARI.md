# V31 Android Studio / Kadro Index Fix

- versionCode: 46
- versionName: 1.0-V31-KADRO-INDEX
- Açılış log etiketleri V31 olarak güncellendi; böylece eski V29/V30 APK ile karışması engellenir.
- V30'daki kadro düzeltmesi korunmuştur: gelecek maçlarda önce yerel ESPN tarihsel DB takım+lig+ESPN takım ID indeksi kullanılır; günlük scoreboard yalnızca fallbacktir.
- Gerçek ESPN eksik oyuncu verisi varsa ikinci tur model yeniden çalışır ve `kadroUygulanan` artırılır. Veri uydurulmaz.

## Android Studio doğrulaması
1. Bu ZIP'i yeni bir klasöre çıkar ve Android Studio'da bu klasörü aç.
2. `Build > Clean Project`, ardından `Build > Rebuild Project` yap.
3. Telefonda eski uygulamayı kaldırıp V31'i yeniden kur.
4. Logcat'te `V31_BOOT` ve `V31_ACTIVITY_ONCREATE` ara.
5. Kadro taramasında `KADRO_TAKIM_INDEX_HAZIR` ve uygun maçlarda `KADRO_ETKI_UYGULANIYOR` görülmeli.
6. Son satır `KADRO_2_TUR_TAMAMLANDI ... kadroUygulanan=N` biçiminde gelir.

Not: Bu çalışma ortamında Gradle dağıtımı `services.gradle.org` DNS nedeniyle indirilemediği için tam APK derlemesi burada doğrulanamadı. Kaynak sürüm ve sürüm numarası doğrulanmıştır.
