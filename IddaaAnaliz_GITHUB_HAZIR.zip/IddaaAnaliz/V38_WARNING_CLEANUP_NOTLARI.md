# V38 Warning Cleanup

- Removed unused MAX_CACHE from ESPNKadroSaglayici.
- Removed unused JsonElement.asJsonObjectOrNull extension from ESPNKadroSaglayici.
- Replaced deprecated Locale("tr", "TR") with Locale.forLanguageTag("tr-TR") in main source.
- Simplified data-flow branches where injury freshness / ok-state conditions were redundant.
- Preserved persistent player-pool fallback and player-to-lambda integration from V37.
- Package names are intentionally unchanged to avoid invasive refactoring of the existing project namespace.
- This environment cannot perform a full Gradle build because services.gradle.org is unreachable.
