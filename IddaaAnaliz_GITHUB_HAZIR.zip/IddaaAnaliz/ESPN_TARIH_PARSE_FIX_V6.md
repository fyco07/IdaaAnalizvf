# ESPN Tarih Parse Fix V6

Loglarda bütün ESPN kayıtlarının `date_gecersiz` nedeniyle elendiği görüldü. Kayıtlar `2026-08-08T16:30Z` gibi saniyesiz ISO-8601 tarih biçiminde geliyor. `Instant.parse()` bu biçimi kabul etmediği için parser 0 kayıt üretiyordu.

Düzeltme: `Instant.parse()` başarısız olursa `OffsetDateTime.parse(..., DateTimeFormatter.ISO_OFFSET_DATE_TIME)` fallback'i kullanılıyor.

Beklenen sonuç: `PARSE_DETAY ... ok=0 skip=...` yerine gerçek `ok` sayısı oluşmalı ve `TARİHSEL_GUN ... futbol>0` görülmeli.
