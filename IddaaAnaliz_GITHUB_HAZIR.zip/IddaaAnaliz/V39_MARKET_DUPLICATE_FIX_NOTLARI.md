# V39 Market tekrar ve olasılık eşleme düzeltmesi

- Handicap branch, match-result branch'ten önce çalışır.
- `st=62` handicap olarak tanınır.
- Handicap çizgisi signed olarak okunur ve Poisson skor dağılımı üzerinde düzeltilmiş farkla hesaplanır.
- UI market başlığı `AnalizMotoru.marketBasligi` üzerinden çözülür.
- `st=61/70/79` ve 1/X/2 outcome kombinasyonları için başlık fallback'i `MAÇ SONUCU` olur.
- Güçlü seçimler market ID yerine semantik market başlığı + seçim ile tekilleştirilir.
