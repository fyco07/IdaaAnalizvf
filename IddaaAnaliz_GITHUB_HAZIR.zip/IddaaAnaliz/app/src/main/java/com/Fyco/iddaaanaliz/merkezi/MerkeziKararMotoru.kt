@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import com.Fyco.iddaaanaliz.FutbolMarketTutarlilikKatmani
import com.Fyco.iddaaanaliz.Karar
import com.Fyco.iddaaanaliz.MarketAnalizSonucu
import com.Fyco.iddaaanaliz.KaynakHarmani
import kotlin.math.max

/**
 * Futbol için TEK karar zincirinin son katmanı.
 *
 * ESPN/Kendi Modeli -> skor dağılımı -> market olasılığı -> no-vig ->
 * Edge/EV -> kontrollü kalibrasyon -> güven -> Günün Güçlüleri kararı.
 *
 * Bu sınıf yeni veri kaynağı eklemez ve skor dağılımını yeniden üretmez.
 * Girdi olarak zaten aynı ESPN skor dağılımından türetilmiş market olasılığını
 * alır; yalnızca ekonomik ve kalibrasyon kararını tek yerde standartlaştırır.
 */
object MerkeziKararMotoru {

    data class MarketKalibrasyon(
        val meanBrier: Double?,
        val settledCount: Int
    )

    data class KalibrasyonDurumu(
        val global: MarketKalibrasyon,
        val byMarket: Map<String, MarketKalibrasyon> = emptyMap()
    )

    fun uygula(
        marketler: List<MarketAnalizSonucu>,
        kalibrasyon: KalibrasyonDurumu
    ): List<MarketAnalizSonucu> {
        if (marketler.isEmpty()) return marketler

        return marketler.map marketMap@ { marketSonucu ->
            val market = marketSonucu.market
            val validOutcomes = market.o.filter { it.oynanabilirOran.isFinite() && it.oynanabilirOran > 1.0 }
            if (validOutcomes.size < 2) return@marketMap marketSonucu

            val noVig = BahisMatematigi.noVig(validOutcomes.map { it.oynanabilirOran })
            val noVigByNo = validOutcomes.indices.associate { idx ->
                validOutcomes[idx].no to noVig.getOrElse(idx) { 0.0 }
            }

            val marketCalibration = kalibrasyon.byMarket[market.i.toString()] ?: kalibrasyon.global
            val updated = marketSonucu.secimler.map secimMap@ { secim ->
                val model = secim.kaynakHarmani?.kendiModelOlasiligi
                    ?: secim.gelmeOlasiligi.takeIf { it > 0.0 }
                if (model == null || !model.isFinite() || model !in 0.0..1.0) {
                    return@secimMap secim.copy(
                        karar = Karar.VERI_YETERSIZ,
                        guvenPuani = 0,
                        edge = null,
                        ev = null
                    )
                }

                val outcome = validOutcomes.firstOrNull { it.no == secim.secimNo }
                    ?: validOutcomes.firstOrNull { it.n.equals(secim.secim, ignoreCase = true) }
                    ?: return@secimMap secim.copy(
                        karar = Karar.VERI_YETERSIZ,
                        guvenPuani = 0,
                        edge = null,
                        ev = null
                    )

                val marketProbability = noVigByNo[outcome.no] ?: return@secimMap secim.copy(
                    karar = Karar.VERI_YETERSIZ,
                    guvenPuani = 0,
                    edge = null,
                    ev = null
                )

                val calibrated = calibrate(model, marketCalibration)
                val edge = calibrated - marketProbability
                val ev = calibrated * outcome.oynanabilirOran - 1.0
                val fair = if (calibrated > 0.0001) 1.0 / calibrated else 0.0
                val confidence = confidence(
                    probability = calibrated,
                    settledCount = marketCalibration.settledCount,
                    meanBrier = marketCalibration.meanBrier,
                    source = secim.kaynakHarmani
                )

                val decision = decision(
                    confidence = confidence,
                    edge = edge,
                    ev = ev,
                    odds = outcome.oynanabilirOran
                )

                secim.copy(
                    gelmeOlasiligi = calibrated,
                    fairOran = fair,
                    edge = edge,
                    ev = ev,
                    guvenPuani = confidence,
                    karar = decision,
                    aciklama = explanation(decision, edge, ev, confidence, marketCalibration.settledCount),
                    kaynakHarmani = (secim.kaynakHarmani ?: KaynakHarmani(nihaiOlasilik = calibrated)).copy(
                        ogrenilmisModelOlasiligi = null,
                        nihaiOlasilik = calibrated
                    )
                )
            }

            val coherent = FutbolMarketTutarlilikKatmani.uygula(
                listOf(marketSonucu.copy(secimler = updated))
            ).firstOrNull()

            coherent ?: marketSonucu.copy(secimler = updated)
        }
    }

    private fun calibrate(raw: Double, state: MarketKalibrasyon): Double {
        val p = raw.coerceIn(0.01, 0.99)
        val brier = state.meanBrier?.takeIf { it.isFinite() }?.coerceIn(0.0, 1.0)
            ?: return p
        if (state.settledCount < 30) return p

        // Brier iyiyse daha az, kötüyse daha fazla merkeze çek;
        // yeni kalibrasyon ESPN'nin kendi validation kalibrasyonunu ezmesin.
        val quality = (1.0 - brier / 0.25).coerceIn(-1.0, 1.0)
        val shrink = (0.08 + quality.coerceAtLeast(0.0) * 0.10).coerceIn(0.08, 0.18)
        return (p * (1.0 - shrink) + 0.5 * shrink).coerceIn(0.01, 0.99)
    }

    private fun confidence(
        probability: Double,
        settledCount: Int,
        meanBrier: Double?,
        source: KaynakHarmani?
    ): Int {
        var score = 0
        if (source?.kendiModelOlasiligi != null) score += 42

        score += when {
            probability >= 0.80 || probability <= 0.20 -> 24
            probability >= 0.70 || probability <= 0.30 -> 20
            probability >= 0.60 || probability <= 0.40 -> 14
            probability >= 0.55 || probability <= 0.45 -> 8
            else -> 3
        }

        val sampleScore = when {
            settledCount >= 500 -> 18
            settledCount >= 250 -> 14
            settledCount >= 100 -> 10
            settledCount >= 30 -> 6
            else -> 2
        }
        score += sampleScore

        if (meanBrier != null && meanBrier.isFinite()) {
            score += when {
                meanBrier <= 0.12 -> 10
                meanBrier <= 0.18 -> 7
                meanBrier <= 0.22 -> 4
                else -> 0
            }
        }

        // Kesinlikle olasılıktan %100 güven türetme.
        return score.coerceIn(0, 90)
    }

    private fun decision(
        confidence: Int,
        edge: Double,
        ev: Double,
        odds: Double
    ): Karar {
        if (!edge.isFinite() || !ev.isFinite()) return Karar.OYNAMA
        if (edge <= 0.0 || ev <= 0.0) return Karar.OYNAMA

        // Çok yüksek oranlar daha güçlü kanıt ister.
        val extra = when {
            odds >= 10.0 -> 10
            odds >= 6.0 -> 7
            odds >= 4.0 -> 4
            else -> 0
        }

        val threshold = 70 + extra
        return when {
            confidence >= threshold && edge >= 0.03 && ev >= 0.03 -> Karar.OYNA
            confidence >= max(55, threshold - 12) && edge >= 0.01 && ev >= 0.0 -> Karar.SINIRDA
            else -> Karar.OYNAMA
        }
    }

    private fun explanation(
        decision: Karar,
        edge: Double,
        ev: Double,
        confidence: Int,
        calibrationCount: Int
    ): String = when (decision) {
        Karar.OYNA -> "ESPN skor modeli + no-vig piyasa benchmarkı pozitif değer üretiyor. Edge ${format(edge)}, EV ${format(ev)}, güven $confidence/100. Kalibrasyon örneği: $calibrationCount."
        Karar.SINIRDA -> "Pozitif değer var ancak karar için kanıt seviyesi sınırlı. Edge ${format(edge)}, EV ${format(ev)}, güven $confidence/100."
        Karar.OYNAMA -> "Model ile piyasa arasındaki fark güçlü karar eşiğini karşılamıyor."
        Karar.VERI_YETERSIZ -> "Karar için gerekli model veya market verisi yeterli değil."
    }

    private fun format(v: Double): String = String.format(java.util.Locale.US, "%.1f%%", v * 100.0)
}
