@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.util.Log
import com.Fyco.iddaaanaliz.espn.ESPNClient
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap

/**
 * Canli ve tarihsel sonuc kaynagi: YALNIZCA ESPN.
 *
 * Ayni sport/league/date icin uygulama icinde ortak cache kullanilir.
 * Basarisiz (403/DNS/timeout) istekler de kisa bir backoff ile cache'lenir;
 * boylece ayni acilista onlarca coroutine ESPN'e tekrar tekrar vurmaz.
 */
object ESPNVeriSaglayici {
    private const val TAG = "ESPN_HISTORY"
    private const val SUCCESS_TTL_MS = 10 * 60 * 1000L
    private const val FAILURE_TTL_MS = 15 * 60 * 1000L
    private const val MAX_CACHE = 256


    private data class CacheEntry(
        val savedAt: Long,
        val data: List<Kayit>,
        val failed: Boolean
    )

    private val cache = object : LinkedHashMap<String, CacheEntry>(MAX_CACHE, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CacheEntry>?): Boolean =
            size > MAX_CACHE
    }
    private val cacheLock = Any()
    private val keyLocks = ConcurrentHashMap<String, Mutex>()

    data class Kayit(
        val eventId: Long,
        val spor: SporTuru,
        val lig: String?,
        val homeId: String?,
        val awayId: String?,
        val homeName: String,
        val awayName: String,
        val baslangic: Long,
        val homeScore: Double?,
        val awayScore: Double?,
        val tamamlandi: Boolean
    )

    suspend fun futbolGununuGetir(tarih: String): List<Kayit> =
        gununuGetir("soccer", "all", tarih, SporTuru.FUTBOL)

    suspend fun basketbolGununuGetir(tarih: String): List<Kayit> {
        val leagues = listOf(
            "nba",
            "wnba",
            "euroleague",
            "mens-college-basketball"
        )
        return leagues.flatMap { league ->
            gununuGetir("basketball", league, tarih, SporTuru.BASKETBOL)
        }.distinctBy { it.eventId }
    }

    suspend fun gununuGetir(
        sport: String,
        league: String,
        tarih: String,
        spor: SporTuru
    ): List<Kayit> = withContext(Dispatchers.IO) {
        val key = "$sport|$league|$tarih"
        val now = System.currentTimeMillis()

        synchronized(cacheLock) {
            val cached = cache[key]
            if (cached != null) {
                val ttl = if (cached.failed) FAILURE_TTL_MS else SUCCESS_TTL_MS
                if (now - cached.savedAt <= ttl) {
                    if (cached.failed) {
                        Log.d(TAG, "CACHE_FAILURE_HIT sport=$sport league=$league tarih=$tarih")
                    }
                    return@withContext cached.data
                }
                cache.remove(key)
            }
        }

        val mutex = keyLocks.getOrPut(key) { Mutex() }
        try {
            mutex.withLock {
                val secondCheck = synchronized(cacheLock) {
                    val cached = cache[key]
                    if (cached != null) {
                        val ttl = if (cached.failed) FAILURE_TTL_MS else SUCCESS_TTL_MS
                        if (now - cached.savedAt <= ttl) cached.data else null
                    } else null
                }
                if (secondCheck != null) return@withLock secondCheck

                val parsed = try {
                    val body = ESPNClient.skorTahtasiGenelGuvenli(sport, league, tarih).toString()
                    if (body.isBlank()) {
                        Log.w(TAG, "ESPN_EMPTY_CACHE_FAILURE sport=$sport league=$league tarih=$tarih")
                        null
                    } else {
                        parse(body, spor, league)
                    }
                } catch (e: Exception) {
                    Log.w(
                        TAG,
                        "ESPN_NETWORK_CACHE_FAILURE sport=$sport league=$league tarih=$tarih " +
                                "type=${e.javaClass.simpleName} backoffMin=15"
                    )
                    null
                }

                val result = parsed ?: emptyList()
                synchronized(cacheLock) {
                    cache[key] = CacheEntry(
                        savedAt = System.currentTimeMillis(),
                        data = result,
                        failed = parsed == null
                    )
                }
                result
            }
        } finally {
            if (!mutex.isLocked) keyLocks.remove(key, mutex)
        }
    }

    fun cacheTemizle() {
        synchronized(cacheLock) { cache.clear() }
        keyLocks.clear()
    }

    private fun parse(body: String, spor: SporTuru, league: String): List<Kayit> {
        val root = JsonParser.parseString(body).asJsonObject
        val events = root.get("events")?.asJsonArray ?: return emptyList()
        val result = ArrayList<Kayit>(events.size())

        for (element in events) {
            val event = element.asJsonObjectOrNull() ?: continue
            val id = event.get("id")?.asString?.toLongOrNull() ?: continue
            val competitions = event.getAsJsonArray("competitions") ?: continue
            val competition = competitions.firstOrNull()?.asJsonObjectOrNull() ?: continue
            val competitors = competition.getAsJsonArray("competitors") ?: continue
            val competitionLeague = competition.getAsJsonObject("league")
                ?.get("slug")?.asString
                ?: competition.getAsJsonObject("league")
                    ?.get("abbreviation")?.asString
                ?: event.getAsJsonObject("league")
                    ?.get("slug")?.asString
                ?: league

            var home: JsonObject? = null
            var away: JsonObject? = null
            for (c in competitors) {
                val competitor = c.asJsonObjectOrNull() ?: continue
                when (competitor.get("homeAway")?.asString) {
                    "home" -> home = competitor
                    "away" -> away = competitor
                }
            }
            if (home == null || away == null) continue

            val homeTeam = home!!.getAsJsonObject("team") ?: continue
            val awayTeam = away!!.getAsJsonObject("team") ?: continue
            val start = parseTimestamp(
                competition.get("date")?.asString
                    ?: event.get("date")?.asString
            ) ?: continue

            result += Kayit(
                eventId = id,
                spor = spor,
                lig = competitionLeague,
                homeId = homeTeam.get("id")?.asString,
                awayId = awayTeam.get("id")?.asString,
                homeName = homeTeam.get("displayName")?.asString
                    ?: homeTeam.get("name")?.asString
                    ?: continue,
                awayName = awayTeam.get("displayName")?.asString
                    ?: awayTeam.get("name")?.asString
                    ?: continue,
                baslangic = start,
                homeScore = home!!.get("score")?.asString?.toDoubleOrNull(),
                awayScore = away!!.get("score")?.asString?.toDoubleOrNull(),
                tamamlandi = event.getAsJsonObject("status")
                    ?.getAsJsonObject("type")
                    ?.get("completed")?.asBoolean
                    ?: false
            )
        }
        return result
    }

    private fun parseTimestamp(value: String?): Long? {
        if (value.isNullOrBlank()) return null
        val patterns = arrayOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd'T'HH:mmXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXX"
        )
        for (pattern in patterns) {
            runCatching {
                return SimpleDateFormat(pattern, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }.parse(value)?.time?.div(1000L)
            }
        }
        return null
    }

    private fun com.google.gson.JsonElement.asJsonObjectOrNull(): JsonObject? =
        if (isJsonObject) asJsonObject else null
}
