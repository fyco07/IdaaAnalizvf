@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi


/** Faz 10: gerçekleşen sonuç ile tahmini eşleştirir; Brier hatası gelecekte kalibrasyon ağırlığı olarak kullanılabilir. */
object KalibrasyonMotoru {
    fun brier(probability: Double, occurred: Boolean): Double {
        val p = probability.coerceIn(0.0,1.0); val y = if (occurred) 1.0 else 0.0; return (p-y)*(p-y)
    }
    fun calibratedProbability(raw: Double, meanBrier: Double?): Double {
        val error = (meanBrier ?: 0.25).coerceIn(0.0,1.0)
        val shrink = (1.0 - error * 0.75).coerceIn(0.55,0.95)
        return (0.5 + (raw-0.5)*shrink).coerceIn(0.01,0.99)
    }
}
