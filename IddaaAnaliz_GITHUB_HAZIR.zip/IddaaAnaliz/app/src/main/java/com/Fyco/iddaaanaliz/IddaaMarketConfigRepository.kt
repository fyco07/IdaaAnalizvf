@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale

/*
 * ============================================================
 * RESMİ İDDAA MARKET İSİMLERİ
 * ============================================================
 *
 * Marketin ne olduğunu outcome isminden tahmin etmiyoruz.
 *
 * Önce yerel cache'teki resmi t+st konfigürasyonu kullanılır;
 * cache yoksa deterministik t/st fallback'i devreye girer.
 *
 * Böylece:
 *
 * Ev Sahibi 0.5 Gol Alt/Üst
 * Deplasman 0.5 Gol Alt/Üst
 * 2.5 Gol Alt/Üst
 * Karşılıklı Gol
 * Maç Sonucu
 *
 * birbirine karışmaz.
 */
object IddaaMarketConfigRepository {

    private var config:
        Map<String, IddaaMarketConfig> =
        emptyMap()

    private var sonGuncelleme:
        Long = 0L

    private var prefs: SharedPreferences? = null
    private val gson = Gson()
    private const val PREFS = "iddaa_market_config_cache_v2"
    private const val KEY_CONFIG = "config_json"

    private val yuklemeMutex = Mutex()

    fun init(ctx: Context) {
        if (prefs == null) {
            prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        }
        if (config.isEmpty()) {
            runCatching {
                val json = prefs?.getString(KEY_CONFIG, null)
                if (!json.isNullOrBlank()) {
                    val type = object : TypeToken<Map<String, IddaaMarketConfig>>() {}.type
                    config = gson.fromJson<Map<String, IddaaMarketConfig>>(json, type) ?: emptyMap()
                    sonGuncelleme = System.currentTimeMillis()
                }
            }
        }
    }

    /**
     * Analiz zincirinde market config ağ çağrısı YAPILMAZ.
     *
     * Bülten zaten marketin t/st/sov/outcome kimliklerini taşıdığı için
     * öncelik disk önbelleği + deterministik fallback'tedir. Bu metod yalnızca
     * yerel cache'i hazırlar; DNS/HTTP gecikmesi güçlüler taramasını durduramaz.
     */
    suspend fun hazirla() = yuklemeMutex.withLock {
        if (prefs == null) return@withLock
        if (config.isEmpty()) {
            val json = prefs?.getString(KEY_CONFIG, null)
            if (!json.isNullOrBlank()) {
                runCatching {
                    val type = object : TypeToken<Map<String, IddaaMarketConfig>>() {}.type
                    config = gson.fromJson<Map<String, IddaaMarketConfig>>(json, type) ?: emptyMap()
                    sonGuncelleme = System.currentTimeMillis()
                }
            }
        }
    }


    /*
     * Marketin resmi adını döndürür.
     */
    fun marketAdi(
        market: IddaaMarket
    ): String? {

        val t =
            market.t
                ?: return null

        val st =
            market.st
                ?: return null

        val key =
            "${t}_${st}"

        val item =
            config[key]
                ?: return null

        var name =
            item.n
                .trim()

        if (name.isEmpty()) {
            return null
        }

        /*
         * Resmi konfigürasyonda {0} varsa
         * marketin gerçek sov değerini yerine koy.
         */
        val sov =
            market.sov
                ?.trim()

        if (
            !sov.isNullOrEmpty()
        ) {

            name =
                name
                    .replace(
                        "{0}",
                        sov
                    )
        }

        return name
    }

    /*
     * UI için güvenli market başlığı.
     *
     * Resmi config yoksa kafadan "TOPLAM" gibi
     * yanlış bir isim üretmiyoruz.
     */
    fun marketBasligi(
        market: IddaaMarket
    ): String {

        val resmi =
            marketAdi(market)

        if (
            !resmi.isNullOrEmpty()
        ) {
            return resmi
        }

        /*
         * Config ulaşılamazsa da ana analiz hattını boş bırakmıyoruz.
         * Aşağıdaki t/st kimlikleri geçmiş resmi İddaa bültenlerindeki
         * standart futbol marketlerine aittir. Bu sadece MARKET ADINI
         * geri kurar; olasılık hesabını hiçbir şekilde oranlardan türetmez.
         */
        val outcomeNames = market.o
            .map { it.n.trim().lowercase(Locale.forLanguageTag("tr-TR")) }
            .toSet()
        val sov = market.sov?.trim()?.replace(",", ".").orEmpty()

        if (market.st == 62 || sov.startsWith("+") || sov.startsWith("-")) {
            return if (sov.isNotEmpty()) "HANDİKAP $sov" else "HANDİKAP"
        }

        if (outcomeNames.contains("var") && outcomeNames.contains("yok")) {
            return "KARŞILIKLI GOL"
        }

        if (market.st == 61 || market.st == 70 || market.st == 79 ||
            (outcomeNames.contains("1") && outcomeNames.contains("2") &&
             (outcomeNames.contains("x") || outcomeNames.contains("0")))) {
            return "MAÇ SONUCU"
        }

        return when (market.st) {
            36 -> "MAÇ SONUCU"
            60 -> if (sov.isNotEmpty()) "EV SAHİBİ $sov GOL ALT/ÜST" else "EV SAHİBİ GOL ALT/ÜST"
            101 -> if (sov.isNotEmpty()) "TOPLAM $sov" else "TOPLAM"
            7 -> if (sov.isNotEmpty()) "MAÇ SONUCU VE TOPLAM $sov" else "MAÇ SONUCU VE TOPLAM"
            700 -> if (sov.isNotEmpty()) "TOPLAM $sov VE KARŞILIKLI GOL" else "TOPLAM VE KARŞILIKLI GOL"
            720 -> "KARŞILIKLI GOL"
            else -> "İDDAA MARKETİ"
        }
    }

    fun temizle() {
        config = emptyMap()
        sonGuncelleme = 0L
        runCatching {
            prefs?.edit()?.remove(KEY_CONFIG)?.apply()
        }
    }

    fun configYukluMu(): Boolean =
        config.isNotEmpty()

    fun configBoyutu(): Int =
        config.size
}
