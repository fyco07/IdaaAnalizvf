@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.util.Log
import com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
import com.Fyco.iddaaanaliz.espn.ESPNTarihselMac
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import java.text.Normalizer
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/**
 * Geriye donuk sinif adi korunmustur; gercek sonuc kaynagi yalnizca ESPN'dir.
 * SofaScore'a ait hicbir HTTP endpoint bu surumde kullanilmaz.
 */
data class SonucMac(
    val eventId: Long,
    val evSahibi: String,
    val deplasman: String,
    val durum: String,
    val evTakimId: Long?,
    val deplasmanTakimId: Long?,
    val evSkor: Int?,
    val depSkor: Int?,
    val evIlkYari: Int?,
    val depIlkYari: Int?,
    val baslangic: Long?
) {
    val tamamlandi: Boolean
        get() = durum.equals("finished", true) ||
                durum.equals("afterpenalties", true) ||
                durum.equals("afterextra", true) ||
                durum.equals("ended", true)
}

object ESPNSonucSaglayici {
    private const val TAG = "IddaaOgrenme"
    private const val MIN_MATCH_SCORE = 60

    suspend fun tarihselMaclariGetir(
        gun: String,
        spor: SporTuru
    ): List<SonucMac> = withContext(Dispatchers.IO) {
        espnGunlukMaclariGetir(gun, spor).filter { it.tamamlandi }
    }

    suspend fun macSonucunuBul(
        kayit: TahminKaydi,
        spor: SporTuru
    ): SonucMac? = withContext(Dispatchers.IO) {
        val gunler = gunListesi(kayit.macZamani)
        var toplamAday = 0
        var enIyiPuan = 0

        for (gun in gunler.sortedBy { gunMesafesi(kayit.macZamani, it) }) {
            val result = espnGunlukMaclariGetir(gun, spor)
            toplamAday += result.size
            val eslesme = result.asSequence()
                .mapNotNull { mac ->
                    val puan = eslesmePuani(kayit, mac)
                    if (puan >= MIN_MATCH_SCORE) mac to puan else null
                }
                .filter { it.first.tamamlandi && it.first.evSkor != null && it.first.depSkor != null }
                .maxByOrNull { it.second }

            if (eslesme != null) {
                enIyiPuan = maxOf(enIyiPuan, eslesme.second)
                Log.i(
                    TAG,
                    "SONUC_ESPN_ESLESME event=${kayit.eventId} ${kayit.evSahibi}-${kayit.deplasman} " +
                            "puan=${eslesme.second} skor=${eslesme.first.evSkor}-${eslesme.first.depSkor} " +
                            "espnEvent=${eslesme.first.eventId}"
                )
                return@withContext eslesme.first
            }
        }

        Log.i(TAG, "SONUC_BULUNAMADI event=${kayit.eventId} ${kayit.evSahibi}-${kayit.deplasman} aday=$toplamAday enIyiPuan=$enIyiPuan")
        null
    }

    suspend fun macSonuclariniBul(
        kayitlar: List<TahminKaydi>
    ): Map<String, SonucMac> = withContext(Dispatchers.IO) {
        if (kayitlar.isEmpty()) return@withContext emptyMap()

        val uygun = kayitlar.filter { it.macZamani > 0L }
        if (uygun.isEmpty()) return@withContext emptyMap()

        Log.i(TAG, "SONUC_KAYNAGI_ACTIVE provider=ESPN_ONLY localFootballHistory=true")

        val sporlar = uygun.mapNotNull {
            runCatching { SporTuru.valueOf(it.spor) }.getOrNull()
        }.distinct()

        val sonuc = LinkedHashMap<String, SonucMac>()
        val primaryDays = uygun.map { gunListesi(it.macZamani).first() }.distinct()
        val dailyCache = HashMap<String, List<SonucMac>>()

        for (spor in sporlar) {
            for (gun in primaryDays) {
                dailyCache["$spor|$gun"] = espnGunlukMaclariGetir(gun, spor)
            }
        }

        val unresolved = ArrayList<TahminKaydi>()
        val unresolvedLogged = HashSet<String>()
        for (kayit in uygun) {
            val spor = runCatching { SporTuru.valueOf(kayit.spor) }.getOrNull()
            if (spor == null) {
                unresolved += kayit
                continue
            }
            val gun = gunListesi(kayit.macZamani).first()
            val best = dailyCache["$spor|$gun"].orEmpty().asSequence()
                .mapNotNull { mac ->
                    val score = eslesmePuani(kayit, mac)
                    if (score >= MIN_MATCH_SCORE) mac to score else null
                }
                .filter { it.first.tamamlandi && it.first.evSkor != null && it.first.depSkor != null }
                .maxByOrNull { it.second }

            if (best != null) {
                sonuc[kayit.anahtar] = best.first
                Log.i(
                    TAG,
                    "SONUC_ESPN_ESLESME event=${kayit.eventId} ${kayit.evSahibi}-${kayit.deplasman} " +
                            "puan=${best.second} skor=${best.first.evSkor}-${best.first.depSkor} espnEvent=${best.first.eventId}"
                )
            } else {
                unresolved += kayit
            }
        }

        Log.i(
            TAG,
            "SONUC_ESPN_OZET gun=${primaryDays.size} kaynakMac=${dailyCache.values.sumOf { it.size }} " +
                    "eslesen=${sonuc.size} kalan=${unresolved.size} kaynak=ESPN_ONLY"
        )

        val secondaryDays = unresolved
            .flatMap { gunListesi(it.macZamani).drop(1) }
            .distinct()

        for (spor in sporlar) {
            for (gun in secondaryDays) {
                val key = "$spor|$gun"
                if (!dailyCache.containsKey(key)) {
                    dailyCache[key] = espnGunlukMaclariGetir(gun, spor)
                }
            }
        }

        for (kayit in unresolved) {
            if (sonuc.containsKey(kayit.anahtar)) continue
            val spor = runCatching { SporTuru.valueOf(kayit.spor) }.getOrNull() ?: continue
            var best: Pair<SonucMac, Int>? = null

            for (gun in gunListesi(kayit.macZamani).drop(1)) {
                val candidate = dailyCache["$spor|$gun"].orEmpty().asSequence()
                    .mapNotNull { mac ->
                        val score = eslesmePuani(kayit, mac)
                        if (score >= MIN_MATCH_SCORE) mac to score else null
                    }
                    .filter { it.first.tamamlandi && it.first.evSkor != null && it.first.depSkor != null }
                    .maxByOrNull { it.second }
                if (candidate != null && (best == null || candidate.second > best!!.second)) {
                    best = candidate
                }
            }

            if (best != null) {
                sonuc[kayit.anahtar] = best.first
                Log.i(
                    TAG,
                    "SONUC_ESPN_KOMSUGUN_ESLESME event=${kayit.eventId} ${kayit.evSahibi}-${kayit.deplasman} " +
                            "puan=${best!!.second} skor=${best!!.first.evSkor}-${best!!.first.depSkor} " +
                            "espnEvent=${best!!.first.eventId}"
                )
            }
        }

        // Yerel futbol DB'sinde maç adı/tarih kapsam dışında kalmışsa, ancak
        // bundan sonra benzersiz spor+tarih kümeleri için uzak ESPN fallback'i
        // denenir. Böylece 977 tahmin için yüzlerce ağ çağrısı yapılmaz.
        val remoteFallbackKeys = unresolved
            .filterNot { sonuc.containsKey(it.anahtar) }
            .flatMap { kayit ->
                val spor = runCatching { SporTuru.valueOf(kayit.spor) }.getOrNull()
                    ?: return@flatMap emptyList()
                gunListesi(kayit.macZamani).map { "$spor|$it" }
            }
            .distinct()

        for (key in remoteFallbackKeys) {
            val separator = key.indexOf('|')
            if (separator <= 0) continue
            val spor = runCatching { SporTuru.valueOf(key.substring(0, separator)) }.getOrNull() ?: continue
            val gun = key.substring(separator + 1)
            val remote = uzakFallbackGunuGetir(gun, spor)
            if (remote.isNotEmpty()) {
                val merged = (dailyCache[key].orEmpty() + remote).distinctBy {
                    "${it.eventId}|${it.evSahibi}|${it.deplasman}|${it.baslangic}"
                }
                dailyCache[key] = merged
            }
        }

        for (kayit in unresolved) {
            if (sonuc.containsKey(kayit.anahtar)) continue
            val spor = runCatching { SporTuru.valueOf(kayit.spor) }.getOrNull() ?: continue
            val best = gunListesi(kayit.macZamani)
                .asSequence()
                .flatMap { gun -> dailyCache["$spor|$gun"].orEmpty().asSequence() }
                .mapNotNull { mac ->
                    val score = eslesmePuani(kayit, mac)
                    if (score >= MIN_MATCH_SCORE) mac to score else null
                }
                .filter { it.first.tamamlandi && it.first.evSkor != null && it.first.depSkor != null }
                .maxByOrNull { it.second }
            if (best != null) {
                sonuc[kayit.anahtar] = best.first
                Log.i(
                    TAG,
                    "SONUC_ESPN_UZAK_ESLESME event=${kayit.eventId} ${kayit.evSahibi}-${kayit.deplasman} " +
                            "puan=${best.second} skor=${best.first.evSkor}-${best.first.depSkor} espnEvent=${best.first.eventId}"
                )
            } else {
                val logKey = "${kayit.spor}|${kayit.eventId}|${kayit.evSahibi}|${kayit.deplasman}"
                if (unresolvedLogged.add(logKey)) {
                    Log.i(TAG, "SONUC_BULUNAMADI event=${kayit.eventId} ${kayit.evSahibi}-${kayit.deplasman}")
                }
            }
        }

        Log.i(TAG, "SONUC_ESPN_FINAL source=LOCAL_THEN_ESPN resolved=${sonuc.size} unresolved=${unresolved.count { !sonuc.containsKey(it.anahtar) }}")
        sonuc
    }

    private suspend fun espnGunlukMaclariGetir(
        gun: String,
        spor: SporTuru
    ): List<SonucMac> {
        // Futbol sonuçlarında önce ve mümkün olduğunca yalnızca yerel ESPN
        // tarihsel DB kullanılır. Böylece 403/DNS uzak kaynak hataları geçmiş
        // maçların sonuçlandırılmasını engellemez.
        if (spor == SporTuru.FUTBOL) {
            val local = yerelEspnGunlukMaclariGetir(gun)
            Log.i(TAG, "RESULT_LOCAL_QUERY gun=$gun spor=$spor local=${local.size}")
            return local
        }

        // Basketbol için bu sürümde yerel ESPN sonuç tablosu bulunmadığından
        // yalnızca gerektiğinde uzak ESPN denenir. Başarısızlık üst katmanda
        // boş sonuç olarak cache'lendiği için sonucu KAYBETTİ yapmaz.
        Log.i(TAG, "RESULT_REMOTE_PRIMARY gun=$gun spor=$spor local=0")
        return espnUzaktanGunlukMaclariGetir(gun, spor)
            .distinctBy { "${it.eventId}|${it.evSahibi}|${it.deplasman}|${it.baslangic}" }
    }

    private suspend fun uzakFallbackGunuGetir(
        gun: String,
        spor: SporTuru
    ): List<SonucMac> {
        Log.i(TAG, "RESULT_REMOTE_FALLBACK gun=$gun spor=$spor")
        return espnUzaktanGunlukMaclariGetir(gun, spor)
    }

    private suspend fun espnUzaktanGunlukMaclariGetir(
        gun: String,
        spor: SporTuru
    ): List<SonucMac> {
        val rows = when (spor) {
            SporTuru.FUTBOL -> ESPNVeriSaglayici.gununuGetir("soccer", "all", gun, SporTuru.FUTBOL)
            SporTuru.BASKETBOL -> listOf(
                ESPNVeriSaglayici.gununuGetir("basketball", "nba", gun, SporTuru.BASKETBOL),
                ESPNVeriSaglayici.gununuGetir("basketball", "wnba", gun, SporTuru.BASKETBOL),
                ESPNVeriSaglayici.gununuGetir("basketball", "euroleague", gun, SporTuru.BASKETBOL),
                ESPNVeriSaglayici.gununuGetir("basketball", "mens-college-basketball", gun, SporTuru.BASKETBOL)
            ).flatten()
        }
        return rows.distinctBy { it.eventId }.map { it.toSonucMac() }
    }

    private fun ESPNVeriSaglayici.Kayit.toSonucMac(): SonucMac = SonucMac(
        eventId = eventId,
        evSahibi = homeName,
        deplasman = awayName,
        durum = if (tamamlandi) "finished" else "notstarted",
        evTakimId = homeId?.toLongOrNull(),
        deplasmanTakimId = awayId?.toLongOrNull(),
        evSkor = homeScore?.toInt(),
        depSkor = awayScore?.toInt(),
        evIlkYari = null,
        depIlkYari = null,
        baslangic = baslangic
    )

    private suspend fun yerelEspnGunlukMaclariGetir(gun: String): List<SonucMac> = withContext(Dispatchers.IO) {
        val center = gunEpochMillis(gun) ?: return@withContext emptyList()
        val margin = 36L * 60L * 60L * 1000L
        val db = IddaaAnalizDatabase.getInstance(requireContext())
        val rows = runCatching {
            db.espnTarihselMacDao().tamamlananMaclariTarihAraligindaGetir(center - margin, center + margin)
        }.getOrElse {
            Log.w(TAG, "LOCAL_ESPN_DB_READ_FAIL gun=$gun hata=${it.javaClass.simpleName}")
            emptyList()
        }
        return@withContext rows.map { it.toSonucMac() }
    }

    private fun ESPNTarihselMac.toSonucMac(): SonucMac = SonucMac(
        eventId = eventId,
        evSahibi = evTakim,
        deplasman = deplasmanTakim,
        durum = if (tamamlandi) "finished" else "notstarted",
        evTakimId = evTakimId?.toLongOrNull(),
        deplasmanTakimId = deplasmanTakimId?.toLongOrNull(),
        evSkor = evSkor,
        depSkor = deplasmanSkor,
        evIlkYari = evIlkYari,
        depIlkYari = deplasmanIlkYari,
        baslangic = baslangic
    )

    private fun gunEpochMillis(gun: String): Long? = runCatching {
        LocalDate.parse(gun)
            .atStartOfDay(ZoneId.of("Europe/Istanbul"))
            .toInstant()
            .toEpochMilli()
    }.getOrNull()

    private fun requireContext(): android.content.Context =
        AppContextHolder.context ?: error("Uygulama context hazır değil")

    private fun gunListesi(timestamp: Long): List<String> {
        val c = Calendar.getInstance().apply { timeInMillis = timestamp * 1000L }
        return listOf(0, -1, 1, -2, 2).map { delta ->
            val copy = c.clone() as Calendar
            copy.add(Calendar.DAY_OF_MONTH, delta)
            String.format(
                Locale.US,
                "%04d-%02d-%02d",
                copy.get(Calendar.YEAR),
                copy.get(Calendar.MONTH) + 1,
                copy.get(Calendar.DAY_OF_MONTH)
            )
        }.distinct()
    }

    private fun gunMesafesi(timestamp: Long, gun: String): Long {
        val c = Calendar.getInstance().apply { timeInMillis = timestamp * 1000L }
        val parts = gun.split('-')
        val target = Calendar.getInstance()
        if (parts.size == 3) {
            target.set(
                parts[0].toIntOrNull() ?: c.get(Calendar.YEAR),
                (parts[1].toIntOrNull() ?: 1) - 1,
                parts[2].toIntOrNull() ?: 1,
                12,
                0,
                0
            )
            target.set(Calendar.MILLISECOND, 0)
        } else {
            target.timeInMillis = c.timeInMillis
        }
        return abs(c.timeInMillis - target.timeInMillis) / 86_400_000L
    }

    private fun eslesmePuani(kayit: TahminKaydi, mac: SonucMac): Int {
        if (kayit.eventId > 0L && mac.eventId > 0L && kayit.eventId == mac.eventId) return 100

        val ev = takimSkoru(kayit.evSahibi, mac.evSahibi)
        val dep = takimSkoru(kayit.deplasman, mac.deplasman)
        if (ev < 42 || dep < 42) return 0

        val isimPuani = when {
            ev >= 50 && dep >= 50 -> 80
            ev >= 44 && dep >= 44 -> 70
            else -> 60
        }
        // Tahmin kaydi zamani UNIX saniye, ESPN tarihsel kaydi ise UNIX milisaniyedir.
        // Dogrudan cikarma eski surumde tum isim eslesmelerini zaman puani 0'a indirip
        // `if (ev >= 50 && dep >= 50 ...) return 0` kosuluyla maci yanlislikla eliyordu.
        val zamanPuani = if (kayit.macZamani > 0L && mac.baslangic != null) {
            val macEpochSeconds = epochSeconds(mac.baslangic)
            val saat = abs(kayit.macZamani - macEpochSeconds) / 3600.0
            when {
                saat <= 1.0 -> 20
                saat <= 2.0 -> 16
                saat <= 4.0 -> 12
                saat <= 8.0 -> 6
                else -> 0
            }
        } else 0

        if (ev >= 50 && dep >= 50 && zamanPuani == 0) return 0
        return (isimPuani + zamanPuani).coerceAtMost(100)
    }

    private fun epochSeconds(value: Long): Long =
        if (value >= 100_000_000_000L) value / 1000L else value

    private fun takimSkoru(a: String, b: String): Int {
        val x = takimAnahtari(a)
        val y = takimAnahtari(b)
        if (x.isBlank() || y.isBlank()) return 0
        if (x == y) return 50
        if (x.contains(y) || y.contains(x)) return 44

        val tx = x.split(' ').filter { it.length >= 2 }.toSet()
        val ty = y.split(' ').filter { it.length >= 2 }.toSet()
        if (tx.isEmpty() || ty.isEmpty()) return 0

        val ortak = tx.intersect(ty)
        if (ortak.isNotEmpty() && (tx.all { it in ty } || ty.all { it in tx })) return 46

        val oran = ortak.size.toDouble() / max(tx.size, ty.size).toDouble()
        return when {
            oran >= .75 -> 42
            oran >= .50 -> 36
            oran >= .33 -> 28
            oran > 0.0 -> 18
            else -> 0
        }
    }

    private fun takimAnahtari(value: String): String {
        val x = temiz(value)
        if (x.isBlank()) return ""
        val generic = setOf(
            "fc", "fk", "cf", "sc", "afc", "ac", "club", "clubs",
            "women", "woman", "w", "female", "ladies", "fem",
            "femenino", "feminino", "kadin", "k"
        )
        return x.split(' ')
            .filter { it.isNotBlank() && it !in generic && it.length >= 2 }
            .joinToString(" ")
            .trim()
    }

    private fun temiz(value: String): String {
        val ascii = Normalizer.normalize(value.lowercase(Locale.forLanguageTag("tr-TR")), Normalizer.Form.NFD)
            .replace("ı", "i")
            .replace("İ", "i")
            .replace("ş", "s")
            .replace("Ş", "s")
            .replace("ğ", "g")
            .replace("Ğ", "g")
            .replace("ü", "u")
            .replace("Ü", "u")
            .replace("ö", "o")
            .replace("Ö", "o")
            .replace("ç", "c")
            .replace("Ç", "c")
            .replace(Regex("\\p{Mn}+"), "")
        return ascii.replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
