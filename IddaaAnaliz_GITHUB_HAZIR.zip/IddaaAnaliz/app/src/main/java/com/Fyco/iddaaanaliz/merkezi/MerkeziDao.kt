@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface MerkeziDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertMatches(items: List<MerkeziMatch>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertTeams(items: List<MerkeziTeam>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertLeagues(items: List<MerkeziLeague>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSeasons(items: List<MerkeziSeason>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertMarkets(items: List<MerkeziMarket>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertOdds(items: List<MerkeziOdds>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSources(items: List<MerkeziSourceData>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertResults(items: List<MerkeziResult>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertPredictions(items: List<MerkeziPrediction>)

    @Transaction
    suspend fun upsertBulten(
        matches: List<MerkeziMatch>,
        teams: List<MerkeziTeam>,
        markets: List<MerkeziMarket>,
        odds: List<MerkeziOdds>,
        sources: List<MerkeziSourceData>
    ) {
        if (matches.isNotEmpty()) upsertMatches(matches)
        if (teams.isNotEmpty()) upsertTeams(teams)
        if (markets.isNotEmpty()) upsertMarkets(markets)
        if (odds.isNotEmpty()) upsertOdds(odds)
        if (sources.isNotEmpty()) upsertSources(sources)
    }

    @Transaction
    suspend fun upsertHistory(
        matches: List<MerkeziMatch>,
        teams: List<MerkeziTeam>,
        leagues: List<MerkeziLeague>,
        seasons: List<MerkeziSeason>,
        results: List<MerkeziResult>,
        sources: List<MerkeziSourceData>
    ) {
        if (matches.isNotEmpty()) upsertMatches(matches)
        if (teams.isNotEmpty()) upsertTeams(teams)
        if (leagues.isNotEmpty()) upsertLeagues(leagues)
        if (seasons.isNotEmpty()) upsertSeasons(seasons)
        if (results.isNotEmpty()) upsertResults(results)
        if (sources.isNotEmpty()) upsertSources(sources)
    }

    @Query("SELECT * FROM merkezi_match WHERE matchId = :matchId LIMIT 1") suspend fun match(matchId: String): MerkeziMatch?
    @Query("SELECT * FROM merkezi_odds WHERE marketId = :marketId ORDER BY capturedAt DESC") suspend fun odds(marketId: String): List<MerkeziOdds>
    @Query("SELECT * FROM merkezi_prediction WHERE result IS NULL ORDER BY createdAt ASC") suspend fun pendingPredictions(): List<MerkeziPrediction>
    @Query("SELECT COUNT(*) FROM merkezi_match") suspend fun matchCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_team") suspend fun teamCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_league") suspend fun leagueCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_season") suspend fun seasonCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_market") suspend fun marketCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_odds") suspend fun oddsCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_source_data") suspend fun sourceCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_prediction") suspend fun predictionCount(): Int
    @Query("UPDATE merkezi_prediction SET result = :result, brierError = :brier WHERE predictionId = :predictionId") suspend fun settlePrediction(predictionId: String, result: String, brier: Double)
    @Query("SELECT AVG(brierError) FROM merkezi_prediction WHERE brierError IS NOT NULL") suspend fun meanBrier(): Double?
    @Query("SELECT * FROM merkezi_team WHERE sport = :sport AND normalizedName = :normalized LIMIT 1") suspend fun teamByNormalized(normalized: String, sport: String): MerkeziTeam?
    @Query("SELECT m.*, r.homeScore AS rHomeScore, r.awayScore AS rAwayScore FROM merkezi_match m INNER JOIN merkezi_result r ON r.matchId = m.matchId WHERE (m.homeTeamId = :teamId OR m.awayTeamId = :teamId) AND r.completedAt < :beforeTs ORDER BY r.completedAt DESC LIMIT :limit") suspend fun teamResults(teamId: String, beforeTs: Long, limit: Int): List<TeamResultRow>
    @Query("""
        SELECT m.*, r.homeScore AS rHomeScore, r.awayScore AS rAwayScore, r.completedAt AS rCompletedAt
        FROM merkezi_match m
        INNER JOIN merkezi_result r ON r.matchId = m.matchId
        WHERE r.completedAt < :beforeTs
          AND m.sport = 'FUTBOL'
          AND r.homeScore >= 0
          AND r.awayScore >= 0
        ORDER BY r.completedAt ASC
        LIMIT :limit
    """)
    suspend fun completedFootballHistory(beforeTs: Long, limit: Int = 50000): List<MerkeziHistoryRow>

    @Query("SELECT * FROM merkezi_result WHERE matchId = :matchId LIMIT 1") suspend fun result(matchId: String): MerkeziResult?
    @Query("SELECT p.*, m.title AS marketTitle, r.homeScore AS resultHome, r.awayScore AS resultAway, r.homeFirstHalf AS resultHomeFirstHalf, r.awayFirstHalf AS resultAwayFirstHalf FROM merkezi_prediction p INNER JOIN merkezi_market m ON m.marketId = p.matchId || ':' || p.marketKey INNER JOIN merkezi_result r ON r.matchId = p.matchId WHERE p.result IS NULL ORDER BY p.createdAt ASC LIMIT :limit") suspend fun pendingSettlements(limit: Int): List<PendingSettlementRow>
    @Query("SELECT COUNT(*) FROM merkezi_result r INNER JOIN merkezi_match m ON m.matchId = r.matchId WHERE m.sport = 'FUTBOL'") suspend fun footballResultCount(): Int
    @Query("SELECT COUNT(*) FROM merkezi_result") suspend fun resultCount(): Int

    @Query("SELECT p.modelProbability AS modelProbability, p.result AS result FROM merkezi_prediction p INNER JOIN merkezi_match m ON m.matchId = p.matchId WHERE m.sport = 'FUTBOL' AND p.result IS NOT NULL ORDER BY p.createdAt DESC LIMIT 5000")
    suspend fun recentFootballSettledPredictions(): List<CalibrationRow>
    suspend fun recentFootballCalibrationTemperature(): Double? {
        return CalibrationModel.fitTemperature(recentFootballSettledPredictions())
    }

}


data class TeamResultRow(
    val matchId: String, val externalId: String?, val sport: String, val homeTeamId: String, val awayTeamId: String,
    val homeTeamName: String, val awayTeamName: String, val leagueId: String?, val leagueName: String?, val seasonId: String?, val seasonName: String?,
    val startTs: Long, val status: String, val updatedAt: Long, val rHomeScore: Double, val rAwayScore: Double
)


data class MerkeziHistoryRow(
    val matchId: String,
    val externalId: String?,
    val sport: String,
    val homeTeamId: String,
    val awayTeamId: String,
    val homeTeamName: String,
    val awayTeamName: String,
    val leagueId: String?,
    val leagueName: String?,
    val seasonId: String?,
    val seasonName: String?,
    val startTs: Long,
    val status: String,
    val updatedAt: Long,
    val rHomeScore: Double,
    val rAwayScore: Double,
    val rCompletedAt: Long
)


data class PendingSettlementRow(
    val predictionId: String, val matchId: String, val marketKey: String, val outcomeKey: String, val modelProbability: Double,
    val marketProbability: Double?, val edge: Double?, val ev: Double?, val confidence: Double, val createdAt: Long, val result: String?, val brierError: Double?,
    val marketTitle: String, val resultHome: Double, val resultAway: Double, val resultHomeFirstHalf: Double?, val resultAwayFirstHalf: Double?
)
