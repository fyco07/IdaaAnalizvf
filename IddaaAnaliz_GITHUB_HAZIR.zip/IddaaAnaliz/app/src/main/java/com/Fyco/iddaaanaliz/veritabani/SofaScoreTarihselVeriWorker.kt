@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import android.util.Log
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Persisted legacy WorkManager class retained only for safe deserialization.
 * It performs no network I/O. ESPN is the sole historical/result source.
 */
@Deprecated("Legacy SofaScore worker disabled; use ESPN history worker")
class SofaScoreTarihselVeriWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        Log.i("ESPN_HISTORY", "LEGACY_SOFASCORE_WORKER_DISABLED reason=ESPN_ONLY")
        return Result.success()
    }
}
