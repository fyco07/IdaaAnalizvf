@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SofaScoreTarihselMacDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun maclariKaydet(maclar: List<SofaScoreTarihselMac>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun macKaydet(mac: SofaScoreTarihselMac)

    @Query("""
        SELECT * FROM sofascore_tarihsel_maclar
        WHERE baslangic BETWEEN :baslangic AND :bitis
        ORDER BY baslangic ASC
    """)
    suspend fun tarihAraliginiGetir(
        baslangic: Long,
        bitis: Long
    ): List<SofaScoreTarihselMac>

    @Query("""
        SELECT * FROM sofascore_tarihsel_maclar
        WHERE evTakimId = :takimId OR deplasmanTakimId = :takimId
        ORDER BY baslangic DESC
        LIMIT :limit
    """)
    suspend fun takimGecmisiniGetir(
        takimId: Long,
        limit: Int
    ): List<SofaScoreTarihselMac>

    @Query("""
        SELECT * FROM sofascore_tarihsel_maclar
        WHERE spor = :spor
          AND (evTakimId = :takimId OR deplasmanTakimId = :takimId)
        ORDER BY baslangic DESC
        LIMIT :limit
    """)
    suspend fun takimGecmisiniSporlaGetir(
        takimId: Long,
        spor: String,
        limit: Int
    ): List<SofaScoreTarihselMac>

    @Query("""
        SELECT * FROM sofascore_tarihsel_maclar
        WHERE spor = :spor
          AND (evTakimAdi = :takimAdi OR deplasmanTakimAdi = :takimAdi)
        ORDER BY baslangic DESC
        LIMIT :limit
    """)
    suspend fun takimAdiGecmisiniSporlaGetir(
        takimAdi: String,
        spor: String,
        limit: Int
    ): List<SofaScoreTarihselMac>

    @Query("""
        SELECT * FROM sofascore_tarihsel_maclar
        WHERE evTakimAdi = :takimAdi OR deplasmanTakimAdi = :takimAdi
        ORDER BY baslangic DESC
        LIMIT :limit
    """)
    suspend fun takimAdiGecmisiniGetir(
        takimAdi: String,
        limit: Int
    ): List<SofaScoreTarihselMac>

    @Query("SELECT COUNT(*) FROM sofascore_tarihsel_maclar")
    suspend fun toplamMacSayisi(): Int

    @Query("SELECT COUNT(*) FROM sofascore_tarihsel_maclar WHERE spor = :spor")
    suspend fun sporMacSayisi(spor: String): Int

    @Query("SELECT MAX(baslangic) FROM sofascore_tarihsel_maclar")
    suspend fun sonMacZamani(): Long?

    @Query("DELETE FROM sofascore_tarihsel_maclar")
    suspend fun temizle()
}
