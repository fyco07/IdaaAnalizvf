@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

data class IddaaResponse(
    val isSuccess: Boolean,
    val data: IddaaData
)

data class IddaaData(
    val isdiff: Boolean,
    val version: Long,
    val events: List<IddaaEvent>
)

data class IddaaEvent(
    val i: Long,
    val bri: Long?,
    val v: Long?,
    val hn: String,
    val an: String,
    val sid: Int?,
    val s: Int?,
    val bp: Int?,
    val il: Boolean?,
    val mbc: Int?,
    val kOdd: Boolean?,
    val m: List<IddaaMarket>,
    val ci: Long?,
    val oc: Int?,
    val d: Long,
    val hc: Boolean?,
    val bgi: String?
)

data class IddaaMarket(
    val i: Long,
    val t: Int?,
    val st: Int?,
    val v: Long?,
    val s: Int?,
    val mbc: Int?,
    val sov: String?,
    val o: List<IddaaOutcome>
)

data class IddaaOutcome(
    val no: Int,
    val odd: Double,
    val wodd: Double,
    val n: String
) {
    /**
     * Kullanıcının bültende gördüğü/oynadığı resmi oran.
     *
     * `sportsbook/events` akışında fiyat alanı `odd` olarak taşınır. `wodd`
     * varsa onu birincil fiyat kabul etmek market oranlarını birbirine
     * karıştırabiliyor; örneğin Ev Sahibi 1.5 ÜST için bültendeki 1.16 yerine
     * başka bir markete ait 1.64 değeri görülebiliyor. Bu nedenle `odd`
     * birincildir; yalnızca geçersizse geriye dönük uyumluluk için `wodd`
     * yedek olarak kullanılır.
     */
    val oynanabilirOran: Double
        get() = if (odd.isFinite() && odd > 1.0) odd else wodd
}

/*
 * Resmi İddaa market konfigürasyonu.
 *
 * İddaa'nın get_market_config cevabındaki data.m
 * nesnesinin değerlerini temsil eder.
 */
data class IddaaMarketConfigResponse(
    val data: IddaaMarketConfigData
)

data class IddaaMarketConfigData(
    val m: Map<String, IddaaMarketConfig> = emptyMap()
)

data class IddaaMarketConfig(
    val d: String? = null,
    val i: Long? = null,
    val il: Boolean? = null,
    val `in`: Boolean? = null,
    val mdv: Double? = null,
    val mlv: Double? = null,
    val mmdv: Double? = null,
    val mmlv: Double? = null,
    val mst: Double? = null,
    val mt: Double? = null,
    val n: String = "Bilinmeyen Market",
    val o: Map<String, String>? = null,
    val p: Double? = null,
    val st: Int? = null
)
