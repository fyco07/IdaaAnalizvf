@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

object OyuncuModelBaglanti {

    fun futbolOyuncuEtkisi(
        temelOlasilik: Double,
        market: AnalizMarketTipi,
        oyuncular: List<OyuncuEtkiVerisi>
    ): Double {

        return OyuncuEtkiMotoru.marketEtkisi(
            spor = SporTuru.FUTBOL,
            market = market,
            oyuncular = oyuncular
        ).let { etki ->

            val degisim =
                (etki / 100.0) * 0.12

            (temelOlasilik + degisim)
                .coerceIn(0.01, 0.99)
        }
    }

    fun basketbolOyuncuEtkisi(
        temelOlasilik: Double,
        market: AnalizMarketTipi,
        oyuncular: List<OyuncuEtkiVerisi>
    ): Double {

        return OyuncuEtkiMotoru.marketEtkisi(
            spor = SporTuru.BASKETBOL,
            market = market,
            oyuncular = oyuncular
        ).let { etki ->

            val degisim =
                (etki / 100.0) * 0.10

            (temelOlasilik + degisim)
                .coerceIn(0.01, 0.99)
        }
    }

    fun oyuncuVerisiVarMi(
        oyuncular: List<OyuncuEtkiVerisi>
    ): Boolean {

        return oyuncular.isNotEmpty()
    }
}