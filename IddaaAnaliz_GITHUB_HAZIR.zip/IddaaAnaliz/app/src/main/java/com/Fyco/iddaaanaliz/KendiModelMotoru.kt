@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import com.Fyco.iddaaanaliz.espn.ESPNKendiModelTahmincisi

import kotlin.math.exp

/**
 * Kendi modelinin hesaplama katmanı.
 *
 * Bu motorun en önemli kuralı: yeterli gerçek veri yoksa tahmin üretmez.
 * Böylece varsayılan 0.0 alanlardan yapay % üretilemez.
 */
object KendiModelMotoru {

    fun marketOlasiliklariniOlustur(
        market: IddaaMarket,
        spor: SporTuru,
        veri: MacDisVerisi?
    ): Map<Int, Double> {
        if (veri == null || veri.spor != spor) return emptyMap()

        // KENDİ MODELİ 2.0: ESPN 365 günlük geçmişten öğrenilmiş takım
        // ratingleri ve ortak skor dağılımı varsa öncelik artık buradadır.
        // İddaa oranı bu modelin girdisi değildir.
        val learned: Map<Int, Double> = runCatching {
            ESPNKendiModelTahmincisi.marketOlasiliklari(
                market = market,
                spor = spor,
                veri = veri
            )
        }.getOrDefault(emptyMap())
        if (learned.isNotEmpty()) return learned

        // FUTBOLDA KRİTİK KURAL:
        // ESPN 365 günlük eğitimli Kendi Modeli sonuç üretemiyorsa
        // eski form/xG/heuristic hesaplarına geri dönme.
        // Aksi halde model eğitilmeden sahte bir olasılık üretilir ve
        // kullanıcının istediği "ESPN -> Kendi Modeli" zinciri bozulur.
        if (spor == SporTuru.FUTBOL) return emptyMap()

        val outcomes = market.o.filter { it.oynanabilirOran > 1.0 }
        if (outcomes.size < 2) return emptyMap()

        val baslik = try {
            IddaaMarketConfigRepository.marketBasligi(market)
        } catch (_: Exception) {
            ""
        }

        val normalized = normalize(baslik)
        val result = linkedMapOf<Int, Double>()

        when {
            isMacSonucuMarket(normalized, market) -> {
                val probs = if (spor == SporTuru.FUTBOL) {
                    futbolMacSonucu(veri)
                } else {
                    basketbolMacSonucu(veri)
                }

                if (probs.isEmpty()) return emptyMap()

                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "1" -> probs[0]?.let { result[outcome.no] = it }
                        "x", "0" -> probs[1]?.let { result[outcome.no] = it }
                        "2" -> probs[2]?.let { result[outcome.no] = it }
                    }
                }
            }

            spor == SporTuru.FUTBOL && isKarsilikliGolMarket(normalized, market) -> {
                val btts = futbolKarsilikliGol(veri) ?: return emptyMap()
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "var" -> result[outcome.no] = btts
                        "yok" -> result[outcome.no] = 1.0 - btts
                    }
                }
            }

            spor == SporTuru.FUTBOL && isToplamGolMarket(normalized, market) -> {
                val line = toplamCizgisi(normalized, market) ?: return emptyMap()
                val over = futbolOverLine(veri, line) ?: return emptyMap()
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "alt" -> result[outcome.no] = 1.0 - over
                        "ust" -> result[outcome.no] = over
                    }
                }
            }

            spor == SporTuru.BASKETBOL && normalized.contains("handikap") -> {
                val home = basketbolSpreadEv(veri)
                    ?: return emptyMap()
                val away = 1.0 - home

                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "1" -> result[outcome.no] = home
                        "2" -> result[outcome.no] = away
                    }
                }
            }

            else -> return emptyMap()
        }

        return normalizeProbabilityMap(result)
    }

    /** FUTBOL 1/X/2 */
    private fun futbolMacSonucu(veri: MacDisVerisi): Map<Int, Double> {
        val evForm = formSkoru(veri.formEv)
        val depForm = formSkoru(veri.formDeplasman)

        val evStats = veri.futbolEv
        val depStats = veri.futbolDeplasman

        val hasForm = formVerisiVar(veri.formEv) && formVerisiVar(veri.formDeplasman)
        val hasStats = evStats != null && depStats != null &&
                ((evStats.gol > 0.0 || evStats.xg > 0.0) &&
                        (depStats.gol > 0.0 || depStats.xg > 0.0))

        if (!hasForm && !hasStats) return emptyMap()

        val evAttack = when {
            evStats?.xg?.takeIf { it > 0.0 } != null -> evStats.xg
            evStats?.gol?.takeIf { it > 0.0 } != null -> evStats.gol
            else -> veri.formEv.atilan
        }

        val depAttack = when {
            depStats?.xg?.takeIf { it > 0.0 } != null -> depStats.xg
            depStats?.gol?.takeIf { it > 0.0 } != null -> depStats.gol
            else -> veri.formDeplasman.atilan
        }

        val evDefense = when {
            evStats?.xga?.takeIf { it > 0.0 } != null -> evStats.xga
            evStats?.yenilenGol?.takeIf { it > 0.0 } != null -> evStats.yenilenGol
            else -> veri.formEv.yenilen
        }

        val depDefense = when {
            depStats?.xga?.takeIf { it > 0.0 } != null -> depStats.xga
            depStats?.yenilenGol?.takeIf { it > 0.0 } != null -> depStats.yenilenGol
            else -> veri.formDeplasman.yenilen
        }

        val evHomeAdv = veri.evDeplasman.evSahibiFormu
        val depAwayForm = veri.evDeplasman.deplasmanFormu

        val evStrength =
            0.46 * evForm +
                    0.22 * evAttack -
                    0.12 * evDefense +
                    0.14 * evHomeAdv +
                    0.06 * veri.macBaglami.motivasyonSkoru

        val depStrength =
            0.46 * depForm +
                    0.22 * depAttack -
                    0.12 * depDefense +
                    0.14 * depAwayForm -
                    0.06 * veri.macBaglami.motivasyonSkoru

        var rawHome = sigmoid((evStrength - depStrength) + 0.28)
        var rawAway = sigmoid((depStrength - evStrength) - 0.05)
        var rawDraw = 1.0 - rawHome * 0.82 - rawAway * 0.82

        // H2H yalnızca gerçekten varsa küçük bir düzeltme olarak kullanılır.
        if (veri.h2h.macSayisi > 0) {
            val total = (
                    veri.h2h.evGalibiyet +
                            veri.h2h.beraberlik +
                            veri.h2h.deplasmanGalibiyet
                    ).coerceAtLeast(1)

            val hHome = veri.h2h.evGalibiyet.toDouble() / total
            val hDraw = veri.h2h.beraberlik.toDouble() / total
            val hAway = veri.h2h.deplasmanGalibiyet.toDouble() / total

            rawHome = rawHome * 0.88 + hHome * 0.12
            rawDraw = rawDraw * 0.88 + hDraw * 0.12
            rawAway = rawAway * 0.88 + hAway * 0.12
        }

        return normalizeTriplet(rawHome, rawDraw, rawAway)
    }

    /** BASKETBOL 1/2 */
    private fun basketbolMacSonucu(veri: MacDisVerisi): Map<Int, Double> {
        val ev = veri.basketbolEv ?: return emptyMap()
        val dep = veri.basketbolDeplasman ?: return emptyMap()

        if (!basketIstatistikVar(ev) || !basketIstatistikVar(dep)) {
            return emptyMap()
        }

        val attackDiff = ev.attigiSayi - dep.attigiSayi
        val defenseDiff = dep.yedigiSayi - ev.yedigiSayi
        val fgDiff = ev.fieldGoalYuzde - dep.fieldGoalYuzde
        val threeDiff = ev.threePointYuzde - dep.threePointYuzde
        val reboundDiff = ev.ribaund - dep.ribaund
        val assistDiff = ev.asist - dep.asist
        val turnoverEdge = dep.topKaybi - ev.topKaybi

        val strength =
            0.32 * attackDiff +
                    0.24 * defenseDiff +
                    0.15 * fgDiff +
                    0.08 * threeDiff +
                    0.08 * reboundDiff +
                    0.06 * assistDiff +
                    0.07 * turnoverEdge

        val home = sigmoid(strength / 10.0 + 0.38)
            .coerceIn(0.05, 0.95)

        return mapOf(
            0 to home,
            1 to 1.0 - home
        )
    }

    /**
     * Futbol toplam gol modeli.
     * Beklenen toplam gol Poisson yaklaşımıyla modellenir; 1.5/2.5/3.5
     * gibi farklı çizgiler aynı temel dağılımdan türetilir.
     */
    private fun futbolOverLine(veri: MacDisVerisi, line: Double): Double? {
        val (lambdaEv, lambdaDep) = futbolBeklenenGoller(veri) ?: return null
        val lambda = (lambdaEv + lambdaDep).coerceIn(0.20, 6.50)

        val maxUnderGoals = kotlin.math.floor(line).toInt()
        var probabilityUnder = 0.0
        var term = exp(-lambda)
        probabilityUnder += term

        if (maxUnderGoals >= 1) {
            for (k in 1..maxUnderGoals) {
                term *= lambda / k.toDouble()
                probabilityUnder += term
            }
        }

        return (1.0 - probabilityUnder).coerceIn(0.02, 0.98)
    }

    private fun futbolKarsilikliGol(veri: MacDisVerisi): Double? {
        val (lambdaEv, lambdaDep) = futbolBeklenenGoller(veri) ?: return null
        val pEvGol = 1.0 - exp(-lambdaEv)
        val pDepGol = 1.0 - exp(-lambdaDep)
        return (pEvGol * pDepGol).coerceIn(0.02, 0.98)
    }

    private fun futbolBeklenenGoller(veri: MacDisVerisi): Pair<Double, Double>? {
        val ev = veri.futbolEv
        val dep = veri.futbolDeplasman

        val evAttackValues = listOfNotNull(
            ev?.xg?.takeIf { it > 0.0 },
            ev?.gol?.takeIf { it > 0.0 },
            veri.formEv.atilan.takeIf { it > 0.0 }
        )
        val depAttackValues = listOfNotNull(
            dep?.xg?.takeIf { it > 0.0 },
            dep?.gol?.takeIf { it > 0.0 },
            veri.formDeplasman.atilan.takeIf { it > 0.0 }
        )
        val evDefenseValues = listOfNotNull(
            dep?.xga?.takeIf { it > 0.0 },
            dep?.yenilenGol?.takeIf { it > 0.0 },
            veri.formDeplasman.yenilen.takeIf { it > 0.0 }
        )
        val depDefenseValues = listOfNotNull(
            ev?.xga?.takeIf { it > 0.0 },
            ev?.yenilenGol?.takeIf { it > 0.0 },
            veri.formEv.yenilen.takeIf { it > 0.0 }
        )

        if (evAttackValues.isEmpty() || depAttackValues.isEmpty()) return null

        val evAttack = evAttackValues.average()
        val depAttack = depAttackValues.average()
        val evDefense = evDefenseValues.averageOrNull() ?: 1.20
        val depDefense = depDefenseValues.averageOrNull() ?: 1.20

        // Hücum ve rakip savunmasını eşit ağırlıkla birleştiriyoruz.
        // Aşırı küçük/büyük örnekleri makul sınırlar içinde tutuyoruz.
        val lambdaEv = (0.55 * evAttack + 0.45 * depDefense + 0.10)
            .coerceIn(0.20, 3.50)
        val lambdaDep = (0.55 * depAttack + 0.45 * evDefense)
            .coerceIn(0.20, 3.50)

        return lambdaEv to lambdaDep
    }

    /** BASKETBOL spread */
    private fun basketbolSpreadEv(veri: MacDisVerisi): Double? {
        val ev = veri.basketbolEv ?: return null
        val dep = veri.basketbolDeplasman ?: return null

        if (!basketIstatistikVar(ev) || !basketIstatistikVar(dep)) {
            return null
        }

        val scoreDiff = ev.attigiSayi - dep.attigiSayi
        val efficiency =
            (ev.fieldGoalYuzde - dep.fieldGoalYuzde) * 0.65 +
                    (ev.threePointYuzde - dep.threePointYuzde) * 0.35

        return sigmoid(
            (scoreDiff * 0.12) +
                    (efficiency * 0.03) +
                    0.35
        ).coerceIn(0.03, 0.97)
    }

    private fun formVerisiVar(form: FormVerisi): Boolean {
        return form.sonMaclar.isNotEmpty() ||
                form.galibiyet + form.beraberlik + form.maglubiyet > 0 ||
                form.atilan > 0.0 ||
                form.yenilen > 0.0
    }

    private fun formSkoru(form: FormVerisi): Double {
        val matches = (
                form.galibiyet +
                        form.beraberlik +
                        form.maglubiyet
                ).coerceAtLeast(1)

        val resultScore =
            (form.galibiyet * 3.0 + form.beraberlik) / (matches * 3.0)

        val goalEdge =
            (form.atilan - form.yenilen) / matches.toDouble()

        return resultScore * 2.0 + goalEdge * 0.25
    }

    private fun basketIstatistikVar(
        data: BasketbolIstatistikleri
    ): Boolean {
        return data.macSayisi > 0 ||
                data.attigiSayi > 0.0 ||
                data.yedigiSayi > 0.0 ||
                data.fieldGoalYuzde > 0.0 ||
                data.ribaund > 0.0 ||
                data.asist > 0.0
    }

    private fun normalizeProbabilityMap(
        values: Map<Int, Double>
    ): Map<Int, Double> {
        val valid = values
            .filterValues { it.isFinite() && it > 0.0 }

        if (valid.size < 2) return emptyMap()

        val total = valid.values.sum()
        if (total <= 0.0) return emptyMap()

        return valid.mapValues { (_, value) ->
            (value / total).coerceIn(0.0, 1.0)
        }
    }

    private fun normalizeTriplet(
        first: Double,
        second: Double,
        third: Double
    ): Map<Int, Double> {
        val values = listOf(first, second, third).map {
            it.coerceIn(0.001, 0.999)
        }
        val total = values.sum()

        return mapOf(
            0 to values[0] / total,
            1 to values[1] / total,
            2 to values[2] / total
        )
    }

    private fun isKarsilikliGolMarket(
        normalizedTitle: String,
        market: IddaaMarket
    ): Boolean {
        if (normalizedTitle.contains("karsilikli gol") ||
            normalizedTitle.contains("kg")
        ) return true

        val names = market.o.map { normalize(it.n) }
        return names.contains("var") && names.contains("yok")
    }

    private fun isToplamGolMarket(
        normalizedTitle: String,
        market: IddaaMarket
    ): Boolean {
        if (!normalizedTitle.contains("toplam")) return false
        val names = market.o.map { normalize(it.n) }
        return names.contains("alt") && names.contains("ust")
    }

    private fun toplamCizgisi(
        normalizedTitle: String,
        market: IddaaMarket
    ): Double? {
        val regex = Regex("([0-9]+(?:\\.[0-9]+)?)")
        val titleMatch = regex.find(normalizedTitle)
        if (titleMatch != null) {
            return titleMatch.groupValues[1].toDoubleOrNull()
        }

        return market.sov?.replace(",", ".")?.toDoubleOrNull()
    }

    private fun isMacSonucuMarket(
        normalizedTitle: String,
        market: IddaaMarket
    ): Boolean {
        /*
         * KRİTİK MARKET AYRIMI
         *
         * 1. Çeyrek Sonucu, 2. Çeyrek Sonucu,
         * 1. Yarı Sonucu ve 1. Yarı / Maç Sonucu
         * marketleri de 1/X/2 seçimleri içerir.
         *
         * Bunları normal Maç Sonucu olarak kabul etmek,
         * tam maç modelinin olasılığını yanlışlıkla çeyrek/yarı
         * marketine taşır. Örneğin 6.78 oranlı bir seçimin
         * %66 görünmesinin ana sebeplerinden biri budur.
         *
         * Bu nedenle başlıkta çeyrek/yarı/devre ifadesi varsa
         * bu fonksiyon kesinlikle Maç Sonucu döndürmez.
         */
        if (
            normalizedTitle.contains("ceyrek") ||
            normalizedTitle.contains("yari") ||
            normalizedTitle.contains("devre")
        ) {
            return false
        }

        /*
         * Gerçek Maç Sonucu marketi.
         */
        if (normalizedTitle == "mac sonucu") {
            return true
        }

        /*
         * Başlık bulunamazsa yalnızca gerçekten 1/X/2
         * yapısına sahip marketlerde fallback yap.
         */
        val names = market.o.map { normalize(it.n) }

        return names.contains("1") &&
                names.contains("2") &&
                (names.contains("x") || names.contains("0"))
    }

    private fun sigmoid(value: Double): Double {
        return 1.0 / (1.0 + exp(-value))
    }

    private fun List<Double>.averageOrNull(): Double? {
        return if (isEmpty()) null else average()
    }

    private fun normalize(value: String?): String {
        return value
            ?.trim()
            ?.lowercase(java.util.Locale.forLanguageTag("tr-TR"))
            ?.replace('ı', 'i')
            ?.replace('ş', 's')
            ?.replace('ğ', 'g')
            ?.replace('ü', 'u')
            ?.replace('ö', 'o')
            ?.replace('ç', 'c')
            ?.replace(Regex("\\s+"), " ")
            ?: ""
    }
}
