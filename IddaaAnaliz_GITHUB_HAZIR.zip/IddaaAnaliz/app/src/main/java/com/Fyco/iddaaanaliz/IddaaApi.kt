@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import retrofit2.http.GET
import retrofit2.http.Query

interface IddaaApi {

    @GET("sportsbook/events")
    suspend fun getEvents(
        @Query("st") st: Int,
        @Query("type") type: Int = 0,
        @Query("version") version: Long = 0,
        @Query("live") live: Boolean = false
    ): IddaaResponse

    @GET("sportsbook/competitions")
    suspend fun getCompetitions(): IddaaCompetitionResponse

}
