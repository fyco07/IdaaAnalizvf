@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import kotlin.math.exp

/**
 * Oyuncu/kadro etkisi.
 *
 * Temel kural: oyuncu "kalitesi" ile oyuncunun takımdaki rol/önemi birbirine
 * karıştırılmaz. ESPN'den gözlenen dakika, ilk 11, gol/asist/şut gibi veriler
 * varsa bunlardan kanıt-ağırlıklı bir 0-100 ÖNEM PUANI türetilir. Veri yoksa
 * oyuncuya puan uydurulmaz.
 */
enum class OyuncuPozisyonu {
    KALECI,
    DEFANS,
    ORTA_SAHA,
    FORVET,
    BELIRSIZ
}

enum class OyuncuDurumTipi {
    SAKAT,
    CEZALI,
    SUPHELI,
    KADRO_DISI,
    DINLENDIRILIYOR,
    OYNAYACAK,
    BELIRSIZ
}

data class OyuncuEtkiVerisi(
    val oyuncuAdi: String,
    val oyuncuId: String? = null,
    val pozisyon: OyuncuPozisyonu = OyuncuPozisyonu.BELIRSIZ,
    val dakikaOrtalamasi: Double = 0.0,
    val ilkOnBirOrani: Double = 0.0,
    val macSayisi: Int = 0,
    val ilkOnBirSayisi: Int = 0,

    val gol: Double = 0.0,
    val asist: Double = 0.0,
    val xg: Double = 0.0,
    val xa: Double = 0.0,
    val sut: Double = 0.0,
    val isabetliSut: Double = 0.0,
    val kurtaris: Double = 0.0,
    val golYeme: Double = 0.0,

    val sayi: Double = 0.0,
    val asistBasketbol: Double = 0.0,
    val ribaund: Double = 0.0,
    val topKaybi: Double = 0.0,
    val topCalma: Double = 0.0,
    val kullanimOrani: Double = 0.0,

    val durum: OyuncuDurumTipi = OyuncuDurumTipi.BELIRSIZ,

    /** Sadece açıkça manuel verilmiş değerler için geriye dönük uyumluluk alanı. */
    val manuelOnemSkoru: Double? = null
)

data class OyuncuEtkiSonucu(
    val oyuncuAdi: String,
    val etkiSkoru: Double,
    val yoklukKatsayisi: Double,
    val takimHucumEtkisi: Double,
    val takimSavunmaEtkisi: Double,
    val toplamEtki: Double
)

/** Maç günü mevcut roster'ın pozisyon-ağırlıklı kalite özeti. */
data class TakimOyuncuKalitesi(
    val genel: Double,
    val hucum: Double,
    val savunma: Double,
    val kanitOyuncuSayisi: Int
)

enum class AnalizMarketTipi {
    MAC_SONUCU,
    CIFT_SANS,
    ALT_UST,
    KG,
    TAKIM_GOLU,
    TAKIM_SAYISI,
    HANDIKAP,
    DIGER
}

object OyuncuEtkiMotoru {

    fun etkiHesapla(
        spor: SporTuru,
        oyuncu: OyuncuEtkiVerisi
    ): OyuncuEtkiSonucu {
        val ham = hamEtkiHesapla(spor, oyuncu)
        val yoklukKatsayisi = when (oyuncu.durum) {
            OyuncuDurumTipi.SAKAT,
            OyuncuDurumTipi.CEZALI,
            OyuncuDurumTipi.KADRO_DISI -> 1.0
            OyuncuDurumTipi.SUPHELI -> 0.50
            OyuncuDurumTipi.DINLENDIRILIYOR -> 0.40
            OyuncuDurumTipi.OYNAYACAK,
            OyuncuDurumTipi.BELIRSIZ -> 0.0
        }
        return ham.copy(
            yoklukKatsayisi = yoklukKatsayisi,
            takimHucumEtkisi = ham.takimHucumEtkisi * yoklukKatsayisi,
            takimSavunmaEtkisi = ham.takimSavunmaEtkisi * yoklukKatsayisi,
            toplamEtki = (ham.toplamEtki * yoklukKatsayisi).coerceIn(0.0, 100.0)
        )
    }

    /** Durum katsayısını uygulamadan önceki oyuncu katkısı; replacement hesabında kullanılır. */
    fun hamEtkiHesapla(
        spor: SporTuru,
        oyuncu: OyuncuEtkiVerisi
    ): OyuncuEtkiSonucu {
        val temelEtki = when (spor) {
            SporTuru.FUTBOL -> futbolOnemSkoru(oyuncu)
            SporTuru.BASKETBOL -> basketbolOnemSkoru(oyuncu)
        }
        val (attackShare, defenseShare) = when (spor) {
            SporTuru.FUTBOL -> futbolRolPaylari(oyuncu.pozisyon)
            SporTuru.BASKETBOL -> 0.78 to 0.22
        }
        return OyuncuEtkiSonucu(
            oyuncuAdi = oyuncu.oyuncuAdi,
            etkiSkoru = temelEtki,
            yoklukKatsayisi = 1.0,
            takimHucumEtkisi = temelEtki * attackShare,
            takimSavunmaEtkisi = temelEtki * defenseShare,
            toplamEtki = temelEtki
        )
    }

    /** Oyuncunun dakika/maç/ilk11 kullanımından türetilen rol payı. */
    fun katilimKatsayisi(oyuncu: OyuncuEtkiVerisi): Double {
        val byMinutes = if (oyuncu.dakikaOrtalamasi > 0.0) {
            (oyuncu.dakikaOrtalamasi / 90.0).coerceIn(0.0, 1.0)
        } else 0.0

        val byStarts = when {
            oyuncu.ilkOnBirOrani > 0.0 -> oyuncu.ilkOnBirOrani.coerceIn(0.0, 1.0)
            oyuncu.macSayisi > 0 && oyuncu.ilkOnBirSayisi > 0 ->
                (oyuncu.ilkOnBirSayisi.toDouble() / oyuncu.macSayisi).coerceIn(0.0, 1.0)
            else -> 0.0
        }

        val byMatches = if (oyuncu.macSayisi > 0) {
            // Sadece gözlenen görünürlüğü temsil eder; dakika yoksa dakika uydurmaz.
            (1.0 - exp(-oyuncu.macSayisi.toDouble() / 8.0)).coerceIn(0.0, 1.0)
        } else 0.0

        return when {
            byMinutes > 0.0 && byStarts > 0.0 ->
                (0.70 * byMinutes + 0.30 * byStarts).coerceIn(0.0, 1.0)
            byMinutes > 0.0 -> byMinutes
            byStarts > 0.0 -> (0.70 * byStarts + 0.30 * byMatches).coerceIn(0.0, 1.0)
            byMatches > 0.0 -> byMatches
            else -> 0.0
        }
    }

    /**
     * Mevcut roster kalitesini tek bir takım puanı olarak değil, pozisyon
     * ağırlıklı hücum/savunma bileşenleriyle özetler. Bu değer yalnızca
     * maç-günü roster sinyali için küçük bir düzeltmede kullanılır; takım
     * ratinginin yerini almaz.
     */
    fun takimOyuncuKalitesi(oyuncular: List<OyuncuEtkiVerisi>): TakimOyuncuKalitesi {
        val adaylar = oyuncular
            .map { player ->
                val etki = hamEtkiHesapla(SporTuru.FUTBOL, player)
                val katilim = katilimKatsayisi(player)
                val secimPuani = etki.etkiSkoru * (0.55 + 0.45 * katilim)
                Triple(player, etki, secimPuani)
            }
            .filter { it.second.etkiSkoru > 0.0 }
            .sortedByDescending { it.third }
            .take(11)

        if (adaylar.isEmpty()) return TakimOyuncuKalitesi(0.0, 0.0, 0.0, 0)

        fun agirlik(player: OyuncuEtkiVerisi): Double =
            (0.55 + 0.45 * katilimKatsayisi(player)).coerceIn(0.55, 1.0)

        val toplamW = adaylar.sumOf { agirlik(it.first) }.coerceAtLeast(0.0001)
        val genel = adaylar.sumOf { tuple -> tuple.second.etkiSkoru * agirlik(tuple.first) } / toplamW

        val attackNumerator = adaylar.sumOf {
            val p = it.first
            val raw = hamEtkiHesapla(SporTuru.FUTBOL, p)
            raw.etkiSkoru * futbolRolPaylari(p.pozisyon).first * agirlik(p)
        }
        val attackDenominator = adaylar.sumOf {
            futbolRolPaylari(it.first.pozisyon).first * agirlik(it.first)
        }.coerceAtLeast(0.0001)

        val defenseNumerator = adaylar.sumOf {
            val p = it.first
            val raw = hamEtkiHesapla(SporTuru.FUTBOL, p)
            raw.etkiSkoru * futbolRolPaylari(p.pozisyon).second * agirlik(p)
        }
        val defenseDenominator = adaylar.sumOf {
            futbolRolPaylari(it.first.pozisyon).second * agirlik(it.first)
        }.coerceAtLeast(0.0001)

        return TakimOyuncuKalitesi(
            genel = genel.coerceIn(0.0, 100.0),
            hucum = (attackNumerator / attackDenominator).coerceIn(0.0, 100.0),
            savunma = (defenseNumerator / defenseDenominator).coerceIn(0.0, 100.0),
            kanitOyuncuSayisi = adaylar.count {
                it.first.macSayisi > 0 || it.first.dakikaOrtalamasi > 0.0 || hasFootballProduction(it.first)
            }
        )
    }

    fun takimEksikOyuncuEtkisi(
        spor: SporTuru,
        oyuncular: List<OyuncuEtkiVerisi>
    ): Double {
        if (oyuncular.isEmpty()) return 0.0

        val sonuclar = oyuncular
            .map { etkiHesapla(spor, it) }
            .filter { it.yoklukKatsayisi > 0.0 }
            .sortedByDescending { it.toplamEtki }

        var toplam = 0.0
        var katsayi = 1.0
        for (sonuc in sonuclar) {
            toplam += sonuc.toplamEtki * katsayi
            katsayi *= 0.70
        }
        return toplam.coerceIn(0.0, 100.0)
    }

    fun marketEtkisi(
        spor: SporTuru,
        market: AnalizMarketTipi,
        oyuncular: List<OyuncuEtkiVerisi>
    ): Double {
        if (oyuncular.isEmpty()) return 0.0

        return oyuncular.sumOf { oyuncu ->
            val sonuc = etkiHesapla(spor, oyuncu)
            if (sonuc.yoklukKatsayisi <= 0.0) return@sumOf 0.0
            when (spor) {
                SporTuru.FUTBOL -> futbolMarketEtkisi(market, sonuc, oyuncu)
                SporTuru.BASKETBOL -> basketbolMarketEtkisi(market, sonuc, oyuncu)
            }
        }.coerceIn(-100.0, 100.0)
    }

    private fun futbolOnemSkoru(oyuncu: OyuncuEtkiVerisi): Double {
        if (oyuncu.manuelOnemSkoru != null) {
            return oyuncu.manuelOnemSkoru.coerceIn(0.0, 100.0)
        }

        val appearances = oyuncu.macSayisi.coerceAtLeast(0)
        val starts = oyuncu.ilkOnBirSayisi.coerceIn(0, appearances)
        val totalMinutes = if (oyuncu.dakikaOrtalamasi > 0.0 && appearances > 0) {
            oyuncu.dakikaOrtalamasi * appearances
        } else 0.0

        val hasUsage = appearances > 0 || totalMinutes > 0.0 || starts > 0
        val hasProduction = hasFootballProduction(oyuncu)
        if (!hasUsage && !hasProduction) return 0.0

        // Per-90 hesapları artık gerçekten toplam dakika üzerinden yapılır.
        // Önceki sürümde dakikaOrtalamasi doğrudan toplam dakika gibi kullanıldığı
        // için "per90" aslında maç başına üretime dönüşebiliyordu.
        val reliability = if (totalMinutes > 0.0) {
            totalMinutes / (totalMinutes + 900.0)
        } else {
            appearances.toDouble() / (appearances + 10.0)
        }

        fun shrunkPer90(total: Double): Double {
            if (total <= 0.0 || totalMinutes <= 0.0) return 0.0
            val raw = total / (totalMinutes / 90.0)
            return raw * reliability
        }

        val goal90 = shrunkPer90(oyuncu.gol)
        val assist90 = shrunkPer90(oyuncu.asist)
        val sot90 = shrunkPer90(oyuncu.isabetliSut)
        val xg90 = shrunkPer90(oyuncu.xg)
        val xa90 = shrunkPer90(oyuncu.xa)

        val production = when (oyuncu.pozisyon) {
            OyuncuPozisyonu.FORVET ->
                35.0 * sat(goal90, 0.65) +
                    25.0 * sat(xg90, 0.75) +
                    15.0 * sat(assist90, 0.45) +
                    10.0 * sat(xa90, 0.45) +
                    15.0 * sat(sot90, 1.90)
            OyuncuPozisyonu.ORTA_SAHA ->
                20.0 * sat(goal90, 0.40) +
                    15.0 * sat(xg90, 0.45) +
                    25.0 * sat(assist90, 0.45) +
                    20.0 * sat(xa90, 0.45) +
                    20.0 * sat(sot90, 1.40)
            OyuncuPozisyonu.DEFANS ->
                10.0 * sat(goal90, 0.20) +
                    5.0 * sat(xg90, 0.20) +
                    15.0 * sat(assist90, 0.20) +
                    10.0 * sat(xa90, 0.20) +
                    10.0 * sat(sot90, 0.60) +
                    50.0 * reliability
            OyuncuPozisyonu.KALECI -> {
                val faced = oyuncu.kurtaris + oyuncu.golYeme
                val saveRate = if (faced > 0.0) oyuncu.kurtaris / faced else 0.0
                70.0 * saveRate.coerceIn(0.0, 1.0) * reliability + 30.0 * reliability
            }
            OyuncuPozisyonu.BELIRSIZ ->
                30.0 * sat(goal90, 0.50) +
                    15.0 * sat(xg90, 0.55) +
                    25.0 * sat(assist90, 0.40) +
                    10.0 * sat(xa90, 0.40) +
                    20.0 * sat(sot90, 1.20)
        }.coerceIn(0.0, 100.0)

        val exposure = if (totalMinutes > 0.0) {
            100.0 * (1.0 - exp(-totalMinutes / 1350.0))
        } else {
            100.0 * (1.0 - exp(-appearances.toDouble() / 10.0))
        }
        val startRatio = if (appearances > 0) starts.toDouble() / appearances else 0.0
        val startScore = startRatio * 100.0

        // Rol/oynama süresi ana sinyal; üretim ise kaliteyi ayrıştıran ek kanıt.
        // Böylece 1-2 kısa maçta atılan goller oyuncuyu otomatik olarak 90+ yapmaz.
        val productionWeight = when (oyuncu.pozisyon) {
            OyuncuPozisyonu.FORVET -> 0.28
            OyuncuPozisyonu.ORTA_SAHA -> 0.25
            OyuncuPozisyonu.DEFANS -> 0.12
            OyuncuPozisyonu.KALECI -> 0.20
            OyuncuPozisyonu.BELIRSIZ -> 0.20
        }
        val usageWeight = 0.45
        val startWeight = 1.0 - usageWeight - productionWeight

        return (exposure * usageWeight + startScore * startWeight + production * productionWeight)
            .coerceIn(0.0, 100.0)
    }

    /** ESPN futbol istatistiklerinden gerçek üretim kanıtı var mı? */
    private fun hasFootballProduction(oyuncu: OyuncuEtkiVerisi): Boolean =
        oyuncu.gol > 0.0 || oyuncu.asist > 0.0 || oyuncu.xg > 0.0 || oyuncu.xa > 0.0 ||
            oyuncu.sut > 0.0 || oyuncu.isabetliSut > 0.0 ||
            oyuncu.kurtaris > 0.0 || oyuncu.golYeme > 0.0

    private fun basketbolOnemSkoru(oyuncu: OyuncuEtkiVerisi): Double {
        if (oyuncu.manuelOnemSkoru != null) return oyuncu.manuelOnemSkoru.coerceIn(0.0, 100.0)
        val evidence = oyuncu.sayi > 0.0 || oyuncu.asistBasketbol > 0.0 ||
            oyuncu.ribaund > 0.0 || oyuncu.kullanimOrani > 0.0 || oyuncu.dakikaOrtalamasi > 0.0
        if (!evidence) return 0.0
        var score = 0.0
        score += 35.0 * sat(oyuncu.sayi, 18.0)
        score += 15.0 * sat(oyuncu.asistBasketbol, 6.0)
        score += 12.0 * sat(oyuncu.ribaund, 8.0)
        score += 20.0 * sat(oyuncu.kullanimOrani, 24.0)
        score += 18.0 * sat(oyuncu.dakikaOrtalamasi, 30.0)
        return score.coerceIn(0.0, 100.0)
    }

    private fun futbolRolPaylari(position: OyuncuPozisyonu): Pair<Double, Double> = when (position) {
        OyuncuPozisyonu.FORVET -> 0.90 to 0.10
        OyuncuPozisyonu.ORTA_SAHA -> 0.65 to 0.35
        OyuncuPozisyonu.DEFANS -> 0.25 to 0.75
        OyuncuPozisyonu.KALECI -> 0.05 to 0.95
        OyuncuPozisyonu.BELIRSIZ -> 0.50 to 0.50
    }

    private fun futbolMarketEtkisi(
        market: AnalizMarketTipi,
        sonuc: OyuncuEtkiSonucu,
        oyuncu: OyuncuEtkiVerisi
    ): Double {
        val hucum = sonuc.takimHucumEtkisi
        val savunma = sonuc.takimSavunmaEtkisi
        return when (market) {
            AnalizMarketTipi.ALT_UST -> when (oyuncu.pozisyon) {
                OyuncuPozisyonu.FORVET, OyuncuPozisyonu.ORTA_SAHA -> -hucum * 0.30
                OyuncuPozisyonu.DEFANS, OyuncuPozisyonu.KALECI -> savunma * 0.18
                else -> -hucum * 0.10
            }
            AnalizMarketTipi.TAKIM_GOLU -> -hucum * 0.55
            AnalizMarketTipi.KG -> when (oyuncu.pozisyon) {
                OyuncuPozisyonu.FORVET, OyuncuPozisyonu.ORTA_SAHA -> -hucum * 0.20
                OyuncuPozisyonu.DEFANS, OyuncuPozisyonu.KALECI -> savunma * 0.22
                else -> 0.0
            }
            AnalizMarketTipi.MAC_SONUCU -> -hucum * 0.25 - savunma * 0.18
            AnalizMarketTipi.CIFT_SANS -> -hucum * 0.16 - savunma * 0.10
            AnalizMarketTipi.HANDIKAP -> -hucum * 0.22 - savunma * 0.14
            else -> 0.0
        }
    }

    private fun basketbolMarketEtkisi(
        market: AnalizMarketTipi,
        sonuc: OyuncuEtkiSonucu,
        oyuncu: OyuncuEtkiVerisi
    ): Double {
        val hucum = sonuc.takimHucumEtkisi
        val savunma = sonuc.takimSavunmaEtkisi
        return when (market) {
            AnalizMarketTipi.ALT_UST -> -hucum * 0.40 + savunma * 0.05
            AnalizMarketTipi.TAKIM_SAYISI -> -hucum * 0.60
            AnalizMarketTipi.MAC_SONUCU -> -hucum * 0.35 - savunma * 0.22
            AnalizMarketTipi.HANDIKAP -> -hucum * 0.30 - savunma * 0.18
            AnalizMarketTipi.CIFT_SANS -> -hucum * 0.22
            else -> 0.0
        }
    }

    private fun sat(value: Double, reference: Double): Double {
        if (reference <= 0.0 || value <= 0.0) return 0.0
        return (1.0 - exp(-value / reference)).coerceIn(0.0, 1.0)
    }

    private fun saturating(value: Double, reference: Double): Double = sat(value.coerceAtLeast(0.0), reference)
}
