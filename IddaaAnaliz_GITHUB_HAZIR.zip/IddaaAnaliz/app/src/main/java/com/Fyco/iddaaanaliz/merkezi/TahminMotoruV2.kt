@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

/** Faz 9: merkezi model çıktısını market bağımsız bir tahmin sözleşmesine dönüştürür. */
object TahminMotoruV2 {
    data class Prediction(val outcome: String, val probability: Double, val edge: Double?, val ev: Double?, val confidence: Double)
    fun predict(market: String, dist: OlasilikMotoruV2.ScoreDistribution, odds: Map<String,Double> = emptyMap()): List<Prediction> {
        val probs = OlasilikMotoruV2.market(dist, market)
        return probs.map { (outcome,p) ->
            val value = odds[outcome]?.let { BahisMatematigi.evaluate(p,it) }
            Prediction(outcome,p,value?.edge,value?.ev,confidence(p))
        }.sortedByDescending { it.probability }
    }
    private fun confidence(p: Double) = (0.50 + kotlin.math.abs(p-0.50)).coerceIn(0.50,0.99)
}
