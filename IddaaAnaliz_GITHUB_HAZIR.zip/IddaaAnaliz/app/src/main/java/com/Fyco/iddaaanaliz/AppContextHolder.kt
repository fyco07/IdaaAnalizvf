@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.content.Context

/** Application context bridge for non-Android-provider singletons. */
internal object AppContextHolder {
    @Volatile
    var context: Context? = null
}
