@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * ESPN istemcisi.
 *
 * Tarihsel veri kritik olduğu için tek hosta bağlı kalmaz.
 * site.api.espn.com geçici DNS/bağlantı hatası verirse
 * site.web.api.espn.com üzerinden aynı Site API çağrısı denenir.
 * Her host birden fazla kez denenir; böylece geçici ağ hatası
 * 365 günlük zinciri gereksiz yere durdurmaz.
 */
object ESPNClient {

    private const val PRIMARY_BASE_URL = "https://site.api.espn.com/"
    private const val FALLBACK_BASE_URL = "https://site.web.api.espn.com/"
    private const val WEB_BASE_URL = "https://www.espn.com/"

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    val api: ESPNApi by lazy {
        Retrofit.Builder()
            .baseUrl(PRIMARY_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ESPNApi::class.java)
    }

    private val fallbackApi: ESPNApi by lazy {
        Retrofit.Builder()
            .baseUrl(FALLBACK_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ESPNApi::class.java)
    }

    /**
     * Sport/league bağımsız scoreboard çağrısı.
     * Önce site.api.espn.com, DNS/HTTP erişim sorunu olursa
     * site.web.api.espn.com denenir. Böylece sonuç sağlayıcısı
     * tek host arızasına bağlı kalmaz.
     */
    suspend fun skorTahtasiGenelGuvenli(
        sport: String,
        league: String,
        tarih: String
    ): JsonObject {
        val cleanSport = sport.trim().trim('/').ifBlank { "soccer" }
        val cleanLeague = league.trim().trim('/').ifBlank { "all" }
        val cleanDate = tarih.replace("-", "")
        val path = "apis/site/v2/sports/$cleanSport/$cleanLeague/scoreboard"
        val query = "?dates=$cleanDate&limit=1000"

        var lastError: Throwable? = null
        val hosts = listOf(PRIMARY_BASE_URL, FALLBACK_BASE_URL, WEB_BASE_URL)
        repeat(2) { round ->
            val ordered = if (round % 2 == 0) hosts else hosts.asReversed()
            for (host in ordered) {
                val url = host.trimEnd('/') + "/" + path + query
                try {
                    val request = okhttp3.Request.Builder()
                        .url(url)
                        .header("Accept", "application/json")
                        .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.8")
                        .header("User-Agent", "Mozilla/5.0 (Android) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                        .build()
                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            lastError = java.io.IOException("HTTP ${response.code}")
                        } else {
                            val body = response.body?.string().orEmpty()
                            if (body.isBlank()) {
                                lastError = java.io.IOException("ESPN boş yanıt")
                            } else {
                                return JsonParser.parseString(body).asJsonObject
                            }
                        }
                    }
                } catch (e: Throwable) {
                    lastError = e
                }
                kotlinx.coroutines.delay(200L)
            }
            kotlinx.coroutines.delay(350L * (round + 1))
        }
        throw (lastError ?: java.io.IOException("ESPN scoreboard erişilemedi"))
    }

    /**
     * ESPN Site API üzerinde genel JSON GET. Kadro/sakatlık gibi tahmin öncesi
     * yardımcı veriler için kullanılır; iki ESPN hostu arasında güvenli fallback
     * uygular.
     */
    suspend fun getJson(path: String): JsonObject {
        val cleanPath = path.trim().trimStart('/')
        var lastError: Throwable? = null
        val hosts = listOf(PRIMARY_BASE_URL, FALLBACK_BASE_URL, WEB_BASE_URL)
        repeat(2) { round ->
            val ordered = if (round % 2 == 0) hosts else hosts.asReversed()
            for (host in ordered) {
                val url = host.trimEnd('/') + "/" + cleanPath
                try {
                    val request = okhttp3.Request.Builder()
                        .url(url)
                        .header("Accept", "application/json")
                        .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.8")
                        .header("User-Agent", "Mozilla/5.0 (Android) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                        .build()
                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            lastError = IOException("HTTP ${response.code}")
                        } else {
                            val body = response.body?.string().orEmpty()
                            if (body.isBlank()) {
                                lastError = IOException("ESPN boş yanıt")
                            } else {
                                return JsonParser.parseString(body).asJsonObject
                            }
                        }
                    }
                } catch (e: Throwable) {
                    lastError = e
                }
                delay(150L)
            }
            delay(300L * (round + 1))
        }
        throw (lastError ?: IOException("ESPN JSON erişilemedi"))
    }


    /**
     * ESPN Core API için JSON GET. Oyuncu sezon istatistikleri Site API
     * roster çağrısından ayrı bir kaynaktan gelir; bu çağrı yalnızca roster
     * yenilemesi sırasında kullanılır ve sonuç yerel oyuncu havuzuna yazılır.
     */
    suspend fun getCoreJson(path: String): JsonObject {
        val cleanPath = path.trim().trimStart('/')
        val url = "https://sports.core.api.espn.com/" + cleanPath
        val request = okhttp3.Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.8")
            .header("User-Agent", "Mozilla/5.0 (Android) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
            .build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val body = response.body?.string().orEmpty()
            if (body.isBlank()) throw IOException("ESPN Core boş yanıt")
            JsonParser.parseString(body).asJsonObject
        }
    }

    /**
     * Günlük ESPN skor tahtasını güvenli şekilde alır.
     *
     * Önce ana host, sonra alternatif host denenir.
     * 5xx ve IOException durumlarında ikinci tur tekrar yapılır.
     * 4xx gibi kalıcı istek hataları doğrudan üst kata bırakılır.
     */
    suspend fun skorTahtasiGuvenli(tarih: String): JsonObject =
        skorTahtasiGenelGuvenli(
            sport = "soccer",
            league = "all",
            tarih = tarih
        )

}
