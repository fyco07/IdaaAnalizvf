@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface ESPNOyuncuHavuzuDao {

    @Query("SELECT * FROM espn_takim_kadro_cache WHERE cacheKey = :cacheKey LIMIT 1")
    suspend fun takimMeta(cacheKey: String): ESPNTakimKadroCache?

    @Query("SELECT * FROM espn_takim_kadro_cache WHERE teamId = :teamId ORDER BY rosterSyncedAt DESC LIMIT 1")
    suspend fun takimMetaByTeamId(teamId: String): ESPNTakimKadroCache?

    @Query("SELECT * FROM espn_takim_kadro_cache ORDER BY rosterSyncedAt DESC")
    suspend fun tumTakimMetalariniGetir(): List<ESPNTakimKadroCache>

    @Query("SELECT * FROM espn_oyuncu_havuzu WHERE teamKey = :teamKey ORDER BY playerName")
    suspend fun oyuncular(teamKey: String): List<ESPNOyuncuHavuzu>

    @Query("SELECT * FROM espn_oyuncu_havuzu WHERE teamId = :teamId ORDER BY savedAt DESC, playerName")
    suspend fun oyuncularByTeamId(teamId: String): List<ESPNOyuncuHavuzu>

    @Query("SELECT * FROM espn_oyuncu_durum_cache WHERE teamKey = :teamKey")
    suspend fun durumlar(teamKey: String): List<ESPNOyuncuDurumCache>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun metaKaydet(meta: ESPNTakimKadroCache)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun oyuncularKaydet(rows: List<ESPNOyuncuHavuzu>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun durumlarKaydet(rows: List<ESPNOyuncuDurumCache>)

    @Query("DELETE FROM espn_oyuncu_havuzu WHERE teamKey = :teamKey")
    suspend fun oyunculariTemizle(teamKey: String)

    @Query("DELETE FROM espn_oyuncu_durum_cache WHERE teamKey = :teamKey")
    suspend fun durumlariTemizle(teamKey: String)

    @Query("UPDATE espn_takim_kadro_cache SET injuryCheckedAt = :checkedAt, lastSuccessfulAt = CASE WHEN :checkedAt > 0 THEN :checkedAt ELSE lastSuccessfulAt END WHERE cacheKey = :cacheKey")
    suspend fun durumKontrolZamaniGuncelle(cacheKey: String, checkedAt: Long)

    @Transaction
    suspend fun rosterSnapshotKaydet(
        meta: ESPNTakimKadroCache,
        oyuncular: List<ESPNOyuncuHavuzu>
    ) {
        oyunculariTemizle(meta.cacheKey)
        if (oyuncular.isNotEmpty()) oyuncularKaydet(oyuncular)
        metaKaydet(meta)
    }

    @Transaction
    suspend fun injurySnapshotKaydet(
        cacheKey: String,
        checkedAt: Long,
        durumlar: List<ESPNOyuncuDurumCache>
    ) {
        durumlariTemizle(cacheKey)
        if (durumlar.isNotEmpty()) durumlarKaydet(durumlar)
        durumKontrolZamaniGuncelle(cacheKey, checkedAt)
    }

    @Query("DELETE FROM espn_takim_kadro_cache")
    suspend fun tumMetaTemizle()

    @Query("DELETE FROM espn_oyuncu_havuzu")
    suspend fun tumOyunculariTemizle()

    @Query("DELETE FROM espn_oyuncu_durum_cache")
    suspend fun tumDurumlariTemizle()
}
