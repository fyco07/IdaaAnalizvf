@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import android.util.Log
import com.Fyco.iddaaanaliz.AnalizMotoru
import com.Fyco.iddaaanaliz.IddaaMarket
import com.Fyco.iddaaanaliz.IddaaOutcome
import com.Fyco.iddaaanaliz.SporTuru
import java.util.Locale
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln

/**
 * Merkezi Veri Havuzu geçmiş sonuçlarından üretilen Kendi Modeli'nin canlı tahmin katmanı.
 *
 * TEMEL KURAL:
 * Bütün futbol marketleri aynı (ev golü, deplasman golü) skor dağılımından
 * türetilir. Böylece MS, KG, Alt/Üst, Çifte Şans ve takım gol marketleri
 * birbirleriyle matematiksel olarak tutarlı kalır.
 *
 * İddaa oranı model girdisi değildir.
 */
object MerkeziFutbolTahmincisi {

    fun marketOlasiliklari(
        market: IddaaMarket,
        spor: SporTuru,
        evTakimAdi: String?,
        deplasmanTakimAdi: String?
    ): Map<Int, Double> {
        return marketOlasiliklariBatch(
            markets = listOf(market),
            spor = spor,
            evTakimAdi = evTakimAdi,
            deplasmanTakimAdi = deplasmanTakimAdi
        )[market.i].orEmpty()
    }

    /**
     * Aynı maçtaki bütün futbol marketleri için Kendi Modeli skor dağılımını
     * yalnızca BİR KEZ hesaplar. 15-30 markette tekrar tekrar Poisson +
     * kalibrasyon + takım ratingi hesabı yapılmasını engeller.
     */
    fun marketOlasiliklariBatch(
        markets: List<IddaaMarket>,
        spor: SporTuru,
        evTakimAdi: String?,
        deplasmanTakimAdi: String?,
        adjustments: MerkeziFutbolModelHavuzu.MatchModelAdjustments = MerkeziFutbolModelHavuzu.MatchModelAdjustments()
    ): Map<Long, Map<Int, Double>> {
        if (spor != SporTuru.FUTBOL || evTakimAdi.isNullOrBlank() || deplasmanTakimAdi.isNullOrBlank()) {
            return emptyMap()
        }

        // DİKKAT: Burada ESPN kaynağından canlı rating okunmaz.
        // Merkezi model, daha önce Merkezi Veri Havuzu'ndan hazırlanmış snapshot'tır.
        // Tarihsel takım bulunamazsa yanlış bir takımı seçmek yerine nötr prior
        // kullanılır. Böylece maç analizi boş kalmaz; düşük örneklem karar katmanında
        // VERİ_YETERSİZ olarak korunur ve Güçlü Seçimler listesine giremez.
        val homeResolution = MerkeziFutbolModelHavuzu.takimTahminIcin(evTakimAdi)
        val awayResolution = MerkeziFutbolModelHavuzu.takimTahminIcin(deplasmanTakimAdi)
        if (homeResolution == null || awayResolution == null) {
            Log.d(
                "MERKEZI_MODEL",
                "MERKEZI_TAHMIN_TAKIM_COZULEMEDI ev=$evTakimAdi dep=$deplasmanTakimAdi"
            )
            return emptyMap()
        }

        val homeRating = homeResolution.model
        val awayRating = awayResolution.model
        if (!homeResolution.tarihsel || !awayResolution.tarihsel) {
            Log.d(
                "MERKEZI_MODEL",
                "MERKEZI_NEUTRAL_PRIOR ev=$evTakimAdi dep=$deplasmanTakimAdi " +
                    "tarihsel=${homeResolution.tarihsel}/${awayResolution.tarihsel} " +
                    "sample=${homeRating.macSayisi}/${awayRating.macSayisi}"
            )
        }

        val lambdas = MerkeziFutbolModelHavuzu.lambdalarForPrediction(
            homeTeamName = evTakimAdi,
            awayTeamName = deplasmanTakimAdi,
            adjustments = adjustments
        ) ?: return emptyMap()
        val lambdaHome = lambdas.first
        val lambdaAway = lambdas.second
        val rawDistribution = com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.poissonDagilimi(
            lambdaHome,
            lambdaAway,
            maxGol = 10,
            rho = MerkeziFutbolModelHavuzu.dixonColesRho()
        )
        // Aşırı uçlara gitmemesi için model kendi olasılık uzayını korur;
        // oran/edge/confidence burada hiçbir şekilde kullanılmaz.
        val distribution = calibrateDistribution(rawDistribution, MerkeziFutbolModelHavuzu.calibrationTemperature())

        val result = LinkedHashMap<Long, Map<Int, Double>>()
        markets.forEach { market ->
            // UI/karar motoru ile aynı resmi + deterministik market sınıflandırmasını
            // kullan; ardından st/sov ile motorun anlayacağı kanonik forma getir.
            // Böylece config cache eksik olsa bile örn. st=101 "TOPLAM 2.5"
            // başlığı, güvenli biçimde "ALT/ÜST 2.5" olarak çözülebilir.
            val title = canonicalMarketTitle(market)
            if (title.isBlank() || title == "iddaa marketi") {
                Log.d(
                    "MERKEZI_MODEL",
                    "MARKET_BASLIK_YOK market=${market.i} t=${market.t} st=${market.st} sov=${market.sov}"
                )
                return@forEach
            }
            if (isUnsupportedMarket(title) && !isFirstHalfResult(title, market)) return@forEach

            val probabilities = marketOlasiliklariDagilimdan(
                market = market,
                title = title,
                distribution = distribution,
                lambdaHome = lambdaHome,
                lambdaAway = lambdaAway,
            )
            if (probabilities.isNotEmpty()) result[market.i] = probabilities
        }

        Log.d(
            "MERKEZI_MODEL",
            "MERKEZI_MAC_BATCH ev=$evTakimAdi dep=$deplasmanTakimAdi market=${result.size}/${markets.size} " +
                "lambda=${"%.3f".format(lambdaHome)}/${"%.3f".format(lambdaAway)} " +
                "elo=${"%.0f".format(homeRating.elo)}/${"%.0f".format(awayRating.elo)}"
        )
        return result
    }


    private fun canonicalMarketTitle(market: IddaaMarket): String {
        val configured = normalize(AnalizMotoru.marketBasligi(market))
        val sov = market.sov?.trim()?.replace(',', '.')?.takeIf { it.isNotBlank() }
        val names = market.o.map { normalize(it.n) }.toSet()

        val isMatchResultShape = names.contains("1") &&
            names.contains("2") &&
            (names.contains("x") || names.contains("0"))
        val isDoubleChanceShape = names.count {
            it in setOf("1x", "x2", "12", "x1", "2x")
        } >= 2
        val isPlainBttsShape = names == setOf("var", "yok")

        return when (market.st) {
            62, 100 -> when {
                // st=62 ve st=100 futbol handikap marketleri olarak kullanılıyor.
                // Başlığın yanlışlıkla "mac sonucu" olmasını önlemek için sov
                // çizgisini kanonik başlığa taşıyoruz.
                configured.contains("handikap") -> configured
                sov != null && sov != "0" && sov != "0.0" -> "handikap $sov"
                else -> "handikap"
            }
            36, 61, 70, 79 -> "mac sonucu"
            60 -> if (sov != null) "ev sahibi $sov gol alt ust" else "ev sahibi gol alt ust"
            101 -> if (sov != null) "alt ust $sov" else "alt ust"
            7 -> if (sov != null) "mac sonucu ve alt ust $sov" else "mac sonucu ve alt ust"
            700 -> if (sov != null) "alt ust $sov ve karsilikli gol" else "alt ust ve karsilikli gol"
            720 -> "karsilikli gol"
            else -> when {
                isMatchResultShape -> "mac sonucu"
                isDoubleChanceShape -> "cifte sans"
                isPlainBttsShape -> "karsilikli gol"
                configured.isBlank() || configured == "iddaa marketi" -> ""
                else -> configured
            }
        }
    }

    private fun marketOlasiliklariDagilimdan(
        market: IddaaMarket,
        title: String,
        distribution: com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.SkorDagilimi,
        lambdaHome: Double,
        lambdaAway: Double
    ): Map<Int, Double> {
        val (homeWin, draw, awayWin) = com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.macSonucu(distribution)
        val outcomes = market.o.filter { it.oynanabilirOran > 1.0 }
        if (outcomes.size < 2) return emptyMap()

        val result = linkedMapOf<Int, Double>()

        when {
            isExactScoreMarket(title, outcomes) -> {
                outcomes.forEach { outcome ->
                    parseExactScore(outcome.n)?.let { score ->
                        result[outcome.no] = distribution.hucreler[score] ?: 0.0
                    }
                }
            }

            isFirstHalfResult(title, market) -> {
                val half = com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.poissonDagilimi(
                    lambdaHome * 0.46,
                    lambdaAway * 0.46,
                    maxGol = 8,
                    rho = MerkeziFutbolModelHavuzu.dixonColesRho()
                )
                val (h1, hx, h2) = com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.macSonucu(half)
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "1" -> result[outcome.no] = h1
                        "x", "0" -> result[outcome.no] = hx
                        "2" -> result[outcome.no] = h2
                    }
                }
            }

            isHandicapMarket(title, market) -> {
                val line = extractHandicapLine(title, market)
                Log.d(
                    "MERKEZI_MODEL",
                    "HANDIKAP_HESAP market=${market.i} st=${market.st} sov=${market.sov} " +
                        "title=$title line=${line ?: "NULL"}"
                )
                if (line == null) return emptyMap()

                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "1", "ev" -> result[outcome.no] = probability(distribution) { sc ->
                            sc.first.toDouble() + line > sc.second.toDouble()
                        }
                        "x", "0", "beraberlik", "draw" -> result[outcome.no] = probability(distribution) { sc ->
                            kotlin.math.abs((sc.first.toDouble() + line) - sc.second.toDouble()) < 1e-9
                        }
                        "2", "dep", "deplasman" -> result[outcome.no] = probability(distribution) { sc ->
                            sc.first.toDouble() + line < sc.second.toDouble()
                        }
                    }
                }
            }

            isMatchResult(title, market) -> {
                // MS 1/X/2 üçlü bir örnek uzayıdır. API bir sonucu kapatmış
                // veya göndermemişse kalan iki sonucu %100'e normalize etmek
                // kesinlikle yapılmaz; aksi halde 1/X/2 birbirinden kopar.
                if (!hasCompleteMatchResultOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "1", "ev" -> result[outcome.no] = homeWin
                        "x", "0", "0.0", "beraberlik", "draw" -> result[outcome.no] = draw
                        "2", "dep", "deplasman" -> result[outcome.no] = awayWin
                    }
                }
            }

            isDoubleChance(title, market) -> {
                outcomes.forEach { outcome ->
                    when (normalizeCompact(outcome.n)) {
                        "1x", "x1" -> result[outcome.no] = homeWin + draw
                        "x2", "2x" -> result[outcome.no] = draw + awayWin
                        "12", "1ve2" -> result[outcome.no] = homeWin + awayWin
                    }
                }
            }

            isPlainBtts(title, market) -> {
                val btts = com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.btts(distribution)
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "var" -> result[outcome.no] = btts
                        "yok" -> result[outcome.no] = 1.0 - btts
                    }
                }
            }

            isMatchResultAndBtts(title) -> {
                val btts = com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.btts(distribution)
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    val resultProb = when {
                        selection.startsWith("1") && selection.endsWith("var") -> probability(distribution) { s -> s.first > s.second && s.first > 0 && s.second > 0 }
                        selection.startsWith("1") && selection.endsWith("yok") -> probability(distribution) { s -> s.first > s.second && !(s.first > 0 && s.second > 0) }
                        selection.startsWith("x") && selection.endsWith("var") -> probability(distribution) { s -> s.first == s.second && s.first > 0 }
                        selection.startsWith("x") && selection.endsWith("yok") -> probability(distribution) { s -> s.first == s.second && !(s.first > 0 && s.second > 0) }
                        selection.startsWith("2") && selection.endsWith("var") -> probability(distribution) { s -> s.first < s.second && s.first > 0 && s.second > 0 }
                        selection.startsWith("2") && selection.endsWith("yok") -> probability(distribution) { s -> s.first < s.second && !(s.first > 0 && s.second > 0) }
                        selection == "var" -> btts
                        selection == "yok" -> 1.0 - btts
                        else -> null
                    }
                    if (resultProb != null) result[outcome.no] = resultProb
                }
            }

            isMatchResultAndTotalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    val p = when {
                        selection.startsWith("1") && selection.endsWith("alt") -> probability(distribution) { s -> s.first > s.second && s.first + s.second <= floor(line).toInt() }
                        selection.startsWith("1") && selection.endsWith("ust") -> probability(distribution) { s -> s.first > s.second && s.first + s.second > floor(line).toInt() }
                        selection.startsWith("x") && selection.endsWith("alt") -> probability(distribution) { s -> s.first == s.second && s.first + s.second <= floor(line).toInt() }
                        selection.startsWith("x") && selection.endsWith("ust") -> probability(distribution) { s -> s.first == s.second && s.first + s.second > floor(line).toInt() }
                        selection.startsWith("2") && selection.endsWith("alt") -> probability(distribution) { s -> s.first < s.second && s.first + s.second <= floor(line).toInt() }
                        selection.startsWith("2") && selection.endsWith("ust") -> probability(distribution) { s -> s.first < s.second && s.first + s.second > floor(line).toInt() }
                        else -> null
                    }
                    if (p != null) result[outcome.no] = p
                }
            }

            isTotalOverUnderAndBtts(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val limit = floor(line).toInt()
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    val p = when {
                        selection.contains("alt") && selection.endsWith("var") -> probability(distribution) { s -> s.first + s.second <= limit && s.first > 0 && s.second > 0 }
                        selection.contains("alt") && selection.endsWith("yok") -> probability(distribution) { s -> s.first + s.second <= limit && !(s.first > 0 && s.second > 0) }
                        selection.contains("ust") && selection.endsWith("var") -> probability(distribution) { s -> s.first + s.second > limit && s.first > 0 && s.second > 0 }
                        selection.contains("ust") && selection.endsWith("yok") -> probability(distribution) { s -> s.first + s.second > limit && !(s.first > 0 && s.second > 0) }
                        else -> null
                    }
                    if (p != null) result[outcome.no] = p
                }
            }

            isTotalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val under = 1.0 - com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.over(distribution, line)
                val over = 1.0 - under
                if (!hasCompleteTwoWayOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (selectionKind(outcome.n)) {
                        SelectionKind.UNDER -> result[outcome.no] = under
                        SelectionKind.OVER -> result[outcome.no] = over
                        else -> Unit
                    }
                }
            }

            isHomeGoalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val over = marginalOver(distribution, line, home = true)
                if (!hasCompleteTwoWayOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (selectionKind(outcome.n)) {
                        SelectionKind.UNDER -> result[outcome.no] = 1.0 - over
                        SelectionKind.OVER -> result[outcome.no] = over
                        else -> Unit
                    }
                }
            }

            isAwayGoalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val over = marginalOver(distribution, line, home = false)
                if (!hasCompleteTwoWayOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (selectionKind(outcome.n)) {
                        SelectionKind.UNDER -> result[outcome.no] = 1.0 - over
                        SelectionKind.OVER -> result[outcome.no] = over
                        else -> Unit
                    }
                }
            }

            isTotalOddEven(title) -> {
                val odd = distribution.hucreler
                    .filterKeys { (h, a) -> (h + a) % 2 == 1 }
                    .values.sum()
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "tek" -> result[outcome.no] = odd
                        "cift" -> result[outcome.no] = 1.0 - odd
                    }
                }
            }

            isTotalGoalsRange(title) -> {
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    parseGoalRange(selection)?.let { range ->
                        result[outcome.no] = probability(distribution) { s ->
                            val total = s.first + s.second
                            total in range
                        }
                    }
                }
            }

            else -> return emptyMap()
        }

        return finalizeResult(result, outcomes)
    }

    // Geriye dönük uyumluluk.
    fun marketOlasiliklari(
        market: IddaaMarket,
        spor: SporTuru,
        veri: com.Fyco.iddaaanaliz.MacDisVerisi?
    ): Map<Int, Double> {
        if (veri == null) return emptyMap()
        return marketOlasiliklari(market, spor, veri.evSahibi.isim, veri.deplasman.isim)
    }

    private fun probability(
        distribution: com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.SkorDagilimi,
        predicate: (Pair<Int, Int>) -> Boolean
    ): Double = distribution.hucreler.filterKeys(predicate).values.sum().coerceIn(0.0, 1.0)

    private fun marginalOver(
        distribution: com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.SkorDagilimi,
        line: Double,
        home: Boolean
    ): Double {
        val limit = floor(line).toInt()
        val under = distribution.hucreler
            .filterKeys { score ->
                val goals = if (home) score.first else score.second
                goals <= limit
            }
            .values.sum()
        return (1.0 - under).coerceIn(0.0, 1.0)
    }

    private fun isUnsupportedMarket(title: String): Boolean {
        val compact = title.replace(" ", "")
        return title.contains("ceyrek") ||
                title.contains("devre") ||
                title.contains("korner") ||
                title.contains("kart") ||
                title.contains("sut") ||
                title.contains("faul") ||
                title.contains("ofsayt") ||
                title.contains("oyuncu") ||
                compact.contains("ilkyar")
    }

    private fun isFirstHalfResult(title: String, market: IddaaMarket): Boolean =
        title.contains("ilk yari") && !title.contains("alt/ust") && !title.contains("karsilikli gol") && hasCompleteMatchResultOutcomes(market.o)

    private fun isExactScoreMarket(title: String, outcomes: List<IddaaOutcome>): Boolean =
        (title.contains("dogru skor") || title.contains("tahmini skor") || title.contains("skor")) &&
            outcomes.any { parseExactScore(it.n) != null }

    private fun parseExactScore(selection: String?): Pair<Int, Int>? {
        val m = Regex("^(\\d+)[-:](\\d+)$").matchEntire(normalizeCompact(selection)) ?: return null
        val h = m.groupValues[1].toIntOrNull() ?: return null
        val a = m.groupValues[2].toIntOrNull() ?: return null
        return h.coerceIn(0, 10) to a.coerceIn(0, 10)
    }

    private fun isMatchResult(title: String, market: IddaaMarket): Boolean {
        if (title == "mac sonucu") return true
        if (title.contains("handikap")) return false
        val names = market.o.map { normalize(it.n) }
        return names.contains("1") && names.contains("2") && (names.contains("x") || names.contains("0"))
    }

    private fun isDoubleChance(title: String, market: IddaaMarket): Boolean {
        if (title.contains("cifte sans") && !title.contains("yari") && !title.contains("ceyrek")) return true
        val names = market.o.map { normalize(it.n) }.toSet()
        return names.count { it in setOf("1x", "x2", "12", "x1", "2x") } >= 2
    }

    private fun isPlainBtts(title: String, market: IddaaMarket): Boolean {
        if (title == "karsilikli gol") return true
        val names = market.o.map { normalize(it.n) }.toSet()
        return names == setOf("var", "yok")
    }

    private fun isMatchResultAndBtts(title: String): Boolean =
        (title.contains("mac sonucu") || title.contains("sonucu")) &&
                title.contains("karsilikli gol")

    private fun isMatchResultAndTotalOverUnder(title: String): Boolean =
        (title.contains("mac sonucu") || title.contains("sonucu")) &&
                (title.contains("alt/ust") || title.contains("alt ust")) &&
                !title.contains("karsilikli gol")

    private fun isTotalOverUnderAndBtts(title: String): Boolean =
        (title.contains("alt/ust") || title.contains("alt ust")) &&
                title.contains("karsilikli gol")

    private fun isTotalOverUnder(title: String): Boolean {
        if (!title.contains("alt/ust") && !title.contains("alt ust")) return false
        return !title.contains("ev sahibi") && !title.contains("deplasman") &&
                !title.contains("korner") && !title.contains("kart")
    }

    private fun isHomeGoalOverUnder(title: String): Boolean =
        title.contains("ev sahibi") && (title.contains("alt/ust") || title.contains("alt ust"))

    private fun isAwayGoalOverUnder(title: String): Boolean =
        title.contains("deplasman") && (title.contains("alt/ust") || title.contains("alt ust"))

    private fun isTotalGoalsRange(title: String): Boolean =
        title.contains("toplam gol") &&
                !title.contains("alt/ust") && !title.contains("alt ust")

    private fun isTotalOddEven(title: String): Boolean =
        title.contains("tek / cift") || title.contains("tek/cift") || title.contains("tek cift")

    private fun isHandicapMarket(title: String, market: IddaaMarket): Boolean {
        if (title.contains("handikap", ignoreCase = true) || title.contains("handicap", ignoreCase = true)) return true
        return market.st == 62 || market.st == 100
    }

    private fun extractHandicapLine(title: String, market: IddaaMarket): Double? {
        val candidates = buildList {
            add(title)
            runCatching { AnalizMotoru.marketBasligi(market) }.getOrNull()?.let { add(normalize(it)) }
            market.sov?.trim()?.let { add(it) }
        }

        // Standart gösterimler: HANDİKAP -1, HANDİKAP +1, vb.
        val signedRegex = Regex("(?<!\\d)([+-]\\d+(?:[.,]\\d+)?)(?!\\d)")
        for (candidate in candidates) {
            signedRegex.find(candidate)?.groupValues?.getOrNull(1)?.let { raw ->
                raw.replace(',', '.').toDoubleOrNull()?.let { return it }
            }
        }

        // Bazı marketlerde çizgi 0:1 / 1:0 biçiminde gelir.
        // Net ev ayarı = ilk değer - ikinci değer.
        val pairRegex = Regex("\\(?\\s*(-?\\d+(?:[.,]\\d+)?)\\s*[:/]\\s*(-?\\d+(?:[.,]\\d+)?)\\s*\\)?")
        for (candidate in candidates) {
            pairRegex.find(candidate)?.let { match ->
                val home = match.groupValues[1].replace(',', '.').toDoubleOrNull()
                val away = match.groupValues[2].replace(',', '.').toDoubleOrNull()
                if (home != null && away != null) return home - away
            }
        }

        // Son çare: market.sov doğrudan sayısal çizgi taşıyorsa kullan.
        return market.sov?.trim()?.replace(',', '.')?.toDoubleOrNull()
    }

    private fun extractLine(title: String): Double? =
        Regex("(0\\.5|1\\.5|2\\.5|3\\.5|4\\.5|5\\.5|6\\.5|7\\.5)")
            .find(title)?.value?.toDoubleOrNull()

    private fun parseGoalRange(selection: String): IntRange? {
        val s = normalizeCompact(selection)
        Regex("^(\\d+)$").matchEntire(s)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return null
            return n..n
        }
        Regex("^(\\d+)-(\\d+)$").matchEntire(s)?.let {
            val a = it.groupValues[1].toIntOrNull() ?: return null
            val b = it.groupValues[2].toIntOrNull() ?: return null
            return minOf(a, b)..maxOf(a, b)
        }
        Regex("^(\\d+)veuzeri$").matchEntire(s)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return null
            return n..20
        }
        Regex("^(\\d+)\\+$").matchEntire(s)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return null
            return n..20
        }
        return null
    }

    private fun calibrateDistribution(
        distribution: com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.SkorDagilimi,
        alpha: Double
    ): com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.SkorDagilimi {
        val a = alpha.coerceIn(0.70, 1.0)
        val powered = distribution.hucreler.mapValues { (_, p) ->
            exp(ln(p.coerceAtLeast(1e-12)) * a)
        }
        return com.Fyco.iddaaanaliz.espn.KolmogorovOlasilikKatmani.normalize(powered)
    }

    private enum class SelectionKind { UNDER, OVER, OTHER }

    private fun selectionKind(value: String?): SelectionKind = when (normalizeCompact(value)) {
        "alt", "under" -> SelectionKind.UNDER
        "ust", "over" -> SelectionKind.OVER
        else -> SelectionKind.OTHER
    }

    private fun hasCompleteTwoWayOutcomes(outcomes: List<IddaaOutcome>): Boolean {
        val kinds = outcomes.map { selectionKind(it.n) }.toSet()
        return SelectionKind.UNDER in kinds && SelectionKind.OVER in kinds
    }

    private fun hasCompleteMatchResultOutcomes(outcomes: List<IddaaOutcome>): Boolean {
        val kinds = outcomes.map { normalizeCompact(it.n) }.toSet()
        val hasHome = "1" in kinds || "ev" in kinds
        val hasDraw = "x" in kinds || "0" in kinds || "beraberlik" in kinds || "draw" in kinds
        val hasAway = "2" in kinds || "dep" in kinds || "deplasman" in kinds
        return hasHome && hasDraw && hasAway
    }

    private fun finalizeResult(
        result: Map<Int, Double>,
        outcomes: List<IddaaOutcome>
    ): Map<Int, Double> {
        // Marketin iki/üç tarafı da çözülemediyse kısmi olasılık üretme.
        val required = outcomes.map { it.no }.toSet()
        if (!required.all { result.containsKey(it) }) return emptyMap()
        val valid = result.filterValues { it.isFinite() && it >= 0.0 }
        if (valid.size < 2) return emptyMap()
        val sum = valid.values.sum()
        if (!sum.isFinite() || sum <= 0.0) return emptyMap()
        return valid.mapValues { (_, p) -> p / sum }
    }

    private fun normalizeCompact(value: String?): String = normalize(value).replace(" ", "")

    private fun normalize(value: String?): String = value
        ?.trim()
        ?.lowercase(Locale.forLanguageTag("tr-TR"))
        ?.replace('ı', 'i')
        ?.replace('ş', 's')
        ?.replace('ğ', 'g')
        ?.replace('ü', 'u')
        ?.replace('ö', 'o')
        ?.replace('ç', 'c')
        ?.replace(Regex("\\s+"), " ")
        ?: ""
}
