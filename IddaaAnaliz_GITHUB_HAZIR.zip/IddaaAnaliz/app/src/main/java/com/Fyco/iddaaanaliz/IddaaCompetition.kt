@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

data class IddaaCompetitionResponse(
    val data: List<IddaaCompetition> = emptyList()
)

data class IddaaCompetition(
    val ec: Int? = null,
    val i: String,
    val n: String,
    val si: String? = null
)
