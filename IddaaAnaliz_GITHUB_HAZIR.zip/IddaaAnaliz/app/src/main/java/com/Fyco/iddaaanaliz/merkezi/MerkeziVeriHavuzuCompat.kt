@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

/**
 * Geriye dönük uyumluluk: eski sürümlerde merkezi paketten kullanılan
 * MerkeziVeriHavuzu yeni sürümde uygulama kök paketindeki tekil servise bağlanır.
 */
typealias MerkeziVeriHavuzu = com.Fyco.iddaaanaliz.MerkeziVeriHavuzu
