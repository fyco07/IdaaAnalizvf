@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import android.content.Context
import android.util.Log
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import java.util.Locale

/**
 * 365 günlük ESPN sonuçlarından Kendi Modeli 2.0'ı eğitir.
 *
 * MODEL ZİNCİRİ:
 *
 * ESPN tarihsel maçları
 *        ↓
 * Takım hücum / savunma ratingleri
 *        ↓
 * Ev avantajı
 *        ↓
 * Beklenen gol (Lambda)
 *        ↓
 * Ortak Poisson skor dağılımı
 *        ↓
 * MS 1/X/2
 * KG
 * Alt/Üst
 *        ↓
 * Kolmogorov olasılık tutarlılığı
 *
 * ÖNEMLİ:
 *
 * İddaa oranı bu eğitim modelinin girdisi değildir.
 *
 * Oranlar daha sonraki aşamada:
 *
 * Kendi Modeli olasılığı
 *        ↓
 * Piyasa olasılığı
 *        ↓
 * No-vig
 *        ↓
 * Edge / EV
 *
 * şeklinde kullanılacaktır.
 */
class ESPNKendiModelTrainer(
    private val context: Context
) {

    /**
     * Ana eğitim fonksiyonu.
     */
    suspend fun egit() {

        val db =
            com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
                .getInstance(context)

        val espnMaclar =
            db.espnTarihselMacDao()
                .tamamlananMaclariGetir()
                .filter {
                    it.evSkor >= 0 &&
                            it.deplasmanSkor >= 0
                }

        // Yeni gerçekleşen tahmin sonuçlarını da eğitim setine dahil et.
        // Aynı event/takım/tarih kaydını iki kez öğretmemek için tekilleştir.
        val geriBildirimMaclari: List<ESPNTarihselMac> =
            runCatching {
                com.Fyco.iddaaanaliz.MerkeziVeriHavuzu
                    .gerceklesenSonuclariEgitimIcinGetir()
            }.getOrDefault(emptyList())

        val maclar =
            (espnMaclar + geriBildirimMaclari)
                .distinctBy {
                    val h = ESPNKendiModelRepository.anahtar(it.evTakim)
                    val a = ESPNKendiModelRepository.anahtar(it.deplasmanTakim)
                    "${it.baslangic}:$h:$a:${it.evSkor}:${it.deplasmanSkor}"
                }
                .sortedBy { it.baslangic }

        /*
         * Minimum veri kontrolü.
         */
        if (maclar.size < MIN_MATCHES) {

            ESPNModelDurumStore.guncelle(
                context = context,
                asama = "VERI_YETERSIZ",
                gun = 365,
                toplamGun = 365,
                mac = maclar.size,
                egitim = 0,
                detay =
                    "Eğitim için en az " +
                            "$MIN_MATCHES maç gerekli"
            )

            Log.i(
                TAG,
                "EGITIM_DURDU " +
                        "yetersizMac=${maclar.size} " +
                        "minimum=$MIN_MATCHES"
            )

            return
        }

        /*
         * Tarihsel veri içinde karşılaşılan benzersiz takım sayısı.
         * Normalize edilmiş ESPN takım adı kullanılır; aynı takımın
         * aksan/noktalama farkları ayrı takım sayılmaz.
         */
        val geriBildirimSayisi = geriBildirimMaclari.size

        val incelenenTakimSayisi =
            maclar
                .flatMap { mac ->
                    listOf(
                        ESPNKendiModelRepository.anahtar(mac.evTakim),
                        ESPNKendiModelRepository.anahtar(mac.deplasmanTakim)
                    )
                }
                .filter { it.isNotBlank() }
                .toSet()
                .size

        /*
         * Eğitim başladı.
         */
        Log.i(
            TAG,
            "========================================"
        )

        Log.i(
            TAG,
            "EGITIM_BASLADI mac=${maclar.size}"
        )

        ESPNModelDurumStore.guncelle(
            context = context,
            asama = "MODEL_EGITILIYOR",
            gun = 365,
            toplamGun = 365,
            mac = maclar.size,
            egitim = 0,
            detay =
                "Kendi Modeli ${maclar.size} maç üzerinden öğreniyor • $incelenenTakimSayisi takım inceleniyor",
            incelenenTakim = incelenenTakimSayisi
        )

        /*
         * ----------------------------------------------------
         * 1. ZAMAN SIRALI VALIDASYON
         * ----------------------------------------------------
         *
         * Geleceği geçmişe öğretmemek için:
         *
         * İlk %80  → eğitim
         * Son %20  → doğrulama
         *
         * kullanıyoruz.
         */
        val holdoutStart =
            (maclar.size * 0.80)
                .toInt()
                .coerceIn(
                    1,
                    maclar.lastIndex
                )

        val trainSet =
            maclar.subList(
                0,
                holdoutStart
            )

        val validationSet =
            maclar.subList(
                holdoutStart,
                maclar.size
            )

        Log.i(
            TAG,
            "FIT_VALIDASYON_BASLADI " +
                    "train=${trainSet.size} " +
                    "validation=${validationSet.size}"
        )

        ESPNModelDurumStore.guncelle(
            context = context,
            asama = "MODEL_EGITILIYOR",
            gun = 365,
            toplamGun = 365,
            mac = maclar.size,
            egitim = trainSet.size,
            detay =
                "İlk %80 geçmiş veriyle takım güçleri öğreniliyor • $incelenenTakimSayisi takım",
            incelenenTakim = incelenenTakimSayisi
        )

        /*
         * İlk model.
         */
        val validationModel =
            fit(trainSet)

        Log.i(
            TAG,
            "FIT_VALIDASYON_TAMAMLANDI " +
                    "takim=${validationModel.ratings.size} " +
                    "homeMean=${validationModel.homeMean} " +
                    "awayMean=${validationModel.awayMean} " +
                    "homeAdv=${validationModel.homeAdvantage}"
        )

        /*
         * ----------------------------------------------------
         * 2. KALİBRASYON
         * ----------------------------------------------------
         *
         * Sonuç olasılıklarının aşırı güvenli veya
         * aşırı temkinli olmasını düzeltmek için
         * zaman sıralı validation set kullanılır.
         */
        ESPNModelDurumStore.guncelle(
            context = context,
            asama = "MODEL_EGITILIYOR",
            gun = 365,
            toplamGun = 365,
            mac = maclar.size,
            egitim = trainSet.size,
            detay =
                "Son %20 veriyle olasılık kalibrasyonu yapılıyor • $incelenenTakimSayisi takım",
            incelenenTakim = incelenenTakimSayisi
        )

        val alpha =
            kalibrasyonAlpha(
                validationModel,
                validationSet
            )

        Log.i(
            TAG,
            "KALIBRASYON_TAMAMLANDI " +
                    "alpha=$alpha"
        )

        /*
         * ----------------------------------------------------
         * 3. FİNAL MODEL
         * ----------------------------------------------------
         *
         * Kalibrasyon parametresi belirlendikten sonra
         * model bütün tarihsel veriyle tekrar eğitilir.
         */
        ESPNModelDurumStore.guncelle(
            context = context,
            asama = "MODEL_EGITILIYOR",
            gun = 365,
            toplamGun = 365,
            mac = maclar.size,
            egitim = trainSet.size,
            detay =
                "Final model 365 günlük verinin tamamıyla kuruluyor • $incelenenTakimSayisi takım",
            incelenenTakim = incelenenTakimSayisi
        )

        Log.i(
            TAG,
            "FIT_FINAL_BASLADI mac=${maclar.size}"
        )

        val finalModel =
            fit(maclar)

        Log.i(
            TAG,
            "FIT_FINAL_TAMAMLANDI " +
                    "takim=${finalModel.ratings.size} " +
                    "homeMean=${finalModel.homeMean} " +
                    "awayMean=${finalModel.awayMean} " +
                    "homeAdv=${finalModel.homeAdvantage}"
        )

        /*
         * ----------------------------------------------------
         * 4. TAKIM RATINGLERİNİ DB'YE YAZ
         * ----------------------------------------------------
         */
        val ratingEntities =
            finalModel.ratings.map { (key, rating) ->

                ESPNModelTakimRating(
                    takimAnahtari = key,
                    takimAdi = rating.name,
                    lig = rating.league,
                    hucum = rating.attack,
                    savunma = rating.defense,
                    macSayisi = rating.matches
                )
            }

        db.espnModelTakimRatingDao()
            .temizle()

        db.espnModelTakimRatingDao()
            .kaydetHepsi(
                ratingEntities
            )

        /*
         * ----------------------------------------------------
         * 5. MODEL META
         * ----------------------------------------------------
         *
         * Burada özellikle egitimTakimSayisi artık
         * gerçek takım sayısını taşıyor.
         */
        db.espnModelMetaDao()
            .metaKaydet(
                ESPNModelMeta(
                    evGolOrtalamasi =
                        finalModel.homeMean,

                    deplasmanGolOrtalamasi =
                        finalModel.awayMean,

                    evAvantajiLog =
                        finalModel.homeAdvantage,

                    kalibrasyonAlpha =
                        alpha,

                    egitimMacSayisi =
                        maclar.size,

                    egitimTakimSayisi =
                        ratingEntities.size,

                    modelVersiyonu =
                        MODEL_VERSION,

                    guncellemeZamani =
                        System.currentTimeMillis()
                )
            )

        /*
         * Repository cache yenile.
         */
        ESPNKendiModelRepository.refresh(
            context
        )

        /*
         * ----------------------------------------------------
         * 6. MODEL HAZIR
         * ----------------------------------------------------
         */
        ESPNModelDurumStore.guncelle(
            context = context,
            asama = "HAZIR",
            gun = 365,
            toplamGun = 365,
            mac = maclar.size,
            egitim = maclar.size,
            detay =
                "Model hazır • " +
                        "${ratingEntities.size} takım ratingi oluşturuldu • " +
                        "$incelenenTakimSayisi takım incelendi",
            incelenenTakim = incelenenTakimSayisi
        )

        Log.i(
            TAG,
            "========================================"
        )

        Log.i(
            TAG,
            "EGITIM_TAMAMLANDI"
        )

        Log.i(
            TAG,
            "mac=${maclar.size}"
        )

        Log.i(
            TAG,
            "takim=${ratingEntities.size}"
        )

        Log.i(
            TAG,
            "incelenenTakim=$incelenenTakimSayisi"
        )

        Log.i(
            TAG,
            "alpha=$alpha"
        )

        Log.i(
            TAG,
            "homeMean=${finalModel.homeMean}"
        )

        Log.i(
            TAG,
            "awayMean=${finalModel.awayMean}"
        )

        Log.i(
            TAG,
            "homeAdvantage=${finalModel.homeAdvantage}"
        )

        Log.i(
            TAG,
            "modelVersion=$MODEL_VERSION"
        )

        Log.i(
            TAG,
            "========================================"
        )
    }

    /**
     * Takımın öğrenilen durumu.
     */
    private data class RatingState(
        val name: String,
        val league: String?,
        var attack: Double = 0.0,
        var defense: Double = 0.0,
        var matches: Int = 0,
        var homeMatches: Int = 0,
        var awayMatches: Int = 0
    )

    /**
     * Eğitim sonucu.
     */
    private data class FitResult(
        val ratings: MutableMap<String, RatingState>,
        val homeMean: Double,
        val awayMean: Double,
        val homeAdvantage: Double
    )

    /**
     * --------------------------------------------------------
     * MODEL FIT
     * --------------------------------------------------------
     *
     * Takımların:
     *
     * - hücum gücü
     * - savunma gücü
     *
     * ayrı ayrı öğrenilir.
     *
     * Ev avantajı ayrıca öğrenilir.
     */
    private fun fit(
        maclar: List<ESPNTarihselMac>
    ): FitResult {

        val ratings =
            linkedMapOf<String, RatingState>()

        /*
         * Ligin genel gol ortalaması.
         */
        val homeMean =
            maclar
                .map {
                    it.evSkor.toDouble()
                }
                .average()
                .coerceIn(
                    0.25,
                    3.5
                )

        val awayMean =
            maclar
                .map {
                    it.deplasmanSkor.toDouble()
                }
                .average()
                .coerceIn(
                    0.20,
                    3.0
                )

        val baseLogHome =
            ln(homeMean)

        val baseLogAway =
            ln(awayMean)

        /*
         * Önce bütün takımları oluştur.
         */
        maclar.forEach { mac ->

            val homeKey =
                ESPNKendiModelRepository
                    .anahtar(
                        mac.evTakim
                    )

            val awayKey =
                ESPNKendiModelRepository
                    .anahtar(
                        mac.deplasmanTakim
                    )

            ratings.getOrPut(homeKey) {
                RatingState(
                    name = mac.evTakim,
                    league = mac.lig
                )
            }.apply {
                matches++
                homeMatches++
            }

            ratings.getOrPut(awayKey) {
                RatingState(
                    name = mac.deplasmanTakim,
                    league = mac.lig
                )
            }.apply {
                matches++
                awayMatches++
            }
        }

        /*
         * Başlangıç ev avantajı.
         */
        var homeAdv =
            0.10

        /*
         * Gradient tabanlı iteratif öğrenme.
         */
        repeat(FIT_ITERATIONS) {

            var gradHomeAdv =
                0.0

            val grad =
                ratings.keys
                    .associateWith {
                        doubleArrayOf(
                            0.0,
                            0.0
                        )
                    }
                    .toMutableMap()

            maclar.forEach { mac ->

                val homeKey =
                    ESPNKendiModelRepository
                        .anahtar(
                            mac.evTakim
                        )

                val awayKey =
                    ESPNKendiModelRepository
                        .anahtar(
                            mac.deplasmanTakim
                        )

                val homeRating =
                    ratings[homeKey]
                        ?: return@forEach

                val awayRating =
                    ratings[awayKey]
                        ?: return@forEach

                /*
                 * Yeni maçlar daha yüksek ağırlık alır.
                 *
                 * Ancak minimum ağırlık sayesinde
                 * eski maçlar tamamen yok sayılmaz.
                 */
                val ageDays =
                    (
                            maclar.last().baslangic -
                                    mac.baslangic
                            )
                        .coerceAtLeast(0L)
                        .div(
                            86_400_000L
                        )
                        .toDouble()

                val weight =
                    exp(
                        -ageDays /
                                RECENCY_DAYS
                    ).coerceIn(
                        0.30,
                        1.0
                    )

                /*
                 * Beklenen ev golü.
                 */
                val lambdaHome =
                    exp(
                        (
                                baseLogHome +
                                        homeAdv +
                                        homeRating.attack -
                                        awayRating.defense
                                )
                            .coerceIn(
                                -2.0,
                                2.0
                            )
                    )

                /*
                 * Beklenen deplasman golü.
                 */
                val lambdaAway =
                    exp(
                        (
                                baseLogAway +
                                        awayRating.attack -
                                        homeRating.defense
                                )
                            .coerceIn(
                                -2.0,
                                2.0
                            )
                    )

                /*
                 * Gerçek skor - beklenen skor.
                 */
                val homeResidual =
                    (
                            mac.evSkor -
                                    lambdaHome
                            ) * weight

                val awayResidual =
                    (
                            mac.deplasmanSkor -
                                    lambdaAway
                            ) * weight

                /*
                 * Ev takımının hücum/savunması.
                 */
                grad[homeKey]!![0] +=
                    homeResidual

                grad[homeKey]!![1] -=
                    awayResidual

                /*
                 * Deplasman takımının hücum/savunması.
                 */
                grad[awayKey]!![0] +=
                    awayResidual

                grad[awayKey]!![1] -=
                    homeResidual

                /*
                 * Ev avantajı gradienti.
                 */
                gradHomeAdv +=
                    homeResidual
            }

            /*
             * Ratingleri güncelle.
             */
            ratings.forEach { (key, state) ->

                val g =
                    grad[key]
                        ?: return@forEach

                val matchCount =
                    max(
                        1,
                        state.matches
                    )

                state.attack =
                    (
                            state.attack +
                                    LEARNING_RATE *
                                    g[0] /
                                    matchCount
                            )
                        .coerceIn(
                            -1.25,
                            1.25
                        )

                state.defense =
                    (
                            state.defense +
                                    LEARNING_RATE *
                                    g[1] /
                                    matchCount
                            )
                        .coerceIn(
                            -1.25,
                            1.25
                        )

                /*
                 * Shrinkage.
                 *
                 * Çok küçük örneklemli takımların
                 * aşırı rating üretmesini sınırlar.
                 */
                state.attack *=
                    SHRINKAGE

                state.defense *=
                    SHRINKAGE
            }

            /*
             * Ratinglerin merkezini hafifçe sıfıra çek.
             */
            val attackMean =
                ratings.values
                    .map {
                        it.attack
                    }
                    .average()

            val defenseMean =
                ratings.values
                    .map {
                        it.defense
                    }
                    .average()

            ratings.values.forEach {

                it.attack -=
                    attackMean *
                            CENTERING_FACTOR

                it.defense -=
                    defenseMean *
                            CENTERING_FACTOR
            }

            /*
             * Ev avantajını güncelle.
             */
            homeAdv =
                (
                        homeAdv +
                                LEARNING_RATE *
                                gradHomeAdv /
                                maclar.size
                        )
                    .coerceIn(
                        0.0,
                        0.35
                    )
        }

        /*
         * ----------------------------------------------------
         * GÜNCEL FORM + İÇ SAHA / DEPLASMAN FORMU
         * ----------------------------------------------------
         *
         * Ana rating yalnızca uzun dönem gol performansından
         * oluşmasın. Son 5/10/20 maçtaki puan ve gol farkı
         * ayrıca hesaplanır. Rakip kalitesi de hesaba katılır.
         *
         * Bu düzeltme ayrı bir model kurmaz; öğrenilmiş hücum
         * ve savunma ratingine kontrollü bir form sinyali ekler.
         * Böylece canlı tahminde mevcut rating tablosu yeterlidir.
         */
        uygulaGuncelFormDuzeltmesi(
            ratings = ratings,
            maclar = maclar
        )

        return FitResult(
            ratings = ratings,
            homeMean = homeMean,
            awayMean = awayMean,
            homeAdvantage = homeAdv
        )
    }

    /**
     * Güncel formu mevcut ratinglerle birlikte hesaplar.
     *
     * Form puanı:
     * - Son 5 maç   : %50
     * - Son 10 maç  : %30
     * - Son 20 maç  : %20
     *
     * Puan performansına gol farkı ve rakip kalitesi eklenir.
     * İç saha ve deplasman maçları ayrıca izlenir.
     */
    private fun uygulaGuncelFormDuzeltmesi(
        ratings: MutableMap<String, RatingState>,
        maclar: List<ESPNTarihselMac>
    ) {
        if (ratings.isEmpty() || maclar.isEmpty()) return

        data class FormSonucu(
            var puan: Double = 0.0,
            var golFarki: Double = 0.0,
            var agirlik: Double = 0.0,
            var mac: Int = 0
        )

        val tumForm = ratings.keys.associateWith { FormSonucu() }.toMutableMap()
        val evForm = ratings.keys.associateWith { FormSonucu() }.toMutableMap()
        val depForm = ratings.keys.associateWith { FormSonucu() }.toMutableMap()

        /*
         * En güncel maçtan geriye doğru 20 maç tutulur.
         * Böylece eski maçlar form sinyalini domine edemez.
         */
        val takimMaclari = mutableMapOf<String, MutableList<ESPNTarihselMac>>()
        maclar.forEach { mac ->
            val evKey = ESPNKendiModelRepository.anahtar(mac.evTakim)
            val depKey = ESPNKendiModelRepository.anahtar(mac.deplasmanTakim)
            takimMaclari.getOrPut(evKey) { mutableListOf() }.add(mac)
            takimMaclari.getOrPut(depKey) { mutableListOf() }.add(mac)
        }

        fun formAyarla(
            hedef: FormSonucu,
            points: Double,
            goalDiff: Double,
            opponentStrength: Double,
            index: Int
        ) {
            val recencyWeight = when {
                index < 5 -> 1.00
                index < 10 -> 0.65
                else -> 0.35
            }
            val pointsSignal = (points / 3.0).coerceIn(0.0, 1.0)
            val goalSignal = (0.5 + goalDiff / 3.0).coerceIn(0.0, 1.0)
            val opponentSignal = (0.5 + opponentStrength / 2.0).coerceIn(0.0, 1.0)

            /*
             * Puan %55, gol farkı %25, rakip kalitesi %20.
             */
            val signal =
                pointsSignal * 0.55 +
                        goalSignal * 0.25 +
                        opponentSignal * 0.20

            hedef.puan += signal * recencyWeight
            hedef.golFarki += goalDiff.coerceIn(-4.0, 4.0) * recencyWeight
            hedef.agirlik += recencyWeight
            hedef.mac++
        }

        ratings.forEach { (key, rating) ->
            val recent = takimMaclari[key]
                ?.sortedByDescending { it.baslangic }
                ?.take(20)
                .orEmpty()

            recent.forEachIndexed { index, mac ->
                val isHome = ESPNKendiModelRepository.anahtar(mac.evTakim) == key
                val gf: Int
                val ga: Int
                val opponentKey: String

                if (isHome) {
                    gf = mac.evSkor
                    ga = mac.deplasmanSkor
                    opponentKey = ESPNKendiModelRepository.anahtar(mac.deplasmanTakim)
                } else {
                    gf = mac.deplasmanSkor
                    ga = mac.evSkor
                    opponentKey = ESPNKendiModelRepository.anahtar(mac.evTakim)
                }

                val points = when {
                    gf > ga -> 3.0
                    gf == ga -> 1.0
                    else -> 0.0
                }

                val opponent = ratings[opponentKey]
                val opponentStrength = if (opponent != null) {
                    (opponent.attack - opponent.defense).coerceIn(-2.0, 2.0)
                } else {
                    0.0
                }

                val goalDiff = (gf - ga).toDouble()
                formAyarla(
                    hedef = tumForm[key]!!,
                    points = points,
                    goalDiff = goalDiff,
                    opponentStrength = opponentStrength,
                    index = index
                )

                if (isHome) {
                    formAyarla(
                        hedef = evForm[key]!!,
                        points = points,
                        goalDiff = goalDiff,
                        opponentStrength = opponentStrength,
                        index = index
                    )
                } else {
                    formAyarla(
                        hedef = depForm[key]!!,
                        points = points,
                        goalDiff = goalDiff,
                        opponentStrength = opponentStrength,
                        index = index
                    )
                }
            }

            fun skor(form: FormSonucu): Double {
                if (form.agirlik <= 0.0) return 0.5
                return (form.puan / form.agirlik).coerceIn(0.0, 1.0)
            }

            /* 0.5 nötr formdur. */
            val genelForm = skor(tumForm[key]!!) - 0.5
            val icSahaForm = skor(evForm[key]!!) - 0.5
            val deplasmanForm = skor(depForm[key]!!) - 0.5

            /*
             * Kontrollü etki:
             * - genel form -> hücum/savunma
             * - iç saha form -> küçük ek ev etkisi
             * - deplasman form -> küçük ek deplasman etkisi
             *
             * Form hiçbir zaman ana ratingi ezemez.
             */
            rating.attack = (
                    rating.attack +
                            genelForm * FORM_ATTACK_WEIGHT +
                            icSahaForm * HOME_FORM_WEIGHT * 0.50 +
                            deplasmanForm * AWAY_FORM_WEIGHT * 0.25
                    ).coerceIn(-1.25, 1.25)

            rating.defense = (
                    rating.defense -
                            genelForm * FORM_DEFENSE_WEIGHT -
                            icSahaForm * HOME_FORM_WEIGHT * 0.35 -
                            deplasmanForm * AWAY_FORM_WEIGHT * 0.20
                    ).coerceIn(-1.25, 1.25)

            if (recent.size >= 5) {
                Log.d(
                    TAG,
                    "FORM " +
                            "takim=${rating.name} " +
                            "son=${recent.size} " +
                            "genel=${"%.3f".format(Locale.US, genelForm + 0.5)} " +
                            "ic=${"%.3f".format(Locale.US, icSahaForm + 0.5)} " +
                            "dep=${"%.3f".format(Locale.US, deplasmanForm + 0.5)}"
                )
            }
        }
    }

    /**
     * --------------------------------------------------------
     * KALİBRASYON
     * --------------------------------------------------------
     *
     * Validation set üzerinde farklı alpha değerleri
     * denenir.
     *
     * En düşük Brier Score seçilir.
     */
    private fun kalibrasyonAlpha(
        model: FitResult,
        validation: List<ESPNTarihselMac>
    ): Double {

        if (validation.size < 20) {
            return 1.0
        }

        var bestAlpha =
            1.0

        var bestBrier =
            Double.POSITIVE_INFINITY

        /*
         * 0.70 - 1.30 arası alpha.
         */
        for (index in 0 until 13) {

            val alpha =
                0.70 +
                        index * 0.05

            var brier =
                0.0

            var count =
                0

            validation.forEach { mac ->

                val probs =
                    sonucOlasiliklari(
                        model,
                        mac,
                        alpha
                    )

                val actual =
                    when {

                        mac.evSkor >
                                mac.deplasmanSkor ->
                            0

                        mac.evSkor ==
                                mac.deplasmanSkor ->
                            1

                        else ->
                            2
                    }

                brier +=
                    probs
                        .mapIndexed { index, probability ->

                            val actualValue =
                                if (
                                    index ==
                                    actual
                                ) {
                                    1.0
                                } else {
                                    0.0
                                }

                            (
                                    probability -
                                            actualValue
                                    ) *
                                    (
                                            probability -
                                                    actualValue
                                            )
                        }
                        .sum()

                count++
            }

            if (count > 0) {

                val average =
                    brier /
                            count

                if (
                    average <
                    bestBrier
                ) {

                    bestBrier =
                        average

                    bestAlpha =
                        alpha
                }
            }
        }

        return bestAlpha
    }

    /**
     * MS 1/X/2 olasılıkları.
     *
     * Ortak skor dağılımından çıkarılır.
     */
    private fun sonucOlasiliklari(
        model: FitResult,
        mac: ESPNTarihselMac,
        alpha: Double
    ): List<Double> {

        val lambda =
            lambdalar(
                model,
                mac
            )

        val distribution =
            KolmogorovOlasilikKatmani
                .poissonDagilimi(
                    lambda.first,
                    lambda.second
                )

        val (
            homeProbability,
            drawProbability,
            awayProbability
        ) =
            KolmogorovOlasilikKatmani
                .macSonucu(
                    distribution
                )

        /*
         * Calibration power.
         */
        val powered =
            listOf(
                homeProbability,
                drawProbability,
                awayProbability
            )
                .map { probability ->

                    probability
                        .coerceAtLeast(
                            1e-9
                        )
                        .pow(
                            alpha
                        )
                }

        val sum =
            powered.sum()

        return powered.map {
            it / sum
        }
    }

    /**
     * Beklenen gol değerleri.
     */
    private fun lambdalar(
        model: FitResult,
        mac: ESPNTarihselMac
    ): Pair<Double, Double> {

        val home =
            model.ratings[
                ESPNKendiModelRepository
                    .anahtar(
                        mac.evTakim
                    )
            ]

        val away =
            model.ratings[
                ESPNKendiModelRepository
                    .anahtar(
                        mac.deplasmanTakim
                    )
            ]

        val homeAttack =
            home?.attack ?: 0.0

        val homeDefense =
            home?.defense ?: 0.0

        val awayAttack =
            away?.attack ?: 0.0

        val awayDefense =
            away?.defense ?: 0.0

        /*
         * Ev beklenen golü.
         */
        val lambdaHome =
            exp(
                (
                        ln(model.homeMean) +
                                model.homeAdvantage +
                                homeAttack -
                                awayDefense
                        )
                    .coerceIn(
                        -2.0,
                        2.0
                    )
            )

        /*
         * Deplasman beklenen golü.
         */
        val lambdaAway =
            exp(
                (
                        ln(model.awayMean) +
                                awayAttack -
                                homeDefense
                        )
                    .coerceIn(
                        -2.0,
                        2.0
                    )
            )

        return (
                lambdaHome.coerceIn(
                    0.10,
                    4.50
                )
                ) to (
                lambdaAway.coerceIn(
                    0.10,
                    4.50
                )
                )
    }

    /**
     * Kotlin'de güvenli üs alma.
     */
    private fun Double.pow(
        p: Double
    ): Double {

        return exp(
            ln(this) * p
        )
    }

    companion object {

        private const val TAG =
            "ESPN_MODEL"

        /*
         * Model versiyonu.
         */
        private const val MODEL_VERSION =
            "KENDI_MODEL_2.2_FORM"

        /*
         * Güncel formun ana ratinge kontrollü etkisi.
         */
        private const val FORM_ATTACK_WEIGHT = 0.18
        private const val FORM_DEFENSE_WEIGHT = 0.12
        private const val HOME_FORM_WEIGHT = 0.10
        private const val AWAY_FORM_WEIGHT = 0.08

        /*
         * Minimum eğitim maçı.
         */
        private const val MIN_MATCHES =
            80

        /*
         * Yeni maçların ağırlığını artıran
         * zaman penceresi.
         */
        private const val RECENCY_DAYS =
            180.0

        /*
         * Öğrenme hızı.
         */
        private const val LEARNING_RATE =
            0.045

        /*
         * Gradient fit iterasyonu.
         */
        private const val FIT_ITERATIONS =
            18

        /*
         * Shrinkage.
         */
        private const val SHRINKAGE =
            0.995

        /*
         * Rating merkezleme.
         */
        private const val CENTERING_FACTOR =
            0.15
    }
}