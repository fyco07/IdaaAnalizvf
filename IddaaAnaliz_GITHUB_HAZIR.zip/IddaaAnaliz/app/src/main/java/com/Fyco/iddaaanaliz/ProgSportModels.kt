@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

data class ProgSportMac(

    val evSahibi: String,

    val deplasman: String,

    val evOlasilik: Double? = null,

    val beraberlikOlasilik: Double? = null,

    val deplasmanOlasilik: Double? = null,

    val altOlasilik: Double? = null,

    val ustOlasilik: Double? = null,

    val evOran: Double? = null,

    val beraberlikOran: Double? = null,

    val deplasmanOran: Double? = null,

    val tahminiEvSkor: Int? = null,

    val tahminiDeplasmanSkor: Int? = null,

    val toplamSayi: Double? = null,

    val spreadEvOlasilik: Double? = null,

    val spreadDeplasmanOlasilik: Double? = null,

    val spread: Double? = null
)


data class ProgSportEslesme(

    val mac: ProgSportMac,

    val eslesmePuani: Int
)


data class ProgSportAnaliz(

    val eventId: Long,

    val spor: SporTuru,

    val mac: ProgSportMac? = null,

    val marketOlasiliklari:
    Map<String, Double> = emptyMap(),

    val eslesmePuani: Int = 0,

    val veriVar: Boolean = false
)