@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import android.content.Context
import androidx.room.Database
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.Room
import androidx.room.RoomDatabase
import com.Fyco.iddaaanaliz.espn.ESPNTarihselMac
import com.Fyco.iddaaanaliz.espn.ESPNTarihselMacDao
import com.Fyco.iddaaanaliz.espn.ESPNModelMeta
import com.Fyco.iddaaanaliz.espn.ESPNModelMetaDao
import com.Fyco.iddaaanaliz.espn.ESPNModelTakimRating
import com.Fyco.iddaaanaliz.espn.ESPNModelTakimRatingDao

@Database(
    entities = [
        SofaScoreTarihselMac::class,
        SofaScoreTarihselGun::class,
        ESPNTarihselMac::class,
        ESPNModelTakimRating::class,
        ESPNModelMeta::class,
        ESPNOyuncuHavuzu::class,
        ESPNTakimKadroCache::class,
        ESPNOyuncuDurumCache::class
    ],
    version = 4,
    exportSchema = false
)
abstract class IddaaAnalizDatabase : RoomDatabase() {
    abstract fun sofascoreTarihselMacDao(): SofaScoreTarihselMacDao
    abstract fun sofascoreTarihselGunDao(): SofaScoreTarihselGunDao
    abstract fun espnTarihselMacDao(): ESPNTarihselMacDao
    abstract fun espnModelTakimRatingDao(): ESPNModelTakimRatingDao
    abstract fun espnModelMetaDao(): ESPNModelMetaDao
    abstract fun espnOyuncuHavuzuDao(): ESPNOyuncuHavuzuDao

    companion object {
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS espn_oyuncu_havuzu (
                        teamKey TEXT NOT NULL,
                        league TEXT NOT NULL,
                        teamId TEXT NOT NULL,
                        playerId TEXT NOT NULL,
                        playerName TEXT NOT NULL,
                        position TEXT NOT NULL,
                        minutes REAL NOT NULL,
                        appearances INTEGER NOT NULL,
                        starts INTEGER NOT NULL,
                        substitutionsIn INTEGER NOT NULL,
                        goals REAL NOT NULL,
                        assists REAL NOT NULL,
                        shots REAL NOT NULL,
                        shotsOnTarget REAL NOT NULL,
                        saves REAL NOT NULL,
                        goalsAgainst REAL NOT NULL,
                        xg REAL NOT NULL,
                        xa REAL NOT NULL,
                        savedAt INTEGER NOT NULL,
                        PRIMARY KEY(teamKey, playerId)
                    )
                """.trimIndent())
                database.execSQL("CREATE INDEX IF NOT EXISTS index_espn_oyuncu_havuzu_teamKey ON espn_oyuncu_havuzu(teamKey)")
                database.execSQL("CREATE INDEX IF NOT EXISTS index_espn_oyuncu_havuzu_playerId ON espn_oyuncu_havuzu(playerId)")
                database.execSQL("CREATE INDEX IF NOT EXISTS index_espn_oyuncu_havuzu_league_teamId ON espn_oyuncu_havuzu(league, teamId)")

                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS espn_takim_kadro_cache (
                        cacheKey TEXT NOT NULL PRIMARY KEY,
                        league TEXT NOT NULL,
                        teamId TEXT NOT NULL,
                        teamName TEXT NOT NULL,
                        seasonKey TEXT NOT NULL,
                        rosterSyncedAt INTEGER NOT NULL,
                        rosterSignature TEXT NOT NULL,
                        injuryCheckedAt INTEGER NOT NULL,
                        lastSuccessfulAt INTEGER NOT NULL
                    )
                """.trimIndent())

                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS espn_oyuncu_durum_cache (
                        teamKey TEXT NOT NULL,
                        playerId TEXT NOT NULL,
                        playerName TEXT NOT NULL,
                        position TEXT NOT NULL,
                        status TEXT NOT NULL,
                        checkedAt INTEGER NOT NULL,
                        PRIMARY KEY(teamKey, playerId)
                    )
                """.trimIndent())
                database.execSQL("CREATE INDEX IF NOT EXISTS index_espn_oyuncu_durum_cache_teamKey ON espn_oyuncu_durum_cache(teamKey)")
            }
        }
        @Volatile
        private var INSTANCE: IddaaAnalizDatabase? = null

        fun getInstance(context: Context): IddaaAnalizDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    IddaaAnalizDatabase::class.java,
                    "iddaa_analiz_tarihsel.db"
                )
                    .addMigrations(MIGRATION_3_4)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
