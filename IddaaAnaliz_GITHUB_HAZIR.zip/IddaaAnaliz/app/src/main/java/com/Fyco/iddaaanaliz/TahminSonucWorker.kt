@file:Suppress("PackageName")

package com.Fyco.iddaaanaliz

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.Constraints
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Arka planda bekleyen tahminleri sonuçlandırır.
 *
 * - İnternet varsa çalışır.
 * - Saatlik periyodik kontrol yapar.
 * - Uygulama açıldığında ayrıca bir kez hemen çalıştırılabilir.
 * - API-Sports / API-Football kullanılmaz.
 */
class TahminSonucWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        TahminOgrenmeRepository.init(applicationContext)

        return try {
            TahminSonucCozumleyici.calistir()
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

object TahminSonucArkaPlanPlanlayici {

    private const val PERIODIC_WORK = "tahmin_sonuc_saatlik"
    private const val IMMEDIATE_WORK = "tahmin_sonuc_hemen"

    fun baslat(context: Context) {
        val app = context.applicationContext

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val periodicRequest =
            PeriodicWorkRequestBuilder<TahminSonucWorker>(
                1,
                TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .build()

        WorkManager.getInstance(app).enqueueUniquePeriodicWork(
            PERIODIC_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            periodicRequest
        )
    }

    /**
     * Uygulama açıldığında bekleyen sonuçları bir kez hemen kontrol eder.
     */
    fun hemenKontrolEt(context: Context) {
        val app = context.applicationContext

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request =
            OneTimeWorkRequestBuilder<TahminSonucWorker>()
                .setConstraints(constraints)
                .build()

        WorkManager.getInstance(app).enqueueUniqueWork(
            IMMEDIATE_WORK,
            ExistingWorkPolicy.KEEP,
            request
        )
    }
}
