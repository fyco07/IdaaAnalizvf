@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.util.Log

/**
 * Legacy source-compatibility bridge. It performs no network I/O.
 * Active result resolution is ESPN-only.
 */
@Deprecated("Use ESPNSonucSaglayici")
object SofascoreSonucSaglayici {
    private const val TAG = "IddaaOgrenme"

    @Deprecated("Compatibility bridge only; active source is ESPNSonucSaglayici")
    suspend fun tarihselMaclariGetir(gun: String, spor: SporTuru): List<SonucMac> =
        run {
            Log.i(TAG, "LEGACY_SOFASCORE_BRIDGE_USED method=tarihselMaclariGetir provider=ESPN_ONLY")
            ESPNSonucSaglayici.tarihselMaclariGetir(gun, spor)
        }

    suspend fun macSonucunuBul(kayit: TahminKaydi, spor: SporTuru): SonucMac? =
        run {
            Log.i(TAG, "LEGACY_SOFASCORE_BRIDGE_USED method=macSonucunuBul provider=ESPN_ONLY")
            ESPNSonucSaglayici.macSonucunuBul(kayit, spor)
        }

    suspend fun macSonuclariniBul(kayitlar: List<TahminKaydi>): Map<String, SonucMac> =
        run {
            Log.i(TAG, "LEGACY_SOFASCORE_BRIDGE_USED method=macSonuclariniBul provider=ESPN_ONLY")
            ESPNSonucSaglayici.macSonuclariniBul(kayitlar)
        }
}
