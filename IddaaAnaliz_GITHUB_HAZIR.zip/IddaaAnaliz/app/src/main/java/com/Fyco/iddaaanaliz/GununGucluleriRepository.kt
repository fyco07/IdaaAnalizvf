@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject

/**
 * Günün Güçlüleri için dinamik snapshot repository.
 *
 * Kritik kural: güçlü seçim "ilk görüldüğü anda" kilitlenmez. Aynı günün
 * güncel bülten/model snapshot'ı her yeniden hesaplamada tamamen yenilenir;
 * böylece 70 puanlı seçim daha sonra 71 puanlı seçim tarafından sıralamada
 * geçilebilir ve listeye girebilir.
 */
data class GununGucluKaydi(
    val anahtar: String,
    val eventId: Long,
    val marketId: Long,
    val secimNo: Int,
    val secim: String,
    val evSahibi: String,
    val deplasman: String,
    val sport: String,
    val macZamani: Long,
    val marketBasligi: String,
    val oran: Double,
    val olasilik: Double,
    val fairOran: Double,
    val edge: Double?,
    val ev: Double?,
    val guven: Int,
    val karar: String,
    val aciklama: String,
    val kayitZamani: Long
)

object GununGucluleriRepository {
    private const val PREFS = "gunun_gucluleri_v6"
    private const val KEY = "kilitli" // eski anahtar adı; içerik artık dinamik snapshot
    private const val KEY_DYNAMIC_SIGNATURE = "dynamic_signature"
    private var prefs: SharedPreferences? = null
    private var cache: List<GununGucluKaydi>? = null

    fun init(ctx: Context) {
        if (prefs == null) {
            prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        }
        if (cache == null) cache = oku()
    }

    @Synchronized
    fun dynamicSignature(): Long? {
        return prefs
            ?.getString(KEY_DYNAMIC_SIGNATURE, null)
            ?.toLongOrNull()
    }

    @Synchronized
    fun replaceDynamicSnapshot(picks: List<GucluSecim>, signature: Long?) {
        val mevcut = cache ?: oku()
        val now = System.currentTimeMillis()
        val keepHistory = mevcut.filter { it.macZamani * 1000L < now - 3L * 86_400_000L }
        val yeni = picks.mapNotNull { pick ->
            val a = pick.analiz
            val marketId = a.marketId ?: return@mapNotNull null
            val secimNo = a.secimNo ?: return@mapNotNull null
            GununGucluKaydi(
                anahtar = "${pick.displayEvent.event.i}:$marketId:$secimNo",
                eventId = pick.displayEvent.event.i,
                marketId = marketId,
                secimNo = secimNo,
                secim = a.secim,
                evSahibi = pick.displayEvent.event.hn,
                deplasman = pick.displayEvent.event.an,
                sport = pick.displayEvent.sport.name,
                macZamani = pick.displayEvent.event.d,
                marketBasligi = pick.marketBasligi,
                oran = a.oran,
                olasilik = a.gelmeOlasiligi,
                fairOran = a.fairOran,
                edge = a.edge,
                ev = a.ev,
                guven = a.guvenPuani,
                karar = a.karar.name,
                aciklama = a.aciklama,
                kayitZamani = now
            )
        }
        cache = (keepHistory + yeni).takeLast(5000)
        yaz(cache ?: emptyList())
        prefs?.edit {
            putString(KEY_DYNAMIC_SIGNATURE, signature?.toString() ?: "")
        }
    }

    @Synchronized
    fun currentDayDynamic(gunBaslangici: Long, gunSonu: Long): List<GununGucluKaydi> =
        (cache ?: oku())
            .filter { it.macZamani * 1000L in gunBaslangici until gunSonu }
            .sortedWith(compareByDescending<GununGucluKaydi> { it.olasilik }
                .thenByDescending { it.guven }
                .thenByDescending { it.edge ?: Double.NEGATIVE_INFINITY }
                .thenByDescending { it.ev ?: Double.NEGATIVE_INFINITY })
            .take(30)

    @Synchronized
    fun snapshot(eventId: Long, marketId: Long, secimNo: Int): GununGucluKaydi? =
        (cache ?: oku()).firstOrNull {
            it.eventId == eventId && it.marketId == marketId && it.secimNo == secimNo
        }

    private fun oku(): List<GununGucluKaydi> {
        val raw = prefs?.getString(KEY, null)
            ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    add(
                        GununGucluKaydi(
                            o.optString("anahtar"), o.optLong("eventId"), o.optLong("marketId"),
                            o.optInt("secimNo"), o.optString("secim"),
                            o.optString("evSahibi"), o.optString("deplasman"),
                            o.optString("sport", SportType.FOOTBALL.name), o.optLong("macZamani"),
                            o.optString("marketBasligi"),
                            o.optDouble("oran"), o.optDouble("olasilik"), o.optDouble("fairOran"),
                            o.optNullableDouble("edge"), o.optNullableDouble("ev"), o.optInt("guven"),
                            o.optString("karar"), o.optString("aciklama"), o.optLong("kayitZamani")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList()).also { cache = it }
    }

    private fun yaz(kayitlar: List<GununGucluKaydi>) {
        val preferences = prefs ?: return
        val a = JSONArray()
        kayitlar.forEach { k ->
            a.put(JSONObject().apply {
                put("anahtar", k.anahtar); put("eventId", k.eventId); put("marketId", k.marketId)
                put("secimNo", k.secimNo); put("secim", k.secim)
                put("evSahibi", k.evSahibi); put("deplasman", k.deplasman)
                put("sport", k.sport); put("macZamani", k.macZamani)
                put("marketBasligi", k.marketBasligi)
                put("oran", k.oran); put("olasilik", k.olasilik); put("fairOran", k.fairOran)
                putNullable("edge", k.edge); putNullable("ev", k.ev); put("guven", k.guven)
                put("karar", k.karar); put("aciklama", k.aciklama); put("kayitZamani", k.kayitZamani)
            })
        }
        preferences.edit {
            putString(KEY, a.toString())
        }
    }

    private fun JSONObject.putNullable(key: String, value: Double?) {
        if (value == null) put(key, JSONObject.NULL) else put(key, value)
    }

    private fun JSONObject.optNullableDouble(key: String): Double? =
        if (isNull(key)) null else optDouble(key, Double.NaN).takeIf { it.isFinite() }
}
