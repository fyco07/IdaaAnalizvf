@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "espn_tarihsel_maclar",
    indices = [
        Index(value = ["baslangic"]),
        Index(value = ["evTakim"]),
        Index(value = ["deplasmanTakim"]),
        Index(value = ["lig"])
    ]
)
data class ESPNTarihselMac(
    @PrimaryKey val eventId: Long,
    val baslangic: Long,
    val lig: String?,
    val sezon: String?,
    val evTakimId: String?,
    val deplasmanTakimId: String?,
    val evTakim: String,
    val deplasmanTakim: String,
    val evSkor: Int,
    val deplasmanSkor: Int,
    val evIlkYari: Int? = null,
    val deplasmanIlkYari: Int? = null,
    val tamamlandi: Boolean = true,
    val kayitZamani: Long = System.currentTimeMillis()
) {
    // Kod uyumluluğu için yardımcı erişimler; Room alanı oluşturmaz.
    fun evTakimAdi(): String = evTakim
    fun deplasmanTakimAdi(): String = deplasmanTakim
}
