package com.Fyco.iddaaanaliz

import android.app.Application
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import com.Fyco.iddaaanaliz.espn.ESPNHistoryWorker
import com.Fyco.iddaaanaliz.espn.ESPNKendiModelRepository
import com.Fyco.iddaaanaliz.veritabani.SofaScoreTarihselVeriWorker

/**
 * Uygulama açılışında sonuç çözümleme, mevcut dış veri güncellemesi ve
 * Kendi Modeli 2.0 için 365 günlük ESPN geçmişi planlanır.
 */
class IddaaAnalizApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        TahminOgrenmeRepository.init(this)
        MerkeziVeriHavuzu.init(this)
        GununGucluleriRepository.init(this)
        SofaScoreVeriSaglayici.init(this)
        ESPNKendiModelRepository.init(this)

        TahminSonucArkaPlanPlanlayici.baslat(this)
        TahminSonucArkaPlanPlanlayici.hemenKontrolEt(this)

        // Mevcut SofaScore tarihsel veri akışı korunuyor.
        val sofaWork = OneTimeWorkRequestBuilder<SofaScoreTarihselVeriWorker>().build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            "SOFASCORE_365_GUN_TARIHSEL_VERI_V2",
            ExistingWorkPolicy.KEEP,
            sofaWork
        )

        // Kendi Modeli 2.0'ın asıl eğitim verisi ESPN'dir.
        /*
         * ESPN işi daha önce SUCCESS durumuna geçmiş olsa bile veritabanı
         * boşaltılmışsa modelin sonsuza kadar "365/365" görünüp aslında
         * 0 maçla kalmasını engelle.
         *
         * Kontrol IO thread'inde yapılır. Çalışan bir iş varsa ona dokunulmaz;
         * yalnızca DB boş/yetersiz ve mevcut iş RUNNING değilse yeni 365 günlük
         * zincir başlatılır.
         */
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val db = com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
                    .getInstance(applicationContext)
                val macSayisi = db.espnTarihselMacDao().toplamMacSayisi()
                val wm = WorkManager.getInstance(applicationContext)
                val mevcut = wm.getWorkInfosForUniqueWork(ESPNHistoryWorker.WORK_NAME).get()
                val calisiyor = mevcut.any { it.state == androidx.work.WorkInfo.State.RUNNING }

                if (macSayisi < 80 && !calisiyor) {
                    val espnWork = OneTimeWorkRequestBuilder<ESPNHistoryWorker>().build()
                    wm.enqueueUniqueWork(
                        ESPNHistoryWorker.WORK_NAME,
                        ExistingWorkPolicy.REPLACE,
                        espnWork
                    )
                }
            } catch (e: Exception) {
                android.util.Log.e("ESPN_HISTORY", "ESPN_IS_KONTROL_HATASI", e)
            }
        }
    }
}
