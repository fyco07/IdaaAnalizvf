@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "espn_model_meta")
data class ESPNModelMeta(
    @PrimaryKey val id: Int = 1,
    val evGolOrtalamasi: Double,
    val deplasmanGolOrtalamasi: Double,
    val evAvantajiLog: Double,
    val kalibrasyonAlpha: Double,
    val egitimMacSayisi: Int,
    val egitimTakimSayisi: Int = 0,
    val modelVersiyonu: String = "KENDI_MODEL_2.0",
    val guncellemeZamani: Long = System.currentTimeMillis()
) {
    fun gecerliMi(): Boolean =
        evGolOrtalamasi.isFinite() &&
        deplasmanGolOrtalamasi.isFinite() &&
        evAvantajiLog.isFinite() &&
        kalibrasyonAlpha.isFinite() &&
        egitimMacSayisi > 0

    companion object {
        fun olustur(
            evGolOrtalamasi: Double,
            deplasmanGolOrtalamasi: Double,
            evAvantajiLog: Double,
            kalibrasyonAlpha: Double,
            egitimMacSayisi: Int,
            egitimTakimSayisi: Int = 0,
            modelVersiyonu: String = "KENDI_MODEL_2.0"
        ) = ESPNModelMeta(
            evGolOrtalamasi = evGolOrtalamasi,
            deplasmanGolOrtalamasi = deplasmanGolOrtalamasi,
            evAvantajiLog = evAvantajiLog,
            kalibrasyonAlpha = kalibrasyonAlpha,
            egitimMacSayisi = egitimMacSayisi,
            egitimTakimSayisi = egitimTakimSayisi,
            modelVersiyonu = modelVersiyonu
        )
    }
}
