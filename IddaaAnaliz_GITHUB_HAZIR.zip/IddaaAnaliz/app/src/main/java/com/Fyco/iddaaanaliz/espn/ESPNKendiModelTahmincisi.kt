@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import android.util.Log
import com.Fyco.iddaaanaliz.IddaaMarket
import com.Fyco.iddaaanaliz.IddaaOutcome
import com.Fyco.iddaaanaliz.IddaaMarketConfigRepository
import com.Fyco.iddaaanaliz.SporTuru
import com.Fyco.iddaaanaliz.merkezi.MerkeziFutbolModelHavuzu
import java.util.Locale
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln

/**
 * ESPN 365 günlük geçmişten eğitilmiş Kendi Modeli'nin canlı tahmin katmanı.
 *
 * TEMEL KURAL:
 * Bütün futbol marketleri aynı (ev golü, deplasman golü) skor dağılımından
 * türetilir. Böylece MS, KG, Alt/Üst, Çifte Şans ve takım gol marketleri
 * birbirleriyle matematiksel olarak tutarlı kalır.
 *
 * İddaa oranı model girdisi değildir.
 */
object ESPNKendiModelTahmincisi {

    /**
     * V10: Eski ESPN model yolu canlı futbol tahmininden KESİNLİKLE çıkarılmıştır.
     * Tüm futbol olasılıkları Merkezi Veri Havuzu modelinden gelmelidir.
     */
    private const val LIVE_CENTRAL_MODEL_ONLY = true

    fun marketOlasiliklari(
        market: IddaaMarket,
        spor: SporTuru,
        evTakimAdi: String?,
        deplasmanTakimAdi: String?
    ): Map<Int, Double> {
        if (LIVE_CENTRAL_MODEL_ONLY) {
            Log.w(
                "ESPN_MODEL_GUARD",
                "CANLI_ESPN_MODEL_DEVRE_DISI merkeziModel=ZORUNLU"
            )
            return emptyMap()
        }
        return marketOlasiliklariBatch(
            markets = listOf(market),
            spor = spor,
            evTakimAdi = evTakimAdi,
            deplasmanTakimAdi = deplasmanTakimAdi
        )[market.i].orEmpty()
    }

    /**
     * Aynı maçtaki bütün futbol marketleri için Kendi Modeli skor dağılımını
     * yalnızca BİR KEZ hesaplar. 15-30 markette tekrar tekrar Poisson +
     * kalibrasyon + takım ratingi hesabı yapılmasını engeller.
     */
    fun marketOlasiliklariBatch(
        markets: List<IddaaMarket>,
        spor: SporTuru,
        evTakimAdi: String?,
        deplasmanTakimAdi: String?
    ): Map<Long, Map<Int, Double>> {
        if (LIVE_CENTRAL_MODEL_ONLY) {
            Log.w("ESPN_MODEL_GUARD", "BATCH_DEVRE_DISI merkeziModel=ZORUNLU")
            return emptyMap()
        }
        if (spor != SporTuru.FUTBOL || evTakimAdi.isNullOrBlank() || deplasmanTakimAdi.isNullOrBlank()) {
            return emptyMap()
        }

        // DİKKAT: Burada ESPN kaynağından rating okunmaz.
        // Merkezi model, daha önce Merkezi Veri Havuzu'ndan hazırlanmış snapshot'tır.
        val homeId = "FUTBOL:team:${normalize(evTakimAdi)}"
        val awayId = "FUTBOL:team:${normalize(deplasmanTakimAdi)}"
        val homeRating = MerkeziFutbolModelHavuzu.takim(homeId)
        val awayRating = MerkeziFutbolModelHavuzu.takim(awayId)
        if (homeRating == null || awayRating == null) {
            Log.d(
                "ESPN_MODEL_TAHMIN",
                "MERKEZI_RATING_ESLESMEDI ev=$evTakimAdi dep=$deplasmanTakimAdi " +
                    "evVar=${homeRating != null} depVar=${awayRating != null}"
            )
            return emptyMap()
        }

        val minSample = minOf(homeRating.macSayisi, awayRating.macSayisi)
        if (minSample < 5) {
            Log.d(
                "ESPN_MODEL_TAHMIN",
                "MERKEZI_RATING_ORNEKLEM_KUCUK ev=${homeRating.macSayisi} dep=${awayRating.macSayisi} minimum=5"
            )
            return emptyMap()
        }

        val lambdas = MerkeziFutbolModelHavuzu.lambdalar(homeId, awayId) ?: return emptyMap()
        val lambdaHome = lambdas.first
        val lambdaAway = lambdas.second
        val rawDistribution = KolmogorovOlasilikKatmani.poissonDagilimi(
            lambdaHome,
            lambdaAway,
            maxGol = 10
        )
        // Aşırı uçlara gitmemesi için model kendi olasılık uzayını korur;
        // oran/edge/confidence burada hiçbir şekilde kullanılmaz.
        val distribution = calibrateDistribution(rawDistribution, 0.92)

        val result = LinkedHashMap<Long, Map<Int, Double>>()
        markets.forEach { market ->
            val title = normalize(
                runCatching { IddaaMarketConfigRepository.marketBasligi(market) }.getOrDefault("")
            )
            if (title.isBlank() || title == "iddaa marketi" || isUnsupportedMarket(title)) return@forEach

            val probabilities = marketOlasiliklariDagilimdan(
                market = market,
                title = title,
                distribution = distribution,
                lambdaHome = lambdaHome,
                lambdaAway = lambdaAway,
                homeRatingVar = true,
                awayRatingVar = true,
                evTakimAdi = evTakimAdi,
                deplasmanTakimAdi = deplasmanTakimAdi
            )
            if (probabilities.isNotEmpty()) result[market.i] = probabilities
        }

        Log.d(
            "ESPN_MODEL_TAHMIN",
            "MERKEZI_MAC_BATCH ev=$evTakimAdi dep=$deplasmanTakimAdi market=${result.size}/${markets.size} " +
                "lambda=${"%.3f".format(lambdaHome)}/${"%.3f".format(lambdaAway)} " +
                "elo=${"%.0f".format(homeRating.elo)}/${"%.0f".format(awayRating.elo)}"
        )
        return result
    }

    private fun marketOlasiliklariDagilimdan(
        market: IddaaMarket,
        title: String,
        distribution: KolmogorovOlasilikKatmani.SkorDagilimi,
        lambdaHome: Double,
        lambdaAway: Double,
        homeRatingVar: Boolean,
        awayRatingVar: Boolean,
        evTakimAdi: String,
        deplasmanTakimAdi: String
    ): Map<Int, Double> {
        val (homeWin, draw, awayWin) = KolmogorovOlasilikKatmani.macSonucu(distribution)
        val outcomes = market.o.filter { it.oynanabilirOran > 1.0 }
        if (outcomes.size < 2) return emptyMap()

        val result = linkedMapOf<Int, Double>()

        when {
            isMatchResult(title, market) -> {
                // MS 1/X/2 üçlü bir örnek uzayıdır. API bir sonucu kapatmış
                // veya göndermemişse kalan iki sonucu %100'e normalize etmek
                // kesinlikle yapılmaz; aksi halde 1/X/2 birbirinden kopar.
                if (!hasCompleteMatchResultOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "1", "ev" -> result[outcome.no] = homeWin
                        "x", "0", "beraberlik", "draw" -> result[outcome.no] = draw
                        "2", "dep", "deplasman" -> result[outcome.no] = awayWin
                    }
                }
            }

            isDoubleChance(title) -> {
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "1x", "x1" -> result[outcome.no] = homeWin + draw
                        "x2", "2x" -> result[outcome.no] = draw + awayWin
                        "12", "1ve2" -> result[outcome.no] = homeWin + awayWin
                    }
                }
            }

            isMatchResultAndBtts(title) -> {
                val btts = KolmogorovOlasilikKatmani.btts(distribution)
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    val resultProb = when {
                        selection.startsWith("1") && selection.endsWith("var") -> probability(distribution) { s -> s.first > s.second && s.first > 0 && s.second > 0 }
                        selection.startsWith("1") && selection.endsWith("yok") -> probability(distribution) { s -> s.first > s.second && !(s.first > 0 && s.second > 0) }
                        selection.startsWith("x") && selection.endsWith("var") -> probability(distribution) { s -> s.first == s.second && s.first > 0 }
                        selection.startsWith("x") && selection.endsWith("yok") -> probability(distribution) { s -> s.first == s.second && !(s.first > 0 && s.second > 0) }
                        selection.startsWith("2") && selection.endsWith("var") -> probability(distribution) { s -> s.first < s.second && s.first > 0 && s.second > 0 }
                        selection.startsWith("2") && selection.endsWith("yok") -> probability(distribution) { s -> s.first < s.second && !(s.first > 0 && s.second > 0) }
                        selection == "var" -> btts
                        selection == "yok" -> 1.0 - btts
                        else -> null
                    }
                    if (resultProb != null) result[outcome.no] = resultProb
                }
            }

            isMatchResultAndTotalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    val p = when {
                        selection.startsWith("1") && selection.endsWith("alt") -> probability(distribution) { s -> s.first > s.second && s.first + s.second <= floor(line).toInt() }
                        selection.startsWith("1") && selection.endsWith("ust") -> probability(distribution) { s -> s.first > s.second && s.first + s.second > floor(line).toInt() }
                        selection.startsWith("x") && selection.endsWith("alt") -> probability(distribution) { s -> s.first == s.second && s.first + s.second <= floor(line).toInt() }
                        selection.startsWith("x") && selection.endsWith("ust") -> probability(distribution) { s -> s.first == s.second && s.first + s.second > floor(line).toInt() }
                        selection.startsWith("2") && selection.endsWith("alt") -> probability(distribution) { s -> s.first < s.second && s.first + s.second <= floor(line).toInt() }
                        selection.startsWith("2") && selection.endsWith("ust") -> probability(distribution) { s -> s.first < s.second && s.first + s.second > floor(line).toInt() }
                        else -> null
                    }
                    if (p != null) result[outcome.no] = p
                }
            }

            isTotalOverUnderAndBtts(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val limit = floor(line).toInt()
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    val p = when {
                        selection.contains("alt") && selection.endsWith("var") -> probability(distribution) { s -> s.first + s.second <= limit && s.first > 0 && s.second > 0 }
                        selection.contains("alt") && selection.endsWith("yok") -> probability(distribution) { s -> s.first + s.second <= limit && !(s.first > 0 && s.second > 0) }
                        selection.contains("ust") && selection.endsWith("var") -> probability(distribution) { s -> s.first + s.second > limit && s.first > 0 && s.second > 0 }
                        selection.contains("ust") && selection.endsWith("yok") -> probability(distribution) { s -> s.first + s.second > limit && !(s.first > 0 && s.second > 0) }
                        else -> null
                    }
                    if (p != null) result[outcome.no] = p
                }
            }

            isTotalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val under = 1.0 - KolmogorovOlasilikKatmani.over(distribution, line)
                val over = 1.0 - under
                if (!hasCompleteTwoWayOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (selectionKind(outcome.n)) {
                        SelectionKind.UNDER -> result[outcome.no] = under
                        SelectionKind.OVER -> result[outcome.no] = over
                        else -> Unit
                    }
                }
            }

            isHomeGoalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val over = marginalOver(distribution, line, home = true)
                if (!hasCompleteTwoWayOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (selectionKind(outcome.n)) {
                        SelectionKind.UNDER -> result[outcome.no] = 1.0 - over
                        SelectionKind.OVER -> result[outcome.no] = over
                        else -> Unit
                    }
                }
            }

            isAwayGoalOverUnder(title) -> {
                val line = extractLine(title) ?: return emptyMap()
                val over = marginalOver(distribution, line, home = false)
                if (!hasCompleteTwoWayOutcomes(outcomes)) return emptyMap()
                outcomes.forEach { outcome ->
                    when (selectionKind(outcome.n)) {
                        SelectionKind.UNDER -> result[outcome.no] = 1.0 - over
                        SelectionKind.OVER -> result[outcome.no] = over
                        else -> Unit
                    }
                }
            }

            isTotalOddEven(title) -> {
                val odd = distribution.hucreler
                    .filterKeys { (h, a) -> (h + a) % 2 == 1 }
                    .values.sum()
                outcomes.forEach { outcome ->
                    when (normalize(outcome.n)) {
                        "tek" -> result[outcome.no] = odd
                        "cift" -> result[outcome.no] = 1.0 - odd
                    }
                }
            }

            isTotalGoalsRange(title) -> {
                outcomes.forEach { outcome ->
                    val selection = normalizeCompact(outcome.n)
                    parseGoalRange(selection)?.let { range ->
                        result[outcome.no] = probability(distribution) { s ->
                            val total = s.first + s.second
                            total in range
                        }
                    }
                }
            }

            else -> return emptyMap()
        }

        return finalizeResult(result, outcomes)
    }

    // Geriye dönük uyumluluk.
    fun marketOlasiliklari(
        market: IddaaMarket,
        spor: SporTuru,
        veri: com.Fyco.iddaaanaliz.MacDisVerisi?
    ): Map<Int, Double> {
        if (veri == null) return emptyMap()
        return marketOlasiliklari(market, spor, veri.evSahibi.isim, veri.deplasman.isim)
    }

    private fun probability(
        distribution: KolmogorovOlasilikKatmani.SkorDagilimi,
        predicate: (Pair<Int, Int>) -> Boolean
    ): Double = distribution.hucreler.filterKeys(predicate).values.sum().coerceIn(0.0, 1.0)

    private fun marginalOver(
        distribution: KolmogorovOlasilikKatmani.SkorDagilimi,
        line: Double,
        home: Boolean
    ): Double {
        val limit = floor(line).toInt()
        val under = distribution.hucreler
            .filterKeys { score ->
                val goals = if (home) score.first else score.second
                goals <= limit
            }
            .values.sum()
        return (1.0 - under).coerceIn(0.0, 1.0)
    }

    private fun isUnsupportedMarket(title: String): Boolean {
        val compact = title.replace(" ", "")
        return title.contains("yari") ||
                title.contains("ceyrek") ||
                title.contains("devre") ||
                title.contains("korner") ||
                title.contains("kart") ||
                title.contains("sut") ||
                title.contains("faul") ||
                title.contains("ofsayt") ||
                title.contains("oyuncu") ||
                compact.contains("ilkyar")
    }

    private fun isMatchResult(title: String, market: IddaaMarket): Boolean {
        if (title == "mac sonucu") return true
        if (title.contains("handikap")) return false
        val names = market.o.map { normalize(it.n) }
        return names.contains("1") && names.contains("2") && (names.contains("x") || names.contains("0"))
    }

    private fun isDoubleChance(title: String): Boolean =
        title.contains("cifte sans") && !title.contains("yari") && !title.contains("ceyrek")

    private fun isMatchResultAndBtts(title: String): Boolean =
        (title.contains("mac sonucu") || title.contains("sonucu")) &&
                title.contains("karsilikli gol")

    private fun isMatchResultAndTotalOverUnder(title: String): Boolean =
        (title.contains("mac sonucu") || title.contains("sonucu")) &&
                (title.contains("alt/ust") || title.contains("alt ust")) &&
                !title.contains("karsilikli gol")

    private fun isTotalOverUnderAndBtts(title: String): Boolean =
        (title.contains("alt/ust") || title.contains("alt ust")) &&
                title.contains("karsilikli gol")

    private fun isTotalOverUnder(title: String): Boolean {
        if (!title.contains("alt/ust") && !title.contains("alt ust")) return false
        return !title.contains("ev sahibi") && !title.contains("deplasman") &&
                !title.contains("korner") && !title.contains("kart")
    }

    private fun isHomeGoalOverUnder(title: String): Boolean =
        title.contains("ev sahibi") && (title.contains("alt/ust") || title.contains("alt ust"))

    private fun isAwayGoalOverUnder(title: String): Boolean =
        title.contains("deplasman") && (title.contains("alt/ust") || title.contains("alt ust"))

    private fun isTotalGoalsRange(title: String): Boolean =
        title.contains("toplam gol") &&
                !title.contains("alt/ust") && !title.contains("alt ust")

    private fun isTotalOddEven(title: String): Boolean =
        title.contains("tek / cift") || title.contains("tek/cift") || title.contains("tek cift")

    private fun extractLine(title: String): Double? =
        Regex("(0\\.5|1\\.5|2\\.5|3\\.5|4\\.5|5\\.5|6\\.5|7\\.5)")
            .find(title)?.value?.toDoubleOrNull()

    private fun parseGoalRange(selection: String): IntRange? {
        val s = normalizeCompact(selection)
        Regex("^(\\d+)$").matchEntire(s)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return null
            return n..n
        }
        Regex("^(\\d+)-(\\d+)$").matchEntire(s)?.let {
            val a = it.groupValues[1].toIntOrNull() ?: return null
            val b = it.groupValues[2].toIntOrNull() ?: return null
            return minOf(a, b)..maxOf(a, b)
        }
        Regex("^(\\d+)veuzeri$").matchEntire(s)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return null
            return n..20
        }
        Regex("^(\\d+)\\+$").matchEntire(s)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return null
            return n..20
        }
        return null
    }

    private fun calibrateDistribution(
        distribution: KolmogorovOlasilikKatmani.SkorDagilimi,
        alpha: Double
    ): KolmogorovOlasilikKatmani.SkorDagilimi {
        val a = alpha.coerceIn(0.70, 1.0)
        val powered = distribution.hucreler.mapValues { (_, p) ->
            exp(ln(p.coerceAtLeast(1e-12)) * a)
        }
        return KolmogorovOlasilikKatmani.normalize(powered)
    }

    private enum class SelectionKind { UNDER, OVER, OTHER }

    private fun selectionKind(value: String?): SelectionKind = when (normalizeCompact(value)) {
        "alt", "under" -> SelectionKind.UNDER
        "ust", "over" -> SelectionKind.OVER
        else -> SelectionKind.OTHER
    }

    private fun hasCompleteTwoWayOutcomes(outcomes: List<IddaaOutcome>): Boolean {
        val kinds = outcomes.map { selectionKind(it.n) }.toSet()
        return SelectionKind.UNDER in kinds && SelectionKind.OVER in kinds
    }

    private fun hasCompleteMatchResultOutcomes(outcomes: List<IddaaOutcome>): Boolean {
        val kinds = outcomes.map { normalizeCompact(it.n) }.toSet()
        val hasHome = "1" in kinds || "ev" in kinds
        val hasDraw = "x" in kinds || "0" in kinds || "beraberlik" in kinds || "draw" in kinds
        val hasAway = "2" in kinds || "dep" in kinds || "deplasman" in kinds
        return hasHome && hasDraw && hasAway
    }

    private fun finalizeResult(
        result: Map<Int, Double>,
        outcomes: List<IddaaOutcome>
    ): Map<Int, Double> {
        // Marketin iki/üç tarafı da çözülemediyse kısmi olasılık üretme.
        val required = outcomes.map { it.no }.toSet()
        if (!required.all { result.containsKey(it) }) return emptyMap()
        val valid = result.filterValues { it.isFinite() && it >= 0.0 }
        if (valid.size < 2) return emptyMap()
        val sum = valid.values.sum()
        if (!sum.isFinite() || sum <= 0.0) return emptyMap()
        return valid.mapValues { (_, p) -> p / sum }
    }

    private fun normalizeCompact(value: String?): String = normalize(value).replace(" ", "")

    private fun normalize(value: String?): String = value
        ?.trim()
        ?.lowercase(Locale.forLanguageTag("tr-TR"))
        ?.replace('ı', 'i')
        ?.replace('ş', 's')
        ?.replace('ğ', 'g')
        ?.replace('ü', 'u')
        ?.replace('ö', 'o')
        ?.replace('ç', 'c')
        ?.replace(Regex("\\s+"), " ")
        ?: ""
}
