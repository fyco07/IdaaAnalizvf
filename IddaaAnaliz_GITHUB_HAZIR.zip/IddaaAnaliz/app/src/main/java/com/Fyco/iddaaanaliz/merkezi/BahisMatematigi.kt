@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

/** Faz 8: piyasa benchmarkı, fair odds, edge ve EV. */
object BahisMatematigi {
    data class Value(val marketProbability: Double, val modelProbability: Double, val edge: Double, val ev: Double, val fairOdds: Double)
    fun evaluate(modelProbability: Double, odds: Double, marketProbability: Double? = null): Value? {
        if (odds <= 1.0 || modelProbability !in 0.0..1.0) return null
        val mp = marketProbability?.takeIf { it in 0.0..1.0 } ?: (1.0 / odds)
        return Value(mp, modelProbability, modelProbability - mp, modelProbability * odds - 1.0, 1.0 / modelProbability.coerceAtLeast(0.0001))
    }
    fun noVig(odds: List<Double>): List<Double> { val inv=odds.map { if(it>1.0) 1.0/it else 0.0 }; val s=inv.sum(); return if(s<=0) emptyList() else inv.map{it/s} }
}
