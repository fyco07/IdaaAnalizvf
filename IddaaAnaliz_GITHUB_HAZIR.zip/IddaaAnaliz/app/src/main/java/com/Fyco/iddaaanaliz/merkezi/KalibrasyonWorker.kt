@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import com.Fyco.iddaaanaliz.MerkeziVeriHavuzu
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

class KalibrasyonWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            MerkeziVeriHavuzu.init(applicationContext)
                        // Settlement, yalnızca kesin sonucu bulunan tahminlerde yapılır.
            // Böylece sonuç gelmeden tahmini "doğru/yanlış" olarak işaretlemeyiz.
            val db = Room.databaseBuilder(applicationContext, MerkeziVeritabani::class.java, "iddaa_merkezi_havuz.db").build()
            val dao = db.dao()
            dao.pendingSettlements(500).forEach { row ->
                val occurred = settles(row.marketTitle, row.outcomeKey, row.resultHome, row.resultAway, row.resultHomeFirstHalf, row.resultAwayFirstHalf)
                    ?: return@forEach
                val brier = KalibrasyonMotoru.brier(row.modelProbability, occurred)
                dao.settlePrediction(row.predictionId, if (occurred) "WON" else "LOST", brier)
            }
            MerkeziFutbolModelHavuzu.refreshCalibration(dao)
            db.close()
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun settles(titleRaw: String, keyRaw: String, h: Double, a: Double, hh: Double?, ah: Double?): Boolean? {
        val t = norm(titleRaw)
        val rawKey = keyRaw.substringAfter("|", keyRaw)
        val k = norm(rawKey)
        val xh = hh ?: h; val xa = ah ?: a
        return when {
            t.contains("dogru skor") || t.contains("tahmini skor") || (t.contains("skor") && Regex("\\d+[-:]\\d+").matches(k)) -> {
                val m = Regex("^(\\d+)[-:](\\d+)$").matchEntire(k) ?: return null
                val sh = m.groupValues[1].toIntOrNull() ?: return null
                val sa = m.groupValues[2].toIntOrNull() ?: return null
                h.toInt() == sh && a.toInt() == sa
            }
            t.contains("karsilikli gol") -> when (k) { "var" -> h > 0 && a > 0; "yok" -> h == 0.0 || a == 0.0; else -> null }
            t.contains("mac sonucu") || (k in setOf("1","x","0","2") && !t.contains("yari") && !t.contains("ceyrek")) -> when(k) { "1" -> h>a; "x","0" -> h==a; "2" -> h<a; else -> null }
            t.contains("ust") || t.contains("alt") -> {
                val line = Regex("([0-9]+(?:[.,][0-9]+)?)").find(t)?.groupValues?.get(1)?.replace(',','.')?.toDoubleOrNull() ?: return null
                when(k) { "ust" -> h+a>line; "alt" -> h+a<line; else -> null }
            }
            t.contains("ilk yari") || t.contains("1. yari") -> when(k) { "1" -> xh>xa; "x","0" -> xh==xa; "2" -> xh<xa; else -> null }
            else -> null
        }
    }
    private fun norm(v:String)=v.lowercase(Locale.forLanguageTag("tr-TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c').trim()
}
