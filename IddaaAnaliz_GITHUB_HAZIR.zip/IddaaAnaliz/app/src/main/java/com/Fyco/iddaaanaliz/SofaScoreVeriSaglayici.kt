@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.content.Context
import com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
import com.Fyco.iddaaanaliz.veritabani.SofaScoreTarihselMac

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.Normalizer
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * İddaa maçlarını dış verilerle zenginleştiren SofaScore sağlayıcısı.
 *
 * Ana maç kimliği ve marketler HER ZAMAN İddaa tarafından belirlenir.
 * SofaScore yalnızca aynı karşılaşmayı bulmak ve dış istatistik sağlamak için kullanılır.
 * API-Sports / API-Football kullanılmaz.
 *
 * Not: SofaScore'ın public/internal endpoint'leri değişebilir ve zaman zaman WAF/403
 * uygulayabilir. Bu nedenle sağlayıcı başarısız olursa null döner; İddaa akışı bozulmaz.
 */
object SofaScoreVeriSaglayici {

    private const val CONNECT_TIMEOUT_SECONDS = 12L
    private const val READ_TIMEOUT_SECONDS = 18L
    private const val MAX_RECENT_MATCHES = 5
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }
    private const val MAX_MISSING_PLAYERS_TO_QUERY = 4

    private val client = OkHttpClient.Builder()
        .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val baseUrls = listOf(
        "https://api.sofascore.com/api/v1/",
        "https://www.sofascore.com/api/v1/",
        "https://api.sofascore.app/api/v1/"
    )

    private val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Linux; Android 15; Pixel 7) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36",
        "Accept" to "application/json, text/plain, */*",
        "Accept-Language" to "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
        "Referer" to "https://www.sofascore.com/"
    )

    suspend fun macVerisiGetir(
        event: IddaaEvent,
        spor: SporTuru
    ): MacDisVerisi? {
        return try {
            val date = istanbulTarihi(event.d)
            val sportSlug = when (spor) {
                SporTuru.FUTBOL -> "football"
                SporTuru.BASKETBOL -> "basketball"
            }

            val schedule = getJson(
                "sport/$sportSlug/scheduled-events/$date"
            ) ?: return null

            val sofaEvent = schedule
                .objArray("events")
                .mapNotNull { it.asJsonObjectOrNull() }
                .mapNotNull { parseScheduleEvent(it) }
                .mapNotNull { candidate ->
                    val score = teamMatchScore(
                        event.hn,
                        event.an,
                        candidate.homeName,
                        candidate.awayName
                    )
                    if (score < 0.82) null else candidate.copy(eslesme = score)
                }
                .maxByOrNull { it.eslesme }
                ?: return null

            val eventRoot = getJson("event/${sofaEvent.sofaEventId}")
            val lineups = getJson("event/${sofaEvent.sofaEventId}/lineups")

            val homeTeamId = eventRoot
                ?.obj("event")
                ?.obj("homeTeam")
                ?.long("id")
                ?: sofaEvent.homeTeamId

            val awayTeamId = eventRoot
                ?.obj("event")
                ?.obj("awayTeam")
                ?.long("id")
                ?: sofaEvent.awayTeamId

            val homeRecent = recentTeamMatches(
                teamId = homeTeamId,
                teamName = event.hn,
                sport = spor,
                sportSlug = sportSlug
            )
            val awayRecent = recentTeamMatches(
                teamId = awayTeamId,
                teamName = event.an,
                sport = spor,
                sportSlug = sportSlug
            )

            val homeForm = formFromRecent(homeRecent, homeTeamId)
            val awayForm = formFromRecent(awayRecent, awayTeamId)

            val homeStats = aggregateSportStats(homeRecent, isHomeTeam = true)
            val awayStats = aggregateSportStats(awayRecent, isHomeTeam = false)

            val h2h = h2hFromRecent(
                event.hn,
                event.an,
                homeRecent + awayRecent
            )

            val homeMissing = parseMissingPlayers(lineups?.obj("home"))
            val awayMissing = parseMissingPlayers(lineups?.obj("away"))

            val tournamentId = eventRoot
                ?.obj("event")
                ?.obj("tournament")
                ?.obj("uniqueTournament")
                ?.long("id")

            val seasonId = eventRoot
                ?.obj("event")
                ?.obj("season")
                ?.long("id")

            val homeMissingEnriched = enrichMissingPlayers(
                homeMissing,
                tournamentId,
                seasonId,
                spor
            )
            val awayMissingEnriched = enrichMissingPlayers(
                awayMissing,
                tournamentId,
                seasonId,
                spor
            )

            val homeLineupPlayers = parseLineupNames(lineups?.obj("home"))
            val awayLineupPlayers = parseLineupNames(lineups?.obj("away"))

            val context = MacBaglami(
                lig = eventRoot
                    ?.obj("event")
                    ?.obj("tournament")
                    ?.string("name"),
                ligSiralamasiEv = null,
                ligSiralamasiDeplasman = null,
                puanFarki = 0.0,
                motivasyonSkoru = motivationFromRecent(homeRecent, awayRecent),
                fiksturYogunluguEv = fixtureDensity(homeRecent),
                fiksturYogunluguDeplasman = fixtureDensity(awayRecent),
                macOnemi = matchImportance(eventRoot)
            )

            val evDeplasman = EvDeplasmanVerisi(
                evSahibiFormu = formStrength(homeForm),
                deplasmanFormu = formStrength(awayForm),
                evSahibiGalibiyetOrani = if (homeForm.galibiyet + homeForm.beraberlik + homeForm.maglubiyet > 0) {
                    homeForm.galibiyet.toDouble() /
                            (homeForm.galibiyet + homeForm.beraberlik + homeForm.maglubiyet)
                } else 0.0,
                deplasmanGalibiyetOrani = if (awayForm.galibiyet + awayForm.beraberlik + awayForm.maglubiyet > 0) {
                    awayForm.galibiyet.toDouble() /
                            (awayForm.galibiyet + awayForm.beraberlik + awayForm.maglubiyet)
                } else 0.0
            )

            val veriKaynaklari = mutableListOf(
                "İddaa maç eşleştirme",
                "SofaScore maç programı",
                "SofaScore son maçlar"
            )
            if (lineups != null) veriKaynaklari += "SofaScore kadro/eksik oyuncular"
            if (h2h.macSayisi > 0) veriKaynaklari += "SofaScore H2H"

            MacDisVerisi(
                spor = spor,
                evSahibi = TakimVerisi(
                    id = homeTeamId?.toString(),
                    isim = event.hn,
                    lig = context.lig,
                    ulke = null
                ),
                deplasman = TakimVerisi(
                    id = awayTeamId?.toString(),
                    isim = event.an,
                    lig = context.lig,
                    ulke = null
                ),
                formEv = homeForm,
                formDeplasman = awayForm,
                h2h = h2h,
                futbolEv = if (spor == SporTuru.FUTBOL) homeStats.futbol else null,
                futbolDeplasman = if (spor == SporTuru.FUTBOL) awayStats.futbol else null,
                basketbolEv = if (spor == SporTuru.BASKETBOL) homeStats.basketbol else null,
                basketbolDeplasman = if (spor == SporTuru.BASKETBOL) awayStats.basketbol else null,
                sakatlikEv = SakatlikVerisi(
                    oyuncular = homeMissingEnriched,
                    eksikOyuncuSayisi = homeMissingEnriched.size,
                    onemliEksikSayisi = homeMissingEnriched.count { it.onemDerecesi >= 0.60 },
                    takimEtkisi = homeMissingEnriched.sumOf { it.onemDerecesi }.coerceIn(0.0, 3.0)
                ),
                sakatlikDeplasman = SakatlikVerisi(
                    oyuncular = awayMissingEnriched,
                    eksikOyuncuSayisi = awayMissingEnriched.size,
                    onemliEksikSayisi = awayMissingEnriched.count { it.onemDerecesi >= 0.60 },
                    takimEtkisi = awayMissingEnriched.sumOf { it.onemDerecesi }.coerceIn(0.0, 3.0)
                ),
                kadroEv = KadroVerisi(
                    mevcut = homeLineupPlayers.isNotEmpty(),
                    oyuncular = homeLineupPlayers,
                    guvenSkoru = if (homeLineupPlayers.isNotEmpty()) 1.0 else 0.0
                ),
                kadroDeplasman = KadroVerisi(
                    mevcut = awayLineupPlayers.isNotEmpty(),
                    oyuncular = awayLineupPlayers,
                    guvenSkoru = if (awayLineupPlayers.isNotEmpty()) 1.0 else 0.0
                ),
                oranHareketleri = emptyList(),
                macBaglami = context,
                evDeplasman = evDeplasman,
                veriKaynaklari = veriKaynaklari,
                veriTamlikPuani = 0
            )


            MacDisVerisi(
                spor = spor,
                evSahibi = TakimVerisi(
                    id = homeTeamId?.toString(),
                    isim = event.hn,
                    lig = context.lig,
                    ulke = null
                ),
                deplasman = TakimVerisi(
                    id = awayTeamId?.toString(),
                    isim = event.an,
                    lig = context.lig,
                    ulke = null
                ),
                formEv = homeForm,
                formDeplasman = awayForm,
                h2h = h2h,
                futbolEv = if (spor == SporTuru.FUTBOL) homeStats.futbol else null,
                futbolDeplasman = if (spor == SporTuru.FUTBOL) awayStats.futbol else null,
                basketbolEv = if (spor == SporTuru.BASKETBOL) homeStats.basketbol else null,
                basketbolDeplasman = if (spor == SporTuru.BASKETBOL) awayStats.basketbol else null,
                sakatlikEv = SakatlikVerisi(
                    oyuncular = homeMissingEnriched,
                    eksikOyuncuSayisi = homeMissingEnriched.size,
                    onemliEksikSayisi = homeMissingEnriched.count { it.onemDerecesi >= 0.60 },
                    takimEtkisi = homeMissingEnriched.sumOf { it.onemDerecesi }.coerceIn(0.0, 3.0)
                ),
                sakatlikDeplasman = SakatlikVerisi(
                    oyuncular = awayMissingEnriched,
                    eksikOyuncuSayisi = awayMissingEnriched.size,
                    onemliEksikSayisi = awayMissingEnriched.count { it.onemDerecesi >= 0.60 },
                    takimEtkisi = awayMissingEnriched.sumOf { it.onemDerecesi }.coerceIn(0.0, 3.0)
                ),
                kadroEv = KadroVerisi(
                    mevcut = homeLineupPlayers.isNotEmpty(),
                    oyuncular = homeLineupPlayers,
                    guvenSkoru = if (homeLineupPlayers.isNotEmpty()) 1.0 else 0.0
                ),
                kadroDeplasman = KadroVerisi(
                    mevcut = awayLineupPlayers.isNotEmpty(),
                    oyuncular = awayLineupPlayers,
                    guvenSkoru = if (awayLineupPlayers.isNotEmpty()) 1.0 else 0.0
                ),
                oranHareketleri = emptyList(),
                macBaglami = context,
                evDeplasman = evDeplasman,
                veriKaynaklari = veriKaynaklari,
                veriTamlikPuani = 0
            )
        } catch (_: Exception) {
            null
        }
    }

    private data class SofaMatch(
        val sofaEventId: Long,
        val homeTeamId: Long?,
        val awayTeamId: Long?,
        val homeName: String,
        val awayName: String,
        val eslesme: Double = 0.0
    )

    private data class MissingPlayerCandidate(
        val playerId: Long?,
        val name: String,
        val status: String
    )

    private data class RecentMatch(
        val eventId: Long,
        val homeName: String,
        val awayName: String,
        val homeId: Long?,
        val awayId: Long?,
        val homeScore: Double?,
        val awayScore: Double?,
        val startTimestamp: Long
    )

    private data class AggregateStats(
        val futbol: FutbolIstatistikleri?,
        val basketbol: BasketbolIstatistikleri?
    )

    private suspend fun recentTeamMatches(
        teamId: Long?,
        teamName: String,
        sport: SporTuru,
        sportSlug: String
    ): List<RecentMatch> {
        // Önce 365 günlük Room arşivini kullan. Böylece geçmiş veri
        // doğrudan modelin form ve istatistik hesaplarına girer.
        val dao = appContext?.let {
            runCatching {
                IddaaAnalizDatabase.getInstance(it).sofascoreTarihselMacDao()
            }.getOrNull()
        }

        if (dao != null) {
            val sporAdi = sport.name
            val tarihsel = if (teamId != null) {
                dao.takimGecmisiniSporlaGetir(
                    takimId = teamId,
                    spor = sporAdi,
                    limit = MAX_RECENT_MATCHES
                )
            } else {
                dao.takimAdiGecmisiniSporlaGetir(
                    takimAdi = teamName,
                    spor = sporAdi,
                    limit = MAX_RECENT_MATCHES
                )
            }

            if (tarihsel.isNotEmpty()) {
                return tarihsel.map { it.toRecentMatch() }
            }
        }

        // Arşiv henüz dolmadıysa mevcut SofaScore endpoint'i fallback.
        if (teamId == null) return emptyList()

        val page0 = getJson("team/$teamId/events/last/0") ?: return emptyList()
        return page0.objArray("events")
            .mapNotNull { it.asJsonObjectOrNull() }
            .mapNotNull { parseRecentMatch(it) }
            .take(MAX_RECENT_MATCHES)
    }

    private fun SofaScoreTarihselMac.toRecentMatch(): RecentMatch =
        RecentMatch(
            eventId = eventId,
            homeName = evTakimAdi,
            awayName = deplasmanTakimAdi,
            homeId = evTakimId,
            awayId = deplasmanTakimId,
            homeScore = evSkor?.toDouble(),
            awayScore = deplasmanSkor?.toDouble(),
            startTimestamp = baslangic
        )

    private fun parseScheduleEvent(obj: JsonObject): SofaMatch? {
        val id = obj.long("id") ?: return null
        val home = obj.obj("homeTeam") ?: return null
        val away = obj.obj("awayTeam") ?: return null
        val homeName = home.string("name") ?: home.string("shortName") ?: return null
        val awayName = away.string("name") ?: away.string("shortName") ?: return null
        return SofaMatch(
            sofaEventId = id,
            homeTeamId = home.long("id"),
            awayTeamId = away.long("id"),
            homeName = homeName,
            awayName = awayName
        )
    }

    private fun parseRecentMatch(obj: JsonObject): RecentMatch? {
        val id = obj.long("id") ?: return null
        val home = obj.obj("homeTeam") ?: return null
        val away = obj.obj("awayTeam") ?: return null
        val homeScore = obj.obj("homeScore")?.number("current")?.toDouble()
        val awayScore = obj.obj("awayScore")?.number("current")?.toDouble()
        val ts = obj.long("startTimestamp") ?: 0L
        return RecentMatch(
            eventId = id,
            homeName = home.string("name") ?: home.string("shortName") ?: "",
            awayName = away.string("name") ?: away.string("shortName") ?: "",
            homeId = home.long("id"),
            awayId = away.long("id"),
            homeScore = homeScore,
            awayScore = awayScore,
            startTimestamp = ts
        )
    }

    private fun formFromRecent(
        matches: List<RecentMatch>,
        teamId: Long?
    ): FormVerisi {
        var w = 0
        var d = 0
        var l = 0
        var gf = 0.0
        var ga = 0.0
        val recent = mutableListOf<MacFormSonucu>()

        matches.take(MAX_RECENT_MATCHES).forEach { match ->
            val homeSide = when {
                teamId != null && match.homeId != null -> match.homeId == teamId
                teamId != null && match.awayId != null -> false
                else -> true
            }
            if (teamId != null && match.homeId != teamId && match.awayId != teamId) return@forEach
            val teamScore = if (homeSide) match.homeScore else match.awayScore
            val oppScore = if (homeSide) match.awayScore else match.homeScore
            if (teamScore == null || oppScore == null) return@forEach

            val win = teamScore > oppScore
            val draw = abs(teamScore - oppScore) < 0.001
            if (win) w++ else if (draw) d++ else l++
            gf += teamScore
            ga += oppScore
            recent += MacFormSonucu(
                rakip = if (homeSide) match.awayName else match.homeName,
                skor = "${teamScore.toInt()}-${oppScore.toInt()}",
                evSahibi = homeSide,
                kazanildi = win,
                beraberlik = draw,
                atilan = teamScore,
                yenilen = oppScore
            )
        }

        val n = recent.size.coerceAtLeast(1)
        return FormVerisi(
            sonMaclar = recent,
            galibiyet = w,
            beraberlik = d,
            maglubiyet = l,
            atilan = gf / n,
            yenilen = ga / n,
            puanOrtalamasi = (w * 3.0 + d) / n
        )
    }

    private fun aggregateSportStats(
        matches: List<RecentMatch>,
        isHomeTeam: Boolean
    ): AggregateStats {
        val valid = matches.filter { it.homeScore != null && it.awayScore != null }
        if (valid.isEmpty()) {
            return AggregateStats(
                futbol = FutbolIstatistikleri(),
                basketbol = BasketbolIstatistikleri()
            )
        }

        val gf = valid.map {
            if (isHomeTeam) it.homeScore!! else it.awayScore!!
        }.average()
        val ga = valid.map {
            if (isHomeTeam) it.awayScore!! else it.homeScore!!
        }.average()

        // Sonuç skorlarından türetilebilen güvenilir alanları dolduruyoruz.
        // Şut/xG/ribaund gibi alanları uydurmuyoruz; bunlar 0 kalıyor.
        return AggregateStats(
            futbol = FutbolIstatistikleri(
                macSayisi = valid.size,
                gol = gf,
                yenilenGol = ga,
                xg = 0.0,
                xga = 0.0,
                sut = 0.0,
                isabetliSut = 0.0,
                topaSahipOlma = 0.0,
                korner = 0.0,
                sariKart = 0.0,
                kirmiziKart = 0.0,
                cleanSheet = valid.count {
                    val opp = if (isHomeTeam) it.awayScore!! else it.homeScore!!
                    opp == 0.0
                }.toDouble() / valid.size,
                golAtamama = valid.count {
                    val own = if (isHomeTeam) it.homeScore!! else it.awayScore!!
                    own == 0.0
                }.toDouble() / valid.size
            ),
            basketbol = BasketbolIstatistikleri(
                macSayisi = valid.size,
                attigiSayi = gf,
                yedigiSayi = ga
            )
        )
    }

    private fun h2hFromRecent(
        homeTeam: String,
        awayTeam: String,
        matches: List<RecentMatch>
    ): H2HVerisi {
        var count = 0
        var homeWins = 0
        var draws = 0
        var awayWins = 0
        var homeFor = 0.0
        var homeAgainst = 0.0
        var awayFor = 0.0
        var awayAgainst = 0.0

        val homeN = normalizeName(homeTeam)
        val awayN = normalizeName(awayTeam)

        matches.forEach { m ->
            val mnH = normalizeName(m.homeName)
            val mnA = normalizeName(m.awayName)
            val isH2H = mnH == homeN && mnA == awayN || mnH == awayN && mnA == homeN
            if (!isH2H || m.homeScore == null || m.awayScore == null) return@forEach
            count++

            if (mnH == homeN) {
                homeFor += m.homeScore
                homeAgainst += m.awayScore
                awayFor += m.awayScore
                awayAgainst += m.homeScore
                when {
                    m.homeScore > m.awayScore -> homeWins++
                    m.homeScore < m.awayScore -> awayWins++
                    else -> draws++
                }
            } else {
                homeFor += m.awayScore
                homeAgainst += m.homeScore
                awayFor += m.homeScore
                awayAgainst += m.awayScore
                when {
                    m.awayScore > m.homeScore -> homeWins++
                    m.awayScore < m.homeScore -> awayWins++
                    else -> draws++
                }
            }
        }

        val n = count.coerceAtLeast(1)
        return H2HVerisi(
            macSayisi = count,
            evGalibiyet = homeWins,
            beraberlik = draws,
            deplasmanGalibiyet = awayWins,
            evAtanOrtalama = homeFor / n,
            evYenilenOrtalama = homeAgainst / n,
            deplasmanAtanOrtalama = awayFor / n,
            deplasmanYenilenOrtalama = awayAgainst / n
        )
    }

    private fun parseMissingPlayers(side: JsonObject?): List<MissingPlayerCandidate> {
        if (side == null) return emptyList()
        return side.objArray("missingPlayers").mapNotNull { el ->
            val obj = el.asJsonObjectOrNull() ?: return@mapNotNull null
            val player = obj.obj("player")
            val name = player?.string("name") ?: obj.string("name") ?: return@mapNotNull null
            MissingPlayerCandidate(
                playerId = player?.long("id"),
                name = name,
                status = normalizeStatus(
                    obj.string("reason")
                        ?: obj.string("description")
                        ?: obj.string("type")
                        ?: "BELIRSIZ"
                )
            )
        }
    }

    private fun parseLineupNames(side: JsonObject?): List<String> {
        if (side == null) return emptyList()
        val values = mutableListOf<String>()

        side.objArray("players").forEach { el ->
            val obj = el.asJsonObjectOrNull() ?: return@forEach
            val p = obj.obj("player")
            (p?.string("name") ?: obj.string("name"))?.let(values::add)
        }
        side.objArray("startingLineup").forEach { el ->
            val obj = el.asJsonObjectOrNull() ?: return@forEach
            val p = obj.obj("player")
            (p?.string("name") ?: obj.string("name"))?.let(values::add)
        }

        return values.distinct()
    }

    private fun enrichMissingPlayers(
        players: List<MissingPlayerCandidate>,
        tournamentId: Long?,
        seasonId: Long?,
        spor: SporTuru
    ): List<OyuncuDurumu> {
        if (players.isEmpty()) return emptyList()

        return players
            .take(MAX_MISSING_PLAYERS_TO_QUERY)
            .map { candidate ->
                val importance = if (candidate.playerId != null && tournamentId != null && seasonId != null) {
                    playerImportance(
                        playerId = candidate.playerId,
                        tournamentId = tournamentId,
                        seasonId = seasonId,
                        spor = spor
                    )
                } else {
                    0.25
                }

                OyuncuDurumu(
                    oyuncuAdi = candidate.name,
                    durum = candidate.status,
                    oynayacak = false,
                    onemDerecesi = importance
                )
            }
    }

    private fun playerImportance(
        playerId: Long,
        tournamentId: Long,
        seasonId: Long,
        spor: SporTuru
    ): Double {
        val json = getJson(
            "player/$playerId/unique-tournament/$tournamentId/season/$seasonId/statistics/overall"
        ) ?: return 0.25
        val stats = json.obj("statistics") ?: return 0.25

        val appearances = stats.number("appearances")?.toDouble() ?: 0.0
        val goals = stats.number("goals")?.toDouble() ?: 0.0
        val assists = stats.number("assists")?.toDouble() ?: 0.0
        val rating = stats.number("rating")?.toDouble() ?: 0.0
        val points = stats.number("points")?.toDouble() ?: 0.0
        val minutes = stats.number("minutesPlayed")?.toDouble() ?: 0.0

        return when (spor) {
            SporTuru.FUTBOL -> {
                val perApp = if (appearances > 0) (goals + assists * 0.7) / appearances else 0.0
                val ratingPart = if (rating > 0.0) ((rating - 6.5) / 1.5).coerceIn(0.0, 1.0) else 0.0
                val minutesPart = (minutes / 1800.0).coerceIn(0.0, 1.0)
                (0.50 * perApp.coerceIn(0.0, 1.0) + 0.30 * ratingPart + 0.20 * minutesPart)
                    .coerceIn(0.20, 1.0)
            }
            SporTuru.BASKETBOL -> {
                val production = if (appearances > 0) {
                    (points + assists * 0.8) / appearances
                } else 0.0
                val productionPart = (production / 25.0).coerceIn(0.0, 1.0)
                val ratingPart = if (rating > 0.0) ((rating - 6.5) / 1.5).coerceIn(0.0, 1.0) else 0.0
                (0.65 * productionPart + 0.35 * ratingPart).coerceIn(0.20, 1.0)
            }
        }
    }

    private fun motivationFromRecent(
        home: List<RecentMatch>,
        away: List<RecentMatch>
    ): Double {
        val homeScore = recentPointsStrength(home)
        val awayScore = recentPointsStrength(away)
        return (homeScore - awayScore).coerceIn(-2.0, 2.0)
    }

    private fun recentPointsStrength(matches: List<RecentMatch>): Double {
        if (matches.isEmpty()) return 0.0
        var points = 0.0
        var count = 0
        matches.take(MAX_RECENT_MATCHES).forEach { m ->
            val hs = m.homeScore ?: return@forEach
            val ascore = m.awayScore ?: return@forEach
            when {
                hs > ascore -> points += 1.0
                hs < ascore -> points -= 1.0
            }
            count++
        }
        return if (count == 0) 0.0 else points / count
    }

    private fun formStrength(form: FormVerisi): Double {
        return if (form.sonMaclar.isEmpty()) 0.0 else {
            ((form.galibiyet * 3.0 + form.beraberlik) /
                    (form.sonMaclar.size * 3.0)).coerceIn(0.0, 1.0)
        }
    }

    private fun fixtureDensity(matches: List<RecentMatch>): Double {
        if (matches.size < 2) return 0.0
        val sorted = matches.sortedByDescending { it.startTimestamp }
        val gaps = sorted.zipWithNext().map { (a, b) -> abs(a.startTimestamp - b.startTimestamp) / 86400.0 }
        val avgGap = gaps.averageOrNull() ?: 0.0
        return when {
            avgGap < 3.0 -> 1.0
            avgGap < 5.0 -> 0.6
            avgGap < 7.0 -> 0.3
            else -> 0.0
        }
    }

    private fun matchImportance(eventRoot: JsonObject?): Double {
        val event = eventRoot?.obj("event") ?: return 0.0
        val status = event.obj("status")
        val type = status?.string("type") ?: ""
        return when {
            type.contains("tournament", true) -> 0.6
            else -> 0.3
        }
    }

    private fun teamMatchScore(
        iddaaHome: String,
        iddaaAway: String,
        sofaHome: String,
        sofaAway: String
    ): Double {
        val direct = (nameSimilarity(iddaaHome, sofaHome) + nameSimilarity(iddaaAway, sofaAway)) / 2.0
        val swapped = (nameSimilarity(iddaaHome, sofaAway) + nameSimilarity(iddaaAway, sofaHome)) / 2.0
        // Ev/deplasman yönü korunur; swapped sadece isim transliterasyonu çok farklıysa yardımcı olur.
        return max(direct, swapped * 0.94)
    }

    private fun nameSimilarity(a: String, b: String): Double {
        val x = normalizeName(a)
        val y = normalizeName(b)
        if (x.isBlank() || y.isBlank()) return 0.0
        if (x == y) return 1.0
        if (x.contains(y) || y.contains(x)) return 0.92

        val xa = x.split(' ').filter { it.isNotBlank() }.toSet()
        val ya = y.split(' ').filter { it.isNotBlank() }.toSet()
        val intersection = xa.intersect(ya).size.toDouble()
        val union = xa.union(ya).size.toDouble().coerceAtLeast(1.0)
        val jaccard = intersection / union

        val distance = levenshtein(x, y)
        val maxLen = max(x.length, y.length).coerceAtLeast(1)
        val lev = 1.0 - distance.toDouble() / maxLen

        return (0.65 * jaccard + 0.35 * lev).coerceIn(0.0, 1.0)
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length

        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)

        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = min(
                    min(cur[j] + 1, prev[j + 1] + 1),
                    prev[j] + cost
                )
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    private fun normalizeName(value: String): String {
        val withoutAccents = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
        return withoutAccents
            .lowercase(Locale.forLanguageTag("tr-TR"))
            .replace('ı', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeStatus(value: String): String {
        val n = normalizeName(value)
        return when {
            n.contains("sakat") || n.contains("injur") -> "SAKAT"
            n.contains("cez") || n.contains("susp") -> "CEZALI"
            n.contains("kad") && n.contains("disi") -> "KADRO_DISI"
            n.contains("doubt") || n.contains("supheli") -> "SUPHELI"
            else -> "BELIRSIZ"
        }
    }

    private fun istanbulTarihi(timestampSeconds: Long): String {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Europe/Istanbul"), Locale.US)
        calendar.timeInMillis = timestampSeconds * 1000L
        return String.format(
            Locale.US,
            "%04d-%02d-%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    private fun getJson(path: String): JsonObject? {
        for (base in baseUrls) {
            try {
                val requestBuilder = Request.Builder()
                    .url(base + path)
                headers.forEach { (k, v) -> requestBuilder.header(k, v) }

                client.newCall(requestBuilder.build()).execute().use { response ->
                    if (!response.isSuccessful) continue
                    val body = response.body?.string() ?: continue
                    if (body.isBlank()) continue
                    val root = JsonParser.parseString(body)
                    if (root.isJsonObject) return root.asJsonObject
                }
            } catch (_: Exception) {
                // Bir sonraki base URL denenir.
            }
        }
        return null
    }

    private fun JsonObject.obj(key: String): JsonObject? =
        get(key)?.asJsonObjectOrNull()

    private fun JsonObject.objArray(key: String): JsonArray =
        get(key)?.takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray()

    private fun JsonObject.string(key: String): String? =
        get(key)?.takeIf { !it.isJsonNull }?.asString

    private fun JsonObject.long(key: String): Long? =
        get(key)?.takeIf { !it.isJsonNull }?.let {
            runCatching { it.asLong }.getOrNull()
        }

    private fun JsonObject.number(key: String): Number? =
        get(key)?.takeIf { !it.isJsonNull }?.let {
            runCatching { it.asNumber }.getOrNull()
        }

    private fun JsonElement.asJsonObjectOrNull(): JsonObject? =
        if (isJsonObject) asJsonObject else null

    private fun List<Double>.averageOrNull(): Double? =
        if (isEmpty()) null else average()
}
