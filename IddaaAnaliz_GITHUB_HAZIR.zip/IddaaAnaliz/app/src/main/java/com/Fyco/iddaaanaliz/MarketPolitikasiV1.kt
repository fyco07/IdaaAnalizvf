@file:Suppress("PackageName")

package com.Fyco.iddaaanaliz

import java.util.Locale

/**
 * Tek merkez market politikası.
 *
 * 1) Ev/Deplasman 0.5 takım gol marketi hesaplanmaz.
 *    Böylece gereksiz model yüzdesi / fair / edge / EV üretilmez.
 *
 * 2) İlk yarı/devre marketleri başlığında açıkça "İLK YARI" taşır.
 *    MarketSonucCozucu da bu etiketi doğrudan tanıyabilir.
 *
 * 3) Bu dosya yalnızca market kimliği/politikasıyla ilgilenir;
 *    olasılık hesabı burada yapılmaz.
 */
object MarketPolitikasiV1 {

    fun aktifMi(
        market: IddaaMarket,
        spor: SporTuru = SporTuru.FUTBOL
    ): Boolean {
        // Basketbolda takım 0.5 gol kavramı futbol market mantığıdır;
        // yine de başlık doğru şekilde takım gol + 0.5 ise kapatılır.
        return !evVeyaDep0_5TakimGol(market)
    }

    fun ilkYariMi(
        market: IddaaMarket,
        resmiBaslik: String? = null
    ): Boolean {
        val title = normalize(
            resmiBaslik ?: runCatching {
                IddaaMarketConfigRepository.marketBasligi(market)
            }.getOrDefault("")
        )

        return title.contains("ilk yari") ||
                title.contains("1 yari") ||
                title.contains("1. yari") ||
                title.contains("devre") ||
                title.startsWith("iy ") ||
                title == "iy"
    }

    fun gorunumBasligi(
        market: IddaaMarket,
        resmiBaslik: String
    ): String {
        val clean = resmiBaslik.trim()
        if (clean.isBlank()) return clean

        if (!ilkYariMi(market, clean)) {
            return clean
        }

        val normalized = normalize(clean)

        // Zaten "ilk yarı" yazıyorsa tekrar ekleme.
        if (normalized.contains("ilk yari")) {
            return clean
        }

        // "İY ..." biçimini solver'ın da güvenle tanıyacağı
        // "İLK YARI ..." biçimine çevir.
        if (normalized == "iy" || normalized.startsWith("iy ")) {
            val withoutIy = clean
                .replaceFirst(
                    Regex(
                        "^\\s*iy\\b\\s*[-:/•]?\\s*",
                        RegexOption.IGNORE_CASE
                    ),
                    ""
                )
                .trim()

            return if (withoutIy.isBlank()) {
                "İLK YARI"
            } else {
                "İLK YARI • $withoutIy"
            }
        }

        return "İLK YARI • $clean"
    }

    private fun evVeyaDep0_5TakimGol(
        market: IddaaMarket
    ): Boolean {
        val title = normalize(
            runCatching {
                IddaaMarketConfigRepository.marketBasligi(market)
            }.getOrDefault("")
        )

        val names = market.o
            .map { normalize(it.n) }

        val isOverUnder = names.any { it == "alt" || it == "ust" } ||
                title.contains("alt") ||
                title.contains("ust")

        val line = market.sov
            ?.trim()
            ?.replace(',', '.')
            ?.toDoubleOrNull()

        val isTeamGoal =
            title.contains("ev sahibi") && title.contains("gol") ||
            title.contains("ev sahibi takim") && title.contains("gol") ||
            title.contains("deplasman") && title.contains("gol") ||
            title.contains("deplasman takim") && title.contains("gol")

        return line != null &&
                kotlin.math.abs(line - 0.5) < 0.000001 &&
                isTeamGoal &&
                isOverUnder
    }

    private fun normalize(value: String): String {
        return value
            .trim()
            .lowercase(Locale("tr", "TR"))
            .replace('ı', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')
            .replace(Regex("\\s+"), " ")
    }
}
