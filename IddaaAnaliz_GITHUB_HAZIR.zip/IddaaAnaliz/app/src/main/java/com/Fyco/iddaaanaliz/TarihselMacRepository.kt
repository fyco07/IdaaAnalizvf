@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.Normalizer
import java.util.Locale

/** 365+ günlük maç geçmişini cihazda kalıcı tutar. */
object TarihselMacRepository {
    private const val DB_NAME = "iddaaanaliz_history.db"
    private const val DB_VERSION = 1
    private lateinit var helper: Helper

    fun init(context: Context) {
        if (!::helper.isInitialized) helper = Helper(context.applicationContext)
    }

    fun kaydet(maclar: List<ESPNVeriSaglayici.Kayit>) {
        if (maclar.isEmpty()) return
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            maclar.forEach { mac ->
                val v = ContentValues().apply {
                    put("event_key", "${mac.spor.name}:${mac.eventId}")
                    put("event_id", mac.eventId)
                    put("sport", mac.spor.name)
                    put("league", mac.lig)
                    put("home_id", mac.homeId)
                    put("away_id", mac.awayId)
                    put("home_name", mac.homeName)
                    put("away_name", mac.awayName)
                    put("home_norm", normalize(mac.homeName))
                    put("away_norm", normalize(mac.awayName))
                    put("start_ts", mac.baslangic)
                    put("home_score", mac.homeScore)
                    put("away_score", mac.awayScore)
                    put("completed", if (mac.tamamlandi) 1 else 0)
                }
                db.insertWithOnConflict("matches", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun sonMaclar(takim: String, spor: SporTuru, limit: Int = 20): List<ESPNVeriSaglayici.Kayit> {
        val n = normalize(takim)
        val db = helper.readableDatabase
        val cursor = db.query(
            "matches", null,
            "sport=? AND completed=1 AND (home_norm=? OR away_norm=?)",
            arrayOf(spor.name, n, n), null, null, "start_ts DESC", limit.toString()
        )
        return cursor.use { c -> read(c, spor) }
    }

    fun h2h(home: String, away: String, spor: SporTuru, limit: Int = 20): List<ESPNVeriSaglayici.Kayit> {
        val h = normalize(home)
        val a = normalize(away)
        val db = helper.readableDatabase
        val cursor = db.query(
            "matches", null,
            "sport=? AND completed=1 AND ((home_norm=? AND away_norm=?) OR (home_norm=? AND away_norm=?))",
            arrayOf(spor.name, h, a, a, h), null, null, "start_ts DESC", limit.toString()
        )
        return cursor.use { c -> read(c, spor) }
    }

    fun sonTarih(spor: SporTuru): String? {
        val c = helper.readableDatabase.rawQuery(
            "SELECT MAX(start_ts) FROM matches WHERE sport=?", arrayOf(spor.name)
        )
        return c.use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0).toString() else null }
    }

    fun toplam(spor: SporTuru? = null): Int {
        val db = helper.readableDatabase
        val c = if (spor == null) db.rawQuery("SELECT COUNT(*) FROM matches", null)
        else db.rawQuery("SELECT COUNT(*) FROM matches WHERE sport=?", arrayOf(spor.name))
        return c.use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    private fun read(c: android.database.Cursor, spor: SporTuru): List<ESPNVeriSaglayici.Kayit> {
        val result = mutableListOf<ESPNVeriSaglayici.Kayit>()
        val iEvent = c.getColumnIndexOrThrow("event_id")
        val iLeague = c.getColumnIndexOrThrow("league")
        val iHomeId = c.getColumnIndexOrThrow("home_id")
        val iAwayId = c.getColumnIndexOrThrow("away_id")
        val iHome = c.getColumnIndexOrThrow("home_name")
        val iAway = c.getColumnIndexOrThrow("away_name")
        val iTs = c.getColumnIndexOrThrow("start_ts")
        val iHs = c.getColumnIndexOrThrow("home_score")
        val iAs = c.getColumnIndexOrThrow("away_score")
        while (c.moveToNext()) {
            result += ESPNVeriSaglayici.Kayit(
                eventId = c.getLong(iEvent), spor = spor, lig = c.getString(iLeague),
                homeId = c.getString(iHomeId), awayId = c.getString(iAwayId),
                homeName = c.getString(iHome), awayName = c.getString(iAway),
                baslangic = c.getLong(iTs),
                homeScore = if (c.isNull(iHs)) null else c.getDouble(iHs),
                awayScore = if (c.isNull(iAs)) null else c.getDouble(iAs),
                tamamlandi = true
            )
        }
        return result
    }

    fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.forLanguageTag("tr-TR")), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace("ı", "i")
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private class Helper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE matches (
                    event_key TEXT PRIMARY KEY,
                    event_id INTEGER NOT NULL,
                    sport TEXT NOT NULL,
                    league TEXT,
                    home_id TEXT,
                    away_id TEXT,
                    home_name TEXT NOT NULL,
                    away_name TEXT NOT NULL,
                    home_norm TEXT NOT NULL,
                    away_norm TEXT NOT NULL,
                    start_ts INTEGER NOT NULL,
                    home_score REAL,
                    away_score REAL,
                    completed INTEGER NOT NULL DEFAULT 0
                )
            """.trimIndent())
            db.execSQL("CREATE INDEX idx_matches_team ON matches(sport, home_norm, away_norm, start_ts DESC)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    }
}
