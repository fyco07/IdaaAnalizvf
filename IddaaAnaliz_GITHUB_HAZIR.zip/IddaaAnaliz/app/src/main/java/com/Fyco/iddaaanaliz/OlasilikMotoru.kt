@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import kotlin.math.exp

/**
 * Ortak skor uzayından market olasılıkları üreten matematik katmanı.
 *
 * Amaç: MS, KG ve Üst/Alt gibi marketleri birbirinden bağımsız uydurmak
 * yerine aynı maçın skor dağılımından türetmek. Böylece Kolmogorov'un
 * olasılık aksiyomları korunur: P>=0, örnek uzayın toplamı 1 ve ayrık
 * olayların olasılıkları toplanabilir.
 */
object OlasilikMotoru {
    data class SkorDagilimi(
        val hucreler: Map<Pair<Int, Int>, Double>,
        val evLambda: Double,
        val depLambda: Double
    )

    fun futbolSkorDagilimi(veri: MacDisVerisi): SkorDagilimi? {
        if (veri.spor != SporTuru.FUTBOL) return null

        val ev = veri.futbolEv
        val dep = veri.futbolDeplasman
        val formVar = veri.formEv.atilan > 0.0 || veri.formEv.yenilen > 0.0 ||
                veri.formDeplasman.atilan > 0.0 || veri.formDeplasman.yenilen > 0.0
        val istatistikVar = ev != null || dep != null
        if (!formVar && !istatistikVar) return null

        fun pozitif(vararg x: Double): Double? = x.firstOrNull { it > 0.0 }

        val evAttack = pozitif(ev?.xg ?: 0.0, ev?.gol ?: 0.0, veri.formEv.atilan)
            ?: return null
        val depAttack = pozitif(dep?.xg ?: 0.0, dep?.gol ?: 0.0, veri.formDeplasman.atilan)
            ?: return null
        val evDefense = pozitif(ev?.xga ?: 0.0, ev?.yenilenGol ?: 0.0, veri.formEv.yenilen) ?: 1.0
        val depDefense = pozitif(dep?.xga ?: 0.0, dep?.yenilenGol ?: 0.0, veri.formDeplasman.yenilen) ?: 1.0

        // Saldırı + rakip savunması harmanı. Ev sahibi avantajı küçük tutulur.
        var evLambda = (evAttack * 0.62 + depDefense * 0.38)
        var depLambda = (depAttack * 0.62 + evDefense * 0.38)

        if (veri.evDeplasman.evSahibiFormu > 0.0) {
            evLambda *= (1.0 + ((veri.evDeplasman.evSahibiFormu - 0.5) * 0.10).coerceIn(-0.08, 0.08))
        }
        if (veri.evDeplasman.deplasmanFormu > 0.0) {
            depLambda *= (1.0 + ((veri.evDeplasman.deplasmanFormu - 0.5) * 0.06).coerceIn(-0.06, 0.06))
        }

        // xG varsa daha güvenilir; şut hacmi yalnızca küçük bir düzeltmedir.
        val shots = ((ev?.sut ?: 0.0) + (dep?.sut ?: 0.0))
        if (shots > 0.0) {
            val boost = ((shots / 25.0) - 1.0).coerceIn(-0.10, 0.10)
            evLambda *= 1.0 + boost * 0.35
            depLambda *= 1.0 + boost * 0.35
        }

        // Önemli eksikler mevcutsa etkiyi sınırlı uygula; ham oranla ilişkilendirme yok.
        evLambda *= (1.0 - (veri.sakatlikEv.takimEtkisi.coerceIn(0.0, 0.20) * 0.35))
        depLambda *= (1.0 - (veri.sakatlikDeplasman.takimEtkisi.coerceIn(0.0, 0.20) * 0.35))

        evLambda = evLambda.coerceIn(0.15, 3.80)
        depLambda = depLambda.coerceIn(0.15, 3.80)

        val maxGoals = 8
        val evP = poisson(evLambda, maxGoals)
        val depP = poisson(depLambda, maxGoals)
        val cells = linkedMapOf<Pair<Int, Int>, Double>()
        var total = 0.0
        for (h in 0..maxGoals) for (a in 0..maxGoals) {
            val p = evP[h] * depP[a]
            cells[h to a] = p
            total += p
        }
        if (total <= 0.0) return null
        val normalized = cells.mapValues { (_, p) -> (p / total).coerceAtLeast(0.0) }
        return SkorDagilimi(normalized, evLambda, depLambda)
    }

    fun marketOlasiliklari(market: IddaaMarket, veri: MacDisVerisi): Map<Int, Double> {
        val skor = futbolSkorDagilimi(veri) ?: return emptyMap()
        val title = normalize(try { IddaaMarketConfigRepository.marketBasligi(market) } catch (_: Exception) { "" })
            .ifBlank { normalize(AnalizMotoru.marketBasligi(market)) }
        val outcomes = market.o.filter { it.oynanabilirOran > 1.0 }
        if (outcomes.size < 2) return emptyMap()

        val values = linkedMapOf<Int, Double>()
        for (o in outcomes) {
            val pick = normalize(o.n)
            val p = when {
                isMacSonucu(title, outcomes) -> when (pick) {
                    "1" -> skor.hucreler.filterKeys { it.first > it.second }.values.sum()
                    "x", "0" -> skor.hucreler.filterKeys { it.first == it.second }.values.sum()
                    "2" -> skor.hucreler.filterKeys { it.first < it.second }.values.sum()
                    else -> null
                }
                title.contains("karsilikli gol") -> when (pick) {
                    "var" -> skor.hucreler.filterKeys { it.first > 0 && it.second > 0 }.values.sum()
                    "yok" -> skor.hucreler.filterKeys { it.first == 0 || it.second == 0 }.values.sum()
                    else -> null
                }
                (title.contains("alt") || title.contains("ust")) -> {
                    val threshold = Regex("""(\d+(?:[.,]\d+)?)""").find(title)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()
                    if (threshold == null) null else {
                        val over = skor.hucreler.filterKeys { it.first + it.second > threshold }.values.sum()
                        when (pick) { "ust" -> over; "alt" -> 1.0 - over; else -> null }
                    }
                }
                title.contains("cifte sans") -> when (pick) {
                    "1-x", "1x", "1 x" -> skor.hucreler.filterKeys { it.first >= it.second }.values.sum()
                    "1-2", "12", "1 2" -> skor.hucreler.filterKeys { it.first != it.second }.values.sum()
                    "x-2", "x2", "x 2" -> skor.hucreler.filterKeys { it.first <= it.second }.values.sum()
                    else -> null
                }
                else -> handicapProbability(title, pick, skor)
            }
            if (p != null && p.isFinite()) values[o.no] = p.coerceIn(0.0, 1.0)
        }
        return normalizeExclusive(values, outcomes.map { it.no })
    }

    private fun handicapProbability(title: String, pick: String, skor: SkorDagilimi): Double? {
        if (!title.contains("handikap") && !title.contains("handicap")) return null
        val m = Regex("""\((-?\d+(?:[.,]\d+)?)\s*:\s*(-?\d+(?:[.,]\d+)?)\)""").find(title) ?: return null
        val h = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        val a = m.groupValues[2].replace(',', '.').toDoubleOrNull() ?: return null
        return when (pick) {
            "1" -> skor.hucreler.filterKeys { it.first + h > it.second + a }.values.sum()
            "x", "0" -> skor.hucreler.filterKeys { it.first + h == it.second + a }.values.sum()
            "2" -> skor.hucreler.filterKeys { it.first + h < it.second + a }.values.sum()
            else -> null
        }
    }

    private fun isMacSonucu(title: String, outcomes: List<IddaaOutcome>): Boolean {
        if (title.contains("yari") || title.contains("ceyrek") || title.contains("devre")) return false
        val names = outcomes.map { normalize(it.n) }
        return names.contains("1") && names.contains("2") && (names.contains("x") || names.contains("0"))
    }

    private fun normalizeExclusive(values: Map<Int, Double>, order: List<Int>): Map<Int, Double> {
        if (values.size < 2) return emptyMap()
        val positive = values.mapValues { it.value.coerceAtLeast(0.0) }
        val sum = positive.values.sum()
        if (sum <= 0.0) return emptyMap()
        // Ayrık olayların toplamını tam 1'e getirir.
        return order.filter { positive.containsKey(it) }.associateWith { positive[it]!! / sum }
    }

    private fun poisson(lambda: Double, maxGoals: Int): DoubleArray {
        val p = DoubleArray(maxGoals + 1)
        p[0] = exp(-lambda)
        for (k in 1..maxGoals) p[k] = p[k - 1] * lambda / k
        return p
    }

    private fun normalize(value: String): String = value.trim().lowercase(java.util.Locale.forLanguageTag("tr-TR"))
        .replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c')
        .replace(Regex("\\s+"), " ")
}
