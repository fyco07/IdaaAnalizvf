@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sofascore_tarihsel_maclar",
    indices = [
        Index(value = ["baslangic"]),
        Index(value = ["spor", "baslangic"]),
        Index(value = ["evTakimId"]),
        Index(value = ["deplasmanTakimId"])
    ]
)
data class SofaScoreTarihselMac(
    @PrimaryKey
    val eventId: Long,

    val spor: String,
    val evTakimId: Long?,
    val deplasmanTakimId: Long?,
    val evTakimAdi: String,
    val deplasmanTakimAdi: String,

    val baslangic: Long,
    val turnuvaAdi: String?,
    val sezonAdi: String?,

    val durum: String,

    val evSkor: Int?,
    val deplasmanSkor: Int?,
    val evIlkYari: Int?,
    val deplasmanIlkYari: Int?,

    val detayJson: String? = null,

    val kayitZamani: Long = System.currentTimeMillis()
)
