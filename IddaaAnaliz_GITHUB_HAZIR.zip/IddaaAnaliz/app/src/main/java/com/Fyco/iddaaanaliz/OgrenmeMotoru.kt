package com.Fyco.iddaaanaliz

import kotlin.math.max

/**
 * Kontrollü online öğrenme katmanı.
 *
 * Amaç:
 * - Gerçekleşmiş tahmin sonuçlarından Brier hatasını ölçmek.
 * - Kaynak ağırlıklarını segment bazında güncellemek.
 * - Yeterli örnek yoksa başlangıç ağırlıklarını korumak.
 * - Öğrenilmiş olasılığı yalnızca gerçekten veri varsa üretmek.
 *
 * ÖNEMLİ:
 * Tahminler doğruluk etiketi olarak kullanılmaz. Yalnızca gerçekleşmiş
 * maç sonuçları (TahminKaydi.sonuc) öğrenme etiketidir.
 */
object OgrenmeMotoru {

    private const val MIN_ORNEK = 50
    private const val MIN_SEGMENT_ORNEK = 30
    private const val MIN_WEIGHT = 0.10
    private const val MAX_WEIGHT = 0.65
    private const val DEFAULT_IDDAA = 0.25
    private const val DEFAULT_PROG = 0.20
    private const val DEFAULT_KENDI = 0.55

    data class Agirliklar(
        val iddaa: Double,
        val progSport: Double,
        val kendiModel: Double
    )

    /**
     * Genel gerçekleşmiş tahminler üzerinden dinamik ağırlık üretir.
     */
    fun dinamikAgirliklar(
        tahminler: List<TahminKaydi> = TahminOgrenmeRepository.cozulenleriGetir()
    ): Agirliklar {
        val iddaa = performansSkoru(tahminler) { it.iddaaOlasiligi }
        val prog = performansSkoru(tahminler) { it.progSportOlasiligi }
        val kendi = performansSkoru(tahminler) { it.kendiModelOlasiligi }

        return agirliklariNormalizeEt(
            iddaaSkoru = iddaa,
            progSkoru = prog,
            kendiSkoru = kendi,
            fallback = Agirliklar(DEFAULT_IDDAA, DEFAULT_PROG, DEFAULT_KENDI)
        )
    }

    /**
     * Spor + market + organizasyon + oran segmentine göre öğrenilmiş ağırlık.
     *
     * Önce dar segment, örnek azsa spor segmenti, o da yetersizse genel havuz
     * kullanılır. Böylece örneğin basketbol handikap verisi futbol alt/üstüyle
     * karıştırılmaz.
     */
    fun segmentAgirliklari(
        spor: SporTuru,
        marketBasligi: String = "",
        organizasyon: String = "",
        oran: Double = 0.0,
        tahminler: List<TahminKaydi> = TahminOgrenmeRepository.cozulenleriGetir()
    ): Agirliklar {
        val valid = tahminler.filter { it.sonuc != null }
        if (valid.isEmpty()) {
            return Agirliklar(DEFAULT_IDDAA, DEFAULT_PROG, DEFAULT_KENDI)
        }

        val sporKey = normalize(spor.name)
        val marketKey = segmentMarket(marketBasligi)
        val orgKey = normalize(organizasyon)
        val oddsBand = oddsBand(oran)

        val dar = valid.filter { kayit ->
            normalize(kayit.spor) == sporKey &&
                segmentMarket(kayit.marketBasligi) == marketKey &&
                oddsBand( kayit.oran ) == oddsBand
        }

        if (dar.size >= MIN_SEGMENT_ORNEK) {
            return agirliklariNormalizeEt(
                iddaaSkoru = performansSkoru(dar) { it.iddaaOlasiligi },
                progSkoru = performansSkoru(dar) { it.progSportOlasiligi },
                kendiSkoru = performansSkoru(dar) { it.kendiModelOlasiligi },
                fallback = sporAgirliklari( spor )
            )
        }

        val orgSegment = valid.filter { kayit ->
            normalize(kayit.spor) == sporKey &&
                segmentMarket(kayit.marketBasligi) == marketKey &&
                (orgKey.isEmpty() || normalize(kayit.organizasyon) == orgKey)
        }

        if (orgSegment.size >= MIN_SEGMENT_ORNEK) {
            return agirliklariNormalizeEt(
                iddaaSkoru = performansSkoru(orgSegment) { it.iddaaOlasiligi },
                progSkoru = performansSkoru(orgSegment) { it.progSportOlasiligi },
                kendiSkoru = performansSkoru(orgSegment) { it.kendiModelOlasiligi },
                fallback = sporAgirliklari(spor)
            )
        }

        val sportSegment = valid.filter { normalize(it.spor) == sporKey }
        if (sportSegment.size >= MIN_SEGMENT_ORNEK) {
            return agirliklariNormalizeEt(
                iddaaSkoru = performansSkoru(sportSegment) { it.iddaaOlasiligi },
                progSkoru = performansSkoru(sportSegment) { it.progSportOlasiligi },
                kendiSkoru = performansSkoru(sportSegment) { it.kendiModelOlasiligi },
                fallback = sporAgirliklari(spor)
            )
        }

        return agirliklariNormalizeEt(
            iddaaSkoru = null,
            progSkoru = null,
            kendiSkoru = null,
            fallback = sporAgirliklari(spor)
        )
    }

    /**
     * Öğrenilmiş olasılık: kullanılabilir bağımsız kaynakları segment ağırlıkları
     * ile birleştirir. Yeterli öğrenme verisi yoksa null döner.
     */
    fun ogrenilmisOlasilik(
        spor: SporTuru,
        marketBasligi: String,
        organizasyon: String = "",
        oran: Double = 0.0,
        iddaaOlasiligi: Double? = null,
        progSportOlasiligi: Double? = null,
        kendiModelOlasiligi: Double? = null,
        guvenPuani: Int = 0,
        tahminler: List<TahminKaydi> = TahminOgrenmeRepository.cozulenleriGetir()
    ): Double? {
        val uygun = listOfNotNull(
            iddaaOlasiligi?.takeIf { it in 0.0..1.0 },
            progSportOlasiligi?.takeIf { it in 0.0..1.0 },
            kendiModelOlasiligi?.takeIf { it in 0.0..1.0 }
        )
        if (uygun.isEmpty()) return null

        val resolved = tahminler.filter { it.sonuc != null }
        if (resolved.size < MIN_ORNEK) return null

        val agirlik = segmentAgirliklari(
            spor = spor,
            marketBasligi = marketBasligi,
            organizasyon = organizasyon,
            oran = oran,
            tahminler = resolved
        )

        var toplam = 0.0
        var agirlikToplami = 0.0

        if (iddaaOlasiligi != null && iddaaOlasiligi in 0.0..1.0) {
            toplam += iddaaOlasiligi * agirlik.iddaa
            agirlikToplami += agirlik.iddaa
        }
        if (progSportOlasiligi != null && progSportOlasiligi in 0.0..1.0) {
            toplam += progSportOlasiligi * agirlik.progSport
            agirlikToplami += agirlik.progSport
        }
        if (kendiModelOlasiligi != null && kendiModelOlasiligi in 0.0..1.0) {
            toplam += kendiModelOlasiligi * agirlik.kendiModel
            agirlikToplami += agirlik.kendiModel
        }

        if (agirlikToplami <= 0.0) return null

        val base = (toplam / agirlikToplami).coerceIn(0.01, 0.99)
        val segmentSize = segmentOrnekSayisi(
            spor = spor,
            marketBasligi = marketBasligi,
            organizasyon = organizasyon,
            oran = oran,
            tahminler = resolved
        )

        // Öğrenmenin etkisi veri miktarına göre kontrollü artar.
        val learningStrength = when {
            segmentSize >= 250 -> 0.25
            segmentSize >= 100 -> 0.20
            segmentSize >= MIN_ORNEK -> 0.15
            else -> 0.0
        }

        if (learningStrength <= 0.0) return base

        // Genel sonucun Brier performansından türetilen hafif kalibrasyon.
        val finalBrier = brier(
            resolved.mapNotNull { kayit ->
                val p = kayit.olasilik.takeIf { it in 0.0..1.0 } ?: return@mapNotNull null
                val y = if (kayit.sonuc == true) 1.0 else 0.0
                val d = p - y
                d * d
            }
        )

        val target = when {
            finalBrier == null -> base
            finalBrier <= 0.16 -> base
            finalBrier <= 0.21 -> 0.5 + (base - 0.5) * 0.96
            finalBrier <= 0.26 -> 0.5 + (base - 0.5) * 0.90
            else -> 0.5 + (base - 0.5) * 0.82
        }

        // guvenPuani yalnızca çok küçük bir güven tavanı sağlar; olasılığı şişirmez.
        val confidenceFactor = ((guvenPuani.coerceIn(0, 100) / 100.0) - 0.5) * 0.01
        return (base + (target - base) * learningStrength + confidenceFactor)
            .coerceIn(0.01, 0.99)
    }

    fun yeterliVeriVarMi(
        tahminler: List<TahminKaydi> = TahminOgrenmeRepository.cozulenleriGetir()
    ): Boolean = tahminler.count { it.sonuc != null } >= MIN_ORNEK

    fun ogrenmeDurumu(): String {
        val resolved = TahminOgrenmeRepository.cozulenleriGetir()
        if (resolved.size < MIN_ORNEK) {
            return "Öğrenme için ${MIN_ORNEK - resolved.size} sonuç daha gerekiyor."
        }

        val w = dinamikAgirliklar(resolved)
        return "Dinamik ağırlıklar aktif: " +
            "İddaa %.1f%%, ProgSport %.1f%%, Kendi Model %.1f%%"
                .format(
                    w.iddaa * 100.0,
                    w.progSport * 100.0,
                    w.kendiModel * 100.0
                )
    }

    private fun performansSkoru(
        tahminler: List<TahminKaydi>,
        selector: (TahminKaydi) -> Double?
    ): Double? {
        val squared = tahminler.mapNotNull { kayit ->
            val p = selector(kayit)
            val y = kayit.sonuc?.let { if (it) 1.0 else 0.0 }
            if (p != null && p in 0.0..1.0 && y != null) {
                val d = p - y
                d * d
            } else null
        }

        if (squared.size < MIN_ORNEK) return null
        return squared.average()
    }

    private fun segmentOrnekSayisi(
        spor: SporTuru,
        marketBasligi: String,
        organizasyon: String,
        oran: Double,
        tahminler: List<TahminKaydi>
    ): Int {
        val sporKey = normalize(spor.name)
        val marketKey = segmentMarket(marketBasligi)
        val orgKey = normalize(organizasyon)
        val band = oddsBand(oran)

        val narrow = tahminler.count {
            normalize(it.spor) == sporKey &&
                segmentMarket(it.marketBasligi) == marketKey &&
                oddsBand(it.oran) == band
        }
        if (narrow >= MIN_SEGMENT_ORNEK) return narrow

        val org = tahminler.count {
            normalize(it.spor) == sporKey &&
                segmentMarket(it.marketBasligi) == marketKey &&
                (orgKey.isEmpty() || normalize(it.organizasyon) == orgKey)
        }
        if (org >= MIN_SEGMENT_ORNEK) return org

        return tahminler.count { normalize(it.spor) == sporKey }
    }

    private fun sporAgirliklari(spor: SporTuru): Agirliklar {
        return when (spor) {
            SporTuru.FUTBOL -> Agirliklar(0.0, 0.30, 0.70)
            SporTuru.BASKETBOL -> Agirliklar(DEFAULT_IDDAA, DEFAULT_PROG, DEFAULT_KENDI)
        }
    }

    private fun agirliklariNormalizeEt(
        iddaaSkoru: Double?,
        progSkoru: Double?,
        kendiSkoru: Double?,
        fallback: Agirliklar
    ): Agirliklar {
        val active = mutableListOf<Pair<String, Double>>()
        iddaaSkoru?.let { active += "iddaa" to (1.0 / max(0.02, it)) }
        progSkoru?.let { active += "prog" to (1.0 / max(0.02, it)) }
        kendiSkoru?.let { active += "kendi" to (1.0 / max(0.02, it)) }

        if (active.isEmpty()) return fallback

        val sumRaw = active.sumOf { it.second }
        if (sumRaw <= 0.0) return fallback

        var wIddaa = 0.0
        var wProg = 0.0
        var wKendi = 0.0

        for ((name, raw) in active) {
            val w = (raw / sumRaw).coerceIn(MIN_WEIGHT, MAX_WEIGHT)
            when (name) {
                "iddaa" -> wIddaa = w
                "prog" -> wProg = w
                "kendi" -> wKendi = w
            }
        }

        val total = wIddaa + wProg + wKendi
        if (total <= 0.0) return fallback

        return Agirliklar(
            iddaa = wIddaa / total,
            progSport = wProg / total,
            kendiModel = wKendi / total
        )
    }

    private fun segmentMarket(value: String): String {
        val n = normalize(value)
        return when {
            n.contains("handikap") || n.contains("handicap") -> "handikap"
            n.contains("toplam") && (n.contains("alt") || n.contains("ust")) -> "toplam_alt_ust"
            n.contains("karsilikli gol") -> "kg"
            n.contains("mac sonucu") -> "ms"
            n.contains("cifte sans") -> "cifte_sans"
            n.contains("tek cift") || n.contains("tek/cift") -> "tek_cift"
            n.contains("korner") -> "korner"
            n.contains("kart") -> "kart"
            n.contains("yari") || n.contains("devre") -> "ilk_yari"
            else -> n.take(80)
        }
    }

    private fun oddsBand(oran: Double): String = when {
        oran <= 0.0 -> "unknown"
        oran < 1.50 -> "1.01-1.49"
        oran < 2.00 -> "1.50-1.99"
        oran < 3.00 -> "2.00-2.99"
        oran < 5.00 -> "3.00-4.99"
        else -> "5.00+"
    }

    private fun normalize(value: String?): String {
        return value
            ?.trim()
            ?.lowercase(java.util.Locale("tr", "TR"))
            ?.replace('ı', 'i')
            ?.replace('ş', 's')
            ?.replace('ğ', 'g')
            ?.replace('ü', 'u')
            ?.replace('ö', 'o')
            ?.replace('ç', 'c')
            ?.replace(Regex("\\s+"), " ")
            ?: ""
    }

    private fun brier(values: List<Double>): Double? =
        values.takeIf { it.isNotEmpty() }?.average()
}
