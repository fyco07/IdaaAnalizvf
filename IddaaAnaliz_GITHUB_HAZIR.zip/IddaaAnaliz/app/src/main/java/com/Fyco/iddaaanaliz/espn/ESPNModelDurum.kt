@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.Fyco.iddaaanaliz.OgrenmeDurumuSaglayici
import com.Fyco.iddaaanaliz.MerkeziVeriHavuzu
import com.Fyco.iddaaanaliz.merkezi.MerkeziFutbolModelHavuzu

/**
 * Kendi Modeli'nin canlı durum bilgisi.
 *
 * Durumlar:
 *
 * HAZIR
 * VERI_TOPLANIYOR
 * MODEL_EGITIM_BASLIYOR
 * MODEL_EGITILIYOR
 * VERI_YETERSIZ
 * HATA
 */
object ESPNModelDurumStore {

    private const val PREF =
        "espn_model_durum"

    private const val KEY_ASAMA =
        "asama"

    private const val KEY_GUN =
        "gun"

    private const val KEY_TOPLAM_GUN =
        "toplamGun"

    private const val KEY_MAC =
        "mac"

    private const val KEY_EGITIM =
        "egitim"

    private const val KEY_DETAY =
        "detay"

    private const val KEY_TARIH =
        "tarih"

    private const val KEY_GUN_MAC =
        "gunMac"

    private const val KEY_INCELENEN_TAKIM =
        "incelenenTakim"

    fun guncelle(
        context: Context,
        asama: String,
        gun: Int = 0,
        toplamGun: Int = 365,
        mac: Int = 0,
        egitim: Int = 0,
        detay: String = "",
        tarih: String = "",
        gunMac: Int = 0,
        incelenenTakim: Int = 0
    ) {

        context
            .getSharedPreferences(
                PREF,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_ASAMA,
                asama
            )
            .putInt(
                KEY_GUN,
                gun
            )
            .putInt(
                KEY_TOPLAM_GUN,
                toplamGun
            )
            .putInt(
                KEY_MAC,
                mac
            )
            .putInt(
                KEY_EGITIM,
                egitim
            )
            .putString(
                KEY_DETAY,
                detay
            )
            .putString(
                KEY_TARIH,
                tarih
            )
            .putInt(
                KEY_GUN_MAC,
                gunMac
            )
            .putInt(
                KEY_INCELENEN_TAKIM,
                incelenenTakim
            )
            .apply()
    }

    fun oku(
        context: Context
    ): Durum {

        val preferences =
            context.getSharedPreferences(
                PREF,
                Context.MODE_PRIVATE
            )

        return Durum(

            asama =
                preferences.getString(
                    KEY_ASAMA,
                    "HAZIRLANIYOR"
                ) ?: "HAZIRLANIYOR",

            gun =
                preferences.getInt(
                    KEY_GUN,
                    0
                ),

            toplamGun =
                preferences.getInt(
                    KEY_TOPLAM_GUN,
                    365
                ),

            mac =
                preferences.getInt(
                    KEY_MAC,
                    0
                ),

            egitim =
                preferences.getInt(
                    KEY_EGITIM,
                    0
                ),

            detay =
                preferences.getString(
                    KEY_DETAY,
                    ""
                ) ?: "",

            tarih =
                preferences.getString(
                    KEY_TARIH,
                    ""
                ) ?: "",

            gunMac =
                preferences.getInt(
                    KEY_GUN_MAC,
                    0
                ),

            incelenenTakim =
                preferences.getInt(
                    KEY_INCELENEN_TAKIM,
                    0
                )
        )
    }

    data class Durum(

        val asama: String,

        val gun: Int,

        val toplamGun: Int,

        val mac: Int,

        val egitim: Int,

        val detay: String,

        val tarih: String,

        val gunMac: Int,

        val incelenenTakim: Int
    )
}


/**
 * Ana ekranda Kendi Modeli durum kartı.
 */
@Composable
fun ESPNModelDurumKarti(
    context: Context
) {

    var durum by remember {

        mutableStateOf(
            ESPNModelDurumStore.oku(
                context
            )
        )
    }

    var dbIncelenenTakim by remember {
        mutableStateOf(0)
    }

    var dbTarihselMac by remember {
        mutableStateOf(0)
    }

    var tahminPerformansi by remember {
        mutableStateOf(OgrenmeDurumuSaglayici.getir())
    }

    // Ana ekranın "öğrenilen takım" ve "model eğitimi" göstergeleri
    // sonuç kalibrasyonundan değil, çalışan merkezi futbol modelinden gelir.
    // Böylece model gerçekten hazırlanmış olsa bile eski ESPN meta/cache
    // kaydından kalan 0 değerleri gösterilmez.
    var merkeziModelTakimSayisi by remember {
        mutableStateOf(0)
    }

    var merkeziModelMacSayisi by remember {
        mutableStateOf(0)
    }

    /*
     * Mevcut tarihsel DB'den benzersiz takım sayısını bir kez al.
     * Böylece eski model kayıtlarında SharedPreferences alanı 0 olsa
     * bile kart gerçek veriyi gösterebilir.
     */
    LaunchedEffect(Unit) {
        while (true) {
            runCatching {
                withContext(Dispatchers.IO) {
                    val dao =
                        com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
                            .getInstance(context)
                            .espnTarihselMacDao()

                    dbTarihselMac = dao.toplamMacSayisi()
                    dbIncelenenTakim = dao.benzersizTakimSayisi()
                }
            }
            delay(1000)
        }
    }

    /*
     * Her saniye SharedPreferences'taki
     * son durumu oku.
     *
     * Böylece Worker arka planda çalışırken
     * kart canlı güncellenir.
     */
    LaunchedEffect(Unit) {

        while (true) {

            durum =
                ESPNModelDurumStore.oku(
                    context
                )

            // Worker başka süreçte/iş parçacığında modeli tamamladıysa
            // Repository cache'ini kısa aralıklarla yenile. Böylece ekran
            // HAZIR durumuna ve gerçek takım sayısına gecikmeden geçer.
            if (!MerkeziVeriHavuzu.futbolModelHazirMi()) {
                runCatching {
                    withContext(Dispatchers.IO) {
                        MerkeziVeriHavuzu.futbolModeliniHazirla(force = false)
                    }
                }
            }

            // Ekran istatistiklerini daima tek merkezi snapshot'tan oku.
            // Böylece ESPN meta tablosundaki eski/0 değerler ekrana sızmaz.
            MerkeziFutbolModelHavuzu.current()?.let { snapshot ->
                merkeziModelTakimSayisi = snapshot.teams.size
                merkeziModelMacSayisi = snapshot.historyMatches
            }

            // Model hazır olduktan sonra DB'yi her 3 saniyede bir yeniden okuma.
            // Worker modeli güncellediğinde zaten repository refresh edilir.
            delay(10000L)
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            tahminPerformansi = runCatching {
                withContext(Dispatchers.Default) { OgrenmeDurumuSaglayici.getir() }
            }.getOrDefault(tahminPerformansi)
            delay(3000L)
        }
    }

    val modelMeta = ESPNKendiModelRepository.modelMeta()

    val toplamGun =
        durum.toplamGun
            .coerceAtLeast(1)

    val gun =
        durum.gun
            .coerceIn(
                0,
                toplamGun
            )

    val veriProgress =
        gun.toFloat() /
                toplamGun.toFloat()

    // SharedPreferences eski sürümden kalmış 0/365 gibi bayat bir değer
    // taşıyabilir. Gerçek model repository hazırsa ekranı buna göre düzelt.
    val gercekModelHazir =
        MerkeziVeriHavuzu.futbolModelHazirMi()

    val modelHazir =
        gercekModelHazir || durum.asama == "HAZIR"

    val veriToplaniyor =
        durum.asama ==
                "VERI_TOPLANIYOR"

    val modelBasliyor =
        durum.asama ==
                "MODEL_EGITIM_BASLIYOR"

    val modelEgitiliyor =
        durum.asama ==
                "MODEL_EGITILIYOR"

    val veriYetersiz =
        durum.asama ==
                "VERI_YETERSIZ"

    val hata =
        durum.asama ==
                "HATA"

    val retry =
        durum.asama ==
                "RETRY"

    Card(

        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 12.dp,
                    vertical = 6.dp
                )
    ) {

        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = androidx.compose.ui.Alignment.Top
        ) {

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {

            /*
             * BAŞLIK
             */
            Row(

                modifier =
                    Modifier.fillMaxWidth(),

                horizontalArrangement =
                    Arrangement.SpaceBetween
            ) {

                Text(

                    text =
                        "KENDİ MODELİ",

                    fontWeight =
                        FontWeight.Bold
                )

                Text(

                    text =
                        when {

                            modelHazir ->
                                "HAZIR"

                            veriToplaniyor ->
                                "VERİ TOPLUYOR"

                            modelBasliyor ->
                                "EĞİTİM BAŞLIYOR"

                            modelEgitiliyor ->
                                "ÖĞRENİYOR"

                            veriYetersiz ->
                                "VERİ YETERSİZ"

                            hata ->
                                "HATA"

                            retry ->
                                "TEKRAR DENENİYOR"

                            else ->
                                durum.asama
                        },

                    fontWeight =
                        FontWeight.Bold
                )
            }


            /*
             * AÇIKLAMA
             */
            Text(

                text =
                    when {

                        modelHazir ->
                            "ESPN geçmişi modele işlendi • tahmin motoru aktif"

                        veriToplaniyor ->
                            "ESPN'den 365 günlük gerçekleşmiş maç sonuçları toplanıyor"

                        modelBasliyor ->
                            "365 günlük veri tamamlandı • Kendi Modeli başlatılıyor"

                        modelEgitiliyor ->
                            "Takım gücü ve gol dağılımı tarihsel verilerden öğreniliyor"

                        veriYetersiz ->
                            "Model eğitimi için yeterli tarihsel maç bulunamadı"

                        hata ->
                            "ESPN veri veya model eğitiminde hata oluştu"

                        retry ->
                            "ESPN bağlantısı yeniden deneniyor"

                        else ->
                            "Kendi Modeli hazırlanıyor"
                    },

                style =
                    MaterialTheme.typography.bodySmall
            )


            /*
             * ESPN 365 GÜN İLERLEME
             */
            if (!modelHazir) {

                Text(

                    text =
                        "ESPN VERİSİ  $gun / $toplamGun gün",

                    fontWeight =
                        FontWeight.Medium
                )

                LinearProgressIndicator(

                    progress = {
                        veriProgress
                    },

                    modifier =
                        Modifier.fillMaxWidth()
                )

                if (durum.tarih.isNotBlank()) {
                    Text(
                        text = "İşlenen tarih: ${durum.tarih}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                if (durum.gunMac > 0) {
                    Text(
                        text = "Bu günde işlenen maç: ${durum.gunMac}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }


            /*
             * TARİHSEL MAÇ SAYISI
             */
            Text(

                text =
                    if (modelHazir && modelMeta != null) {
                        "Tarihsel maç: ${modelMeta.egitimMacSayisi}"
                    } else {
                        // Worker SharedPreferences güncellemesini kaçırsa bile
                        // kart doğrudan Room'daki gerçek kayıt sayısını gösterir.
                        // Böylece tarihsel veri ilerlerken yanlışlıkla sürekli 0
                        // görünmez.
                        "Tarihsel maç: ${maxOf(durum.mac, dbTarihselMac)}"
                    }
            )


            /*
             * TAKIM SAYILARI
             *
             * İncelenen = tarihsel veride karşılaşılan benzersiz takım.
             * Öğrenilen = final modelinde rating üretilen takım.
             */
            // "Öğrenilen takım" = sonuç kalibrasyonu değil, merkezi modelde
            // ratingi bulunan takım sayısıdır. Merkezi snapshot tek kaynaktır.
            val ogrenilenTakim =
                merkeziModelTakimSayisi
                    .coerceAtLeast(modelMeta?.egitimTakimSayisi ?: 0)

            val incelenenTakim =
                dbIncelenenTakim
                    .coerceAtLeast(durum.incelenenTakim)
                    .coerceAtLeast(ogrenilenTakim)

            if (modelHazir || incelenenTakim > 0 || ogrenilenTakim > 0) {
                Text(
                    text =
                        "İncelenen takım: $incelenenTakim"
                )

                Text(
                    text =
                        "Öğrenilen takım: $ogrenilenTakim"
                )
            }


            /*
             * MODEL EĞİTİMİ
             */
            if (
                modelBasliyor ||
                modelEgitiliyor ||
                modelHazir
            ) {

                Text(

                    text =
                        if (modelHazir) {

                            "Model eğitimi: ${merkeziModelMacSayisi.coerceAtLeast(modelMeta?.egitimMacSayisi ?: 0).coerceAtLeast(durum.egitim)} maç"

                        } else {

                            "Model eğitimi: ${durum.egitim} maç işlendi"

                        }
                )
            }


            /*
             * DETAY
             */
            /*
             * Model hazır olduktan sonra geçmiş Worker denemelerinden kalan
             * RETRY/HATA detayını gösterme. Repository'deki gerçek model
             * hazırsa bu mesaj artık güncel durumu temsil etmez.
             */
            if (
                !modelHazir &&
                durum.detay.isNotBlank()
            ) {

                Text(

                    text =
                        durum.detay,

                    style =
                        MaterialTheme.typography.bodySmall
                )
            }
            }

            Column(
                modifier = Modifier.weight(0.72f),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text(
                    text = "TAHMİN",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelLarge
                )
                Text(
                    text = "${tahminPerformansi.toplamTahmin}",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(text = "Sonuçlanan ${tahminPerformansi.sonuclanan}", style = MaterialTheme.typography.bodySmall)
                Text(text = "Tutan ${tahminPerformansi.kazanan}", style = MaterialTheme.typography.bodySmall)
                Text(text = "Kayıp ${tahminPerformansi.kaybeden}", style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "DOĞRU %${String.format(java.util.Locale.US, "%.1f", tahminPerformansi.basariOrani * 100.0)}",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall
                )
                val bekleyen = (tahminPerformansi.toplamTahmin - tahminPerformansi.sonuclanan).coerceAtLeast(0)
                if (bekleyen > 0) {
                    Text(text = "Bekleyen $bekleyen", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}