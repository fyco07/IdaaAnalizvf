@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz
import com.Fyco.iddaaanaliz.merkezi.MerkeziFutbolModelHavuzu

import com.Fyco.iddaaanaliz.merkezi.MerkeziDao
import com.Fyco.iddaaanaliz.merkezi.MerkeziLeague
import com.Fyco.iddaaanaliz.merkezi.MerkeziMarket
import com.Fyco.iddaaanaliz.merkezi.MerkeziMatch
import com.Fyco.iddaaanaliz.merkezi.MerkeziOdds
import com.Fyco.iddaaanaliz.merkezi.MerkeziPrediction
import com.Fyco.iddaaanaliz.merkezi.MerkeziResult
import com.Fyco.iddaaanaliz.merkezi.MerkeziSeason
import com.Fyco.iddaaanaliz.merkezi.MerkeziSourceData
import com.Fyco.iddaaanaliz.merkezi.MerkeziTeam
import com.Fyco.iddaaanaliz.merkezi.MerkeziVeritabani
import com.Fyco.iddaaanaliz.merkezi.KalibrasyonMotoru
import com.Fyco.iddaaanaliz.merkezi.OlasilikMotoruV2
import com.Fyco.iddaaanaliz.merkezi.TakimProfilMotoru

import android.content.Context
import android.util.Log
import androidx.room.Room
import com.Fyco.iddaaanaliz.IddaaEvent
import com.Fyco.iddaaanaliz.IddaaMarketConfigRepository
import com.Fyco.iddaaanaliz.ProgSportMac
import com.Fyco.iddaaanaliz.AnalizSonucu
import com.Fyco.iddaaanaliz.ProgSportRepository
import com.Fyco.iddaaanaliz.SporTuru
import com.Fyco.iddaaanaliz.espn.ESPNTarihselMac
import com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs

/** Faz 2-6'nın ortak veri katmanı. Eski veri akışlarına dokunmadan ayrı merkezi havuz tutar. */
object MerkeziVeriHavuzu {
    private lateinit var db: MerkeziVeritabani
    private val gson = Gson()

    fun init(context: Context) {
        this.context = context.applicationContext
        if (!::db.isInitialized) {
            db = Room.databaseBuilder(this.context!!, MerkeziVeritabani::class.java, "iddaa_merkezi_havuz.db").build()
        }
    }

    suspend fun iddaaBultenYaz(events: List<IddaaEvent>, spor: SporTuru) = withContext(Dispatchers.IO) {
        if (events.isEmpty()) return@withContext
        val dao = db.dao()
        val sport = spor.name
        val matches = mutableListOf<MerkeziMatch>()
        val teams = mutableListOf<MerkeziTeam>()
        val markets = mutableListOf<MerkeziMarket>()
        val odds = mutableListOf<MerkeziOdds>()
        val sources = mutableListOf<MerkeziSourceData>()

        events.forEach { e ->
            val matchId = "$sport:${e.i}"
            val leagueName = e.bri?.toString()
            val homeId = "${sport}:team:${normalize(e.hn)}"
            val awayId = "${sport}:team:${normalize(e.an)}"
            matches += MerkeziMatch(matchId, e.i.toString(), sport, homeId, awayId, e.hn, e.an, e.bri?.toString(), leagueName, null, null, e.d)
            teams += MerkeziTeam(homeId, sport, e.hn, normalize(e.hn), e.bri?.toString(), leagueName)
            teams += MerkeziTeam(awayId, sport, e.an, normalize(e.an), e.bri?.toString(), leagueName)
            e.m.forEach { m ->
                val title = runCatching { IddaaMarketConfigRepository.marketBasligi(m) }.getOrDefault("Market ${m.i}")
                val marketId = "$matchId:${m.i}"
                markets += MerkeziMarket(marketId, matchId, m.i.toString(), title, sport)
                m.o.forEach { o ->
                    odds += MerkeziOdds("$marketId:${o.no}", matchId, marketId, o.no.toString(), o.n, o.odd, "IDDAA")
                }
            }
            sources += MerkeziSourceData("IDDAA:$matchId:${e.d}", matchId, "IDDAA", gson.toJson(e))
        }
        val uniqueMatches = matches.distinctBy { it.matchId }
        val uniqueTeams = teams.distinctBy { it.teamId }
        val uniqueMarkets = markets.distinctBy { it.marketId }
        val uniqueOdds = odds.distinctBy { it.oddsId }
        val uniqueSources = sources.distinctBy { it.sourceDataId }

        Log.i("MERKEZI_HAVUZ", "IDDAA_BULTEN_KAYIT_BASLIYOR spor=$sport mac=${uniqueMatches.size} takim=${uniqueTeams.size} market=${uniqueMarkets.size} oran=${uniqueOdds.size} kaynak=${uniqueSources.size}")
        dao.upsertBulten(uniqueMatches, uniqueTeams, uniqueMarkets, uniqueOdds, uniqueSources)
        Log.i("MERKEZI_HAVUZ", "IDDAA_BULTEN_KAYIT_TAMAMLANDI spor=$sport mac=${uniqueMatches.size} takim=${uniqueTeams.size} market=${uniqueMarkets.size} oran=${uniqueOdds.size} kaynak=${uniqueSources.size} toplamDB=${dao.matchCount()}")
    }

    suspend fun progSportYaz(event: IddaaEvent, spor: SporTuru, mac: ProgSportMac?) = withContext(Dispatchers.IO) {
        if (mac == null) return@withContext
        val matchId = "${spor.name}:${event.i}"
        db.dao().upsertSources(listOf(MerkeziSourceData("PROGSPORT:$matchId:${System.currentTimeMillis()}", matchId, "PROGSPORT", gson.toJson(mac))))
    }

    /**
     * Geriye dönük uyumluluk: MainActivity eski çağrıda Context geçiriyor.
     * Veritabanını bu Context ile hazırlar ve asıl senkronizasyonu çalıştırır.
     */
    suspend fun espnTarihselYaz(context: Context) {
        init(context)
        espnTarihselYaz()
    }

    suspend fun espnTarihselYaz(): Unit = withContext<Unit>(Dispatchers.IO) {
        val sourceDb = IddaaAnalizDatabase.getInstance(requireContext())
        val sourceDao = sourceDb.espnTarihselMacDao()
        val dao = db.dao()

        // ESPN tarihsel havuzu değişmediyse 30K+ satırı tekrar okuyup
        // merkezi DB'ye yeniden yazma. Yeni tamamlanan maç geldiğinde
        // source count artacağı için bir sonraki senkron otomatik çalışır.
        val sourceCount = sourceDao.toplamMacSayisi()
        val centralCount = dao.footballResultCount()
        if (sourceCount > 0 && sourceCount == centralCount) {
            Log.i(
                "MERKEZI_HAVUZ",
                "ESPN_TARIHSEL_CACHE_HIT source=$sourceCount central=$centralCount"
            )
            return@withContext
        }

        val rows = sourceDao.tamamlananMaclariGetir()
        val matches = rows.map { it.toMatch() }
        val teams = rows.flatMap { listOf(it.homeTeam(), it.awayTeam()) }
        val leagues = rows.mapNotNull { r -> r.lig?.takeIf { it.isNotBlank() }?.let { MerkeziLeague("ESPN:L:${normalize(it)}", "FUTBOL", it, normalize(it)) } }
        val seasons = rows.mapNotNull { r ->
            val league = r.lig?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val season = r.sezon?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            MerkeziSeason("ESPN:S:${normalize(league)}:${normalize(season)}", "ESPN:L:${normalize(league)}", season, normalize(season))
        }
        val results = rows.map { it.toResult() }
        val uniqueMatches = matches.distinctBy { it.matchId }
        val uniqueTeams = teams.distinctBy { it.teamId }
        val uniqueLeagues = leagues.distinctBy { it.leagueId }
        val uniqueSeasons = seasons.distinctBy { it.seasonId }
        val uniqueResults = results.distinctBy { it.resultId }
        val uniqueSources = rows.map { r -> MerkeziSourceData("ESPN:${r.eventId}", r.matchId(), "ESPN", gson.toJson(r)) }.distinctBy { it.sourceDataId }

        Log.i("MERKEZI_HAVUZ", "ESPN_TARIHSEL_KAYIT_BASLIYOR mac=${uniqueMatches.size}")
        dao.upsertHistory(uniqueMatches, uniqueTeams, uniqueLeagues, uniqueSeasons, uniqueResults, uniqueSources)
        Log.i("MERKEZI_HAVUZ", "ESPN_TARIHSEL_KAYIT_TAMAMLANDI macDB=${dao.matchCount()} sonucDB=${dao.resultCount()} kaynakDB=${dao.sourceCount()}")
    }

    suspend fun tahminleriYaz(event: IddaaEvent, spor: SporTuru, predictions: List<AnalizSonucu>) = withContext(Dispatchers.IO) {
        if (predictions.isEmpty()) return@withContext
        val matchId = "${spor.name}:${event.i}"
        val rows = predictions.mapNotNull { p ->
            val marketId = p.marketId ?: return@mapNotNull null
            // Store both the stable outcome number and the human-readable selection.
            // This keeps old rows compatible while allowing exact-score / first-half
            // settlement to resolve the real selection text.
            val outcomeKey = if (p.secimNo != null) "${p.secimNo}|${p.secim.trim()}" else p.secim.trim()
            MerkeziPrediction(
                predictionId = "$matchId:$marketId:${p.secimNo ?: p.secim.trim()}",
                matchId = matchId,
                marketKey = marketId.toString(),
                outcomeKey = outcomeKey,
                modelProbability = p.gelmeOlasiligi.coerceIn(0.0, 1.0),
                marketProbability = p.kaynakHarmani?.iddaaOlasiligi,
                edge = p.edge,
                ev = p.ev,
                confidence = (p.guvenPuani / 100.0).coerceIn(0.0, 1.0)
            )
        }
        db.dao().insertPredictions(rows)
    }



    /** Faz 10: gerçekleşen maç sonucunu merkezi sonuca yazar. */
    suspend fun sonucuYaz(
        eventId: Long,
        homeTeam: String,
        awayTeam: String,
        spor: SporTuru = SporTuru.FUTBOL,
        homeScore: Double,
        awayScore: Double,
        homeFirstHalf: Double? = null,
        awayFirstHalf: Double? = null,
        completedAt: Long = System.currentTimeMillis(),
        source: String = "ESPN"
    ) = withContext(Dispatchers.IO) {
        val matchId = "${spor.name}:$eventId"
        db.dao().upsertResults(
            listOf(
                MerkeziResult(
                    resultId = "$source:$eventId",
                    matchId = matchId,
                    homeScore = homeScore,
                    awayScore = awayScore,
                    homeFirstHalf = homeFirstHalf,
                    awayFirstHalf = awayFirstHalf,
                    completedAt = completedAt,
                    source = source
                )
            )
        )
    }

    /**
     * Faz 6-10 tek akış: merkezi takım profili + Poisson skor dağılımı +
     * piyasa/no-vig + Edge/EV + kalibrasyon + tahmin kaydı.
     *
     * Mevcut MacAnalizServisi'nin sonuçlarını kırmadan ek bir merkezi karar
     * katmanı üretir. Tarihsel örneklem yeterliyse Poisson çıktısı kullanılır;
     * aksi halde mevcut çalışan motorun tahmini güvenli fallback olarak alınır.
     */
    /**
     * Merkezi pipeline'ın denetim/audit adımı.
     *
     * Asıl futbol olasılığı MacAnalizServisi -> MerkeziFutbolModelHavuzu zincirinden gelir. Bu fonksiyon ikinci bir
     * bağımsız olasılık üretip sonucu değiştirmez; yalnızca kullanılan merkezi
     * model snapshot'ını ve kaydedilen tahminlerin izini merkezi havuzda tutar.
     */
    suspend fun merkeziPipelineCalistir(
        event: IddaaEvent,
        spor: SporTuru,
        fallback: List<AnalizSonucu>
    ) = withContext(Dispatchers.IO) {
        if (event.m.isEmpty()) return@withContext

        val dao = db.dao()
        val matchId = "${spor.name}:${event.i}"
        val model = if (spor == SporTuru.FUTBOL) {
            MerkeziFutbolModelHavuzu.current()
        } else null

        val homeId = if (spor == SporTuru.FUTBOL) {
            "FUTBOL:team:${normalize(event.hn)}"
        } else null
        val awayId = if (spor == SporTuru.FUTBOL) {
            "FUTBOL:team:${normalize(event.an)}"
        } else null
        val home = homeId?.let { MerkeziFutbolModelHavuzu.takim(it) }
        val away = awayId?.let { MerkeziFutbolModelHavuzu.takim(it) }

        val summary = mapOf(
            "version" to "CENTRAL_MODEL_V8",
            "sport" to spor.name,
            "matchId" to matchId,
            "historyMatches" to (model?.historyMatches ?: 0),
            "homeTeamKnown" to (home != null),
            "awayTeamKnown" to (away != null),
            "homeSample" to (home?.macSayisi ?: 0),
            "awaySample" to (away?.macSayisi ?: 0),
            "homeElo" to (home?.elo ?: 0.0),
            "awayElo" to (away?.elo ?: 0.0),
            "homeForm10" to (home?.form10 ?: 0.0),
            "awayForm10" to (away?.form10 ?: 0.0),
            "homeOpponentStrength" to (home?.rakipGucu ?: 0.0),
            "awayOpponentStrength" to (away?.rakipGucu ?: 0.0),
            "fallbackPredictionCount" to fallback.size
        )

        dao.upsertSources(
            listOf(
                MerkeziSourceData(
                    sourceDataId = "MERKEZI_PIPELINE_V8:$matchId",
                    matchId = matchId,
                    source = "MERKEZI_PIPELINE_V8",
                    payloadJson = gson.toJson(summary)
                )
            )
        )

        Log.i(
            "MERKEZI_MODEL",
            "PIPELINE_AUDIT event=${event.i} ${event.hn} - ${event.an} " +
                "history=${model?.historyMatches ?: 0} " +
                "takim=${home != null}/${away != null} " +
                "sample=${home?.macSayisi ?: 0}/${away?.macSayisi ?: 0}"
        )
    }

    private suspend fun merkeziTakimProfili(
        dao: MerkeziDao,
        teamId: String,
        beforeTs: Long
    ): TakimProfilMotoru.Profile {
        return TakimProfilMotoru.profile(
            dao = dao,
            teamId = teamId,
            beforeTs = beforeTs,
            leagueId = null,
            seasonId = null
        )
    }

    private fun mapMerkeziMarket(
        distribution: com.Fyco.iddaaanaliz.merkezi.OlasilikMotoruV2.ScoreDistribution,
        title: String,
        market: com.Fyco.iddaaanaliz.IddaaMarket
    ): Map<String, Double>? {
        val normalized = normalize(title)
        val line = Regex("([0-9]+(?:[.,][0-9]+)?)").find(normalized)
            ?.groupValues?.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull()
            ?: 0.5

        val base: Map<String, Double> = when {
            normalized.contains("ilk yari") -> {
                val half = OlasilikMotoruV2.firstHalf(distribution)
                OlasilikMotoruV2.market(half, "ms")
            }
            normalized.contains("karsilikli gol") -> OlasilikMotoruV2.market(distribution, "kg")
            normalized.contains("mac sonucu") || normalized == "ms" -> OlasilikMotoruV2.market(distribution, "ms")
            normalized.contains("ev sahibi gol") || normalized.contains("ev sahibi takim gol") ->
                OlasilikMotoruV2.teamGoals(distribution, home = true, line = line)
            normalized.contains("deplasman gol") || normalized.contains("deplasman takim gol") ->
                OlasilikMotoruV2.teamGoals(distribution, home = false, line = line)
            normalized.contains("ust") || normalized.contains("alt") ->
                OlasilikMotoruV2.market(distribution, "ustalt", line.takeIf { it > 0.0 } ?: 2.5)
            else -> return null
        }

        fun lookup(outcome: String): Double {
            val key = normalize(outcome)
            return when {
                key == "1" -> base["1"] ?: 0.0
                key == "x" || key == "0" || key == "beraberlik" -> base["x"] ?: base["0"] ?: 0.0
                key == "2" -> base["2"] ?: 0.0
                key.contains("var") -> base["var"] ?: 0.0
                key.contains("yok") -> base["yok"] ?: 0.0
                key.contains("ust") -> base["ust"] ?: 0.0
                key.contains("alt") -> base["alt"] ?: 0.0
                else -> base.entries.firstOrNull { normalize(it.key) == key }?.value ?: 0.0
            }
        }

        return market.o.associate { it.n to lookup(it.n) }
    }

    private var context: Context? = null
    private fun requireContext(): Context = context ?: error("MerkeziVeriHavuzu.init(context) çağrılmalı")

    fun setContext(context: Context) { this.context = context.applicationContext }

    /** Merkezi geçmiş havuzundan takım ratingi + form + rakip gücü modelini kurar. */
    suspend fun futbolModeliniHazirla(force: Boolean = false): MerkeziFutbolModelHavuzu.Snapshot? = withContext(Dispatchers.IO) {
        val current = MerkeziFutbolModelHavuzu.current()
        val dao = db.dao()
        if (!force && current?.ready == true) {
            val dbResultCount = runCatching { dao.footballResultCount() }.getOrDefault(-1)
            if (dbResultCount == current.historyMatches ||
            (dbResultCount > 50_000 && current.historyMatches >= 50_000)) {
                Log.i("MERKEZI_HAVUZ", "FUTBOL_MODEL_CACHE_HIT history=${current.historyMatches}")
                return@withContext current
            }
        }

        val built = if (force) {
            MerkeziFutbolModelHavuzu.rebuild(dao)
        } else {
            MerkeziFutbolModelHavuzu.ensureCurrent(dao, force = false)
        }
        val ready = MerkeziFutbolModelHavuzu.current()?.takeIf { it.ready } ?: built.takeIf { it.ready }
        Log.i(
            "MERKEZI_HAVUZ",
            "FUTBOL_MODEL_HAZIR history=${ready?.historyMatches ?: built.historyMatches} " +
                "takim=${ready?.teams?.size ?: built.teams.size} ready=${ready != null} force=$force"
        )
        ready
    }

    fun futbolModelHazirMi(): Boolean = MerkeziFutbolModelHavuzu.current()?.ready == true

    /** Canlı İddaa takım adını yalnızca merkezi havuzdaki tam normalize isimle eşler. */
    suspend fun futbolTakimIdBul(ad: String): String? = withContext(Dispatchers.IO) {
        if (ad.isBlank()) return@withContext null
        db.dao().teamByNormalized(normalize(ad), "FUTBOL")?.teamId
    }

    private fun ESPNTarihselMac.matchId() = "FUTBOL:ESPN:$eventId"
    private fun ESPNTarihselMac.toMatch() = MerkeziMatch(matchId(), eventId.toString(), "FUTBOL", "FUTBOL:team:${normalize(evTakim)}", "FUTBOL:team:${normalize(deplasmanTakim)}", evTakim, deplasmanTakim, null, lig, null, sezon, baslangic, if (tamamlandi) "completed" else "scheduled")
    private fun ESPNTarihselMac.homeTeam() = MerkeziTeam("FUTBOL:team:${normalize(evTakim)}", "FUTBOL", evTakim, normalize(evTakim), null, lig)
    private fun ESPNTarihselMac.awayTeam() = MerkeziTeam("FUTBOL:team:${normalize(deplasmanTakim)}", "FUTBOL", deplasmanTakim, normalize(deplasmanTakim), null, lig)
    private fun ESPNTarihselMac.toResult() = MerkeziResult("ESPN:$eventId", matchId(), evSkor.toDouble(), deplasmanSkor.toDouble(), evIlkYari?.toDouble(), deplasmanIlkYari?.toDouble(), baslangic, "ESPN")

    suspend fun istatistik(): MerkeziHavuzIstatistik = withContext(Dispatchers.IO) {
        val dao = db.dao()
        MerkeziHavuzIstatistik(
            mac = dao.matchCount(),
            takim = dao.teamCount(),
            lig = dao.leagueCount(),
            sezon = dao.seasonCount(),
            market = dao.marketCount(),
            oran = dao.oddsCount(),
            kaynak = dao.sourceCount(),
            sonuc = dao.resultCount(),
            tahmin = dao.predictionCount()
        )
    }


    /**
     * Merkezi havuzda birikmiş tamamlanmış futbol maçlarını,
     * Kendi Modeli eğitiminde kullanılan ESPN tarihsel modeline dönüştürür.
     * Gerçekleşmiş skorlar eğitim gerçeğidir; tahminler bu listeye dahil edilmez.
     */
    suspend fun gerceklesenSonuclariEgitimIcinGetir(): List<ESPNTarihselMac> =
        withContext(Dispatchers.IO) {
            if (!::db.isInitialized) return@withContext emptyList()

            val rows = db.dao().completedFootballHistory(
                beforeTs = Long.MAX_VALUE,
                limit = 50_000
            )

            rows.map { row ->
                val eventId = row.externalId
                    ?.toLongOrNull()
                    ?: row.matchId.hashCode().toLong()

                ESPNTarihselMac(
                    eventId = eventId,
                    baslangic = row.startTs,
                    lig = row.leagueName,
                    sezon = row.seasonName,
                    evTakimId = row.homeTeamId,
                    deplasmanTakimId = row.awayTeamId,
                    evTakim = row.homeTeamName,
                    deplasmanTakim = row.awayTeamName,
                    evSkor = row.rHomeScore.toInt(),
                    deplasmanSkor = row.rAwayScore.toInt(),
                    evIlkYari = null,
                    deplasmanIlkYari = null,
                    tamamlandi = true,
                    kayitZamani = row.rCompletedAt
                )
            }
        }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale("tr", "TR")), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").replace("ı", "i").replace(Regex("[^a-z0-9]+"), " ").trim().replace(Regex("\\s+"), " ")
}


data class MerkeziHavuzIstatistik(
    val mac: Int,
    val takim: Int,
    val lig: Int,
    val sezon: Int,
    val market: Int,
    val oran: Int,
    val kaynak: Int,
    val sonuc: Int,
    val tahmin: Int
)
