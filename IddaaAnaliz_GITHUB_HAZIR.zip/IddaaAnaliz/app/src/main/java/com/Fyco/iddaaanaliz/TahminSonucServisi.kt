@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

/**
 * Sonuç geldiğinde öğrenme kaydını kapatır.
 *
 * Şimdilik sonuç kaynağından bağımsızdır.
 * Resmî sonuç sağlayıcısı bağlandığında bu sınıf kullanılacak.
 */
object TahminSonucServisi {

    fun secimSonucunuIsle(
        eventId: Long,
        marketId: Long,
        secimNo: Int,
        kazandi: Boolean
    ): Boolean {
        return TahminOgrenmeRepository.sonucuIsle(
            eventId = eventId,
            marketId = marketId,
            secimNo = secimNo,
            kazandi = kazandi
        )
    }

    fun performans(): OgrenmePerformans =
        TahminOgrenmeRepository.performansOzeti()
}
