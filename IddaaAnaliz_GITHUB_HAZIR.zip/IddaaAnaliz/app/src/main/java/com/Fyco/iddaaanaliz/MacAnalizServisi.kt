@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz
import com.Fyco.iddaaanaliz.merkezi.MerkeziFutbolModelHavuzu
import com.Fyco.iddaaanaliz.merkezi.MerkeziFutbolTahmincisi
import com.Fyco.iddaaanaliz.merkezi.MacModelDuzeltmeleri

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext

import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

/**
 * Analizin merkez orkestrasyon katmanı.
 *
 * Akış:
 * 1) Resmî İddaa marketleri temel alınır.
 * 2) Merkezi Veri Havuzu içindeki takım/geçmiş verisi hazırlanır.
 * 3) Geçmişten takım ratingi + form + rakip gücü çıkarılır.
 * 4) Merkezi Poisson/skor dağılımı ile tüm futbol marketleri hesaplanır.
 * 5) AnalizMotoru yalnızca model olasılığını ekonomik metriklerle sonradan değerlendirir.
 *
 * Canlı futbol modelinde yalnızca Merkezi Veri Havuzu kullanılır; ProgSport/ESPN canlı modele girmez.
 */
object MacAnalizServisi {

    // Aynı maç güçlü seçim taramasında analiz edildikten sonra
    // kullanıcı detay ekranına girerse aynı ağır dış veri çağrılarını
    // ikinci kez yapma. Bu, özellikle düşük RAM'li telefonlarda
    // donma/kapanma riskini ciddi biçimde azaltır.
    private const val CACHE_SURE_MS = 15 * 60 * 1000L
    private const val CACHE_MAX = 512

    private data class AnalizCache(
        val zaman: Long,
        val fingerprint: Long,
        val modelCreatedAt: Long,
        val sonuc: MacAnalizSonucu
    )

    private val analizCache = ConcurrentHashMap<Long, AnalizCache>()

    suspend fun analizEt(
        event: IddaaEvent,
        spor: SporTuru,
        disVeriKullan: Boolean = true,
        kaydet: Boolean = true,
        evEksikOyuncular: List<OyuncuEtkiVerisi> = emptyList(),
        depEksikOyuncular: List<OyuncuEtkiVerisi> = emptyList(),
        evKadro: List<OyuncuEtkiVerisi> = emptyList(),
        depKadro: List<OyuncuEtkiVerisi> = emptyList(),
        ppdaEv: Double? = null,
        ppdaDep: Double? = null,
        ligPpdaOrt: Double? = null,
        ligPpdaStd: Double? = null
    ): MacAnalizSonucu {
        val simdi = System.currentTimeMillis()
        val currentModelCreatedAt = MerkeziFutbolModelHavuzu.current()?.createdAt ?: 0L
        val fingerprint = eventFingerprint(event) xor oyuncuFingerprint(
            evEksikOyuncular + evKadro,
            depEksikOyuncular + depKadro
        )
        // Kadro/oyuncu verisi sağlandığında analiz mutlaka yeniden çalıştırılır.
        // Aksi halde daha önce kadrosuz oluşturulmuş sonuç cache'den dönerek
        // yeni oyuncu kalite sinyalini lambda katmanına hiç ulaştırmayabilir.
        val kadroVerisiVar = evKadro.isNotEmpty() || depKadro.isNotEmpty() ||
            evEksikOyuncular.isNotEmpty() || depEksikOyuncular.isNotEmpty()
        val useResultCache = !kadroVerisiVar

        if (useResultCache) {
            analizCache[event.i]?.let { cached ->
                if (simdi - cached.zaman <= CACHE_SURE_MS &&
                    cached.fingerprint == fingerprint &&
                    cached.modelCreatedAt == currentModelCreatedAt
                ) {
                    Log.i("IddaaOgrenme", "ANALİZ_CACHE_HIT event=${event.i} ${event.hn} - ${event.an}")
                    return cached.sonuc
                } else {
                    analizCache.remove(event.i)
                }
            }
        }

        // Normal detay analizinde resmi market config yenilenebilir.
        // Günün Güçlüleri ise binlerce maç taradığı için her maçta ağ çağrısı
        // kesinlikle yapılmaz; cached/fallback t-st sınıflaması yeterlidir.
        if (disVeriKullan && !IddaaMarketConfigRepository.configYukluMu()) {
            runCatching { IddaaMarketConfigRepository.hazirla() }
        }

        // Güçlü seçimlerin 1000+ maç taramasında her maç için yeniden ağ çağrısı
        // yapmak gereksizdir. Kendi model hazır olduğunda hızlı tarama yalnızca
        // mevcut İddaa + ESPN model verisini kullanır. Detay ekranındaki normal
        // analiz disVeriKullan=true ile eski davranışı korur.
        val organizasyonAdi = if (disVeriKullan) {
            runCatching { IddaaCompetitionRepository.ad(event) }.getOrDefault("")
        } else {
            ""
        }

        // Aktif üretim zinciri yalnızca İDDAA + Merkezi Veri Havuzudur.
        // ESPN yalnızca tarihsel verinin havuza aktarılmasında kullanılır;
        // canlı tahmin olasılığı ayrı ESPN model deposundan okunmaz.
        val progSportMac: ProgSportMac? = null
        val macDisVerisi: MacDisVerisi? = null
        val veri = macDisVerisi

        val modelOrneklemMin = if (spor == SporTuru.FUTBOL) {
            // Merkezi snapshot yoksa hazırlanır. Belirli bir takım tarihsel havuzda
            // bulunmasa bile analiz kesilmez; tahminci nötr prior kullanır.
            if (MerkeziFutbolModelHavuzu.current() == null) {
                MerkeziVeriHavuzu.futbolModeliniHazirla(force = false)
            }

            if (MerkeziFutbolModelHavuzu.current() == null) {
                // Tarihsel model henüz hazır değilse bile canlı maç analizi
                // tamamen boşaltılmaz. Merkezi tahminci bu durumda takım başına
                // güvenli 0-0.5 nötr prior kullanabilir; karar katmanı ise
                // örneklem yetersizliğini OYNA kararıyla cezalandırır.
                Log.w(
                    "MERKEZI_MODEL",
                    "MODEL_NEUTRAL_BOOT event=${event.i} ${event.hn} - ${event.an} sebep=SNAPSHOT_YOK"
                )
            }

            val home = MerkeziFutbolModelHavuzu.takimByName(event.hn)
            val away = MerkeziFutbolModelHavuzu.takimByName(event.an)
            val homeSample = home?.macSayisi ?: 0
            val awaySample = away?.macSayisi ?: 0

            Log.d(
                "MERKEZI_MODEL",
                "TAKIM_MODEL ev=${home?.teamName ?: event.hn} dep=${away?.teamName ?: event.an} " +
                    "tarihsel=${home != null}/${away != null} mac=$homeSample/$awaySample " +
                    "elo=${"%.0f".format(home?.elo ?: 1500.0)}/${"%.0f".format(away?.elo ?: 1500.0)} " +
                    "quality=${home?.modelQuality ?: 0}/${away?.modelQuality ?: 0}"
            )

            if (home == null || away == null) {
                Log.i(
                    "MERKEZI_MODEL",
                    "MODEL_NEUTRAL_PRIOR event=${event.i} ${event.hn} - ${event.an} " +
                        "historical=${home != null}/${away != null} sample=$homeSample/$awaySample"
                )
            }

            minOf(homeSample, awaySample)
        } else 0

        val modelAdjustments = if (spor == SporTuru.FUTBOL) {
            val squad = MacModelDuzeltmeleri.oyuncuEksiklerinden(
                homeUnavailable = evEksikOyuncular,
                awayUnavailable = depEksikOyuncular,
                homeRoster = evKadro,
                awayRoster = depKadro
            )
            val rosterQuality = MacModelDuzeltmeleri.oyuncuKadroKalitesinden(
                homeRoster = evKadro,
                awayRoster = depKadro
            )
            val pressing = MacModelDuzeltmeleri.ppda(
                homePpda = ppdaEv,
                awayPpda = ppdaDep,
                leagueAverage = ligPpdaOrt,
                leagueStd = ligPpdaStd
            )

            Log.i(
                "OYUNCU_MODEL",
                "KADRO_MODEL_BAGLANDI event=${event.i} " +
                    "kadro=${evKadro.size}/${depKadro.size} eksik=${evEksikOyuncular.size}/${depEksikOyuncular.size} " +
                    "kaliteDeltaA=${"%.4f".format(rosterQuality.homeAttackLogDelta)}/${"%.4f".format(rosterQuality.awayAttackLogDelta)} " +
                    "kaliteDeltaD=${"%.4f".format(rosterQuality.homeDefenseLogDelta)}/${"%.4f".format(rosterQuality.awayDefenseLogDelta)}"
            )

            MerkeziFutbolModelHavuzu.MatchModelAdjustments(
                homeAttackLogDelta = squad.homeAttackLogDelta + rosterQuality.homeAttackLogDelta,
                homeDefenseLogDelta = squad.homeDefenseLogDelta + rosterQuality.homeDefenseLogDelta,
                awayAttackLogDelta = squad.awayAttackLogDelta + rosterQuality.awayAttackLogDelta,
                awayDefenseLogDelta = squad.awayDefenseLogDelta + rosterQuality.awayDefenseLogDelta,
                homePpdaEffect = pressing.homePpdaEffect,
                awayPpdaEffect = pressing.awayPpdaEffect,
                confidencePenalty = (squad.confidencePenalty + kotlin.math.abs(pressing.homePpdaEffect) * 0.10 + kotlin.math.abs(pressing.awayPpdaEffect) * 0.10).coerceAtMost(0.08)
            )
        } else MerkeziFutbolModelHavuzu.MatchModelAdjustments()

        if (spor == SporTuru.FUTBOL && (evEksikOyuncular.isNotEmpty() || depEksikOyuncular.isNotEmpty())) {
            Log.i(
                "OYUNCU_MODEL",
                "KADRO_LAMBDA_DUZELTMESI event=${event.i} " +
                    "evA=${"%.4f".format(modelAdjustments.homeAttackLogDelta)} " +
                    "evD=${"%.4f".format(modelAdjustments.homeDefenseLogDelta)} " +
                    "depA=${"%.4f".format(modelAdjustments.awayAttackLogDelta)} " +
                    "depD=${"%.4f".format(modelAdjustments.awayDefenseLogDelta)} " +
                    "ceza=${"%.4f".format(modelAdjustments.confidencePenalty)}"
            )
        }

        val aktifMarketler = event.m
            .filter { it.o.isNotEmpty() }
            .filter { MarketPolitikasiV1.aktifMi(it, spor) }

        // ESPN Kendi Modeli aynı maçın bütün marketlerinde ortak skor
        // dağılımını yalnızca bir kez üretir. Böylece 15-30 markette
        // Poisson + kalibrasyon + takım ratingi tekrar edilmez.
        val merkeziBatchProbabilities: Map<Long, Map<Int, Double>> = if (spor == SporTuru.FUTBOL) {
            runCatching {
                MerkeziFutbolTahmincisi.marketOlasiliklariBatch(
                    markets = aktifMarketler,
                    spor = spor,
                    evTakimAdi = event.hn,
                    deplasmanTakimAdi = event.an,
                    adjustments = modelAdjustments
                )
            }.onFailure {
                Log.e("MERKEZI_MODEL", "TAHMIN_HATASI event=${event.i}", it)
            }.getOrDefault(emptyMap())
        } else {
            emptyMap<Long, Map<Int, Double>>()
        }

        if (spor == SporTuru.FUTBOL && merkeziBatchProbabilities.isEmpty()) {
            // Merkezi tahminci hiçbir market üretemediyse bütün maçı sessizce
            // "market yok" sayma. Aşağıdaki per-market yolunun kendi güvenli
            // VERİ_YETERSİZ açıklamasını üretmesine izin veriyoruz.
            Log.w("MERKEZI_MODEL", "MERKEZI_MARKET_BATCH_BOS event=${event.i} market=${aktifMarketler.size}")
        }

        val hamMarketSonuclari = aktifMarketler
            .map { market ->
                val progProbabilities = if (progSportMac != null) {
                    progSportOlasiliklariniOlustur(
                        market = market,
                        spor = spor,
                        progSportMac = progSportMac
                    )
                } else {
                    emptyMap()
                }

                // V10: FUTBOLDA tek yetkili model Merkezi Veri Havuzudur.
                // ESPN eski model yolu kesinlikle fallback değildir.
                val kendiModelProbabilities: Map<Int, Double> = if (spor == SporTuru.FUTBOL) {
                    val merkeziProbabilities = merkeziBatchProbabilities[market.i].orEmpty()
                    // Futbolda ortak skor dağılımının dışına çıkmamak için
                    // Merkezi model market bazında boş dönerse başka bir modelle
                    // doldurmuyoruz. Aksi halde aynı maçta bazı marketler ESPN,
                    // bazı marketler ayrı KendiModelMotoru hesabı kullanır.
                    merkeziProbabilities
                } else {
                    KendiModelMotoru.marketOlasiliklariniOlustur(
                        market = market,
                        spor = spor,
                        veri = veri
                    )
                }

                // FUTBOLDA bütün ana marketler tek ortak skor dağılımından türetilir.
                // Oyuncu/kadro etkisi ayrı market olasılığına sonradan eklenmez;
                // lambda üretilmeden önce ortak MatchModelAdjustments içine girer.
                // Böylece MS, KG, Alt/Üst ve takım golü aynı düzeltilmiş dağılımı kullanır.
                val duzeltilmisKendiModelProbabilities: Map<Int, Double> =
                    if (spor == SporTuru.FUTBOL) {
                        kendiModelProbabilities
                    } else {
                        val oyuncuDuzeltmeleri =
                            oyuncuDuzeltmeleriniOlustur(
                                market = market,
                                spor = spor,
                                veri = veri
                            )
                        oyuncuDuzeltmeleriniUygula(
                            olasiliklar = kendiModelProbabilities,
                            duzeltmeler = oyuncuDuzeltmeleri
                        )
                    }

                AnalizMotoru.analizMarket(
                    market = market,
                    progSportOlasiliklari = progProbabilities,
                    kendiModelOlasiliklari = duzeltilmisKendiModelProbabilities,
                    spor = spor,
                    organizasyon = organizasyonAdi,
                    modelOrneklemMin = modelOrneklemMin,
                    modelQuality = modelQualityFromSnapshot(event),
                    modelSampleCount = modelOrneklemMin
                )
            }

        // FUTBOL: MS / KG / Alt-Üst gibi marketlerin aynı skor dağılımından
        // türetilmiş olması zorunlu. Son aşamada çapraz-market tutarlılık filtresi
        // ile matematiksel olarak çelişen seçimler OYNAMA'ya düşürülür.
        val marketSonuclari = if (spor == SporTuru.FUTBOL) {
            FutbolMarketTutarlilikKatmani.uygula(hamMarketSonuclari)
        } else {
            hamMarketSonuclari
        }

        val toplamCozulenSecim = marketSonuclari.sumOf { marketSonucu ->
            marketSonucu.secimler.count {
                it.marketId == marketSonucu.market.i &&
                    it.oran > 1.0 &&
                    it.gelmeOlasiligi > 0.0
            }
        }
        val kararOyna = marketSonuclari.sumOf { marketSonucu ->
            marketSonucu.secimler.count { it.karar == Karar.OYNA }
        }
        val kararSinirda = marketSonuclari.sumOf { marketSonucu ->
            marketSonucu.secimler.count { it.karar == Karar.SINIRDA }
        }
        val kararVeriYetersiz = marketSonuclari.sumOf { marketSonucu ->
            marketSonucu.secimler.count { it.karar == Karar.VERI_YETERSIZ }
        }

        Log.i(
            "IddaaOgrenme",
            "ANALİZ_TAMAMLANDI event=${event.i} ${event.hn} - ${event.an} " +
                "marketSayisi=${marketSonuclari.size} çözülenSecim=$toplamCozulenSecim " +
                "oyna=$kararOyna sinirda=$kararSinirda veriYetersiz=$kararVeriYetersiz"
        )

        val enIyiSecimler = marketSonuclari
            .flatMap { marketSonucu ->
                marketSonucu.secimler.filter { secim ->
                    secim.marketId == marketSonucu.market.i &&
                            marketSonucu.market.o.any { normalize(it.n) == normalize(secim.secim) } &&
                            secim.oran > 1.0 &&
                            secim.gelmeOlasiligi > 0.0
                }
            }
            .sortedWith(
                compareByDescending<AnalizSonucu> { it.gelmeOlasiligi }
                    .thenByDescending { it.guvenPuani }
                    .thenByDescending { it.edge ?: Double.NEGATIVE_INFINITY }
                    .thenByDescending { it.ev ?: Double.NEGATIVE_INFINITY }
            )

        Log.i("IddaaOgrenme", "ÖĞRENME_ADAYLARI event=${event.i} adet=${enIyiSecimler.size}")

        if (kaydet) {
            // Normal detay analizinde öğrenme/audit kayıtları devam eder.
            // Günün Güçlüleri taraması kaydet=false ile çağrıldığı için
            // yüzlerce maçın her seferinde ağır DB yazımı yapılmaz.
            enIyiSecimler.forEach { secim ->
                val market = marketSonuclari.firstOrNull {
                    it.market.i == secim.marketId
                }?.market ?: return@forEach

                val secimNo = secim.secimNo ?: return@forEach
                val marketId = secim.marketId ?: return@forEach
                val anahtar = "${event.i}:$marketId:$secimNo"

                val canonicalMarketTitle = (secim.marketBasligi
                    ?.takeIf { it.isNotBlank() }
                    ?: marketSonuclari.firstOrNull { it.market.i == marketId }?.baslik
                    ?: AnalizMotoru.marketBasligi(market))
                    .trim()
                    .ifBlank { "MARKET" }

                TahminOgrenmeRepository.kaydetVeyaGuncelle(
                    TahminKaydi(
                        anahtar = anahtar,
                        eventId = event.i,
                        marketId = marketId,
                        secimNo = secimNo,
                        secim = secim.secim,
                        marketBasligi = canonicalMarketTitle,
                        sov = market.sov,
                        organizasyon = organizasyonAdi,
                        spor = spor.name,
                        evSahibi = event.hn,
                        deplasman = event.an,
                        macZamani = event.d,
                        kayitZamani = System.currentTimeMillis(),
                        oran = secim.oran,
                        olasilik = secim.gelmeOlasiligi,
                        iddaaOlasiligi = secim.kaynakHarmani?.iddaaOlasiligi,
                        progSportOlasiligi = secim.kaynakHarmani?.progSportOlasiligi,
                        kendiModelOlasiligi = secim.kaynakHarmani?.kendiModelOlasiligi,
                        karar = secim.karar.name,
                        guvenPuani = secim.guvenPuani
                    )
                )
            }

            // Nihai tahminleri merkezi havuza kaydet. Üst coroutine iptal edilse
            // bile kritik audit/öğrenme yazımının tamamlanmasına izin ver.
            runCatching {
                withContext(NonCancellable + Dispatchers.IO) {
                    MerkeziVeriHavuzu.tahminleriYaz(event, spor, enIyiSecimler)
                    MerkeziVeriHavuzu.merkeziPipelineCalistir(event, spor, enIyiSecimler)
                }
            }.onFailure {
                Log.e("MERKEZI_HAVUZ", "MERKEZI_PIPELINE_KAYIT_HATASI event=${event.i}", it)
            }
        }

        val sonuc = MacAnalizSonucu(
            marketler = marketSonuclari,
            enIyiSecimler = enIyiSecimler
        )

        if (useResultCache) {
            analizCache[event.i] = AnalizCache(
                zaman = System.currentTimeMillis(),
                fingerprint = fingerprint,
                modelCreatedAt = MerkeziFutbolModelHavuzu.current()?.createdAt ?: currentModelCreatedAt,
                sonuc = sonuc
            )

            // Belleğin sınırsız büyümesini önle.
            if (analizCache.size > CACHE_MAX) {
                val eskiAnahtar = analizCache.entries
                    .minByOrNull { it.value.zaman }
                    ?.key
                if (eskiAnahtar != null) analizCache.remove(eskiAnahtar)
            }
        }

        return sonuc
    }

    private fun modelQualityFromSnapshot(event: IddaaEvent): Int {
        val home = MerkeziFutbolModelHavuzu.takimByName(event.hn) ?: return 0
        val away = MerkeziFutbolModelHavuzu.takimByName(event.an) ?: return 0
        return ((home.modelQuality + away.modelQuality) / 2.0).roundToInt().coerceIn(0, 100)
    }

    private fun oyuncuDuzeltmeleriniUygula(
        olasiliklar: Map<Int, Double>,
        duzeltmeler: Map<Int, Double>
    ): Map<Int, Double> {
        if (olasiliklar.isEmpty() || duzeltmeler.isEmpty()) return olasiliklar

        val duzeltilmis = olasiliklar.mapValues { (secimNo, olasilik) ->
            (olasilik + (duzeltmeler[secimNo] ?: 0.0)).coerceIn(0.001, 0.999)
        }

        val toplam = duzeltilmis.values.sum()
        if (toplam <= 0.0) return olasiliklar

        return duzeltilmis.mapValues { (_, olasilik) ->
            (olasilik / toplam).coerceIn(0.0, 1.0)
        }
    }

    private fun progSportOlasiliklariniOlustur(
        market: IddaaMarket,
        spor: SporTuru,
        progSportMac: ProgSportMac
    ): Map<Int, Double> {
        val baslik = try {
            IddaaMarketConfigRepository.marketBasligi(market)
        } catch (_: Exception) {
            ""
        }

        val normalizedBaslik = normalize(baslik)
        val outcomeMap = linkedMapOf<Int, Double>()

        if (spor == SporTuru.FUTBOL && isMacSonucuMarket(market, normalizedBaslik)) {
            market.o.forEach { outcome ->
                when (normalize(outcome.n)) {
                    "1" -> progSportMac.evOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                    "x", "0" -> progSportMac.beraberlikOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                    "2" -> progSportMac.deplasmanOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                }
            }
            return normalizeProbabilityMap(outcomeMap)
        }

        if (spor == SporTuru.FUTBOL && isToplam25Market(market, normalizedBaslik)) {
            market.o.forEach { outcome ->
                when (normalize(outcome.n)) {
                    "alt" -> progSportMac.altOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                    "ust" -> progSportMac.ustOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                }
            }
            return normalizeProbabilityMap(outcomeMap)
        }

        if (spor == SporTuru.BASKETBOL && isMacSonucuMarket(market, normalizedBaslik)) {
            market.o.forEach { outcome ->
                when (normalize(outcome.n)) {
                    "1" -> progSportMac.evOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                    "2" -> progSportMac.deplasmanOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                }
            }
            return normalizeProbabilityMap(outcomeMap)
        }

        if (spor == SporTuru.BASKETBOL && normalizedBaslik.contains("handikap")) {
            market.o.forEach { outcome ->
                when (normalize(outcome.n)) {
                    "1" -> progSportMac.spreadEvOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                    "2" -> progSportMac.spreadDeplasmanOlasilik?.let { p ->
                        if (p in 0.0..1.0) outcomeMap[outcome.no] = p
                    }
                }
            }
            return normalizeProbabilityMap(outcomeMap)
        }

        // Diğer özel marketlerde ProgSport genel tahmini yanlış markete taşınmaz.
        return emptyMap()
    }

    private fun oyuncuDuzeltmeleriniOlustur(
        market: IddaaMarket,
        spor: SporTuru,
        veri: MacDisVerisi?
    ): Map<Int, Double> {
        if (veri == null) return emptyMap()

        val evEtki = veri.sakatlikEv.takimEtkisi
        val depEtki = veri.sakatlikDeplasman.takimEtkisi

        if (evEtki <= 0.0 && depEtki <= 0.0) return emptyMap()

        val title = normalize(
            try {
                IddaaMarketConfigRepository.marketBasligi(market)
            } catch (_: Exception) {
                ""
            }
        )

        val result = linkedMapOf<Int, Double>()

        // Doğrudan sonuç marketi: eksikler takım lehine olasılığı etkiler.
        if (isMacSonucuMarket(market, title)) {
            market.o.forEach { outcome ->
                when (normalize(outcome.n)) {
                    "1" -> result[outcome.no] = (-0.035 * evEtki + 0.035 * depEtki)
                    "2" -> result[outcome.no] = (-0.035 * depEtki + 0.035 * evEtki)
                    "x", "0" -> result[outcome.no] = 0.0
                }
            }
            return result.mapValues { it.value.coerceIn(-0.12, 0.12) }
        }

        // Toplam gol/sayı marketleri için eksiklerin toplam hücum kapasitesine etkisini uygula.
        if (spor == SporTuru.FUTBOL && title.contains("toplam") &&
            (title.contains("gol") || title.contains("2.5"))) {
            val totalPenalty = minOf(0.10, (evEtki + depEtki) * 0.02)
            market.o.forEach { outcome ->
                when (normalize(outcome.n)) {
                    "ust" -> result[outcome.no] = -totalPenalty
                    "alt" -> result[outcome.no] = totalPenalty
                }
            }
            return result
        }

        if (spor == SporTuru.BASKETBOL && title.contains("toplam")) {
            val totalPenalty = minOf(0.10, (evEtki + depEtki) * 0.02)
            market.o.forEach { outcome ->
                when (normalize(outcome.n)) {
                    "ust" -> result[outcome.no] = -totalPenalty
                    "alt" -> result[outcome.no] = totalPenalty
                }
            }
            return result
        }

        return emptyMap()
    }

    private fun isToplam25Market(
        market: IddaaMarket,
        normalizedTitle: String
    ): Boolean {
        if (normalizedTitle.contains("toplam 2.5")) return true
        if (market.sov?.trim()?.replace(',', '.') != "2.5") return false
        val names = market.o.map { normalize(it.n) }
        return names.contains("alt") && names.contains("ust")
    }

    private fun isMacSonucuMarket(
        market: IddaaMarket,
        normalizedTitle: String
    ): Boolean {
        if (normalizedTitle == "mac sonucu") return true
        if (normalizedTitle.contains("handikap")) return false

        val names = market.o.map { normalize(it.n) }
        return names.contains("1") &&
                names.contains("2") &&
                (names.contains("x") || names.contains("0"))
    }

    private fun normalizeProbabilityMap(
        values: Map<Int, Double>
    ): Map<Int, Double> {
        val valid = values.filterValues { it.isFinite() && it > 0.0 }
        if (valid.size < 2) return emptyMap()
        val total = valid.values.sum()
        if (total <= 0.0) return emptyMap()
        return valid.mapValues { (_, value) ->
            (value / total).coerceIn(0.0, 1.0)
        }
    }

    private fun oyuncuFingerprint(
        home: List<OyuncuEtkiVerisi>,
        away: List<OyuncuEtkiVerisi>
    ): Long {
        var h = 23L
        (home + away).sortedBy { it.oyuncuAdi.lowercase(Locale.ROOT) }.forEach { p ->
            h = h * 31L + p.oyuncuAdi.hashCode().toLong()
            h = h * 31L + (p.oyuncuId?.hashCode()?.toLong() ?: 0L)
            h = h * 31L + p.pozisyon.ordinal
            h = h * 31L + p.durum.ordinal
            h = h * 31L + java.lang.Double.doubleToLongBits(p.dakikaOrtalamasi)
            h = h * 31L + p.macSayisi
            h = h * 31L + p.ilkOnBirSayisi
            h = h * 31L + java.lang.Double.doubleToLongBits(p.ilkOnBirOrani)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.gol)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.asist)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.xg)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.xa)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.sut)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.isabetliSut)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.kurtaris)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.golYeme)
            h = h * 31L + java.lang.Double.doubleToLongBits(p.manuelOnemSkoru ?: -1.0)
        }
        return h
    }

    private fun eventFingerprint(event: IddaaEvent): Long {
        var h = 17L
        h = h * 31L + event.i
        h = h * 31L + event.d
        h = h * 31L + event.m.size
        event.m.forEach { market ->
            h = h * 31L + market.i
            h = h * 31L + (market.sov?.hashCode()?.toLong() ?: 0L)
            market.o.forEach { outcome ->
                h = h * 31L + outcome.no
                h = h * 31L + java.lang.Double.doubleToLongBits(outcome.odd)
            }
        }
        return h
    }

    private fun normalize(value: String?): String {
        return value
            ?.trim()
            ?.lowercase(Locale.forLanguageTag("tr-TR"))
            ?.replace('ı', 'i')
            ?.replace('ş', 's')
            ?.replace('ğ', 'g')
            ?.replace('ü', 'u')
            ?.replace('ö', 'o')
            ?.replace('ç', 'c')
            ?.replace(Regex("\\s+"), " ")
            ?: ""
    }
}
