package com.Fyco.iddaaanaliz

/**
 * Bekleyen tahminleri otomatik olarak sonuçlandırır.
 *
 * Güvenlik prensibi:
 * - maç zamanı geçmeden çözmez
 * - sonuç sağlayıcı maçı kesin eşleştiremezse çözmez
 * - market çözümleyici desteklemiyorsa çözmez
 * - null sonucu hiçbir zaman kayıp/kazanç olarak yazmaz
 */
object TahminSonucCozumleyici {
    private const val MIN_SONUC_GECIKMESI_MS = 90 * 60 * 1000L

    suspend fun calistir(): SonucCozumOzeti {
        val bekleyenler = TahminOgrenmeRepository.bekleyenleriGetir()
        if (bekleyenler.isEmpty()) return SonucCozumOzeti()

        var kontrolEdilen = 0
        var cozuldu = 0
        var kazanildi = 0
        var kaybedildi = 0
        var beklemede = 0

        val now = System.currentTimeMillis()

        for (kayit in bekleyenler) {
            if (kayit.macZamani <= 0L) {
                beklemede++
                continue
            }

            val macZamaniMs = kayit.macZamani * 1000L
            if (now < macZamaniMs + MIN_SONUC_GECIKMESI_MS) {
                beklemede++
                continue
            }

            kontrolEdilen++
            val spor = runCatching { SporTuru.valueOf(kayit.spor) }.getOrNull()
            if (spor == null) {
                beklemede++
                continue
            }

            val sonucMac = try {
                SofascoreSonucSaglayici.macSonucunuBul(kayit, spor)
            } catch (_: Exception) {
                null
            }

            if (sonucMac == null || !sonucMac.tamamlandi) {
                beklemede++
                continue
            }

            val sonuc = MarketSonucCozucu.coz(
                marketBasligi = kayit.marketBasligi,
                sov = kayit.sov,
                secim = kayit.secim,
                mac = sonucMac,
                spor = spor
            )

            if (sonuc == null) {
                beklemede++
                continue
            }

            // Gerçekleşen maç sonucunu merkezi havuza da yaz.
            // Böylece self-learning döngüsü aynı sonuçtan Brier + yeniden eğitim
            // için doğrudan yararlanabilir.
            if (sonucMac.evSkor != null && sonucMac.depSkor != null) {
                runCatching {
                    MerkeziVeriHavuzu.sonucuYaz(
                        eventId = kayit.eventId,
                        homeTeam = sonucMac.evSahibi,
                        awayTeam = sonucMac.deplasman,
                        spor = spor,
                        homeScore = sonucMac.evSkor.toDouble(),
                        awayScore = sonucMac.depSkor.toDouble(),
                        homeFirstHalf = sonucMac.evIlkYari?.toDouble(),
                        awayFirstHalf = sonucMac.depIlkYari?.toDouble(),
                        completedAt = (sonucMac.baslangic ?: kayit.macZamani) * 1000L,
                        source = "SOFASCORE"
                    )
                }.onFailure { error ->
                    android.util.Log.w(
                        "MERKEZI_HAVUZ",
                        "SONUC_MERKEZE_YAZILAMADI event=${kayit.eventId}",
                        error
                    )
                }
            }

            if (TahminOgrenmeRepository.sonucuIsle(
                    eventId = kayit.eventId,
                    marketId = kayit.marketId,
                    secimNo = kayit.secimNo,
                    kazandi = sonuc
                )) {
                cozuldu++
                if (sonuc) kazanildi++ else kaybedildi++
            }
        }

        return SonucCozumOzeti(
            kontrolEdilen = kontrolEdilen,
            cozuldu = cozuldu,
            kazanildi = kazanildi,
            kaybedildi = kaybedildi,
            beklemede = beklemede
        )
    }
}

data class SonucCozumOzeti(
    val kontrolEdilen: Int = 0,
    val cozuldu: Int = 0,
    val kazanildi: Int = 0,
    val kaybedildi: Int = 0,
    val beklemede: Int = 0
)
