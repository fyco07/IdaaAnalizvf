@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SofaScoreTarihselGunDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun gunKaydet(gun: SofaScoreTarihselGun)

    @Query("""
        SELECT * FROM sofascore_tarihsel_gunler
        WHERE gun = :gun AND spor = :spor
        LIMIT 1
    """)
    suspend fun getir(gun: String, spor: String): SofaScoreTarihselGun?

    @Query("""
        SELECT COUNT(*) FROM sofascore_tarihsel_gunler
        WHERE tamamlandi = 1
    """)
    suspend fun tamamlananGunSayisi(): Int

    @Query("""
        SELECT COUNT(*) FROM sofascore_tarihsel_gunler
    """)
    suspend fun toplamIslenenGunSayisi(): Int

    @Query("""
        SELECT COUNT(*) FROM sofascore_tarihsel_gunler
        WHERE tamamlandi = 1 AND spor = :spor
    """)
    suspend fun sporTamamlananGunSayisi(spor: String): Int
}
