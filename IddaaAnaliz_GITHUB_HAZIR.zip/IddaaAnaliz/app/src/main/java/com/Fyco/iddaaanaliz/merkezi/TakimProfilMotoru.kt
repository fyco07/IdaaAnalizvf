@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi


/** Faz 6: aynı gerçek sonuç havuzundan genel/lig/sezon/ev/deplasman/form pencereleri üretir. */
object TakimProfilMotoru {
    data class FormStats(val played: Int, val wins: Int, val draws: Int, val losses: Int, val scored: Double, val conceded: Double) {
        val pointsRate: Double get() = if (played == 0) 0.0 else (wins * 3.0 + draws) / (played * 3.0)
        val goalsFor: Double get() = if (played == 0) 0.0 else scored / played
        val goalsAgainst: Double get() = if (played == 0) 0.0 else conceded / played
    }
    data class Profile(val general: FormStats, val league: FormStats, val season: FormStats, val home: FormStats, val away: FormStats, val last5: FormStats, val last10: FormStats, val last20: FormStats)

    suspend fun profile(dao: MerkeziDao, teamId: String, beforeTs: Long, leagueId: String? = null, seasonId: String? = null): Profile {
        val all = dao.teamResults(teamId, beforeTs, 200)
        fun stats(rows: List<TeamResultRow>): FormStats = rows.fold(FormStats(0,0,0,0,0.0,0.0)) { a, r ->
            val home = r.homeTeamId == teamId
            val gf = if (home) r.rHomeScore else r.rAwayScore
            val ga = if (home) r.rAwayScore else r.rHomeScore
            val win = gf > ga; val draw = gf == ga
            FormStats(a.played+1, a.wins + if (win) 1 else 0, a.draws + if (draw) 1 else 0, a.losses + if (!win && !draw) 1 else 0, a.scored+gf, a.conceded+ga)
        }
        fun take(n: Int) = all.take(n)
        val league = all.filter { leagueId == null || it.leagueId == leagueId }
        val season = all.filter { seasonId == null || it.seasonId == seasonId }
        return Profile(stats(all), stats(league), stats(season), stats(all.filter { it.homeTeamId == teamId }), stats(all.filter { it.awayTeamId == teamId }), stats(take(5)), stats(take(10)), stats(take(20)))
    }
}
