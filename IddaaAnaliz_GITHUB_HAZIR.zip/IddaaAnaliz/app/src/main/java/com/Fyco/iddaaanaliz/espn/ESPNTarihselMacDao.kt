@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ESPNTarihselMacDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun kaydet(maclar: List<ESPNTarihselMac>)

    @Query("""
        SELECT *
        FROM espn_tarihsel_maclar
        WHERE tamamlandi = 1
        ORDER BY baslangic ASC
    """)
    suspend fun tamamlananMaclariGetir(): List<ESPNTarihselMac>

    @Query("""
        SELECT COUNT(*)
        FROM espn_tarihsel_maclar
        WHERE tamamlandi = 1
    """)
    suspend fun toplamMacSayisi(): Int

    @Query("""
        SELECT COUNT(*)
        FROM espn_tarihsel_maclar
    """)
    suspend fun toplamTumKayitSayisi(): Int

    @Query("""
        SELECT COUNT(DISTINCT eventId)
        FROM espn_tarihsel_maclar
    """)
    suspend fun benzersizEventIdSayisi(): Int

    @Query("""
        SELECT COUNT(*)
        FROM (
            SELECT evTakim AS takim
            FROM espn_tarihsel_maclar
            WHERE tamamlandi = 1
            UNION
            SELECT deplasmanTakim AS takim
            FROM espn_tarihsel_maclar
            WHERE tamamlandi = 1
        )
    """)
    suspend fun benzersizTakimSayisi(): Int

    @Query("""
        SELECT COUNT(*)
        FROM espn_tarihsel_maclar
        WHERE eventId = :eventId
    """)
    suspend fun eventIdVarMi(eventId: Long): Int

    @Query("""
        SELECT eventId
        FROM espn_tarihsel_maclar
        ORDER BY kayitZamani DESC
        LIMIT 10
    """)
    suspend fun sonEklenenEventIdler(): List<Long>

    @Query("""
        SELECT MIN(baslangic)
        FROM espn_tarihsel_maclar
    """)
    suspend fun ilkMacZamani(): Long?

    @Query("""
        SELECT MAX(baslangic)
        FROM espn_tarihsel_maclar
    """)
    suspend fun sonMacZamani(): Long?

    @Query("""
        SELECT MAX(baslangic)
        FROM espn_tarihsel_maclar
        WHERE tamamlandi = 1
    """)
    suspend fun sonMacBaslangicZamani(): Long?

    @Query("""
        SELECT MIN(baslangic)
        FROM espn_tarihsel_maclar
        WHERE tamamlandi = 1
    """)
    suspend fun ilkTamamlananMacZamani(): Long?

    @Query("""
        SELECT COUNT(*)
        FROM espn_tarihsel_maclar
        WHERE baslangic >= :baslangic
        AND baslangic < :bitis
    """)
    suspend fun tarihAraligindaMacSayisi(
        baslangic: Long,
        bitis: Long
    ): Int

    @Query("""
        SELECT COUNT(*)
        FROM espn_tarihsel_maclar
        WHERE tamamlandi = 1
        AND baslangic >= :baslangic
        AND baslangic < :bitis
    """)
    suspend fun tarihAraligindaTamamlananMacSayisi(
        baslangic: Long,
        bitis: Long
    ): Int

    @Query("""
        SELECT *
        FROM espn_tarihsel_maclar
        WHERE tamamlandi = 1
          AND baslangic >= :baslangic
          AND baslangic < :bitis
        ORDER BY baslangic ASC
        LIMIT 2000
    """)
    suspend fun tamamlananMaclariTarihAraligindaGetir(
        baslangic: Long,
        bitis: Long
    ): List<ESPNTarihselMac>

    @Query("""
        SELECT *
        FROM espn_tarihsel_maclar
        WHERE eventId = :eventId
        LIMIT 1
    """)
    suspend fun eventGetir(eventId: Long): ESPNTarihselMac?

    @Query("""
        SELECT *
        FROM espn_tarihsel_maclar
        ORDER BY baslangic ASC
        LIMIT 1
    """)
    suspend fun ilkMacGetir(): ESPNTarihselMac?

    @Query("""
        SELECT *
        FROM espn_tarihsel_maclar
        ORDER BY baslangic DESC
        LIMIT 1
    """)
    suspend fun sonMacGetir(): ESPNTarihselMac?

    @Query("""
        DELETE FROM espn_tarihsel_maclar
    """)
    suspend fun temizle()
}