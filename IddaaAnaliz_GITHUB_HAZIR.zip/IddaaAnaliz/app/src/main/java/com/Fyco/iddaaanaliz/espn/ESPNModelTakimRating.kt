@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "espn_model_takim_rating")
data class ESPNModelTakimRating(
    @PrimaryKey val takimAnahtari: String,
    val takimAdi: String,
    val lig: String?,
    val hucum: Double,
    val savunma: Double,
    val macSayisi: Int,
    val guncellemeZamani: Long = System.currentTimeMillis()
)
