@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import android.util.Log
import com.Fyco.iddaaanaliz.OyuncuDurumTipi
import com.Fyco.iddaaanaliz.OyuncuEtkiMotoru
import com.Fyco.iddaaanaliz.OyuncuEtkiVerisi
import com.Fyco.iddaaanaliz.SporTuru
import kotlin.math.max

/** Maç gününe özel, gerçek kadro verisine dayalı model düzeltmeleri. */
object MacModelDuzeltmeleri {

    /**
     * Eksik oyuncu etkisini "mutlak oyuncu puanı" olarak değil, takımın aynı
     * pozisyondaki gözlenen oyuncularına göre ABOVE-REPLACEMENT farkı olarak hesaplar.
     * Böylece yedek seviyesindeki bir oyuncunun yokluğu yıldız oyuncu kadar cezalandırılmaz.
     */
    fun oyuncuEksiklerinden(
        homeUnavailable: List<OyuncuEtkiVerisi> = emptyList(),
        awayUnavailable: List<OyuncuEtkiVerisi> = emptyList(),
        homeRoster: List<OyuncuEtkiVerisi> = emptyList(),
        awayRoster: List<OyuncuEtkiVerisi> = emptyList()
    ): MerkeziFutbolModelHavuzu.MatchModelAdjustments {
        if (homeUnavailable.isEmpty() && awayUnavailable.isEmpty()) {
            return MerkeziFutbolModelHavuzu.MatchModelAdjustments()
        }

        data class SideImpact(val attackLoss: Double, val defenseLoss: Double, val confidencePenalty: Double)

        fun statusFactor(player: OyuncuEtkiVerisi): Double = when (player.durum) {
            OyuncuDurumTipi.SAKAT,
            OyuncuDurumTipi.CEZALI,
            OyuncuDurumTipi.KADRO_DISI -> 1.0
            OyuncuDurumTipi.SUPHELI -> 0.50
            OyuncuDurumTipi.DINLENDIRILIYOR -> 0.40
            OyuncuDurumTipi.OYNAYACAK,
            OyuncuDurumTipi.BELIRSIZ -> 0.0
        }

        fun raw(player: OyuncuEtkiVerisi) = OyuncuEtkiMotoru.hamEtkiHesapla(SporTuru.FUTBOL, player)

        fun median(values: List<Double>): Double? {
            if (values.isEmpty()) return null
            val sorted = values.filter { it.isFinite() }.sorted()
            if (sorted.isEmpty()) return null
            val mid = sorted.size / 2
            return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2.0 else sorted[mid]
        }

        fun side(unavailable: List<OyuncuEtkiVerisi>, roster: List<OyuncuEtkiVerisi>): SideImpact {
            if (unavailable.isEmpty()) return SideImpact(0.0, 0.0, 0.0)

            val missingIds = unavailable.mapNotNull { it.oyuncuId }.toSet()
            val missingNames = unavailable.map { it.oyuncuAdi.lowercase() }.toSet()
            val availableRoster = roster.filter { p ->
                (p.oyuncuId == null || p.oyuncuId !in missingIds) &&
                    p.oyuncuAdi.lowercase() !in missingNames &&
                    p.durum != OyuncuDurumTipi.BELIRSIZ &&
                    OyuncuEtkiMotoru.hamEtkiHesapla(SporTuru.FUTBOL, p).etkiSkoru > 0.0
            }

            var attackLoss = 0.0
            var defenseLoss = 0.0
            var actionable = 0

            for (missing in unavailable) {
                val factor = statusFactor(missing)
                if (factor <= 0.0) continue

                val m = raw(missing)
                val pool = availableRoster.filter { it.pozisyon == missing.pozisyon }
                    .ifEmpty { availableRoster }
                val replacementRaw = pool.map(::raw)
                val replacementAttack = median(replacementRaw.map { it.takimHucumEtkisi }) ?: 0.0
                val replacementDefense = median(replacementRaw.map { it.takimSavunmaEtkisi }) ?: 0.0

                // Only the player's excess contribution over an observed replacement is lost.
                val aLoss = max(0.0, m.takimHucumEtkisi - replacementAttack) / 100.0
                val dLoss = max(0.0, m.takimSavunmaEtkisi - replacementDefense) / 100.0
                attackLoss += aLoss * factor
                defenseLoss += dLoss * factor
                actionable++

                Log.d(
                    "OYUNCU_MODEL",
                    "OYUNCU_ETKI name=${missing.oyuncuAdi} id=${missing.oyuncuId ?: "-"} " +
                        "poz=${missing.pozisyon} puan=${"%.1f".format(m.etkiSkoru)} " +
                        "katilim=${"%.2f".format(OyuncuEtkiMotoru.katilimKatsayisi(missing))} " +
                        "replacementA=${"%.2f".format(replacementAttack)} " +
                        "replacementD=${"%.2f".format(replacementDefense)} " +
                        "lossA=${"%.4f".format(aLoss * factor)} lossD=${"%.4f".format(dLoss * factor)} durum=${missing.durum}"
                )
            }

            // One certainty penalty per actionable absence, capped at 4 percentage points.
            return SideImpact(
                attackLoss = (attackLoss * 0.09).coerceIn(0.0, 0.14),
                defenseLoss = (defenseLoss * 0.07).coerceIn(0.0, 0.12),
                confidencePenalty = (actionable * 0.004).coerceAtMost(0.04)
            )
        }

        val home = side(homeUnavailable, homeRoster)
        val away = side(awayUnavailable, awayRoster)

        return MerkeziFutbolModelHavuzu.MatchModelAdjustments(
            homeAttackLogDelta = -home.attackLoss,
            homeDefenseLogDelta = -home.defenseLoss,
            awayAttackLogDelta = -away.attackLoss,
            awayDefenseLogDelta = -away.defenseLoss,
            confidencePenalty = (home.confidencePenalty + away.confidencePenalty).coerceAtMost(0.06)
        )
    }

    /**
     * Mevcut ESPN roster kalitesini ana modele küçük, bağımsız ve kontrollü
     * bir düzeltme olarak bağlar. Ev sahibi için yalnızca ev roster kanıtı,
     * deplasman için yalnızca deplasman roster kanıtı kullanılır. Bir tarafın
     * istatistiği eksikse diğer tarafın etkisi sıfırlanmaz.
     */
    fun oyuncuKadroKalitesinden(
        homeRoster: List<OyuncuEtkiVerisi>,
        awayRoster: List<OyuncuEtkiVerisi>
    ): MerkeziFutbolModelHavuzu.MatchModelAdjustments {
        val home = OyuncuEtkiMotoru.takimOyuncuKalitesi(homeRoster)
        val away = OyuncuEtkiMotoru.takimOyuncuKalitesi(awayRoster)

        fun guvenilirlik(kanit: Int): Double =
            (kanit / 11.0).coerceIn(0.25, 1.0)

        // 50, oyuncu kalite ölçeğinin nötr merkezi/priorudur. Bu değer
        // oyuncuya kalite uydurmak için değil, yalnızca gözlenen kaliteyi
        // log-rate ölçeğine dönüştürmek için kullanılan sabit referanstır.
        fun delta(quality: Double, evidence: Int, scale: Double, cap: Double): Double {
            if (evidence <= 0 || !quality.isFinite()) return 0.0
            val reliability = guvenilirlik(evidence)
            return ((quality - 50.0) * scale * reliability).coerceIn(-cap, cap)
        }

        // Takımın kendi roster kalitesi, karşı tarafın roster verisi yok diye
        // etkisini kaybetmemeli. Savunma pozitif olduğunda rakibin lambda'sını
        // azaltacak savunma log-delta'sı üretir.
        val homeAttackDelta = delta(home.hucum, home.kanitOyuncuSayisi, 0.00110, 0.055)
        val homeDefenseDelta = delta(home.savunma, home.kanitOyuncuSayisi, 0.00070, 0.040)
        val awayAttackDelta = delta(away.hucum, away.kanitOyuncuSayisi, 0.00110, 0.055)
        val awayDefenseDelta = delta(away.savunma, away.kanitOyuncuSayisi, 0.00070, 0.040)

        Log.i(
            "OYUNCU_MODEL",
            "KADRO_KALITE home=${"%.1f".format(home.genel)}:${"%.1f".format(home.hucum)}:${"%.1f".format(home.savunma)} " +
                "away=${"%.1f".format(away.genel)}:${"%.1f".format(away.hucum)}:${"%.1f".format(away.savunma)} " +
                "kanit=${home.kanitOyuncuSayisi}/${away.kanitOyuncuSayisi} " +
                "deltaA=${"%.4f".format(homeAttackDelta)}/${"%.4f".format(awayAttackDelta)} " +
                "deltaD=${"%.4f".format(homeDefenseDelta)}/${"%.4f".format(awayDefenseDelta)}"
        )

        return MerkeziFutbolModelHavuzu.MatchModelAdjustments(
            homeAttackLogDelta = homeAttackDelta,
            homeDefenseLogDelta = homeDefenseDelta,
            awayAttackLogDelta = awayAttackDelta,
            awayDefenseLogDelta = awayDefenseDelta
        )
    }

    fun ppda(
        homePpda: Double?,
        awayPpda: Double?,
        leagueAverage: Double?,
        leagueStd: Double?
    ): MerkeziFutbolModelHavuzu.MatchModelAdjustments {
        if (homePpda == null || awayPpda == null || leagueAverage == null || leagueStd == null) {
            return MerkeziFutbolModelHavuzu.MatchModelAdjustments()
        }
        if (!homePpda.isFinite() || !awayPpda.isFinite() || !leagueAverage.isFinite() ||
            !leagueStd.isFinite() || leagueStd <= 0.0 || homePpda <= 0.0 || awayPpda <= 0.0) {
            return MerkeziFutbolModelHavuzu.MatchModelAdjustments()
        }
        fun effect(ppda: Double): Double {
            val z = ((leagueAverage - ppda) / leagueStd).coerceIn(-3.0, 3.0)
            return (z * 0.018).coerceIn(-0.045, 0.045)
        }
        return MerkeziFutbolModelHavuzu.MatchModelAdjustments(
            homePpdaEffect = effect(homePpda),
            awayPpdaEffect = effect(awayPpda)
        )
    }

    fun beklenenKadroDegisimi(
        normalHome: List<OyuncuEtkiVerisi>,
        expectedHome: List<OyuncuEtkiVerisi>,
        normalAway: List<OyuncuEtkiVerisi>,
        expectedAway: List<OyuncuEtkiVerisi>
    ): MerkeziFutbolModelHavuzu.MatchModelAdjustments {
        fun aggregate(players: List<OyuncuEtkiVerisi>): Pair<Double, Double> {
            var a = 0.0
            var d = 0.0
            for (p in players) {
                val x = OyuncuEtkiMotoru.hamEtkiHesapla(SporTuru.FUTBOL, p)
                val minuteWeight = OyuncuEtkiMotoru.katilimKatsayisi(p)
                a += x.takimHucumEtkisi / 100.0 * minuteWeight
                d += x.takimSavunmaEtkisi / 100.0 * minuteWeight
            }
            return a to d
        }
        val nh = aggregate(normalHome); val eh = aggregate(expectedHome)
        val na = aggregate(normalAway); val ea = aggregate(expectedAway)
        return MerkeziFutbolModelHavuzu.MatchModelAdjustments(
            homeAttackLogDelta = ((eh.first - nh.first) * 0.10).coerceIn(-0.15, 0.15),
            homeDefenseLogDelta = ((eh.second - nh.second) * 0.08).coerceIn(-0.12, 0.12),
            awayAttackLogDelta = ((ea.first - na.first) * 0.10).coerceIn(-0.15, 0.15),
            awayDefenseLogDelta = ((ea.second - na.second) * 0.08).coerceIn(-0.12, 0.12)
        )
    }
}
