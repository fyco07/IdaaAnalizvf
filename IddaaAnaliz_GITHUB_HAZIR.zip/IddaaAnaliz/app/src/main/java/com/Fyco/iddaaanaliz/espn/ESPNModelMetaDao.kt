@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ESPNModelMetaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun metaKaydet(meta: ESPNModelMeta)

    @Query("SELECT * FROM espn_model_meta WHERE id = 1 LIMIT 1")
    suspend fun metaGetir(): ESPNModelMeta?

    @Query("SELECT COUNT(*) FROM espn_model_meta")
    suspend fun metaVarMi(): Int

    @Query("SELECT COUNT(*) FROM espn_model_meta WHERE egitimMacSayisi > 0")
    suspend fun egitimYapilmisMi(): Int

    @Query("SELECT modelVersiyonu FROM espn_model_meta WHERE id = 1 LIMIT 1")
    suspend fun modelVersiyonunuGetir(): String?

    @Query("SELECT egitimMacSayisi FROM espn_model_meta WHERE id = 1 LIMIT 1")
    suspend fun egitimMacSayisiniGetir(): Int?

    @Query("SELECT egitimTakimSayisi FROM espn_model_meta WHERE id = 1 LIMIT 1")
    suspend fun egitimTakimSayisiniGetir(): Int?

    @Query("SELECT guncellemeZamani FROM espn_model_meta WHERE id = 1 LIMIT 1")
    suspend fun sonEgitimZamaniniGetir(): Long?

    @Query("DELETE FROM espn_model_meta")
    suspend fun metaTemizle()
}
