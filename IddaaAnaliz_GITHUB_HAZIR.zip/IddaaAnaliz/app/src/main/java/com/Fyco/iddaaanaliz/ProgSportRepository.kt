@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

object ProgSportRepository {

    private const val CACHE_SURESI_MS = 10 * 60 * 1000L

    private var futbolCache: List<ProgSportMac> = emptyList()

    private var basketbolCache: List<ProgSportMac> = emptyList()

    private var futbolCacheZamani: Long = 0L

    private var basketbolCacheZamani: Long = 0L


    fun futbolVerisiVarMi(): Boolean {
        return futbolCache.isNotEmpty()
    }


    fun basketbolVerisiVarMi(): Boolean {
        return basketbolCache.isNotEmpty()
    }


    fun futbolMacSayisi(): Int {
        return futbolCache.size
    }


    fun basketbolMacSayisi(): Int {
        return basketbolCache.size
    }


    fun futbolVerisiniKaydet(
        maclar: List<ProgSportMac>
    ) {
        futbolCache = maclar
        futbolCacheZamani = System.currentTimeMillis()
    }


    fun basketbolVerisiniKaydet(
        maclar: List<ProgSportMac>
    ) {
        basketbolCache = maclar
        basketbolCacheZamani = System.currentTimeMillis()
    }


    fun futbolCacheGecerliMi(): Boolean {
        return cacheGecerliMi(
            futbolCacheZamani
        )
    }


    fun basketbolCacheGecerliMi(): Boolean {
        return cacheGecerliMi(
            basketbolCacheZamani
        )
    }


    fun futbolEslesme(
        event: IddaaEvent
    ): ProgSportAnaliz {

        return macEsle(
            event = event,
            spor = SporTuru.FUTBOL
        )
    }


    fun basketbolEslesme(
        event: IddaaEvent
    ): ProgSportAnaliz {

        return macEsle(
            event = event,
            spor = SporTuru.BASKETBOL
        )
    }


    fun macEsle(
        event: IddaaEvent,
        spor: SporTuru
    ): ProgSportAnaliz {

        val adaylar =
            when (spor) {

                SporTuru.FUTBOL ->
                    futbolCache

                SporTuru.BASKETBOL ->
                    basketbolCache
            }

        if (adaylar.isEmpty()) {

            return ProgSportAnaliz(
                eventId = event.i,
                spor = spor,
                mac = null,
                marketOlasiliklari = emptyMap(),
                eslesmePuani = 0,
                veriVar = false
            )
        }


        val eslesme =
            adaylar
                .map { aday ->

                    val puan =
                        VeriMotoru.macEslesmePuani(
                            iddaaEv = event.hn,
                            iddaaDeplasman = event.an,
                            disEv = aday.evSahibi,
                            disDeplasman = aday.deplasman
                        )

                    ProgSportEslesme(
                        mac = aday,
                        eslesmePuani = puan
                    )
                }
                .filter {
                    it.eslesmePuani >= 70
                }
                .maxByOrNull {
                    it.eslesmePuani
                }


        if (eslesme == null) {

            return ProgSportAnaliz(
                eventId = event.i,
                spor = spor,
                mac = null,
                marketOlasiliklari = emptyMap(),
                eslesmePuani = 0,
                veriVar = false
            )
        }


        val marketler =
            marketOlasiliklariniOlustur(
                mac = eslesme.mac,
                spor = spor
            )


        return ProgSportAnaliz(
            eventId = event.i,
            spor = spor,
            mac = eslesme.mac,
            marketOlasiliklari = marketler,
            eslesmePuani = eslesme.eslesmePuani,
            veriVar = true
        )
    }


    private fun marketOlasiliklariniOlustur(
        mac: ProgSportMac,
        spor: SporTuru
    ): Map<String, Double> {

        val sonuc =
            mutableMapOf<String, Double>()


        if (spor == SporTuru.FUTBOL) {

            mac.evOlasilik?.let {

                sonuc["1"] =
                    yuzdeyeCevir(it)
            }


            mac.beraberlikOlasilik?.let {

                sonuc["X"] =
                    yuzdeyeCevir(it)
            }


            mac.deplasmanOlasilik?.let {

                sonuc["2"] =
                    yuzdeyeCevir(it)
            }


            mac.altOlasilik?.let {

                sonuc["ALT_2_5"] =
                    yuzdeyeCevir(it)
            }


            mac.ustOlasilik?.let {

                sonuc["UST_2_5"] =
                    yuzdeyeCevir(it)
            }
        }


        if (spor == SporTuru.BASKETBOL) {

            mac.evOlasilik?.let {

                sonuc["EV"] =
                    yuzdeyeCevir(it)
            }


            mac.deplasmanOlasilik?.let {

                sonuc["DEP"] =
                    yuzdeyeCevir(it)
            }


            mac.spreadEvOlasilik?.let {

                sonuc["SPREAD_EV"] =
                    yuzdeyeCevir(it)
            }


            mac.spreadDeplasmanOlasilik?.let {

                sonuc["SPREAD_DEP"] =
                    yuzdeyeCevir(it)
            }


            mac.tahminiEvSkor?.let {

                sonuc["TAHMIN_EV_SKOR"] =
                    it.toDouble()
            }


            mac.tahminiDeplasmanSkor?.let {

                sonuc["TAHMIN_DEP_SKOR"] =
                    it.toDouble()
            }
        }


        return sonuc
    }


    private fun yuzdeyeCevir(
        value: Double
    ): Double {

        val sonuc =
            if (value <= 1.0) {
                value
            } else {
                value / 100.0
            }

        return sonuc.coerceIn(
            0.0,
            1.0
        )
    }


    private fun cacheGecerliMi(
        zaman: Long
    ): Boolean {

        if (zaman <= 0L) {
            return false
        }

        val gecenSure =
            System.currentTimeMillis() - zaman

        return gecenSure < CACHE_SURESI_MS
    }


    fun cacheTemizle() {

        futbolCache = emptyList()

        basketbolCache = emptyList()

        futbolCacheZamani = 0L

        basketbolCacheZamani = 0L
    }


    fun normalizeTeamName(
        value: String
    ): String {

        var text =
            value
                .lowercase()
                .replace("ı", "i")
                .replace("ğ", "g")
                .replace("ü", "u")
                .replace("ş", "s")
                .replace("ö", "o")
                .replace("ç", "c")


        text =
            " $text "


        val replacements =
            listOf(
                " fc " to " ",
                " cf " to " ",
                " bc " to " ",
                " fk " to " ",
                " sk " to " ",
                " ac " to " "
            )


        for (replacement in replacements) {

            text =
                text.replace(
                    replacement.first,
                    replacement.second
                )
        }


        return text
            .replace(
                Regex("[^a-z0-9 ]"),
                " "
            )
            .replace(
                Regex("\\s+"),
                " "
            )
            .trim()
    }
}