@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.Fyco.iddaaanaliz.MerkeziVeriHavuzu
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * ESPN'den son 365 günlük tamamlanmış futbol maçlarını toplar ve
 * tamamlandığında Kendi Modeli'ni yeniden eğitir.
 *
 * ESPNApi.skorTahtasi / skorTahtasiGuvenli JsonObject döndürdüğü için
 * burada response.events gibi olmayan Kotlin alanlarına erişilmez.
 * Ham JSON yalnızca bu Worker içinde, kontrollü yardımcılarla parse edilir.
 */
class ESPNHistoryWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val db = com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase.getInstance(applicationContext)
        val dao = db.espnTarihselMacDao()

        val today = LocalDate.now(ZoneId.of("Europe/Istanbul"))
        val start = today.minusDays(365)
        val end = today.minusDays(1)
        val offset = inputData.getInt(KEY_OFFSET, 0).coerceIn(0, 364)
        val chunkEndOffset = (offset + CHUNK_DAYS - 1).coerceAtMost(364)

        try {
            ESPNModelDurumStore.guncelle(
                applicationContext,
                "VERI_TOPLANIYOR",
                offset,
                365,
                dao.toplamMacSayisi(),
                0,
                "ESPN tarihsel veri işleniyor: $offset/365"
            )

            for (i in offset..chunkEndOffset) {
                val date = start.plusDays(i.toLong())
                if (date.isAfter(end)) break

                val dateText = date.format(DateTimeFormatter.BASIC_ISO_DATE)

                // ESPNApi JsonObject döndürüyor; güvenli istemci kullanılıyor.
                val response = ESPNClient.skorTahtasiGuvenli(dateText)
                val records = parseEvents(response)

                if (records.isNotEmpty()) {
                    dao.kaydet(records)
                }

                val completed = dao.toplamMacSayisi()
                setProgress(
                    workDataOf(
                        "gun" to (i + 1),
                        "toplamGun" to 365,
                        "mac" to completed
                    )
                )

                ESPNModelDurumStore.guncelle(
                    applicationContext,
                    "VERI_TOPLANIYOR",
                    i + 1,
                    365,
                    completed,
                    0,
                    "ESPN günü işlendi: ${i + 1}/365 • maç=${records.size}"
                )

                Log.i(
                    TAG,
                    "TARİHSEL_GUN gun=${i + 1}/365 tarih=$dateText " +
                            "events=${eventCount(response)} futbol=${records.size} toplamDB=$completed"
                )

                delay(120)
            }

            if (chunkEndOffset >= 364) {
                val total = dao.toplamMacSayisi()
                Log.i(TAG, "TARİHSEL_TAMAMLANDI toplamMac=$total")

                if (total < MIN_TRAIN_MATCHES) {
                    ESPNModelDurumStore.guncelle(
                        applicationContext,
                        "VERI_YETERSIZ",
                        365,
                        365,
                        total,
                        0,
                        "ESPN verisi tamamlandı fakat eğitim için yeterli maç yok: $total"
                    )
                    return Result.success(workDataOf("tamamlandi" to true, "mac" to total))
                }

                ESPNModelDurumStore.guncelle(
                    applicationContext,
                    "MODEL_EGITIM_BASLIYOR",
                    365,
                    365,
                    total,
                    0,
                    "365 günlük veri tamamlandı; Kendi Modeli eğitiliyor"
                )

                ESPNKendiModelTrainer(applicationContext).egit()

                runCatching {
                    MerkeziVeriHavuzu.espnTarihselYaz()
                    MerkeziVeriHavuzu.futbolModeliniHazirla(force = true)
                }.onFailure {
                    Log.e(TAG, "MERKEZI_MODEL_SYNC_HATASI", it)
                }

                return Result.success(workDataOf("tamamlandi" to true, "mac" to total))
            }

            val next = OneTimeWorkRequestBuilder<ESPNHistoryWorker>()
                .setInputData(workDataOf(KEY_OFFSET to chunkEndOffset + 1))
                .build()

            WorkManager.getInstance(applicationContext).enqueueUniqueWork(
                WORK_NAME,
                ExistingWorkPolicy.APPEND_OR_REPLACE,
                next
            )

            Log.i(TAG, "TARİHSEL_DEVAM next=${chunkEndOffset + 1}")
            return Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "HATA offset=$offset", e)
            return if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure(
                    workDataOf("hata" to (e.message ?: "Bilinmeyen ESPN hatası"))
                )
            }
        }
    }

    /** JSON içindeki events dizisini ESPNTarihselMac listesine çevirir. */
    private fun parseEvents(response: JsonObject): List<ESPNTarihselMac> {
        val eventsElement = response.get("events")
        if (eventsElement == null || !eventsElement.isJsonArray) return emptyList()

        val records = ArrayList<ESPNTarihselMac>()
        for (element in eventsElement.asJsonArray) {
            if (!element.isJsonObject) continue
            parseHistoricalMatch(element.asJsonObject)?.let(records::add)
        }
        return records
    }

    private fun eventCount(response: JsonObject): Int {
        val eventsElement = response.get("events")
        return if (eventsElement?.isJsonArray == true) eventsElement.asJsonArray.size() else 0
    }

    /** ESPN scoreboard event JSON'unu güvenli biçimde tarihsel maç kaydına dönüştürür. */
    private fun parseHistoricalMatch(event: JsonObject): ESPNTarihselMac? {
        /*
         * ESPN scoreboard -> Room parser.
         *
         * Veri toplama aşamasında kadın/gençlik/rezerv filtreleri uygulanmaz.
         * Önce gerçek tarihi kaydı eksiksiz şekilde havuza alırız; model eğitim
         * filtresi daha sonra ayrı bir katmanda uygulanır. Böylece geniş ESPN
         * scoreboard'unda geçerli maçların yanlışlıkla 0 kayda düşmesi engellenir.
         */
        val eventId = jsonString(event, "id")?.toLongOrNull() ?: run {
            Log.w(TAG, "PARSE_NEDEN id_yok")
            return null
        }

        val eventDate = jsonString(event, "date") ?: run {
            Log.w(TAG, "PARSE_NEDEN date_yok id=$eventId")
            return null
        }

        // ESPN bazı kayıtlarda saniyesiz ISO-8601 tarih gönderir:
        // 2026-08-08T16:30Z
        // Instant.parse bu biçimde hata verdiği için önce standart Instant,
        // sonra OffsetDateTime ile fallback parse edilir.
        val millis = runCatching {
            Instant.parse(eventDate).toEpochMilli()
        }.recoverCatching {
            OffsetDateTime.parse(
                eventDate,
                DateTimeFormatter.ISO_OFFSET_DATE_TIME
            ).toInstant().toEpochMilli()
        }.getOrElse {
            Log.w(TAG, "PARSE_NEDEN date_gecersiz id=$eventId date=$eventDate")
            return null
        }

        val competitions = jsonArray(event, "competitions")?.asList().orEmpty()
        if (competitions.isEmpty()) {
            Log.w(TAG, "PARSE_NEDEN competitions_yok id=$eventId")
            return null
        }

        val competition = competitions.asSequence()
            .filter { it.isJsonObject }
            .map { it.asJsonObject }
            .mapNotNull { comp ->
                val competitors = jsonArray(comp, "competitors")?.asList().orEmpty()
                if (competitors.size >= 2) comp else null
            }
            .firstOrNull()
            ?: run {
                Log.w(TAG, "PARSE_NEDEN competitors_2den_az id=$eventId competitions=${competitions.size}")
                return null
            }

        val competitors = jsonArray(competition, "competitors")?.asList().orEmpty()
            .filter { it.isJsonObject }
        if (competitors.size < 2) {
            Log.w(TAG, "PARSE_NEDEN competitors_filtre id=$eventId size=${competitors.size}")
            return null
        }

        val homeElement = competitors.firstOrNull { side(it, "home") }
            ?: competitors.getOrNull(0)
        val awayElement = competitors.firstOrNull { side(it, "away") }
            ?: competitors.getOrNull(1)
        if (homeElement == null || awayElement == null) {
            Log.w(TAG, "PARSE_NEDEN home_away_yok id=$eventId")
            return null
        }

        val home = homeElement.asJsonObject
        val away = awayElement.asJsonObject
        val homeTeam = jsonObject(home, "team")
        val awayTeam = jsonObject(away, "team")

        fun teamName(team: JsonObject?, competitor: JsonObject): String? =
            jsonString(team, "displayName")
                ?: jsonString(team, "name")
                ?: jsonString(team, "shortDisplayName")
                ?: jsonString(team, "location")
                ?: jsonString(competitor, "displayName")
                ?: jsonString(competitor, "name")
                ?: jsonString(competitor, "shortDisplayName")

        val homeName = teamName(homeTeam, home)?.trim()
        val awayName = teamName(awayTeam, away)?.trim()

        if (homeName.isNullOrBlank() || awayName.isNullOrBlank()) {
            Log.w(TAG, "PARSE_NEDEN takim_adi_yok id=$eventId home=$homeName away=$awayName")
            return null
        }

        val homeScore = parseScoreJson(home.get("score"))
            ?: parseScoreJson(home.get("displayValue"))
        val awayScore = parseScoreJson(away.get("score"))
            ?: parseScoreJson(away.get("displayValue"))

        if (homeScore == null || awayScore == null || homeScore < 0 || awayScore < 0) {
            Log.w(TAG, "PARSE_NEDEN skor_yok id=$eventId homeScore=$homeScore awayScore=$awayScore")
            return null
        }

        val status = jsonObject(jsonObject(competition, "status"), "type")
            ?: jsonObject(jsonObject(event, "status"), "type")
        val completed = jsonBoolean(status, "completed")
        val state = jsonString(status, "state")

        val season = jsonObject(event, "season")
        val competitionLeague = jsonObject(competition, "league")
        // Kadro/team endpointleri season.slug değil gerçek ESPN league slug
        // bekler (ör. eng.1, esp.1). Önce competition.league bilgisini sakla.
        // Eski DB kayıtlarında season slug bulunabilir; V34 ayrıca runtime'da
        // bunları API slug'ına dönüştürür.
        val espnLeague = jsonString(competitionLeague, "slug")
            ?: jsonString(competitionLeague, "abbreviation")
            ?: jsonString(event, "league")?.takeIf { it.contains('.') }
        val homeTeamId = jsonString(homeTeam, "id") ?: jsonString(home, "id")
        val awayTeamId = jsonString(awayTeam, "id") ?: jsonString(away, "id")

        Log.d(TAG, "MAC_KAYIT event=$eventId $homeName $homeScore-$awayScore $awayName completed=$completed state=$state league=$espnLeague season=${jsonString(season, "slug")}")

        return ESPNTarihselMac(
            eventId = eventId,
            baslangic = millis,
            lig = espnLeague ?: jsonString(season, "slug") ?: jsonString(season, "name"),
            sezon = jsonInt(season, "year")?.toString(),
            evTakimId = homeTeamId,
            deplasmanTakimId = awayTeamId,
            evTakim = homeName,
            deplasmanTakim = awayName,
            evSkor = homeScore,
            deplasmanSkor = awayScore,
            evIlkYari = null,
            deplasmanIlkYari = null,
            tamamlandi = completed ?: (state.equals("post", true) || state.equals("final", true)),
            kayitZamani = System.currentTimeMillis()
        )
    }


    private fun side(element: JsonElement, wanted: String): Boolean {
        if (!element.isJsonObject) return false
        return jsonString(element.asJsonObject, "homeAway")
            ?.equals(wanted, ignoreCase = true) == true
    }

    private fun jsonObject(obj: JsonObject?, key: String): JsonObject? {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull) return null
        return runCatching {
            obj.get(key).takeIf { it.isJsonObject }?.asJsonObject
        }.getOrNull()
    }

    private fun jsonArray(obj: JsonObject?, key: String): com.google.gson.JsonArray? {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull) return null
        return runCatching {
            obj.get(key).takeIf { it.isJsonArray }?.asJsonArray
        }.getOrNull()
    }

    private fun jsonString(obj: JsonObject?, key: String): String? {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull) return null
        return runCatching { obj.get(key).asString.trim() }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
    }

    private fun jsonBoolean(obj: JsonObject?, key: String): Boolean? {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull) return null
        return runCatching { obj.get(key).asBoolean }.getOrNull()
    }

    private fun jsonInt(obj: JsonObject?, key: String): Int? {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull) return null
        return runCatching { obj.get(key).asInt }.getOrNull()
    }

    private fun parseScoreJson(value: JsonElement?): Int? {
        if (value == null || value.isJsonNull) return null

        if (value.isJsonPrimitive) {
            val primitive = value.asJsonPrimitive
            if (primitive.isNumber) {
                return runCatching { primitive.asNumber.toInt() }.getOrNull()
            }
            if (primitive.isString) {
                return parseScoreText(primitive.asString)
            }
        }

        if (value.isJsonObject) {
            val obj = value.asJsonObject
            listOf("displayValue", "value", "score", "display").forEach { key ->
                if (obj.has(key)) {
                    parseScoreJson(obj.get(key))?.let { return it }
                }
            }
        }

        return null
    }

    private fun parseScoreText(text: String?): Int? {
        val clean = text?.trim().orEmpty()
        if (clean.isEmpty()) return null
        clean.toIntOrNull()?.let { return it }

        var number = 0
        var found = false
        for (ch in clean) {
            if (ch in '0'..'9') {
                number = (number * 10 + (ch - '0')).coerceAtMost(100)
                found = true
            } else if (found) {
                break
            }
        }
        return if (found) number else null
    }

    companion object {
        private const val TAG = "ESPN_HISTORY"
        const val WORK_NAME = "ESPN_365_GUN_TARIHSEL_MODEL_V3"
        const val KEY_OFFSET = "offset"
        private const val CHUNK_DAYS = 7
        private const val MIN_TRAIN_MATCHES = 80
    }
}
