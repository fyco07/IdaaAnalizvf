@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ESPNModelTakimRatingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun kaydetHepsi(ratings: List<ESPNModelTakimRating>)

    @Query("SELECT * FROM espn_model_takim_rating")
    suspend fun hepsiniGetir(): List<ESPNModelTakimRating>

    @Query("DELETE FROM espn_model_takim_rating")
    suspend fun temizle()
}
