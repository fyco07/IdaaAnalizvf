@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import java.util.Locale

/**
 * Sadece kesin olarak desteklediğimiz marketleri çözer.
 * Bilinmeyen/karmaşık marketler null bırakılır; yanlış öğrenme verisi üretilmez.
 */
object MarketSonucCozucu {
    fun coz(
        marketBasligi: String,
        sov: String?,
        secim: String,
        mac: SonucMac,
        spor: SporTuru
    ): Boolean? {
        val ev = mac.evSkor ?: return null
        val dep = mac.depSkor ?: return null
        val title = norm(marketBasligi)
        val pick = norm(secim)

        if (title == "mac sonucu") {
            return when (pick) {
                "1" -> ev > dep
                "x", "0" -> ev == dep
                "2" -> dep > ev
                else -> null
            }
        }

        if (title.contains("cifte sans")) {
            return when (pick) {
                "1-x", "1 x", "1x" -> ev >= dep
                "1-2", "1 2", "12" -> ev != dep
                "x-2", "x 2", "x2" -> ev <= dep
                else -> null
            }
        }

        if (title.contains("karsilikli gol")) {
            val varMi = ev > 0 && dep > 0
            return when (pick) {
                "var" -> varMi
                "yok" -> !varMi
                else -> null
            }
        }

        if (title.contains("tek/cift") || title.contains("tek cift")) {
            val tek = (ev + dep) % 2 != 0
            return when (pick) {
                "tek" -> tek
                "cift" -> !tek
                else -> null
            }
        }

        val threshold = (sov ?: extractNumber(title))?.replace(',', '.')?.toDoubleOrNull()
        if (threshold != null && (title.contains("alt") || title.contains("ust"))) {
            val isFirstHalf = title.contains("1. yari") || title.contains("ilk yari")
            val homeScore = if (isFirstHalf) mac.evIlkYari else ev
            val awayScore = if (isFirstHalf) mac.depIlkYari else dep
            val isTeamHome = title.contains("ev sahibi")
            val isTeamAway = title.contains("deplasman")
            val value = when {
                isTeamHome -> homeScore?.toDouble() ?: return null
                isTeamAway -> awayScore?.toDouble() ?: return null
                else -> ((homeScore ?: return null) + (awayScore ?: return null)).toDouble()
            }
            return when {
                pick == "alt" -> value < threshold
                pick == "ust" -> value > threshold
                else -> null
            }
        }

        if (title.contains("1. yari") && title.contains("mac sonucu")) {
            val h = mac.evIlkYari ?: return null
            val a = mac.depIlkYari ?: return null
            return when (pick) {
                "1" -> h > a
                "x", "0" -> h == a
                "2" -> a > h
                else -> null
            }
        }

        // Basketbol ve futbol handikaplarının başlığında (1:0), (2:0), vb. olabilir.
        if (title.contains("handikap")) {
            val handicap = parseHandicap(sov, title) ?: return null
            val adjusted = ev + handicap.first to dep + handicap.second
            return when (pick) {
                "1" -> adjusted.first > adjusted.second
                "x", "0" -> adjusted.first == adjusted.second
                "2" -> adjusted.second > adjusted.first
                else -> null
            }
        }

        return null
    }

    private fun parseHandicap(sov: String?, title: String): Pair<Int, Int>? {
        val raw = sov ?: Regex("""\((-?\d+)\s*:\s*(-?\d+)\)""").find(title)?.value ?: return null
        val m = Regex("""(-?\d+)\s*:\s*(-?\d+)""").find(raw) ?: return null
        return m.groupValues[1].toIntOrNull()?.let { a ->
            m.groupValues[2].toIntOrNull()?.let { b -> a to b }
        }
    }

    private fun extractNumber(text: String): String? =
        Regex("""(?<!\d)(\d+(?:[.,]\d+)?)(?!\d)""").find(text)?.groupValues?.getOrNull(1)

    private fun norm(value: String): String = value.lowercase(Locale.forLanguageTag("tr-TR"))
        .replace('İ', 'i').replace('ı', 'i').replace('ş', 's').replace('ğ', 'g')
        .replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')
        .replace(Regex("""\s+"""), " ").trim()
}
