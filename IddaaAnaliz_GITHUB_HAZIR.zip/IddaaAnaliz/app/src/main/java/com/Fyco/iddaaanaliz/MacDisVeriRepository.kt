@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import java.util.concurrent.ConcurrentHashMap

/**
 * Maç dış verilerinin merkezi hafızası.
 *
 * Event ID mutlaka çağıran tarafından verilir. Böylece aynı isimli takımların
 * veya farklı günlerdeki maçların birbirine karışması engellenir.
 */
object MacDisVeriRepository {

    private val cache = ConcurrentHashMap<Long, MacDisVerisi>()

    fun kaydet(
        eventId: Long,
        veri: MacDisVerisi
    ) {
        cache[eventId] = veri
    }

    fun getir(eventId: Long): MacDisVerisi? =
        cache[eventId]

    fun varMi(eventId: Long): Boolean =
        cache.containsKey(eventId)

    fun tumunuGetir(): List<MacDisVerisi> =
        cache.values.toList()

    fun sil(eventId: Long) {
        cache.remove(eventId)
    }

    fun temizle() {
        cache.clear()
    }
}
