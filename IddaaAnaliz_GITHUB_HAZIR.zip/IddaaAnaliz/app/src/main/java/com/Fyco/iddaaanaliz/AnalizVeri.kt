@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

enum class SporTuru {
    FUTBOL,
    BASKETBOL
}

data class TakimVerisi(
    val id: String? = null,
    val isim: String,
    val lig: String? = null,
    val ulke: String? = null
)

data class FormVerisi(
    val sonMaclar: List<MacFormSonucu> = emptyList(),
    val galibiyet: Int = 0,
    val beraberlik: Int = 0,
    val maglubiyet: Int = 0,
    val atilan: Double = 0.0,
    val yenilen: Double = 0.0,
    val puanOrtalamasi: Double = 0.0
)

data class MacFormSonucu(
    val rakip: String,
    val skor: String,
    val evSahibi: Boolean,
    val kazanildi: Boolean,
    val beraberlik: Boolean = false,
    val atilan: Double = 0.0,
    val yenilen: Double = 0.0
)

data class H2HVerisi(
    val macSayisi: Int = 0,
    val evGalibiyet: Int = 0,
    val beraberlik: Int = 0,
    val deplasmanGalibiyet: Int = 0,
    val evAtanOrtalama: Double = 0.0,
    val evYenilenOrtalama: Double = 0.0,
    val deplasmanAtanOrtalama: Double = 0.0,
    val deplasmanYenilenOrtalama: Double = 0.0
)

data class FutbolIstatistikleri(
    val macSayisi: Int = 0,
    val gol: Double = 0.0,
    val yenilenGol: Double = 0.0,
    val xg: Double = 0.0,
    val xga: Double = 0.0,
    val sut: Double = 0.0,
    val isabetliSut: Double = 0.0,
    val topaSahipOlma: Double = 0.0,
    val korner: Double = 0.0,
    val sariKart: Double = 0.0,
    val kirmiziKart: Double = 0.0,
    val cleanSheet: Double = 0.0,
    val golAtamama: Double = 0.0
)

data class BasketbolIstatistikleri(
    val macSayisi: Int = 0,
    val attigiSayi: Double = 0.0,
    val yedigiSayi: Double = 0.0,
    val tempo: Double = 0.0,
    val fieldGoalYuzde: Double = 0.0,
    val threePointYuzde: Double = 0.0,
    val freeThrowYuzde: Double = 0.0,
    val ribaund: Double = 0.0,
    val asist: Double = 0.0,
    val topKaybi: Double = 0.0,
    val topCalma: Double = 0.0,
    val blok: Double = 0.0,
    val ilkYariSayi: Double = 0.0,
    val ilkCeyrekSayi: Double = 0.0,
    val ikinciCeyrekSayi: Double = 0.0,
    val ucuncuCeyrekSayi: Double = 0.0,
    val dorduncuCeyrekSayi: Double = 0.0
)

data class OyuncuDurumu(
    val oyuncuAdi: String,
    val durum: String,
    val oynayacak: Boolean? = null,
    val onemDerecesi: Double = 0.0
)

data class SakatlikVerisi(
    val oyuncular: List<OyuncuDurumu> = emptyList(),
    val eksikOyuncuSayisi: Int = 0,
    val onemliEksikSayisi: Int = 0,
    val takimEtkisi: Double = 0.0
)

data class KadroVerisi(
    val mevcut: Boolean = false,
    val oyuncular: List<String> = emptyList(),
    val guvenSkoru: Double = 0.0
)

data class OranHareketi(
    val secim: String,
    val acilisOrani: Double? = null,
    val mevcutOran: Double? = null,
    val kapanisOrani: Double? = null,
    val hareketYuzdesi: Double = 0.0,
    val hareketYonu: String = "SABIT"
)

data class MacBaglami(
    val lig: String? = null,
    val ligSiralamasiEv: Int? = null,
    val ligSiralamasiDeplasman: Int? = null,
    val puanFarki: Double = 0.0,
    val motivasyonSkoru: Double = 0.0,
    val fiksturYogunluguEv: Double = 0.0,
    val fiksturYogunluguDeplasman: Double = 0.0,
    val macOnemi: Double = 0.0
)

data class EvDeplasmanVerisi(
    val evSahibiFormu: Double = 0.0,
    val deplasmanFormu: Double = 0.0,
    val evSahibiGalibiyetOrani: Double = 0.0,
    val deplasmanGalibiyetOrani: Double = 0.0
)

data class MacDisVerisi(
    val spor: SporTuru,
    val evSahibi: TakimVerisi,
    val deplasman: TakimVerisi,
    val formEv: FormVerisi = FormVerisi(),
    val formDeplasman: FormVerisi = FormVerisi(),
    val h2h: H2HVerisi = H2HVerisi(),
    val futbolEv: FutbolIstatistikleri? = null,
    val futbolDeplasman: FutbolIstatistikleri? = null,
    val basketbolEv: BasketbolIstatistikleri? = null,
    val basketbolDeplasman: BasketbolIstatistikleri? = null,
    val sakatlikEv: SakatlikVerisi = SakatlikVerisi(),
    val sakatlikDeplasman: SakatlikVerisi = SakatlikVerisi(),
    val kadroEv: KadroVerisi = KadroVerisi(),
    val kadroDeplasman: KadroVerisi = KadroVerisi(),
    val oranHareketleri: List<OranHareketi> = emptyList(),
    val macBaglami: MacBaglami = MacBaglami(),
    val evDeplasman: EvDeplasmanVerisi = EvDeplasmanVerisi(),
    val veriKaynaklari: List<String> = emptyList(),
    val veriTamlikPuani: Int = 0
)

data class ModelFaktorleri(
    val modelOlasiligi: Double? = null,
    val piyasaOlasiligi: Double = 0.0,
    val edge: Double? = null,
    val ev: Double? = null,
    val formPuani: Double = 0.0,
    val evDeplasmanPuani: Double = 0.0,
    val istatistikPuani: Double = 0.0,
    val h2hPuani: Double = 0.0,
    val sakatlikPuani: Double = 0.0,
    val kadroPuani: Double = 0.0,
    val oranHareketPuani: Double = 0.0,
    val macBaglamiPuani: Double = 0.0
)

data class MarketModelSonucu(
    val marketId: Long,
    val secimNo: Int,
    val secim: String,
    val oran: Double,
    val modelOlasiligi: Double? = null,
    val piyasaOlasiligi: Double = 0.0,
    val fairOran: Double = 0.0,
    val edge: Double? = null,
    val ev: Double? = null,
    val guvenPuani: Int = 0,
    val faktorler: ModelFaktorleri? = null
)

data class MacModelSonucu(
    val eventId: Long,
    val evSahibi: String,
    val deplasman: String,
    val spor: SporTuru,
    val veriTamlikPuani: Int,
    val marketSonuclari: List<MarketModelSonucu> = emptyList(),
    val enIyiSecimler: List<MarketModelSonucu> = emptyList(),
    val modelVersiyonu: String = "2.0.0",
    val hesaplamaZamani: Long = System.currentTimeMillis()
)

object VeriTamlikHesaplayici {

    fun hesapla(veri: MacDisVerisi): Int {
        var puan = 0

        if (veri.formEv.sonMaclar.isNotEmpty()) {
            puan += 10
        }

        if (veri.formDeplasman.sonMaclar.isNotEmpty()) {
            puan += 10
        }

        if (veri.h2h.macSayisi > 0) {
            puan += 10
        }

        if (veri.spor == SporTuru.FUTBOL) {
            if (veri.futbolEv != null) {
                puan += 10
            }

            if (veri.futbolDeplasman != null) {
                puan += 10
            }
        } else {
            if (veri.basketbolEv != null) {
                puan += 10
            }

            if (veri.basketbolDeplasman != null) {
                puan += 10
            }
        }

        if (
            veri.sakatlikEv.oyuncular.isNotEmpty() ||
            veri.sakatlikDeplasman.oyuncular.isNotEmpty()
        ) {
            puan += 10
        }

        if (
            veri.kadroEv.mevcut ||
            veri.kadroDeplasman.mevcut
        ) {
            puan += 5
        }

        if (veri.oranHareketleri.isNotEmpty()) {
            puan += 5
        }

        if (
            veri.macBaglami.lig != null ||
            veri.macBaglami.macOnemi > 0.0
        ) {
            puan += 5
        }

        if (
            veri.evDeplasman.evSahibiFormu > 0.0 ||
            veri.evDeplasman.deplasmanFormu > 0.0
        ) {
            puan += 5
        }

        return puan.coerceIn(0, 100)
    }
}

object ModelVeriKontrolu {

    fun yeterliMi(veri: MacDisVerisi): Boolean {
        val tamlik = VeriTamlikHesaplayici.hesapla(veri)
        return tamlik >= 60
    }

    fun durum(veri: MacDisVerisi): String {
        val tamlik = VeriTamlikHesaplayici.hesapla(veri)

        return when {
            tamlik >= 85 -> "ÇOK İYİ"
            tamlik >= 70 -> "İYİ"
            tamlik >= 60 -> "YETERLİ"
            tamlik >= 40 -> "EKSİK"
            else -> "YETERSİZ"
        }
    }
}