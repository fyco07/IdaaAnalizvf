@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

data class OgrenmeDurumuDetay(
    val toplamTahmin: Int,
    val sonuclanan: Int,
    val kazanan: Int,
    val kaybeden: Int,
    val basariOrani: Double,
    val brier: Double,
    val ogrenmeAktif: Boolean,
    val durumMetni: String
)

object OgrenmeDurumuSaglayici {
    fun getir(): OgrenmeDurumuDetay {
        val toplam = TahminOgrenmeRepository.tumunuGetir()
        val performans = TahminOgrenmeRepository.performansOzeti()
        val aktif = OgrenmeMotoru.yeterliVeriVarMi()
        return OgrenmeDurumuDetay(
            toplamTahmin = toplam.size,
            sonuclanan = performans.cozulenTahmin,
            kazanan = performans.kazanan,
            kaybeden = performans.kaybeden,
            basariOrani = performans.basariOrani,
            brier = performans.finalBrier,
            ogrenmeAktif = aktif,
            durumMetni = OgrenmeMotoru.ogrenmeDurumu()
        )
    }
}
