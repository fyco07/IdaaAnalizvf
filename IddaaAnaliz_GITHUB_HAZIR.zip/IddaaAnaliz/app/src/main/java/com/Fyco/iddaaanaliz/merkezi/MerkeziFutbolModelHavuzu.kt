@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import android.util.Log
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * MERKEZİ FUTBOL MODELİ
 *
 * Kaynak zinciri tek yönlüdür:
 * İDDAA / ESPN -> Merkezi Veri Havuzu -> geçmiş sonuçlar -> takım ratingi
 * -> form -> rakip gücü -> beklenen gol -> olasılık.
 *
 * Bu sınıf canlı analiz sırasında hiçbir dış kaynağa gitmez ve ESPN'in ayrı
 * rating DB'sini kullanmaz. Bütün takım gücü merkezi_match + merkezi_result
 * tablolarından çıkarılır.
 */
object MerkeziFutbolModelHavuzu {
    data class TakimModel(
        val teamId: String,
        val teamName: String,
        val macSayisi: Int,
        val homeMatches: Int,
        val awayMatches: Int,
        /** Global latent team strength. The displayed 0-100 rating should be derived from this. */
        val elo: Double,
        /** General attack/defence latent log-strength. Positive attack and defence mean stronger. */
        val attackLog: Double,
        val defenseLog: Double,
        /** Home/away specific latent strength; blended with the general value for stability. */
        val homeAttackLog: Double,
        val homeDefenseLog: Double,
        val awayAttackLog: Double,
        val awayDefenseLog: Double,
        val form5: Double,
        val form10: Double,
        val form20: Double,
        val weightedForm: Double,
        val trend: Double,
        val goalDiff10: Double,
        val rakipGucu: Double,
        /** Learned league scoring environment / context, not a manually assigned tier. */
        val leagueStrength: Double = ELO_BASE,
        /** Data/model reliability score, independent from predicted probability and market odds. */
        val modelQuality: Int = 0,
        /** Average absolute Elo movement from recent matches, used only as a stability signal. */
        val eloVolatility: Double = 0.0,
        /** Display-only 0-100 team strength derived from latent model components. */
        val takimPuani: Int = 50
    )

    data class Snapshot(
        val createdAt: Long,
        val historyMatches: Int,
        val leagueHomeGoals: Double,
        val leagueAwayGoals: Double,
        val teams: Map<String, TakimModel>,
        val dixonColesRho: Double = DEFAULT_DIXON_COLES_RHO,
        /** Learned probability temperature from settled historical predictions. */
        val calibrationTemperature: Double = DEFAULT_CALIBRATION_TEMPERATURE,
        val nameIndex: Map<String, TakimModel> = emptyMap()
    ) {
        val ready: Boolean get() = historyMatches >= MIN_HISTORY && teams.isNotEmpty()
    }

    data class MatchModelAdjustments(
        val homeAttackLogDelta: Double = 0.0,
        val homeDefenseLogDelta: Double = 0.0,
        val awayAttackLogDelta: Double = 0.0,
        val awayDefenseLogDelta: Double = 0.0,
        /** League-normalized pressing effect. Lower PPDA is generally more aggressive, when supplied. */
        val homePpdaEffect: Double = 0.0,
        val awayPpdaEffect: Double = 0.0,
        /** Safety cap on any combined match-day squad adjustment. */
        val confidencePenalty: Double = 0.0
    )

    private data class MatchEval(
        val row: MerkeziHistoryRow,
        val homeEloBefore: Double,
        val awayEloBefore: Double,
        val homeEloMove: Double,
        val awayEloMove: Double
    )

    private val mutex = Mutex()
    @Volatile private var snapshot: Snapshot? = null

    suspend fun rebuild(dao: MerkeziDao): Snapshot = mutex.withLock {
        val history = dao.completedFootballHistory(
            beforeTs = System.currentTimeMillis() + 60_000L,
            limit = MAX_HISTORY
        )

        val calibrationTemperature = dao.recentFootballCalibrationTemperature()
        val built = build(history, calibrationTemperature)
        val previous = snapshot

        // Kritik kural: hazır bir snapshot varken geçici/eksik bir rebuild
        // onu asla ezemez. Tarihsel worker DB'yi doldururken aynı anda model
        // hazırlanırsa, analiz eski ama tutarlı hazır snapshot ile devam eder.
        if (built.ready || previous == null) {
            snapshot = built
        } else {
            Log.w(
                TAG,
                "MERKEZI_MODEL_SNAPSHOT_KORUNDU builtReady=false " +
                    "builtHistory=${built.historyMatches} builtTeams=${built.teams.size} " +
                    "previousHistory=${previous.historyMatches} previousTeams=${previous.teams.size}"
            )
        }

        val published = snapshot ?: built
        Log.i(
            TAG,
            "MERKEZI_MODEL_HAZIR history=${published.historyMatches} " +
                "takim=${published.teams.size} evOrt=${"%.3f".format(published.leagueHomeGoals)} " +
                "depOrt=${"%.3f".format(published.leagueAwayGoals)} " +
                "publishedReady=${published.ready}"
        )
        published
    }

    fun current(): Snapshot? = snapshot

    suspend fun ensureCurrent(dao: MerkeziDao, force: Boolean = false): Snapshot = mutex.withLock {
        val existing = snapshot
        if (!force && existing?.ready == true) {
            val dbCount = dao.footballResultCount()
            val expectedHistory = dbCount.coerceAtMost(MAX_HISTORY)
            if (dbCount >= 0 && expectedHistory == existing.historyMatches) {
                return@withLock existing
            }
        }
        val history = dao.completedFootballHistory(
            beforeTs = System.currentTimeMillis() + 60_000L,
            limit = MAX_HISTORY
        )
        val calibrationTemperature = dao.recentFootballCalibrationTemperature()
        val built = build(history, calibrationTemperature)
        val previous = snapshot
        if (built.ready || previous == null) {
            snapshot = built
        } else {
            Log.w(TAG, "MERKEZI_MODEL_SMART_REBUILD_KORUNDU")
        }
        snapshot ?: built
    }

    fun clear() {
        snapshot = null
    }

    fun ensureReady(): Snapshot? {
        return snapshot?.takeIf { it.ready }
    }

    fun takim(teamId: String): TakimModel? = snapshot?.teams?.get(teamId)

    /**
     * Önce tam normalize anahtar aranır. Bulunamazsa yalnızca build() sırasında
     * oluşturulan, tekil olduğu kanıtlanmış deterministic alias aranır.
     * Fuzzy/token benzerlik ve skor tabanlı eşleştirme yoktur.
     */
    fun takimByName(teamName: String): TakimModel? {
        val s = snapshot ?: return null
        val exactKey = "FUTBOL:team:${normalize(teamName)}"
        return s.teams[exactKey] ?: nameAliases(teamName).asSequence()
            .mapNotNull { s.nameIndex[it] }
            .firstOrNull()
    }

    data class TahminTakimCozumu(
        val model: TakimModel,
        val tarihsel: Boolean
    )

    /**
     * Canlı tahmin için takım çözümlemesi.
     * Tarihsel kayıt yoksa başka bir takıma eşleştirme yapılmaz; yalnızca nötr
     * prior üretilir. Nötr prior güçlü seçim üretmek için yeterli veri sayılmaz.
     */
    fun takimTahminIcin(teamName: String): TahminTakimCozumu? {
        if (teamName.isBlank()) return null
        val historical = takimByName(teamName)
        if (historical != null) return TahminTakimCozumu(historical, true)
        return TahminTakimCozumu(neutralPredictionTeam(teamName), false)
    }

    /** Tarihsel takım ID'leriyle çalışan mevcut güvenli lambda yolu. */
    fun lambdalar(
        homeTeamId: String,
        awayTeamId: String,
        adjustments: MatchModelAdjustments = MatchModelAdjustments()
    ): Pair<Double, Double>? {
        val s = snapshot ?: return null
        val home = s.teams[homeTeamId] ?: return null
        val away = s.teams[awayTeamId] ?: return null
        if (minOf(home.macSayisi, away.macSayisi) < MIN_TEAM_MATCHES) return null
        return lambdalarFromModels(s, home, away, adjustments)
    }

    /**
     * Canlı maç adıyla lambda üretir. Tarihsel bir takım bulunamazsa yalnızca
     * o takım için nötr prior kullanılır; yanlış takım verisi kesinlikle çekilmez.
     */
    fun lambdalarForPrediction(
        homeTeamName: String,
        awayTeamName: String,
        adjustments: MatchModelAdjustments = MatchModelAdjustments()
    ): Pair<Double, Double>? {
        val home = takimTahminIcin(homeTeamName)?.model ?: return null
        val away = takimTahminIcin(awayTeamName)?.model ?: return null
        val s = snapshot ?: Snapshot(
            createdAt = System.currentTimeMillis(),
            historyMatches = 0,
            leagueHomeGoals = DEFAULT_HOME_GOALS,
            leagueAwayGoals = DEFAULT_AWAY_GOALS,
            teams = emptyMap()
        )
        return lambdalarFromModels(s, home, away, adjustments)
    }

    private fun lambdalarFromModels(
        s: Snapshot,
        home: TakimModel,
        away: TakimModel,
        adjustments: MatchModelAdjustments
    ): Pair<Double, Double> {
        // General + venue-specific strengths. The venue split receives the larger
        // weight, but the general estimate prevents small samples from exploding.
        val homeAttack = blendVenue(home.homeAttackLog, home.attackLog).coerceIn(-0.70, 0.70) + adjustments.homeAttackLogDelta
        val homeDefense = blendVenue(home.homeDefenseLog, home.defenseLog).coerceIn(-0.70, 0.70) + adjustments.homeDefenseLogDelta
        val awayAttack = blendVenue(away.awayAttackLog, away.attackLog).coerceIn(-0.70, 0.70) + adjustments.awayAttackLogDelta
        val awayDefense = blendVenue(away.awayDefenseLog, away.defenseLog).coerceIn(-0.70, 0.70) + adjustments.awayDefenseLogDelta

        val homeForm = formEffect(home)
        val awayForm = formEffect(away)
        val ratingGap = (home.elo - away.elo) / 400.0
        val ratingEffectHome = (ratingGap * 0.055).coerceIn(-0.10, 0.10)
        val ratingEffectAway = (-ratingGap * 0.055).coerceIn(-0.10, 0.10)
        val opponentHome = opponentEffect(home.rakipGucu)
        val opponentAway = opponentEffect(away.rakipGucu)
        val leagueHomeEnvironment = ln(s.leagueHomeGoals.coerceAtLeast(0.55))
        val leagueAwayEnvironment = ln(s.leagueAwayGoals.coerceAtLeast(0.35))
        val leagueContextHome = ((home.leagueStrength - ELO_BASE) / 9000.0).coerceIn(-0.035, 0.035)
        val leagueContextAway = ((away.leagueStrength - ELO_BASE) / 9000.0).coerceIn(-0.035, 0.035)

        val homeLogLambda = leagueHomeEnvironment +
            HOME_ADVANTAGE_LOG +
            homeAttack * 0.58 -
            awayDefense * 0.42 +
            homeForm +
            ratingEffectHome +
            leagueContextHome +
            opponentHome +
            adjustments.homePpdaEffect

        val awayLogLambda = leagueAwayEnvironment +
            awayAttack * 0.58 -
            homeDefense * 0.42 +
            awayForm +
            ratingEffectAway +
            leagueContextAway +
            opponentAway +
            adjustments.awayPpdaEffect

        val confidencePenalty = adjustments.confidencePenalty.coerceIn(0.0, 0.20)
        val homeLambda = exp(homeLogLambda - confidencePenalty).coerceIn(0.15, 3.60)
        val awayLambda = exp(awayLogLambda - confidencePenalty).coerceIn(0.10, 3.20)

        Log.d(
            TAG,
            "MERKEZI_LAMBDA ev=${home.teamName} dep=${away.teamName} " +
                "elo=${"%.0f".format(home.elo)}/${"%.0f".format(away.elo)} " +
                "attack=${"%.2f".format(homeAttack)}/${"%.2f".format(awayAttack)} " +
                "def=${"%.2f".format(homeDefense)}/${"%.2f".format(awayDefense)} " +
                "form=${"%.2f".format(home.weightedForm)}/${"%.2f".format(away.weightedForm)} " +
                "trend=${"%.2f".format(home.trend)}/${"%.2f".format(away.trend)} " +
                "rakip=${"%.0f".format(home.rakipGucu)}/${"%.0f".format(away.rakipGucu)} " +
                "ppda=${"%.3f".format(adjustments.homePpdaEffect)}/${"%.3f".format(adjustments.awayPpdaEffect)} " +
                "squad=${"%.3f".format(adjustments.homeAttackLogDelta)}/${"%.3f".format(adjustments.awayAttackLogDelta)} " +
                "sample=${home.macSayisi}/${away.macSayisi} " +
                "lambda=${"%.3f".format(homeLambda)}/${"%.3f".format(awayLambda)}"
        )
        return homeLambda to awayLambda
    }

    private fun neutralPredictionTeam(teamName: String): TakimModel =
        TakimModel(
            teamId = "FUTBOL:neutral:${normalize(teamName)}",
            teamName = teamName,
            macSayisi = 0,
            homeMatches = 0,
            awayMatches = 0,
            elo = ELO_BASE,
            attackLog = 0.0,
            defenseLog = 0.0,
            homeAttackLog = 0.0,
            homeDefenseLog = 0.0,
            awayAttackLog = 0.0,
            awayDefenseLog = 0.0,
            form5 = 0.50,
            form10 = 0.50,
            form20 = 0.50,
            weightedForm = 0.50,
            trend = 0.0,
            goalDiff10 = 0.0,
            rakipGucu = ELO_BASE,
            leagueStrength = ELO_BASE,
            modelQuality = 0,
            eloVolatility = 0.0,
            takimPuani = 50
        )

    fun calibrationTemperature(): Double =
        snapshot?.calibrationTemperature?.coerceIn(0.60, 1.80) ?: DEFAULT_CALIBRATION_TEMPERATURE

    fun dixonColesRho(): Double =
        snapshot?.dixonColesRho?.coerceIn(-0.20, 0.20) ?: DEFAULT_DIXON_COLES_RHO

    /** Update only calibration state after new settled predictions are available. */
    suspend fun refreshCalibration(dao: MerkeziDao): Snapshot? = mutex.withLock {
        val current = snapshot ?: return@withLock null
        val temperature = dao.recentFootballCalibrationTemperature()
            ?: current.calibrationTemperature
        snapshot = current.copy(
            calibrationTemperature = temperature.coerceIn(0.60, 1.80),
            createdAt = System.currentTimeMillis()
        )
        snapshot
    }

    private fun blendVenue(venue: Double, general: Double): Double =
        (venue * 0.62 + general * 0.38)

    private fun formEffect(t: TakimModel): Double {
        val points = ((t.weightedForm - 0.50) * 0.18).coerceIn(-0.11, 0.11)
        val goals = (t.goalDiff10 / 2.4).coerceIn(-0.12, 0.12)
        val trend = (t.trend * 0.04).coerceIn(-0.04, 0.04)
        return (points + goals + trend).coerceIn(-0.20, 0.20)
    }

    private fun opponentEffect(elo: Double): Double {
        return (((elo - ELO_BASE) / 400.0) * 0.025).coerceIn(-0.045, 0.045)
    }

    private fun build(rows: List<MerkeziHistoryRow>, calibrationTemperature: Double? = null): Snapshot {
        if (rows.isEmpty()) {
            return Snapshot(System.currentTimeMillis(), 0, DEFAULT_HOME_GOALS, DEFAULT_AWAY_GOALS, emptyMap())
        }

        val totalHome = rows.sumOf { it.rHomeScore }
        val totalAway = rows.sumOf { it.rAwayScore }
        val homeAvg = (totalHome / rows.size).coerceIn(0.70, 2.80)
        val awayAvg = (totalAway / rows.size).coerceIn(0.50, 2.40)
        // General attack/defence uses one neutral global goal environment.
        // Venue-specific terms below continue to use homeAvg/awayAvg.
        val overallAvgGoals = ((homeAvg + awayAvg) / 2.0).coerceIn(0.60, 2.60)

        // Çapraz kaynaklarda aynı takım için farklı numeric/string ID'ler
        // gelebilir. Modelin kimlik uzayı bunlardan etkilenmemeli; burada
        // takım adından üretilen tek ve deterministik canonical key kullanılır.
        fun canonicalTeamId(name: String): String = "FUTBOL:team:${normalize(name)}"

        val elo = mutableMapOf<String, Double>()
        val evals = ArrayList<MatchEval>(rows.size)
        rows.sortedBy { it.rCompletedAt }.forEach { original ->
            val row = original.copy(
                homeTeamId = canonicalTeamId(original.homeTeamName),
                awayTeamId = canonicalTeamId(original.awayTeamName)
            )
            val h = elo.getOrDefault(row.homeTeamId, ELO_BASE)
            val a = elo.getOrDefault(row.awayTeamId, ELO_BASE)
            val expectedHome = 1.0 / (1.0 + 10.0.pow(-(h + HOME_ELO_ADVANTAGE - a) / 400.0))
            val expectedAway = 1.0 - expectedHome
            val actualHome = when {
                row.rHomeScore > row.rAwayScore -> 1.0
                row.rHomeScore == row.rAwayScore -> 0.5
                else -> 0.0
            }
            val actualAway = 1.0 - actualHome
            val goalDiff = abs(row.rHomeScore - row.rAwayScore).coerceAtMost(4.0)
            val goalMultiplier = (1.0 + 0.12 * goalDiff).coerceIn(1.0, 1.48)
            val k = ELO_K * goalMultiplier
            val homeMove = k * abs(actualHome - expectedHome)
            val awayMove = k * abs(actualAway - expectedAway)
            evals += MatchEval(row, h, a, homeMove, awayMove)

            elo[row.homeTeamId] = h + k * (actualHome - expectedHome)
            elo[row.awayTeamId] = a + k * (actualAway - expectedAway)
        }

        data class Acc(
            var name: String = "",
            var games: Int = 0,
            var homeGames: Int = 0,
            var awayGames: Int = 0,
            var attackNum: Double = 0.0,
            var attackDen: Double = 0.0,
            var defenseNum: Double = 0.0,
            var defenseDen: Double = 0.0,
            var homeAttackNum: Double = 0.0,
            var homeAttackDen: Double = 0.0,
            var homeDefenseNum: Double = 0.0,
            var homeDefenseDen: Double = 0.0,
            var awayAttackNum: Double = 0.0,
            var awayAttackDen: Double = 0.0,
            var awayDefenseNum: Double = 0.0,
            var awayDefenseDen: Double = 0.0,
            var eloMoveSum: Double = 0.0,
            var eloMoveCount: Int = 0,
            val results: MutableList<ResultPoint> = mutableListOf(),
            var opponentEloSum: Double = 0.0,
            var opponentGames: Int = 0
        )
        val acc = mutableMapOf<String, Acc>()

        fun addTeam(id: String, name: String): Acc = acc.getOrPut(id) { Acc(name = name) }
        val now = System.currentTimeMillis()
        fun timeWeight(ts: Long): Double {
            val ageDays = ((now - ts).coerceAtLeast(0L) / 86_400_000.0)
            return exp(-ageDays / HALF_LIFE_DAYS)
        }
        fun opponentFactor(eloValue: Double): Double = (1.0 + ((eloValue - ELO_BASE) / 600.0) * 0.28).coerceIn(0.72, 1.28)

        evals.forEach { e ->
            val r = e.row
            val w = timeWeight(r.rCompletedAt)
            val afHome = opponentFactor(e.awayEloBefore)
            val afAway = opponentFactor(e.homeEloBefore)
            val ah = addTeam(r.homeTeamId, r.homeTeamName)
            val aa = addTeam(r.awayTeamId, r.awayTeamName)

            ah.games++
            ah.homeGames++
            ah.attackNum += r.rHomeScore * w * afHome
            ah.attackDen += w
            ah.defenseNum += r.rAwayScore * w * afHome
            ah.defenseDen += w
            ah.homeAttackNum += r.rHomeScore * w * afHome
            ah.homeAttackDen += w
            ah.homeDefenseNum += r.rAwayScore * w * afHome
            ah.homeDefenseDen += w
            ah.eloMoveSum += e.homeEloMove
            ah.eloMoveCount++
            ah.opponentEloSum += e.awayEloBefore
            ah.opponentGames++
            ah.results += ResultPoint(r.rHomeScore, r.rAwayScore, true, r.rCompletedAt)

            aa.games++
            aa.awayGames++
            aa.attackNum += r.rAwayScore * w * afAway
            aa.attackDen += w
            aa.defenseNum += r.rHomeScore * w * afAway
            aa.defenseDen += w
            aa.awayAttackNum += r.rAwayScore * w * afAway
            aa.awayAttackDen += w
            aa.awayDefenseNum += r.rHomeScore * w * afAway
            aa.awayDefenseDen += w
            aa.eloMoveSum += e.awayEloMove
            aa.eloMoveCount++
            aa.opponentEloSum += e.homeEloBefore
            aa.opponentGames++
            aa.results += ResultPoint(r.rAwayScore, r.rHomeScore, false, r.rCompletedAt)
        }

        val teamModels: Map<String, TakimModel> = acc.map { (id, a) ->
            val scored = (a.attackNum / a.attackDen.coerceAtLeast(0.001)).coerceIn(0.25, 3.50)
            val conceded = (a.defenseNum / a.defenseDen.coerceAtLeast(0.001)).coerceIn(0.20, 3.50)
            val rawAttack = ln((scored / overallAvgGoals).coerceIn(0.45, 2.20))
            val rawDefense = ln((overallAvgGoals / conceded).coerceIn(0.45, 2.20))
            val shrink = a.games.toDouble() / (a.games + SHRINK_MATCHES).toDouble()
            val attack = rawAttack * shrink
            val defense = rawDefense * shrink
            val rawHomeAttack = ln(((a.homeAttackNum / a.homeAttackDen.coerceAtLeast(0.001)) / homeAvg.coerceAtLeast(0.25)).coerceIn(0.45, 2.20))
            val rawHomeDefense = ln((awayAvg.coerceAtLeast(0.20) / (a.homeDefenseNum / a.homeDefenseDen.coerceAtLeast(0.001))).coerceIn(0.45, 2.20))
            val rawAwayAttack = ln(((a.awayAttackNum / a.awayAttackDen.coerceAtLeast(0.001)) / awayAvg.coerceAtLeast(0.20)).coerceIn(0.45, 2.20))
            val rawAwayDefense = ln((homeAvg.coerceAtLeast(0.25) / (a.awayDefenseNum / a.awayDefenseDen.coerceAtLeast(0.001))).coerceIn(0.45, 2.20))
            val homeAttack = rawHomeAttack * shrink
            val homeDefense = rawHomeDefense * shrink
            val awayAttack = rawAwayAttack * shrink
            val awayDefense = rawAwayDefense * shrink
            val ordered = a.results.sortedByDescending { it.ts }
            val form5 = formRate(ordered.take(5))
            val form10 = formRate(ordered.take(10))
            val form20 = formRate(ordered.take(20))
            val weightedForm = weightedFormRate(ordered.take(20))
            val trend = trendRate(ordered)
            val gd10 = weightedAverageGoalDiff(ordered.take(10))
            val opponent = (a.opponentEloSum / a.opponentGames.coerceAtLeast(1)).coerceIn(1200.0, 1800.0)
            val finalElo = elo[id] ?: ELO_BASE
            val volatility = (a.eloMoveSum / a.eloMoveCount.coerceAtLeast(1)).coerceIn(0.0, 80.0)
            val sampleQuality = (100.0 * (1.0 - exp(-a.games / 35.0))).coerceIn(0.0, 100.0)
            val stabilityQuality = (100.0 - volatility * 0.75).coerceIn(25.0, 100.0)
            val modelQuality = (sampleQuality * 0.70 + stabilityQuality * 0.30).roundToInt().coerceIn(0, 100)

            id to TakimModel(
                teamId = id,
                teamName = a.name,
                macSayisi = a.games,
                homeMatches = a.homeGames,
                awayMatches = a.awayGames,
                elo = finalElo,
                attackLog = attack,
                defenseLog = defense,
                homeAttackLog = homeAttack,
                homeDefenseLog = homeDefense,
                awayAttackLog = awayAttack,
                awayDefenseLog = awayDefense,
                form5 = form5,
                form10 = form10,
                form20 = form20,
                weightedForm = weightedForm,
                trend = trend,
                goalDiff10 = gd10,
                rakipGucu = opponent,
                leagueStrength = ELO_BASE,
                modelQuality = modelQuality,
                eloVolatility = volatility
            )
        }.toMap()

        // Lig seviyesi sabit/elle atanmaz. Aynı tarihsel havuzdaki liglerin
        // gözlenen gol üretim ortamını küresel ortalamaya göre ölçüyoruz.
        // Bu düzeltme bilinçli olarak küçüktür; tek başına takım ratinginin
        // yerini almaz.
        val globalGoalEnvironment = ((totalHome + totalAway) / (rows.size * 2.0)).coerceAtLeast(0.35)
        data class LeagueAcc(var goals: Double = 0.0, var matches: Int = 0)
        val leagueAcc = mutableMapOf<String, LeagueAcc>()
        val teamLeagueCounts = mutableMapOf<String, MutableMap<String, Int>>()
        rows.forEach { r ->
            val league = normalize(r.leagueName ?: "Bilinmeyen")
            val la = leagueAcc.getOrPut(league) { LeagueAcc() }
            la.goals += r.rHomeScore + r.rAwayScore
            la.matches++
            val homeId = "FUTBOL:team:${normalize(r.homeTeamName)}"
            val awayId = "FUTBOL:team:${normalize(r.awayTeamName)}"
            teamLeagueCounts.getOrPut(homeId) { mutableMapOf() }[league] =
                (teamLeagueCounts.getOrPut(homeId) { mutableMapOf() }[league] ?: 0) + 1
            teamLeagueCounts.getOrPut(awayId) { mutableMapOf() }[league] =
                (teamLeagueCounts.getOrPut(awayId) { mutableMapOf() }[league] ?: 0) + 1
        }
        val leagueEnv = leagueAcc.mapValues { (_, a) ->
            (a.goals / (a.matches.coerceAtLeast(1) * 2.0)).coerceAtLeast(0.20)
        }
        val leagueStrengthByTeam = mutableMapOf<String, Double>()
        teamModels.values.forEach { team ->
            val leagues = teamLeagueCounts[team.teamId].orEmpty()
            var weightedSum = 0.0
            var weight = 0.0
            leagues.forEach { (league, games) ->
                val env = leagueEnv[league] ?: globalGoalEnvironment
                weightedSum += env * games
                weight += games
            }
            val env = if (weight > 0.0) weightedSum / weight else globalGoalEnvironment
            val adj = (ln((env / globalGoalEnvironment).coerceIn(0.70, 1.30)) * 180.0).coerceIn(-90.0, 90.0)
            leagueStrengthByTeam[team.teamId] = ELO_BASE + adj
        }

        val adjustedTeamModels = teamModels.mapValues { (id, team) ->
            team.copy(leagueStrength = leagueStrengthByTeam[id] ?: ELO_BASE)
        }

        // UI puanı, latent modelin yerine geçen ayrı bir rating değildir.
        // ELO + hücum + savunma + form/trend bileşenlerinden türetilen,
        // yalnızca insan tarafından okunabilir 0-100 gösterimidir.
        val latentForDisplay = adjustedTeamModels.values.associateWith { team ->
            team.elo +
                120.0 * team.attackLog +
                100.0 * team.defenseLog +
                40.0 * (team.weightedForm - 0.50) +
                20.0 * team.trend
        }
        val displayMean = latentForDisplay.values.let { values ->
            if (values.isEmpty()) 0.0 else values.average()
        }
        val displayVariance = latentForDisplay.values
            .map { value -> (value - displayMean) * (value - displayMean) }
            .let { values -> if (values.isEmpty()) 0.0 else values.average() }
        val displayStd = kotlin.math.sqrt(displayVariance).coerceAtLeast(90.0)

        val displayRatedTeamModels = adjustedTeamModels.mapValues { (_, team) ->
            val latent = latentForDisplay[team] ?: ELO_BASE
            val z = (latent - displayMean) / (displayStd * 0.95)
            val rating = (100.0 / (1.0 + kotlin.math.exp(-z)))
                .roundToInt()
                .coerceIn(1, 99)
            team.copy(takimPuani = rating)
        }

        // Dixon-Coles rho is learned from the observed low-score frequency
        // rather than being permanently hard-coded. A conservative bounded grid
        // prevents one tiny league/sample from creating an extreme correction.
        val rho = estimateDixonColesRho(rows, homeAvg, awayAvg)

        // Deterministic, collision-safe aliases.
        // Example: O'Higgins <-> O Higgins, FC Barcelona <-> Barcelona.
        // If two distinct teams would share an alias, that alias is NOT published.
        val aliasOwners = mutableMapOf<String, MutableList<TakimModel>>()
        adjustedTeamModels.values.forEach { team ->
            nameAliases(team.teamName).forEach { alias ->
                aliasOwners.getOrPut(alias) { mutableListOf() }.add(team)
            }
        }
        val uniqueNameIndex = aliasOwners.mapNotNull { (alias, owners) ->
            val distinct = owners.distinctBy { it.teamId }
            if (distinct.size == 1) alias to distinct.first() else null
        }.toMap()

        return Snapshot(
            createdAt = System.currentTimeMillis(),
            historyMatches = rows.size,
            leagueHomeGoals = homeAvg,
            leagueAwayGoals = awayAvg,
            teams = displayRatedTeamModels,
            dixonColesRho = rho,
            calibrationTemperature = calibrationTemperature?.coerceIn(0.60, 1.80) ?: DEFAULT_CALIBRATION_TEMPERATURE,
            nameIndex = uniqueNameIndex
        )
    }

    private fun estimateDixonColesRho(rows: List<MerkeziHistoryRow>, homeLambda: Double, awayLambda: Double): Double {
        if (rows.size < 100) return DEFAULT_DIXON_COLES_RHO
        var bestRho = DEFAULT_DIXON_COLES_RHO
        var bestNll = Double.POSITIVE_INFINITY
        for (i in -20..20) {
            val rho = i / 100.0
            var nll = 0.0
            var count = 0
            rows.takeLast(minOf(5000, rows.size)).forEach { r ->
                val h = r.rHomeScore.toInt().coerceIn(0, 10)
                val a = r.rAwayScore.toInt().coerceIn(0, 10)
                val ph = poissonProbability(homeLambda.coerceAtLeast(0.2), h)
                val pa = poissonProbability(awayLambda.coerceAtLeast(0.2), a)
                val correction = when {
                    h == 0 && a == 0 -> 1.0 - homeLambda * awayLambda * rho
                    h == 0 && a == 1 -> 1.0 + homeLambda * rho
                    h == 1 && a == 0 -> 1.0 + awayLambda * rho
                    h == 1 && a == 1 -> 1.0 - rho
                    else -> 1.0
                }.coerceAtLeast(0.001)
                val p = (ph * pa * correction).coerceAtLeast(1e-12)
                nll -= ln(p)
                count++
            }
            if (count > 0 && nll < bestNll) {
                bestNll = nll
                bestRho = rho
            }
        }
        // Stabilize the estimate toward the conventional baseline so that a
        // noisy league/sample cannot force an extreme Dixon-Coles correction.
        val shrunk = bestRho * 0.75 + DEFAULT_DIXON_COLES_RHO * 0.25
        return shrunk.coerceIn(-0.15, 0.05)
    }

    private fun poissonProbability(lambda: Double, k: Int): Double {
        var p = exp(-lambda)
        for (i in 1..k) p *= lambda / i.toDouble()
        return p
    }

    private data class ResultPoint(val gf: Double, val ga: Double, val home: Boolean, val ts: Long)

    private fun formRate(items: List<ResultPoint>): Double {
        if (items.isEmpty()) return 0.50
        var points = 0.0
        items.forEach { r ->
            points += when {
                r.gf > r.ga -> 1.0
                r.gf == r.ga -> 0.5
                else -> 0.0
            }
        }
        return (points / items.size).coerceIn(0.0, 1.0)
    }

    private fun weightedFormRate(items: List<ResultPoint>): Double {
        if (items.isEmpty()) return 0.50
        var num = 0.0
        var den = 0.0
        items.sortedByDescending { it.ts }.forEachIndexed { index, r ->
            val w = 2.0.pow(-index.toDouble() / RECENCY_HALF_LIFE_MATCHES)
            val points = when {
                r.gf > r.ga -> 1.0
                r.gf == r.ga -> 0.5
                else -> 0.0
            }
            num += points * w
            den += w
        }
        return (num / den.coerceAtLeast(1e-9)).coerceIn(0.0, 1.0)
    }

    private fun weightedAverageGoalDiff(items: List<ResultPoint>): Double {
        if (items.isEmpty()) return 0.0
        var num = 0.0
        var den = 0.0
        items.sortedByDescending { it.ts }.forEachIndexed { index, r ->
            val w = 2.0.pow(-index.toDouble() / RECENCY_HALF_LIFE_MATCHES)
            num += (r.gf - r.ga) * w
            den += w
        }
        return (num / den.coerceAtLeast(1e-9)).coerceIn(-3.0, 3.0)
    }

    private fun trendRate(items: List<ResultPoint>): Double {
        if (items.size < 10) return 0.0
        val ordered = items.sortedByDescending { it.ts }
        val recent = weightedFormRate(ordered.take(5))
        val prior = weightedFormRate(ordered.drop(5).take(10))
        return (recent - prior).coerceIn(-1.0, 1.0)
    }

    private fun nameAliases(value: String): Set<String> {
        val base = normalize(value)
        if (base.isBlank()) return emptySet()

        val result = linkedSetOf(base)
        result += base.replace(" ", "")

        val prefixes = setOf("fc", "afc", "sc", "cf", "cd", "ca", "ac", "fk", "nk", "sk", "sv", "ks", "ud", "ad", "us", "as", "club", "sm")
        val suffixes = setOf("fc", "afc", "sc", "cf", "cd", "fk", "nk", "sk", "sv", "ks", "ud", "ad", "us", "as", "club", "sm")
        val tokens = base.split(' ').filter { it.isNotBlank() }.toMutableList()

        if (tokens.size > 1 && tokens.first() in prefixes) {
            result += tokens.drop(1).joinToString(" ")
        }
        if (tokens.size > 1 && tokens.last() in suffixes) {
            result += tokens.dropLast(1).joinToString(" ")
        }
        if (tokens.size > 2 && tokens.first() in prefixes && tokens.last() in suffixes) {
            result += tokens.subList(1, tokens.size - 1).joinToString(" ")
        }

        // İddaa bazı takımları ilk kelimeyi tek harfe indirerek yayınlayabiliyor:
        // "P. Thistle" -> "p thistle", "C Glogow" -> "c glogow".
        // Bu bir fuzzy eşleştirme değildir: alias yalnızca build sırasında
        // tek bir takıma ait olduğu kanıtlanırsa nameIndex'e alınır.
        if (tokens.size > 1 && tokens.first().length >= 2) {
            result += "${tokens.first().first()} ${tokens.drop(1).joinToString(" ")}"
        }

        // Tek kelimelik alias üretmiyoruz. Ortak kelimeler (ör. "mayo",
        // "city", "united") farklı takımları yanlışlıkla birbirine bağlayabilir.
        // Güvenli eşleştirme yalnızca tam ad ve kontrollü prefix/suffix aliaslarıdır.

        // Category markers such as U19/U21/Women/(K)/B are never removed.
        return result.filter { it.isNotBlank() }.toSet()
    }

    private fun normalize(value: String): String = value
        .lowercase(java.util.Locale.forLanguageTag("tr-TR"))
        .normalizeTurkish()
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun String.normalizeTurkish(): String = this
        .replace('ı', 'i')
        .replace('İ', 'i')
        .replace('ş', 's').replace('Ş', 's')
        .replace('ğ', 'g').replace('Ğ', 'g')
        .replace('ü', 'u').replace('Ü', 'u')
        .replace('ö', 'o').replace('Ö', 'o')
        .replace('ç', 'c').replace('Ç', 'c')

    private const val TAG = "MERKEZI_MODEL"
    private const val MIN_HISTORY = 80
    private const val MIN_TEAM_MATCHES = 1
    private const val MAX_HISTORY = 50_000
    private const val HALF_LIFE_DAYS = 120.0
    private const val RECENCY_HALF_LIFE_MATCHES = 5.0
    private const val SHRINK_MATCHES = 12.0
    private const val ELO_BASE = 1500.0
    private const val HOME_ELO_ADVANTAGE = 55.0
    private const val ELO_K = 24.0
    private const val HOME_ADVANTAGE_LOG = 0.08
    private const val DEFAULT_HOME_GOALS = 1.35
    private const val DEFAULT_AWAY_GOALS = 1.10
    private const val DEFAULT_DIXON_COLES_RHO = -0.08
    private const val DEFAULT_CALIBRATION_TEMPERATURE = 1.08
}
