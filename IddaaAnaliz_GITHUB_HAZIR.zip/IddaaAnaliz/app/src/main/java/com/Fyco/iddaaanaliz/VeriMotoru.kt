@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

enum class SporVeriDurumu {
    YETERSIZ,
    EKSIK,
    YETERLI,
    IYI,
    COK_IYI
}

data class EslesmeAdayi(
    val eventId: String,
    val evSahibi: String,
    val deplasman: String,
    val lig: String? = null,
    val tarih: String? = null,
    val eslesmePuani: Int = 0
)

object VeriMotoru {

    fun takimEslesmePuani(
        iddaaAdi: String,
        disKaynakAdi: String
    ): Int {

        val a = normalize(iddaaAdi)
        val b = normalize(disKaynakAdi)

        if (a.isEmpty() || b.isEmpty()) {
            return 0
        }

        if (a == b) {
            return 100
        }

        if (a.contains(b) || b.contains(a)) {
            return 90
        }

        val kelimeA = a.split(" ")
        val kelimeB = b.split(" ")

        val ortakKelime =
            kelimeA.intersect(kelimeB.toSet()).size

        return when {
            ortakKelime >= 2 -> 80
            ortakKelime == 1 -> 55
            else -> 0
        }
    }

    fun macEslesmePuani(
        iddaaEv: String,
        iddaaDeplasman: String,
        disEv: String,
        disDeplasman: String
    ): Int {

        val evPuani =
            takimEslesmePuani(
                iddaaEv,
                disEv
            )

        val deplasmanPuani =
            takimEslesmePuani(
                iddaaDeplasman,
                disDeplasman
            )

        if (evPuani == 0 || deplasmanPuani == 0) {
            return 0
        }

        return (evPuani + deplasmanPuani) / 2
    }

    fun enIyiMacEslesmesi(
        iddaaEv: String,
        iddaaDeplasman: String,
        adaylar: List<EslesmeAdayi>
    ): EslesmeAdayi? {

        return adaylar
            .map { aday ->

                val puan =
                    macEslesmePuani(
                        iddaaEv = iddaaEv,
                        iddaaDeplasman = iddaaDeplasman,
                        disEv = aday.evSahibi,
                        disDeplasman = aday.deplasman
                    )

                aday.copy(
                    eslesmePuani = puan
                )
            }
            .filter {
                it.eslesmePuani >= 70
            }
            .maxByOrNull {
                it.eslesmePuani
            }
    }

    fun veriTamlikPuani(
        veri: MacDisVerisi
    ): Int {

        return VeriTamlikHesaplayici.hesapla(veri)
    }

    fun modelHazirMi(
        veri: MacDisVerisi
    ): Boolean {

        return ModelVeriKontrolu.yeterliMi(veri)
    }

    fun durum(
        veri: MacDisVerisi
    ): SporVeriDurumu {

        val puan =
            veriTamlikPuani(veri)

        return when {
            puan >= 85 ->
                SporVeriDurumu.COK_IYI

            puan >= 70 ->
                SporVeriDurumu.IYI

            puan >= 60 ->
                SporVeriDurumu.YETERLI

            puan >= 40 ->
                SporVeriDurumu.EKSIK

            else ->
                SporVeriDurumu.YETERSIZ
        }
    }

    private fun normalize(
        text: String
    ): String {

        return text
            .lowercase()
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
            .replace("-", " ")
            .replace(".", " ")
            .replace(",", " ")
            .replace("(", " ")
            .replace(")", " ")
            .replace("/", " ")
            .replace("'", "")
            .replace("\"", "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}