@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import kotlin.math.exp

/** Faz 7: Poisson skor uzayı + koşullu olasılık + bağımsız olaylar + Bayes. */
object OlasilikMotoruV2 {
    data class ScoreDistribution(
        val cells: Map<Pair<Int, Int>, Double>,
        val homeLambda: Double,
        val awayLambda: Double
    )

    fun football(
        profileHome: TakimProfilMotoru.Profile,
        profileAway: TakimProfilMotoru.Profile,
        maxGoals: Int = 8
    ): ScoreDistribution {
        fun blend(last: TakimProfilMotoru.FormStats, split: TakimProfilMotoru.FormStats): Double =
            (last.goalsFor * 0.55 + split.goalsFor * 0.45).coerceIn(0.15, 4.0)

        val homeAttack = blend(profileHome.last10, profileHome.home)
        val awayAttack = blend(profileAway.last10, profileAway.away)
        val homeDefense = (profileHome.last10.goalsAgainst * 0.55 + profileHome.home.goalsAgainst * 0.45).coerceIn(0.15, 4.0)
        val awayDefense = (profileAway.last10.goalsAgainst * 0.55 + profileAway.away.goalsAgainst * 0.45).coerceIn(0.15, 4.0)

        val homeLambda = (homeAttack * 0.65 + awayDefense * 0.35 + 0.12).coerceIn(0.15, 4.0)
        val awayLambda = (awayAttack * 0.65 + homeDefense * 0.35).coerceIn(0.15, 4.0)
        return distribution(homeLambda, awayLambda, maxGoals)
    }

    fun firstHalf(dist: ScoreDistribution, maxGoals: Int = 6): ScoreDistribution =
        distribution((dist.homeLambda * 0.48).coerceIn(0.08, 2.5), (dist.awayLambda * 0.48).coerceIn(0.08, 2.5), maxGoals)

    fun market(dist: ScoreDistribution, market: String, line: Double = 2.5): Map<String, Double> {
        val p = dist.cells
        fun sum(f: (Int, Int) -> Boolean) = p.filter { f(it.key.first, it.key.second) }.values.sum()
        return when (market.lowercase()) {
            "ms" -> mapOf("1" to sum { h, a -> h > a }, "x" to sum { h, a -> h == a }, "2" to sum { h, a -> h < a })
            "kg" -> mapOf("var" to sum { h, a -> h > 0 && a > 0 }, "yok" to sum { h, a -> h == 0 || a == 0 })
            "ustalt" -> mapOf("ust" to sum { h, a -> h + a > line }, "alt" to sum { h, a -> h + a < line })
            else -> emptyMap()
        }
    }

    fun teamGoals(dist: ScoreDistribution, home: Boolean, line: Double = 0.5): Map<String, Double> {
        val p = dist.cells
        fun sum(f: (Int) -> Boolean) = p.filter { f(if (home) it.key.first else it.key.second) }.values.sum()
        return mapOf("ust" to sum { it > line }, "alt" to sum { it < line })
    }

    fun conditional(aAndB: Double, b: Double): Double =
        if (b <= 0.0) 0.0 else (aAndB / b).coerceIn(0.0, 1.0)

    fun independent(a: Double, b: Double): Double =
        (a.coerceIn(0.0, 1.0) * b.coerceIn(0.0, 1.0)).coerceIn(0.0, 1.0)

    fun bayes(prior: Double, likelihoodIfTrue: Double, likelihoodIfFalse: Double): Double {
        val den = likelihoodIfTrue * prior + likelihoodIfFalse * (1.0 - prior)
        return if (den <= 0.0) prior else (likelihoodIfTrue * prior / den).coerceIn(0.0, 1.0)
    }

    private fun distribution(homeLambda: Double, awayLambda: Double, maxGoals: Int): ScoreDistribution {
        val hp = poisson(homeLambda, maxGoals)
        val ap = poisson(awayLambda, maxGoals)
        val raw = mutableMapOf<Pair<Int, Int>, Double>()
        var total = 0.0
        for (h in 0..maxGoals) {
            for (a in 0..maxGoals) {
                val value = hp[h] * ap[a]
                raw[h to a] = value
                total += value
            }
        }
        val normalized = if (total > 0.0) raw.mapValues { it.value / total } else raw
        return ScoreDistribution(normalized, homeLambda, awayLambda)
    }

    private fun poisson(lambda: Double, max: Int): DoubleArray {
        val p = DoubleArray(max + 1)
        p[0] = exp(-lambda)
        for (k in 1..max) p[k] = p[k - 1] * lambda / k
        return p
    }
}
