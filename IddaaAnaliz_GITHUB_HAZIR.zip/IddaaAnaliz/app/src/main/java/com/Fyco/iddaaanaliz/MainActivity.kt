@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz
import com.Fyco.iddaaanaliz.merkezi.MerkeziFutbolModelHavuzu

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.Fyco.iddaaanaliz.ui.theme.IddaaAnalizTheme
import com.Fyco.iddaaanaliz.espn.ESPNModelDurumKarti
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@androidx.compose.material3.ExperimentalMaterial3Api
class MainActivity : ComponentActivity() {


    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(
            savedInstanceState
        )

        Log.i("IddaaOgrenme", "V35_ACTIVITY_ONCREATE version=${BuildConfig.VERSION_NAME} code=${BuildConfig.VERSION_CODE} FINAL_MODEL=true PLAYER_MODEL=true")
        setContent {

            IddaaAnalizTheme {

                var events by remember {

                    mutableStateOf<
                            List<DisplayEvent>
                            >(
                        emptyList()
                    )
                }


                var loading by remember {

                    mutableStateOf(
                        true
                    )
                }


                var error by remember {

                    mutableStateOf<
                            String?
                            >(
                        null
                    )
                }


                var selectedFilter by remember {

                    mutableStateOf(
                        MatchFilter.ALL
                    )
                }


                var selectedEvent by remember {

                    mutableStateOf<
                            DisplayEvent?
                            >(
                        null
                    )
                }


                var competitionNames by remember {
                    mutableStateOf<Map<Long, String>>(emptyMap())
                }


                var strongestPicks by remember {
                    mutableStateOf<List<GucluSecim>>(emptyList())
                }


                var strongestLoading by remember {
                    mutableStateOf(false)
                }

                var strongestProgress by remember {
                    mutableIntStateOf(0)
                }

                var strongestJob by remember {
                    mutableStateOf<Job?>(null)
                }

                var strongestSignature by remember {
                    mutableStateOf<Long?>(null)
                }


                val scope =
                    rememberCoroutineScope()


                suspend fun loadWithRetry(
                    st: Int,
                    maxAttempts: Int = 3
                ): IddaaResponse {

                    var lastException:
                            Exception? = null


                    repeat(
                        maxAttempts
                    ) { attempt ->

                        try {

                            // Ana istek: ön maç bülteni.
                            // live=false, resmi bülten akışını hedefler.
                            return RetrofitClient
                                .api
                                .getEvents(
                                    st = st,
                                    live = false
                                )

                        } catch (_: Exception) {

                            // Bazı dönemlerde servis live=true ile cevap verebiliyor.
                            // İlk istek başarısız olursa ikinci resmi varyant denenir.
                            try {
                                return RetrofitClient
                                    .api
                                    .getEvents(
                                        st = st,
                                        live = true
                                    )
                            } catch (
                                secondError: Exception
                            ) {
                                // Kullanıcıya kök nedeni gösterebilmek için ikinci
                                // hatayı saklıyoruz.
                                val combined =
                                    Exception(
                                        "${secondError.javaClass.simpleName}: ${secondError.message ?: "Bilinmeyen ağ hatası"}",
                                        secondError
                                    )
                                lastException = combined
                            }


                            if (
                                attempt <
                                maxAttempts - 1
                            ) {

                                delay(
                                    when (attempt) {
                                        0 -> 1.seconds
                                        1 -> 2.5.seconds
                                        else -> 4.seconds
                                    }
                                )
                            }
                        }
                    }


                    throw lastException
                        ?: Exception(
                            "İddaa bağlantısı kurulamadı."
                        )
                }


                suspend fun loadData(forceStrongest: Boolean = false) {

                    loading =
                        true

                    error =
                        null

                    competitionNames = try {
                        IddaaCompetitionRepository.hazirla(force = true)
                    } catch (_: Exception) {
                        competitionNames
                    }


                    val allEvents =
                        mutableListOf<
                                DisplayEvent
                                >()


                    val errors =
                        mutableListOf<
                                String
                                >()


                    /*
                     * =====================================
                     * FUTBOL
                     * =====================================
                     */

                    try {

                        val response =
                            loadWithRetry(
                                st = 1
                            )


                        if (
                            response.isSuccess
                        ) {

                            response
                                .data
                                .events
                                .filter {
                                    it.m.isNotEmpty()
                                }
                                .forEach {

                                    allEvents.add(

                                        DisplayEvent(

                                            event =
                                                it,

                                            sport =
                                                SportType.FOOTBALL
                                        )
                                    )
                                }

                        } else {

                            errors.add(
                                "Futbol verisi alınamadı."
                            )
                        }

                    } catch (e: Exception) {

                        errors.add(
                            "Futbol bağlantısı başarısız: ${e.message ?: e.javaClass.simpleName}"
                        )
                    }


                    /*
                     * =====================================
                     * BASKETBOL
                     * =====================================
                     */

                    try {

                        val response =
                            loadWithRetry(
                                st = 2
                            )


                        if (
                            response.isSuccess
                        ) {

                            response
                                .data
                                .events
                                .filter {
                                    it.m.isNotEmpty()
                                }
                                .forEach {

                                    allEvents.add(

                                        DisplayEvent(

                                            event =
                                                it,

                                            sport =
                                                SportType.BASKETBALL
                                        )
                                    )
                                }

                        } else {

                            errors.add(
                                "Basketbol verisi alınamadı."
                            )
                        }

                    } catch (e: Exception) {

                        errors.add(
                            "Basketbol bağlantısı başarısız: ${e.message ?: e.javaClass.simpleName}"
                        )
                    }


                    events =
                        allEvents.sortedBy {

                            it.event.d
                        }


                    if (
                        events.isEmpty()
                    ) {

                        error =
                            if (
                                errors.isEmpty()
                            ) {

                                "İddaa servislerinden maç verisi gelmedi."

                            } else {

                                errors.joinToString(
                                    "\n"
                                )
                            }

                    } else if (
                        errors.isNotEmpty()
                    ) {

                        error =
                            "Bazı maç verileri alınamadı."
                    }


                    // Market konfigürasyonunu bülten taramasından ÖNCE bir kez hazırla.
                    // Başarısızsa disk cache/fallback kullanılmaya devam edilir; her maçta
                    // tekrar ağ isteği yapılmaz.
                    runCatching {
                        IddaaMarketConfigRepository.init(this@MainActivity)
                        IddaaMarketConfigRepository.hazirla()
                    }.onFailure {
                        Log.w("IDDAA_MARKET", "MARKET_CONFIG_HAZIR_DEGIL cache=${IddaaMarketConfigRepository.configYukluMu()}")
                    }

                    // FAZ 2-4: İddaa bültenini merkezi havuza yaz.
                    runCatching {
                        MerkeziVeriHavuzu.iddaaBultenYaz(
                            allEvents.filter { it.sport == SportType.FOOTBALL }.map { it.event },
                            SporTuru.FUTBOL
                        )
                        MerkeziVeriHavuzu.iddaaBultenYaz(
                            allEvents.filter { it.sport == SportType.BASKETBALL }.map { it.event },
                            SporTuru.BASKETBOL
                        )
                        // ESPN tarihsel DB mevcutsa merkezi havuza senkronla.
                        MerkeziVeriHavuzu.espnTarihselYaz(this@MainActivity)
                        MerkeziVeriHavuzu.futbolModeliniHazirla(force = false)
                        val stats = MerkeziVeriHavuzu.istatistik()
                        Log.i(
                            "MERKEZI_HAVUZ",
                            "SENKRON_OZET mac=${stats.mac} takim=${stats.takim} lig=${stats.lig} sezon=${stats.sezon} " +
                                    "market=${stats.market} oran=${stats.oran} kaynak=${stats.kaynak} sonuc=${stats.sonuc} tahmin=${stats.tahmin}"
                        )
                    }.onFailure {
                        Log.e("MERKEZI_HAVUZ", "MERKEZI_SENKRON_HATASI", it)
                    }


                    // Aktif üretim zinciri yalnızca İDDAA + ESPN'dir.

                    loading =
                        false

                    // Aynı bülten imzası için güçlü analiz tekrar başlatılmaz.
                    // Manuel YENİLEme forceStrongest=true ile açıkça yeniden analiz eder.
                    val modelHazir = MerkeziVeriHavuzu.futbolModelHazirMi()
                    var sig = 17L
                    for (displayEvent in allEvents) {
                        sig = sig * 31L + displayEvent.event.i
                        sig = sig * 31L + displayEvent.event.m.size
                        for (market in displayEvent.event.m) {
                            sig = sig * 31L + market.i
                            sig = sig * 31L + market.o.size
                            for (outcome in market.o) {
                                sig = sig * 31L + java.lang.Double.doubleToLongBits(outcome.oynanabilirOran)
                            }
                        }
                    }
                    sig = sig * 31L + if (modelHazir) 1L else 0L
                    val modelSnapshotForSignature = MerkeziFutbolModelHavuzu.current()
                    sig = sig * 31L + (modelSnapshotForSignature?.createdAt ?: 0L)
                    sig = sig * 31L + (modelSnapshotForSignature?.historyMatches ?: 0).toLong()
                    sig = sig * 31L + (modelSnapshotForSignature?.teams?.size ?: 0).toLong()
                    sig = sig * 31L + java.lang.Double.doubleToLongBits(
                        modelSnapshotForSignature?.calibrationTemperature ?: 1.0
                    )
                    sig = sig * 31L + java.lang.Double.doubleToLongBits(
                        modelSnapshotForSignature?.dixonColesRho ?: -0.08
                    )

                    val cachedDynamicSignature = GununGucluleriRepository.dynamicSignature()
                    if (!forceStrongest && cachedDynamicSignature == sig) {
                        val gunBaslangic = istanbulGunBaslangiciUi()
                        strongestPicks = GununGucluleriRepository.currentDayDynamic(
                            gunBaslangic, gunBaslangic + 86_400_000L
                        ).map { k -> kilitliKaydiGucluSecimeDonustur(k, allEvents) }
                        strongestSignature = sig
                        strongestLoading = false
                        strongestProgress = 0
                        return
                    }

                    if (!forceStrongest && strongestSignature == sig && strongestJob?.isActive != true) {
                        loading = false
                        return
                    }
                    strongestSignature = sig

                    // Günün bütün maçlarını analiz et; yalnızca gerçek value sinyallerini
                    // Günün Güçlüleri dinamik snapshot olarak yenilenir; önceki seçimler koşulsuz kilitlenmez.
                    strongestJob?.cancel()
                    strongestJob = scope.launch {
                        if (allEvents.isEmpty()) {
                            val bugun = istanbulGunBaslangiciUi()
                            strongestPicks = GununGucluleriRepository.currentDayDynamic(
                                bugun, bugun + 86_400_000L
                            ).map { k -> kilitliKaydiGucluSecimeDonustur(k, allEvents) }
                            strongestLoading = false
                            strongestProgress = 0
                        } else {
                            strongestLoading = true
                            strongestProgress = 0
                            Log.i(
                                "IddaaOgrenme",
                                "GUNUN_GUCLULERI_TARAMA_BASLADI allEvents=${allEvents.size} " +
                                        "futbol=${allEvents.count { it.sport == SportType.FOOTBALL }} " +
                                        "basketbol=${allEvents.count { it.sport == SportType.BASKETBALL }}"
                            )
                            strongestPicks = try {
                                val yeniSecimler = GunlukGucluSecimAnalizcisi.analizEt(
                                    events = allEvents,
                                    onProgress = { done ->
                                        if (done == 1 || done % 5 == 0) {
                                            withContext(Dispatchers.Main.immediate) {
                                                strongestProgress = done
                                            }
                                        }
                                    }
                                )
                                GununGucluleriRepository.replaceDynamicSnapshot(yeniSecimler, sig)
                                yeniSecimler
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Log.e("IddaaOgrenme", "GUNUN_GUCLULERI_UI_HATASI", e)
                                emptyList()
                            } finally {
                                strongestLoading = false
                                // Günün analizi biter bitmez dünden/önceki günlerden
                                // kalan tahminleri bağımsız sonuç taramasına ver.
                                // Bülten otomatik yenilenmez; yalnızca sonuç/öğrenme
                                // zinciri ilerletilir.
                            }
                        }
                    }
                }


                LaunchedEffect(Unit) {
                    // Bülten yalnızca uygulama açılışında yüklenir.
                    // Uygulama açık kaldığı sürece otomatik yenileme YOKTUR.
                    withContext(Dispatchers.IO) {
                        loadData()
                    }
                }


                if (
                    selectedEvent != null
                ) {

                    MatchDetailScreen(

                        displayEvent =
                            selectedEvent!!,

                        onBack = {

                            selectedEvent =
                                null
                        }
                    )

                } else {

                    MainMatchListScreen(

                        competitionNames =
                            competitionNames,

                        events =
                            events,

                        strongestPicks =
                            strongestPicks,

                        strongestLoading =
                            strongestLoading,

                        strongestProgress =
                            strongestProgress,

                        loading =
                            loading,

                        error =
                            error,

                        selectedFilter =
                            selectedFilter,

                        onFilterChange = {

                            selectedFilter =
                                it
                        },

                        onRefresh = {
                            scope.launch {
                                // Mevcut güçlüler taraması bitmeden ikinci bir tarama başlatma.
                                while (strongestLoading || strongestJob?.isActive == true) {
                                    delay(1.seconds)
                                }
                                withContext(Dispatchers.IO) {
                                    loadData(forceStrongest = true)
                                }
                            }
                        },

                        onResultCheck = {
                            TahminSonucArkaPlanPlanlayici.hemenKontrolEt(this@MainActivity)
                        },

                        onMatchClick = {

                            // Detay analizine geçerken Günün Güçlüleri'nin ağır
                            // arka plan analizini durdur. İki analiz aynı anda
                            // çalışıp telefonu zorlamasın.
                            strongestJob?.cancel()
                            strongestJob = null
                            strongestLoading = false

                            selectedEvent =
                                it
                        }
                    )
                }
            }
        }
    }
}


enum class SportType {

    FOOTBALL,

    BASKETBALL
}


data class DisplayEvent(

    val event: IddaaEvent,

    val sport: SportType
)


enum class MatchFilter {

    ALL,

    FOOTBALL,

    BASKETBALL,

    STRONGEST
}

data class GucluSecim(
    val displayEvent: DisplayEvent,
    val analiz: AnalizSonucu,
    val marketBasligi: String,
    val siralamaPuani: Double
)

// Karar sıralaması ekranın her Composable fonksiyonundan erişilebilir.
// MainMatchListScreen içindeki yerel kopyaya bağlı kalınmaz.
private fun kararSirasi(karar: Karar): Int = when (karar) {
    Karar.OYNA -> 2
    Karar.SINIRDA -> 1
    Karar.OYNAMA -> 0
    Karar.VERI_YETERSIZ -> 0
}


@androidx.compose.material3.ExperimentalMaterial3Api
@Composable
fun MainMatchListScreen(
    competitionNames: Map<Long, String>,
    events: List<DisplayEvent>,
    strongestPicks: List<GucluSecim>,
    strongestLoading: Boolean,
    strongestProgress: Int,
    loading: Boolean,
    error: String?,
    selectedFilter: MatchFilter,
    onFilterChange: (MatchFilter) -> Unit,
    onRefresh: () -> Unit,
    onResultCheck: () -> Unit,
    onMatchClick: (DisplayEvent) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "İddaa Analiz",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    Button(
                        onClick = onResultCheck,
                        enabled = !strongestLoading
                    ) {
                        Text("SONUÇ")
                    }
                    Button(
                        onClick = onRefresh,
                        enabled = !loading && !strongestLoading
                    ) {
                        Text("YENİLE")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (loading) {
                LoadingScreen()
                return@Column
            }

            if (error != null) {
                Text(
                    text = error,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }

            MatchSummary(events = events)

            ESPNModelDurumKarti(context = LocalContext.current)

            PrimaryTabRow(
                selectedTabIndex = when (selectedFilter) {
                    MatchFilter.ALL -> 0
                    MatchFilter.FOOTBALL -> 1
                    MatchFilter.BASKETBALL -> 2
                    MatchFilter.STRONGEST -> 3
                }
            ) {
                Tab(
                    selected = selectedFilter == MatchFilter.ALL,
                    onClick = { onFilterChange(MatchFilter.ALL) },
                    text = { Text("TÜMÜ") }
                )
                Tab(
                    selected = selectedFilter == MatchFilter.FOOTBALL,
                    onClick = { onFilterChange(MatchFilter.FOOTBALL) },
                    text = { Text("⚽ FUTBOL") }
                )
                Tab(
                    selected = selectedFilter == MatchFilter.BASKETBALL,
                    onClick = { onFilterChange(MatchFilter.BASKETBALL) },
                    text = { Text("🏀 BASKET") }
                )
                Tab(
                    selected = selectedFilter == MatchFilter.STRONGEST,
                    onClick = { onFilterChange(MatchFilter.STRONGEST) },
                    text = { Text("🔥 BÜLTENİN GÜÇLÜLERİ") }
                )
            }

            if (selectedFilter == MatchFilter.STRONGEST) {
                StrongestPicksScreen(
                    picks = strongestPicks,
                    loading = strongestLoading,
                    progress = strongestProgress,
                    onMatchClick = onMatchClick
                )
                return@Column
            }

            val filteredBySport = when (selectedFilter) {
                MatchFilter.ALL -> events
                MatchFilter.FOOTBALL -> events.filter {
                    it.sport == SportType.FOOTBALL
                }
                MatchFilter.BASKETBALL -> events.filter {
                    it.sport == SportType.BASKETBALL
                }
                else -> emptyList()
            }

            if (filteredBySport.isEmpty()) {
                EmptyMatchScreen()
            } else if (competitionNames.isEmpty()) {
                CompetitionLoadingScreen()
            } else {
                /*
                 * =====================================================
                 * İDDAA TARZI HİYERARŞİ
                 * =====================================================
                 *
                 * ÜLKE / BÖLGE
                 *     ↓ dokun
                 * LİGLER
                 *     ↓ dokun
                 * MAÇLAR
                 *
                 * İlk açılışta sadece ülke/bölge satırları görünür.
                 * Böylece 1000+ maç tek seferde ekrana yığılmaz.
                 */
                val groupedByCountry = filteredBySport
                    .groupBy { displayEvent ->
                        val competitionName = competitionNameFor(
                            displayEvent.event,
                            competitionNames
                        )
                        countryFromCompetitionName(competitionName)
                    }
                    .toSortedMap(compareBy { countrySortKey(it) })

                val expandedCountries = remember(groupedByCountry.keys) {
                    mutableStateOf(emptySet<String>())
                }

                val expandedLeagues = remember {
                    mutableStateOf(emptySet<String>())
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    groupedByCountry.forEach { (countryName, countryEvents) ->
                        val countryExpanded =
                            expandedCountries.value.contains(countryName)

                        item(key = "country-$countryName") {
                            CountryRow(
                                name = countryName,
                                count = countryEvents.size,
                                expanded = countryExpanded,
                                onClick = {
                                    val current = expandedCountries.value
                                    expandedCountries.value = if (countryExpanded) {
                                        current - countryName
                                    } else {
                                        current + countryName
                                    }
                                }
                            )
                        }

                        if (countryExpanded) {
                            val groupedByLeague = countryEvents
                                .groupBy { displayEvent ->
                                    competitionNameFor(
                                        displayEvent.event,
                                        competitionNames
                                    )
                                }
                                .toSortedMap(String.CASE_INSENSITIVE_ORDER)

                            groupedByLeague.forEach { (leagueName, leagueEvents) ->
                                val leagueKey = "$countryName|$leagueName"
                                val leagueExpanded =
                                    expandedLeagues.value.contains(leagueKey)

                                item(key = "league-$leagueKey") {
                                    LeagueRow(
                                        name = leagueName,
                                        count = leagueEvents.size,
                                        expanded = leagueExpanded,
                                        onClick = {
                                            val current = expandedLeagues.value
                                            expandedLeagues.value = if (leagueExpanded) {
                                                current - leagueKey
                                            } else {
                                                current + leagueKey
                                            }
                                        }
                                    )
                                }

                                if (leagueExpanded) {
                                    items(
                                        items = leagueEvents,
                                        key = { "${it.sport}-${it.event.i}" }
                                    ) { displayEvent ->
                                        MatchCard(
                                            displayEvent = displayEvent,
                                            onClick = {
                                                onMatchClick(displayEvent)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun StrongestPicksScreen(
    picks: List<GucluSecim>,
    loading: Boolean,
    progress: Int,
    onMatchClick: (DisplayEvent) -> Unit
) {
    if (loading && picks.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text(
                "Günün tüm maçları ve marketleri analiz ediliyor",
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text("$progress maç ayrıntılı olarak incelendi")
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    "BÜLTENİN GÜÇLÜLERİ",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (loading) {
                        "Günün maçları güncelleniyor • $progress analiz tamamlandı"
                    } else {
                        "Tüm maçlar ve marketler içinden güncel modele göre güçlü bulunan seçimler"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (picks.isEmpty() && !loading) {
            item {
                Text(
                    "Bültendeki maçlar içinde yeterli değer sinyali bulunamadı.",
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        items(
            items = picks,
            key = { "strong-${it.displayEvent.sport}-${it.displayEvent.event.i}-${it.analiz.marketId}-${it.analiz.secimNo}" }
        ) { pick ->
            StrongestPickCard(
                rank = picks.indexOf(pick) + 1,
                pick = pick,
                onClick = { onMatchClick(pick.displayEvent) }
            )
        }
    }
}

@Composable
fun StrongestPickCard(
    rank: Int,
    pick: GucluSecim,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "#$rank",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.padding(horizontal = 5.dp))
                Text(
                    if (pick.displayEvent.sport == SportType.FOOTBALL) "⚽ FUTBOL" else "🏀 BASKETBOL",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(Modifier.weight(1f))
                Text(
                    pick.analiz.karar.name,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(8.dp))
            Text(
                pick.displayEvent.event.hn,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Text("VS")
            Text(
                pick.displayEvent.event.an,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(Modifier.height(8.dp))
            Text(formatMatchTime(pick.displayEvent.event.d))
            Spacer(Modifier.height(10.dp))

            Text(
                pick.marketBasligi,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                kullaniciSecimAdi(
                    market = pick.displayEvent.event.m.firstOrNull { market ->
                        market.i == pick.analiz.marketId
                    } ?: pick.displayEvent.event.m.first(),
                    secim = pick.analiz.secim
                ),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(8.dp))
            Text(
                "GELME OLASILIĞI %${(pick.analiz.gelmeOlasiligi * 100.0).toInt()}",
                fontWeight = FontWeight.Bold
            )
            Text("ORAN ${AnalizMotoru.oranFormat(pick.analiz.oran)}")
            Text("GÜVEN ${pick.analiz.guvenPuani}/100")
            Text("EDGE ${pick.analiz.edge?.let { AnalizMotoru.yuzde(it) } ?: "-"}  •  EV ${pick.analiz.ev?.let { AnalizMotoru.yuzde(it) } ?: "-"}")
            Text("FAIR ORAN ${AnalizMotoru.oranFormat(pick.analiz.fairOran)}")
            Spacer(Modifier.height(8.dp))
            Text("NEDEN SEÇİLDİ?", fontWeight = FontWeight.Bold)
            Text(pick.analiz.aciklama, style = MaterialTheme.typography.bodySmall)

            val kayit = TahminOgrenmeRepository.tumunuGetir().firstOrNull {
                it.eventId == pick.displayEvent.event.i &&
                        it.marketId == pick.analiz.marketId &&
                        it.secimNo == pick.analiz.secimNo
            }
            kayit?.sonuc?.let { kazandi ->
                Spacer(Modifier.height(8.dp))
                Text(
                    if (kazandi) "KAZANDI ✓" else "KAYBETTİ ✕",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun competitionNameFor(
    event: IddaaEvent,
    competitionNames: Map<Long, String>
): String {
    val id = event.ci
    return competitionNames[id]
        ?.trim()
        ?.takeIf { it.isNotBlank() }
        ?: if (id != null) {
            "ORGANİZASYON #$id"
        } else {
            "ORGANİZASYON BİLGİSİ YOK"
        }
}

@Composable
fun CountryRow(
    name: String,
    count: Int,
    expanded: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = countryFlag(name),
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(Modifier.padding(horizontal = 7.dp))

        Text(
            text = countryDisplayLabel(name),
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge
        )

        if (count > 0) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.padding(horizontal = 5.dp))
        }

        Text(
            text = if (expanded) "⌃" else "⌄",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun LeagueRow(
    name: String,
    count: Int,
    expanded: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 54.dp, end = 16.dp, top = 11.dp, bottom = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (expanded) "⌃" else "›",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.padding(horizontal = 5.dp))

        Text(
            text = name,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium
        )

        Text(
            text = count.toString(),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}


fun countrySortKey(country: String): String {
    return when (normalizeCountry(country)) {
        "TURKIYE" -> "01-$country"
        "TURKIYE AMATOR" -> "02-$country"
        "DUNYA" -> "03-$country"
        "AVRUPA" -> "04-$country"
        "GUNEY AMERIKA" -> "05-$country"
        "ASYA" -> "06-$country"
        "AFRIKA" -> "07-$country"
        "KUZEY VE ORTA AMERIKA" -> "08-$country"
        "OKYANUSYA" -> "09-$country"
        "INGILTERE" -> "10-$country"
        "ISPANYA" -> "11-$country"
        "ALMANYA" -> "12-$country"
        "ITALYA" -> "13-$country"
        "FRANSA" -> "14-$country"
        "ABD" -> "15-$country"
        else -> "99-${normalizeCountry(country)}"
    }
}

fun countryDisplayLabel(country: String): String {
    return country.trim()
}

fun countryFlag(country: String): String {
    return when (normalizeCountry(country)) {
        "TURKIYE" -> "🇹🇷"
        "TURKIYE AMATOR" -> "🇹🇷"
        "AVUSTURYA" -> "🇦🇹"
        "ALMANYA" -> "🇩🇪"
        "INGILTERE" -> "🏴"
        "ISPANYA" -> "🇪🇸"
        "ITALYA" -> "🇮🇹"
        "FRANSA" -> "🇫🇷"
        "ABD" -> "🇺🇸"
        "AFGANISTAN" -> "🇦🇫"
        "ANDORRA" -> "🇦🇩"
        "ANGOLA" -> "🇦🇴"
        "ARJANTIN" -> "🇦🇷"
        "AVUSTRALYA" -> "🇦🇺"
        "BELCIKA" -> "🇧🇪"
        "BREZILYA" -> "🇧🇷"
        "BULGARISTAN" -> "🇧🇬"
        "CEKYA" -> "🇨🇿"
        "DANIMARKA" -> "🇩🇰"
        "FINLANDIYA" -> "🇫🇮"
        "HIRVATISTAN" -> "🇭🇷"
        "HOLLANDA" -> "🇳🇱"
        "IRLANDA" -> "🇮🇪"
        "ISKOCLYA" -> "🏴"
        "ISVEC" -> "🇸🇪"
        "ISVICRE" -> "🇨🇭"
        "JAPONYA" -> "🇯🇵"
        "KANADA" -> "🇨🇦"
        "KORE" -> "🇰🇷"
        "MACARISTAN" -> "🇭🇺"
        "NORVEC" -> "🇳🇴"
        "POLONYA" -> "🇵🇱"
        "PORTEKIZ" -> "🇵🇹"
        "ROMANYA" -> "🇷🇴"
        "SIRBISTAN" -> "🇷🇸"
        "SLOVAKYA" -> "🇸🇰"
        "SLOVENYA" -> "🇸🇮"
        "YUNANISTAN" -> "🇬🇷"
        "DUNYA" -> "🌍"
        "AVRUPA" -> "🌐"
        "GUNEY AMERIKA" -> "🌎"
        "ASYA" -> "🌏"
        "AFRIKA" -> "🌍"
        "KUZEY VE ORTA AMERIKA" -> "🌎"
        "OKYANUSYA" -> "🌏"
        else -> "🌐"
    }
}

fun normalizeCountry(value: String): String {
    return value
        .uppercase(Locale.forLanguageTag("tr-TR"))
        .replace("İ", "I")
        .replace("Ş", "S")
        .replace("Ğ", "G")
        .replace("Ü", "U")
        .replace("Ö", "O")
        .replace("Ç", "C")
        .replace("  ", " ")
        .trim()
}

fun countryFromCompetitionName(competitionName: String): String {
    val n = normalizeCountry(competitionName)

    val aliases = listOf(
        "TURKIYE AMATOR" to "TÜRKİYE AMATÖR",
        "TURKIYE" to "TÜRKİYE",
        "AVUSTURYA" to "AVUSTURYA",
        "AUSTRIA" to "AVUSTURYA",
        "ALMANYA" to "ALMANYA",
        "GERMANY" to "ALMANYA",
        "INGILTERE" to "İNGİLTERE",
        "ENGLAND" to "İNGİLTERE",
        "ISPANYA" to "İSPANYA",
        "SPAIN" to "İSPANYA",
        "ITALYA" to "İTALYA",
        "ITALY" to "İTALYA",
        "FRANSA" to "FRANSA",
        "FRANCE" to "FRANSA",
        "ABD" to "ABD",
        "USA" to "ABD",
        "AMERIKA" to "ABD",
        "HOLLANDA" to "HOLLANDA",
        "NETHERLANDS" to "HOLLANDA",
        "BELCIKA" to "BELÇİKA",
        "BELGIUM" to "BELÇİKA",
        "PORTEKIZ" to "PORTEKİZ",
        "PORTUGAL" to "PORTEKİZ",
        "ISVICRE" to "İSVİÇRE",
        "SWITZERLAND" to "İSVİÇRE",
        "YUNANISTAN" to "YUNANİSTAN",
        "GREECE" to "YUNANİSTAN",
        "HIRVATISTAN" to "HIRVATİSTAN",
        "CROATIA" to "HIRVATİSTAN",
        "SIRBISTAN" to "SIRBİSTAN",
        "SERBIA" to "SIRBİSTAN",
        "ROMANYA" to "ROMANYA",
        "ROMANIA" to "ROMANYA",
        "BULGARISTAN" to "BULGARİSTAN",
        "BULGARIA" to "BULGARİSTAN",
        "POLONYA" to "POLONYA",
        "POLAND" to "POLONYA",
        "CEKYA" to "ÇEKYA",
        "CZECHIA" to "ÇEKYA",
        "CZECH REPUBLIC" to "ÇEKYA",
        "SLOVAKYA" to "SLOVAKYA",
        "SLOVAKIA" to "SLOVAKYA",
        "SLOVENYA" to "SLOVENYA",
        "SLOVENIA" to "SLOVENYA",
        "MACARISTAN" to "MACARİSTAN",
        "HUNGARY" to "MACARİSTAN",
        "DANIMARKA" to "DANİMARKA",
        "DENMARK" to "DANİMARKA",
        "NORVEC" to "NORVEÇ",
        "NORWAY" to "NORVEÇ",
        "ISVEC" to "İSVEÇ",
        "SWEDEN" to "İSVEÇ",
        "FINLANDIYA" to "FİNLANDİYA",
        "FINLAND" to "FİNLANDİYA",
        "IRLANDA" to "İRLANDA",
        "IRELAND" to "İRLANDA",
        "ISKOCLYA" to "İSKOÇYA",
        "SCOTLAND" to "İSKOÇYA",
        "BREZILYA" to "BREZİLYA",
        "BRAZIL" to "BREZİLYA",
        "ARJANTIN" to "ARJANTİN",
        "ARGENTINA" to "ARJANTİN",
        "AVUSTRALYA" to "AVUSTRALYA",
        "AUSTRALIA" to "AVUSTRALYA",
        "JAPONYA" to "JAPONYA",
        "JAPAN" to "JAPONYA",
        "KANADA" to "KANADA",
        "CANADA" to "KANADA",
        "AFGANISTAN" to "AFGANİSTAN",
        "AFGHANISTAN" to "AFGANİSTAN",
        "ANDORRA" to "ANDORRA",
        "ANGOLA" to "ANGOLA",
        "DUNYA" to "DÜNYA",
        "WORLD" to "DÜNYA",
        "AVRUPA" to "AVRUPA",
        "EUROPE" to "AVRUPA",
        "GUNEY AMERIKA" to "GÜNEY AMERİKA",
        "SOUTH AMERICA" to "GÜNEY AMERİKA",
        "ASYA" to "ASYA",
        "ASIA" to "ASYA",
        "AFRIKA" to "AFRİKA",
        "AFRICA" to "AFRİKA",
        "KUZEY VE ORTA AMERIKA" to "KUZEY VE ORTA AMERİKA",
        "NORTH AND CENTRAL AMERICA" to "KUZEY VE ORTA AMERİKA",
        "OKYANUSYA" to "OKYANUSYA",
        "OCEANIA" to "OKYANUSYA"
    )

    for ((alias, country) in aliases) {
        if (n.contains(alias)) return country
    }

    val separators = listOf(" - ", " – ", " — ", ":")
    for (separator in separators) {
        val first = competitionName
            .split(separator)
            .firstOrNull()
            ?.trim()
            .orEmpty()

        if (first.isNotBlank() && first.length <= 35) {
            return first
        }
    }

    return "DİĞER"
}

@Composable
fun CompetitionLoadingScreen() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "Lig bilgileri yükleniyor...",
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Resmi İDDAA organizasyonları eşleştiriliyor.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun LoadingScreen() {

    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator()

        Spacer(
            modifier = Modifier.height(16.dp)
        )

        Text(
            text = "İddaa maçları yükleniyor..."
        )
    }
}

@Composable
fun MatchSummary(

    events:
    List<DisplayEvent>

) {

    val football =
        events.count {

            it.sport ==
                    SportType.FOOTBALL
        }


    val basketball =
        events.count {

            it.sport ==
                    SportType.BASKETBALL
        }


    Row(

        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 16.dp,
                    vertical = 12.dp
                ),

        horizontalArrangement =
            Arrangement.SpaceBetween
    ) {

        Text(

            text =
                "Toplam ${events.size} maç",

            fontWeight =
                FontWeight.Bold
        )


        Text(
            "⚽ $football"
        )


        Text(
            "🏀 $basketball"
        )
    }
}


@Composable
fun MatchCard(

    displayEvent:
    DisplayEvent,

    onClick:
        () -> Unit

) {

    val event =
        displayEvent.event


    Card(

        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 10.dp,
                    vertical = 5.dp
                )
                .clickable {

                    onClick()
                }

    ) {

        Column(

            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        16.dp
                    )

        ) {

            Text(

                text =

                    if (
                        displayEvent.sport ==
                        SportType.FOOTBALL
                    ) {

                        "⚽ FUTBOL"

                    } else {

                        "🏀 BASKETBOL"
                    },

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                Modifier.height(
                    8.dp
                )
            )


            Text(

                text =
                    event.hn,

                style =
                    MaterialTheme
                        .typography
                        .titleMedium,

                fontWeight =
                    FontWeight.Bold
            )


            Text(
                "vs"
            )


            Text(

                text =
                    event.an,

                style =
                    MaterialTheme
                        .typography
                        .titleMedium,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                Modifier.height(
                    8.dp
                )
            )


            Text(
                formatMatchTime(
                    event.d
                )
            )


            Spacer(
                Modifier.height(
                    12.dp
                )
            )


            Text(

                text =
                    "MAÇI ANALİZ ET →",

                fontWeight =
                    FontWeight.Bold
            )
        }
    }
}


@Composable
private fun ModelKadroKarti(kadro: ESPNKadroSaglayici.MacKadroModel) {
    Spacer(Modifier.height(8.dp))
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("KADRO / OYUNCU MODELİ", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("ESPN veri kapsaması: ${kadro.coverage}%")
            Text("Oyuncu verisi: ${kadro.homePlayers.size} / ${kadro.awayPlayers.size}")
            Text("Kadro kalite: ${"%.1f".format(kadro.homePlayerQuality)} / ${"%.1f".format(kadro.awayPlayerQuality)}")
            Text("Kalite kanıtı: ${kadro.homePlayerEvidence} / ${kadro.awayPlayerEvidence} oyuncu")
            Text("Eksik / şüpheli: ${kadro.homeMissing.size} / ${kadro.awayMissing.size}")
            Text(
                if (kadro.homeRosterSyncedAt > 0L && kadro.awayRosterSyncedAt > 0L)
                    "Oyuncu havuzu: yerel veri havuzu (kadrolar 8 saatte bir yenilenir)"
                else
                    "Oyuncu havuzu: canlı ESPN çekimi"
            )
            Text(
                if (kadro.homeInjuryCheckedAt > 0L && kadro.awayInjuryCheckedAt > 0L)
                    "Durum kontrolü: sakatlık/ceza/kadro dışı raporu 20 dk önbellekli"
                else
                    "Durum kontrolü: henüz doğrulanmadı"
            )
            kadro.warning?.let { Text("ℹ️ $it") }
            Text("Kaynak: ${kadro.source}", style = MaterialTheme.typography.bodySmall)

            val missing = (
                kadro.homeMissing.map { "${kadro.homeTeam}: ${it.oyuncuAdi}" to it } +
                    kadro.awayMissing.map { "${kadro.awayTeam}: ${it.oyuncuAdi}" to it }
                ).map { it.second }
                .sortedByDescending { OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, it).etkiSkoru }

            if (missing.isEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text("Tespit edilmiş kritik eksik yok / ESPN bu maç için eksik bildirimi vermedi.")
            } else {
                Spacer(Modifier.height(6.dp))
                Text("Eksik / şüpheli oyuncular", fontWeight = FontWeight.SemiBold)
                missing.take(8).forEach { player ->
                    val etki = OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, player)
                    Text(
                        "⚠️ ${player.oyuncuAdi}  ${"%.0f".format(etki.etkiSkoru)}/100  ${player.durum.name}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "   Hücum ${"%.2f".format(etki.takimHucumEtkisi)} | Savunma ${"%.2f".format(etki.takimSavunmaEtkisi)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun ModelTakimKarti(
    ev: MerkeziFutbolModelHavuzu.TakimModel,
    dep: MerkeziFutbolModelHavuzu.TakimModel,
    evTarihsel: Boolean,
    depTarihsel: Boolean
) {
    Spacer(Modifier.height(8.dp))
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("MERKEZİ MODEL", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ModelTakimSutunu(ev)
                Text("VS", fontWeight = FontWeight.Bold)
                ModelTakimSutunu(dep)
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Son 5: ${(ev.form5 * 100).toInt()}/${(dep.form5 * 100).toInt()}  |  " +
                    "Son 10: ${(ev.form10 * 100).toInt()}/${(dep.form10 * 100).toInt()}  |  " +
                    "Son 20: ${(ev.form20 * 100).toInt()}/${(dep.form20 * 100).toInt()}"
            )
            Text(
                "Model kalitesi: ${ev.modelQuality}/${dep.modelQuality}  |  " +
                    "Maç örneklemi: ${ev.macSayisi}/${dep.macSayisi}"
            )
            Text(
                "Veri durumu: ${if (evTarihsel) "Tarihsel" else "Nötr başlangıç"} / ${if (depTarihsel) "Tarihsel" else "Nötr başlangıç"}"
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Oyuncu etkisi yalnızca gerçek kadro/sakatlık verisi sağlandığında lambdaya uygulanır.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun ModelTakimSutunu(team: MerkeziFutbolModelHavuzu.TakimModel) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(team.teamName, fontWeight = FontWeight.Bold)
        Text("${team.takimPuani}/100", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("ELO ${team.elo.toInt()}")
        Text(
            "Hücum ${"%.2f".format(team.attackLog)} | Savunma ${"%.2f".format(team.defenseLog)}",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private fun kullaniciSecimAdi(
    market: IddaaMarket,
    secim: String
): String {
    val marketAdi = IddaaMarketConfigRepository.marketBasligi(market)
    val temiz = secim.trim()

    return when {
        marketAdi.equals("KARŞILIKLI GOL", ignoreCase = true) &&
                temiz.equals("Hayır", ignoreCase = true) -> "YOK"

        marketAdi.equals("KARŞILIKLI GOL", ignoreCase = true) &&
                (temiz.equals("Evet", ignoreCase = true) ||
                        temiz.equals("Var", ignoreCase = true)) -> "VAR"

        else -> temiz
    }
}

@androidx.compose.material3.ExperimentalMaterial3Api
@Composable
fun MatchDetailScreen(
    displayEvent: DisplayEvent,
    onBack: () -> Unit
) {
    var analizYukleniyor by remember {
        mutableStateOf(true)
    }

    var sonuc by remember {
        mutableStateOf<MacAnalizSonucu?>(null)
    }

    var hata by remember {
        mutableStateOf<String?>(null)
    }

    var kadroModel by remember {
        mutableStateOf<ESPNKadroSaglayici.MacKadroModel?>(null)
    }

    LaunchedEffect(displayEvent.event.i) {
        analizYukleniyor = true
        hata = null

        try {
            val spor = when (displayEvent.sport) {
                SportType.FOOTBALL -> SporTuru.FUTBOL
                SportType.BASKETBALL -> SporTuru.BASKETBOL
            }

            // Config, ProgSport, dış veri ve öğrenme kaydı dahil bütün ağır
            // analiz zinciri ana thread'den çıkarılır. Önceki logda 495 frame
            // atlanması bu zincirin UI'yi yaklaşık 8.3 saniye kilitlediğini
            // gösteriyordu.
            val analizSonucu = withContext(Dispatchers.Default) {
                /*
                 * RESMİ İDDAA MARKET KONFİGÜRASYONU
                 *
                 * Market adı t/st kimliğinden alınır.
                 * Outcome isminden market türü tahmin edilmez.
                 */
                try {
                    withTimeoutOrNull(3500.milliseconds) {
                        IddaaMarketConfigRepository.hazirla()
                    }
                } catch (_: Exception) {
                    // Config alınamazsa merkezi tahminci fallback market başlığı kullanır.
                }

                // Kadro verisi yardımcıdır; cevap gelmezse ana model bloke edilmez.
                val kadro = if (spor == SporTuru.FUTBOL) {
                    runCatching {
                        withTimeoutOrNull(5000.milliseconds) {
                            ESPNKadroSaglayici.macIcin(displayEvent.event)
                        }
                    }.getOrNull()
                } else null
                withContext(Dispatchers.Main.immediate) { kadroModel = kadro }

                MacAnalizServisi.analizEt(
                    event = displayEvent.event,
                    spor = spor,
                    evEksikOyuncular = kadro?.homeMissing.orEmpty(),
                    depEksikOyuncular = kadro?.awayMissing.orEmpty(),
                    evKadro = kadro?.homePlayers.orEmpty(),
                    depKadro = kadro?.awayPlayers.orEmpty()
                )
            }

            sonuc = analizSonucu
        } catch (e: Exception) {
            hata = e.message ?: "Analiz sırasında hata oluştu."
        } finally {
            analizYukleniyor = false
        }
    }

    /*
     * =========================================================
     * KRİTİK MARKET KORUMASI
     * =========================================================
     *
     * Artık bütün seçimleri tek bir listeye atıp,
     * oradan kafamıza göre bir seçim seçmiyoruz.
     *
     * Her seçim kendi MarketAnalizSonucu ile birlikte tutuluyor.
     *
     * Böylece:
     *
     * TOPLAM 2.5 -> ÜST -> 2.21
     *
     * hiçbir zaman:
     *
     * TOPLAM 0.5 -> ÜST -> 1.32
     *
     * gibi başka bir marketin oranıyla eşleşemez.
     */
    val marketSecimCiftleri =
        sonuc
            ?.marketler
            ?.flatMap { marketSonucu ->
                marketSonucu.secimler
                    .filter { secim ->
                        secim.marketId == marketSonucu.market.i &&
                                secim.oran > 1.0 &&
                                secim.gelmeOlasiligi > 0.0
                    }
                    .map { secim ->
                        marketSonucu to secim
                    }
            }
            ?: emptyList()

    /*
     * Her marketteki en güçlü seçim önce kendi marketi
     * içinde değerlendirilir.
     *
     * Sonra marketler arasında karşılaştırılır.
     */
    val marketBazliEnGucluSecimler =
        marketSecimCiftleri
            .filter { (_, secim) ->
                // Detay ekranındaki GÜÇLÜ SEÇİMLER, Günün Güçlüleri ile aynı
                // kalite kapısını kullanır. Böylece yalnızca OYNA/SINIRDA kararı
                // veren ama düşük olasılıklı / yetersiz örneklemli seçimler burada
                // görünmez.
                (secim.karar == Karar.OYNA || secim.karar == Karar.SINIRDA) &&
                        secim.gelmeOlasiligi.isFinite() &&
                        secim.gelmeOlasiligi >= 0.65 &&
                        secim.gelmeOlasiligi <= 1.0 &&
                        secim.guvenPuani >= 65 &&
                        secim.modelSampleCount >= 20 &&
                        secim.oran.isFinite() &&
                        secim.oran > 1.0
            }
            .groupBy { pair ->
                val title = AnalizMotoru.marketBasligi(pair.first.market)
                    .trim()
                    .lowercase(Locale.forLanguageTag("tr-TR"))
                val selection = pair.second.secim
                    .trim()
                    .lowercase(Locale.forLanguageTag("tr-TR"))
                "$title|$selection"
            }
            .values
            .mapNotNull { marketSecimleri ->
                marketSecimleri
                    .maxWithOrNull(
                        compareBy<Pair<MarketAnalizSonucu, AnalizSonucu>> {
                            kararSirasi(it.second.karar)
                        }.thenBy {
                            it.second.ev ?: Double.NEGATIVE_INFINITY
                        }.thenBy {
                            it.second.edge ?: Double.NEGATIVE_INFINITY
                        }.thenBy {
                            it.second.guvenPuani
                        }
                    )
            }

    /*
     * Ana seçim önce gerçek değer taşıyan (OYNA/SINIRDA) seçimlerden seçilir.
     * Ancak bütün marketler ekonomik olarak OYNAMA ise ekranı boş bırakmak
     * doğru değildir: model yine çalışmış ve market olasılığını üretmiş olabilir.
     * Bu durumda en iyi mevcut analiz ayrıca gösterilir ve kararı OYNAMA olarak
     * açıkça yazılır. Böylece "market yok" ile "değerli bahis yok" birbirine
     * karıştırılmaz.
     */
    val anaCift =
        marketBazliEnGucluSecimler
            .maxWithOrNull(
                compareBy<Pair<MarketAnalizSonucu, AnalizSonucu>> {
                    kararSirasi(it.second.karar)
                }.thenBy {
                    it.second.ev ?: Double.NEGATIVE_INFINITY
                }.thenBy {
                    it.second.edge ?: Double.NEGATIVE_INFINITY
                }.thenBy {
                    it.second.guvenPuani
                }.thenBy {
                    it.second.gelmeOlasiligi
                }
            )
            ?: marketSecimCiftleri
                .maxWithOrNull(
                    compareBy<Pair<MarketAnalizSonucu, AnalizSonucu>> {
                        kararSirasi(it.second.karar)
                    }.thenBy {
                        it.second.gelmeOlasiligi
                    }.thenBy {
                        it.second.guvenPuani
                    }.thenBy {
                        it.second.edge ?: Double.NEGATIVE_INFINITY
                    }
                )

    val anaMarket = anaCift?.first
    val analiz = anaCift?.second

    /*
     * Güçlü seçimler de market + seçim çifti olarak tutuluyor.
     * Aynı isimli "Üst", "Alt", "Var", "Yok" seçimleri
     * birbirine karışamaz.
     */
    val strongSelections =
        marketBazliEnGucluSecimler
            .sortedWith(
                compareByDescending<Pair<MarketAnalizSonucu, AnalizSonucu>> {
                    kararSirasi(it.second.karar)
                }.thenByDescending {
                    it.second.ev ?: Double.NEGATIVE_INFINITY
                }.thenByDescending {
                    it.second.edge ?: Double.NEGATIVE_INFINITY
                }.thenByDescending {
                    it.second.guvenPuani
                }.thenByDescending {
                    it.second.gelmeOlasiligi
                }
            )
            .take(10)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Maç Analizi")
                },
                navigationIcon = {
                    Button(
                        onClick = onBack
                    ) {
                        Text("←")
                    }
                }
            )
        }
    ) { paddingValues ->

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {

            /*
             * =================================================
             * MAÇ BİLGİLERİ
             * =================================================
             */
            item {
                Spacer(
                    Modifier.height(25.dp)
                )

                Text(
                    text = if (
                        displayEvent.sport ==
                        SportType.FOOTBALL
                    ) {
                        "⚽ FUTBOL"
                    } else {
                        "🏀 BASKETBOL"
                    },
                    fontWeight = FontWeight.Bold
                )

                Spacer(
                    Modifier.height(18.dp)
                )

                Text(
                    text = displayEvent.event.hn,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Text("VS")

                Text(
                    text = displayEvent.event.an,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Spacer(
                    Modifier.height(8.dp)
                )

                Text(
                    formatMatchTime(
                        displayEvent.event.d
                    )
                )

                Spacer(
                    Modifier.height(25.dp)
                )
            }

            if (displayEvent.sport == SportType.FOOTBALL) {
                item {
                    val evCozum = MerkeziFutbolModelHavuzu.takimTahminIcin(displayEvent.event.hn)
                    val depCozum = MerkeziFutbolModelHavuzu.takimTahminIcin(displayEvent.event.an)
                    if (evCozum != null && depCozum != null) {
                        ModelTakimKarti(
                            ev = evCozum.model,
                            dep = depCozum.model,
                            evTarihsel = evCozum.tarihsel,
                            depTarihsel = depCozum.tarihsel
                        )
                    }
                }
                item {
                    kadroModel?.let { ModelKadroKarti(it) }
                }
            }

            /*
             * =================================================
             * ANA ANALİZ
             * =================================================
             */
            item {
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment =
                            Alignment.CenterHorizontally
                    ) {

                        when {
                            analizYukleniyor -> {
                                CircularProgressIndicator()

                                Spacer(
                                    Modifier.height(18.dp)
                                )

                                Text(
                                    "VERİLER ANALİZ EDİLİYOR",
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            hata != null -> {
                                Text(
                                    hata!!,
                                    color =
                                        MaterialTheme
                                            .colorScheme
                                            .error
                                )
                            }

                            displayEvent.sport == SportType.FOOTBALL &&
                                    !MerkeziVeriHavuzu.futbolModelHazirMi() -> {
                                Text(
                                    "KENDİ MODELİ HENÜZ HAZIR DEĞİL",
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(Modifier.height(8.dp))

                                Text(
                                    "ESPN 365 günlük tarihsel veri ve takım ratingleri tamamlanmadan " +
                                            "futbol marketi için geçerli model olasılığı üretilemez."
                                )
                            }

                            analiz == null ||
                                    anaMarket == null -> {

                                Text(
                                    "GEÇERLİ BİR MARKET ANALİZİ OLUŞTURULAMADI",
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(
                                    Modifier.height(8.dp)
                                )

                                Text(
                                    "Açık ve geçerli oran bulunan bir market bulunamadı."
                                )
                            }

                            else -> {

                                /*
                                 * MARKET BAŞLIĞI
                                 *
                                 * Kesinlikle seçimden üretilmiyor.
                                 * Doğrudan seçimle aynı MarketAnalizSonucu
                                 * içinden geliyor.
                                 */
                                Text(
                                    text = AnalizMotoru.marketBasligi(anaMarket.market),
                                    style =
                                        MaterialTheme
                                            .typography
                                            .labelLarge,
                                    fontWeight = FontWeight.Bold
                                )

                                when (analiz.karar) {
                                    Karar.OYNAMA -> {
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = "DEĞERLİ SEÇİM YOK",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Karar.VERI_YETERSIZ -> {
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = "MODEL VERİSİ YETERSİZ – OLASILIK YALNIZCA REFERANS",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    else -> Unit
                                }

                                Spacer(
                                    Modifier.height(8.dp)
                                )

                                /*
                                 * SEÇİM
                                 */
                                Text(
                                    text = kullaniciSecimAdi(anaMarket.market, analiz.secim),
                                    style =
                                        MaterialTheme
                                            .typography
                                            .titleLarge,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(
                                    Modifier.height(16.dp)
                                )

                                /*
                                 * UI'DA SADECE TEK NİHAİ OLASILIK
                                 */
                                Text(
                                    text =
                                        "GELME OLASILIĞI %${
                                            (
                                                    analiz.gelmeOlasiligi *
                                                            100.0
                                                    ).toInt()
                                        }",
                                    style =
                                        MaterialTheme
                                            .typography
                                            .headlineMedium,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(
                                    Modifier.height(12.dp)
                                )

                                Text(
                                    text =
                                        "ORAN ${
                                            AnalizMotoru.oranFormat(
                                                analiz.oran
                                            )
                                        }"
                                )

                                Spacer(
                                    Modifier.height(8.dp)
                                )

                                Text(
                                    text = analiz.karar.name,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(
                                    Modifier.height(8.dp)
                                )

                                Text(
                                    text =
                                        "GÜVEN ${analiz.guvenPuani}/100"
                                )

                                Spacer(Modifier.height(8.dp))

                                val piyasa = analiz.kaynakHarmani?.iddaaOlasiligi
                                if (piyasa != null && piyasa.isFinite()) {
                                    Text(
                                        text = "PİYASA NO-VIG %${(piyasa * 100.0).toInt()}"
                                    )
                                }

                                Text(
                                    text = "FAİR ORAN ${AnalizMotoru.oranFormat(analiz.fairOran)}"
                                )

                                Text(
                                    text = "EDGE ${AnalizMotoru.yuzde(analiz.edge ?: 0.0)}"
                                )

                                Text(
                                    text = "EV ${AnalizMotoru.yuzde(analiz.ev ?: -1.0)}"
                                )

                                Spacer(
                                    Modifier.height(10.dp)
                                )

                                Text(
                                    text = analiz.aciklama,
                                    style =
                                        MaterialTheme
                                            .typography
                                            .bodySmall
                                )
                            }
                        }
                    }
                }
            }

            /*
             * =================================================
             * GÜÇLÜ SEÇİMLER
             * =================================================
             */
            if (strongSelections.isNotEmpty()) {

                item {
                    Spacer(
                        Modifier.height(24.dp)
                    )

                    Text(
                        "GÜÇLÜ SEÇİMLER",
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(
                        Modifier.height(8.dp)
                    )
                }

                items(
                    strongSelections
                ) { pair ->

                    /*
                     * MARKET VE SEÇİM AYNI NESNE ÇİFTİNDEN GELİYOR.
                     */
                    val market = pair.first
                    val secim = pair.second

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {

                            /*
                             * MARKET
                             */
                            Text(
                                text = AnalizMotoru.marketBasligi(market.market),
                                style =
                                    MaterialTheme
                                        .typography
                                        .labelMedium,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(
                                Modifier.height(4.dp)
                            )

                            /*
                             * SEÇİM
                             */
                            Text(
                                text = kullaniciSecimAdi(market.market, secim.secim),
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text =
                                    "GELME OLASILIĞI %${
                                        (
                                                secim.gelmeOlasiligi *
                                                        100.0
                                                ).toInt()
                                    }"
                            )

                            Text(
                                text =
                                    "ORAN ${
                                        AnalizMotoru.oranFormat(
                                            secim.oran
                                        )
                                    }"
                            )

                            Text(
                                secim.karar.name
                            )
                        }
                    }
                }
            }

            /*
             * =================================================
             * TÜM MARKET ANALİZLERİ
             * =================================================
             * Ana ekran yalnızca ana seçimi ve güçlü seçimleri gösteriyordu.
             * Bu nedenle model 15-30 market hesapladığı halde kullanıcı yalnızca
             * Alt/Üst gibi güçlü sonuçları görebiliyordu. Burada her açık marketin
             * model olasılığı, oranı ve kararını aynı market nesnesinden gösteriyoruz.
             */
            val tumMarketler = sonuc?.marketler.orEmpty()
                .filter { marketSonucu ->
                    marketSonucu.secimler.any {
                        it.marketId == marketSonucu.market.i &&
                            it.oran > 1.0 &&
                            it.gelmeOlasiligi > 0.0
                    }
                }

            if (tumMarketler.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(24.dp))
                    Text(
                        "TÜM MARKET ANALİZLERİ",
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Model tarafından çözülen açık marketler aşağıdadır."
                    )
                }

                items(
                    tumMarketler,
                    key = { it.market.i }
                ) { marketSonucu ->
                    val acikSecimler = marketSonucu.secimler
                        .filter {
                            it.marketId == marketSonucu.market.i &&
                                it.oran > 1.0 &&
                                it.gelmeOlasiligi > 0.0
                        }
                        .sortedByDescending { it.gelmeOlasiligi }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Text(
                                text = AnalizMotoru.marketBasligi(marketSonucu.market),
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(Modifier.height(6.dp))

                            acikSecimler.forEach { secim ->
                                Text(
                                    text =
                                        "${kullaniciSecimAdi(marketSonucu.market, secim.secim)}  •  " +
                                            "%${(secim.gelmeOlasiligi * 100.0).toInt()}  •  " +
                                            "${AnalizMotoru.oranFormat(secim.oran)}  •  ${secim.karar.name}"
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun EmptyMatchScreen() {

    Column(

        modifier =
            Modifier
                .fillMaxSize()
                .padding(
                    30.dp
                ),

        horizontalAlignment =
            Alignment.CenterHorizontally,

        verticalArrangement =
            Arrangement.Center
    ) {

        Text(
            "Gösterilecek maç bulunamadı."
        )
    }
}


fun formatMatchTime(
    timestamp: Long
): String {

    return try {

        val date =
            Date(
                timestamp * 1000
            )


        SimpleDateFormat(

            "dd.MM.yyyy HH:mm",

            Locale.forLanguageTag("tr-TR")

        ).apply {

            /*
             * İddaa timestamp'i UTC tabanlıdır.
             * Türkiye'de uygulama daima İstanbul saatini gösterir.
             */
            timeZone =
                java.util.TimeZone.getTimeZone(
                    "Europe/Istanbul"
                )

        }.format(
            date
        )

    } catch (
        _: Exception
    ) {

        "-"
    }

}

private fun kilitliKaydiGucluSecimeDonustur(
    k: GununGucluKaydi,
    currentEvents: List<DisplayEvent>
): GucluSecim {
    val mevcut = currentEvents.firstOrNull { it.event.i == k.eventId }
    if (mevcut != null) {
        val analiz = AnalizSonucu(
            secim = k.secim, oran = k.oran, gelmeOlasiligi = k.olasilik,
            fairOran = k.fairOran, edge = k.edge, ev = k.ev, guvenPuani = k.guven,
            karar = runCatching { Karar.valueOf(k.karar) }.getOrDefault(Karar.OYNA),
            aciklama = k.aciklama, marketId = k.marketId, marketBasligi = k.marketBasligi,
            secimNo = k.secimNo
        )
        return GucluSecim(mevcut, analiz, k.marketBasligi,
            k.olasilik * 10000.0 + k.guven * 25.0 + (k.edge ?: 0.0) * 5.0 + (k.ev ?: 0.0) * 2.0)
    }

    val sport = runCatching { SportType.valueOf(k.sport) }.getOrDefault(SportType.FOOTBALL)
    val syntheticOutcome = IddaaOutcome(k.secimNo, k.oran, k.oran, k.secim)
    val syntheticMarket = IddaaMarket(
        i = k.marketId, t = null, st = null, v = null, s = null, mbc = null,
        sov = null, o = listOf(syntheticOutcome)
    )
    val syntheticEvent = IddaaEvent(
        i = k.eventId, bri = null, v = null, hn = k.evSahibi, an = k.deplasman,
        sid = null, s = null, bp = null, il = null, mbc = null, kOdd = null,
        m = listOf(syntheticMarket), ci = null, oc = null, d = k.macZamani, hc = null, bgi = null
    )
    val display = DisplayEvent(syntheticEvent, sport)
    val analiz = AnalizSonucu(
        secim = k.secim, oran = k.oran, gelmeOlasiligi = k.olasilik, fairOran = k.fairOran,
        edge = k.edge, ev = k.ev, guvenPuani = k.guven,
        karar = runCatching { Karar.valueOf(k.karar) }.getOrDefault(Karar.OYNA),
        aciklama = k.aciklama, marketId = k.marketId, marketBasligi = k.marketBasligi,
        secimNo = k.secimNo
    )
    return GucluSecim(display, analiz, k.marketBasligi,
        k.olasilik * 10000.0 + k.guven * 25.0 + (k.edge ?: 0.0) * 5.0 + (k.ev ?: 0.0) * 2.0)
}

private fun istanbulGunBaslangiciUi(): Long {
    val calendar = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Istanbul"))
    calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
    calendar.set(java.util.Calendar.MINUTE, 0)
    calendar.set(java.util.Calendar.SECOND, 0)
    calendar.set(java.util.Calendar.MILLISECOND, 0)
    return calendar.timeInMillis
}

