@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Eski WorkManager kayıtlarını güvenle tüketmek için tutulan uyumluluk sınıfı.
 * Aktif tarihsel zincir yalnızca ESPNHistoryWorker'dır.
 */
@Deprecated("Legacy historical worker disabled; use ESPNHistoryWorker")
class TarihselVeriWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        Log.i("ESPN_HISTORY", "LEGACY_TARIHSEL_WORKER_DISABLED reason=ESPN_CANONICAL_ONLY")
        return Result.success()
    }

    companion object {
    }
}

object TarihselVeriPlanlayici {
    fun baslat(context: Context) {
        Log.i("ESPN_HISTORY", "LEGACY_TARIHSEL_PLANLAYICI_DISABLED reason=ESPN_CANONICAL_ONLY")
    }
}
