@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.time.DayOfWeek
import java.time.LocalDate
import java.util.Locale
import java.util.concurrent.TimeUnit

object ProgSportApi {

    private const val FOOTBALL_BASE =
        "https://www.prosoccer.gr/en/football/predictions/"

    private const val BASKETBALL_BASE =
        "https://www.progsport.com/"

    private val client =
        OkHttpClient.Builder()
            .connectTimeout(
                15,
                TimeUnit.SECONDS
            )
            .readTimeout(
                20,
                TimeUnit.SECONDS
            )
            .writeTimeout(
                20,
                TimeUnit.SECONDS
            )
            .retryOnConnectionFailure(true)
            .build()

    /*
     * =====================================================
     * GENEL
     * =====================================================
     */

    fun kaynakAdi(): String {
        return "ProgSport"
    }

    fun futbolAdresi(): String {
        return FOOTBALL_BASE
    }

    fun basketbolAdresi(): String {
        return BASKETBALL_BASE
    }

    /*
     * =====================================================
     * FUTBOL
     * =====================================================
     */

    suspend fun futbolMaclariniGetir():
            List<ProgSportMac> {

        return withContext(
            Dispatchers.IO
        ) {

            try {

                val url =
                    futbolBugunUrl()

                val html =
                    sayfaGetir(url)

                parseFootball(
                    html
                )

            } catch (
                _: Exception
            ) {

                emptyList()
            }
        }
    }

    /*
     * =====================================================
     * BASKETBOL
     * =====================================================
     *
     * ProgSport ana sayfası basketbol tahminlerini
     * yayınlıyor.
     *
     * HTML yapısı zaman zaman değişebildiği için parser
     * mümkün olduğunca toleranslı çalışıyor.
     */

    suspend fun basketbolMaclariniGetir():
            List<ProgSportMac> {

        return withContext(
            Dispatchers.IO
        ) {

            try {

                val html =
                    sayfaGetir(
                        BASKETBALL_BASE
                    )

                parseBasketball(
                    html
                )

            } catch (
                _: Exception
            ) {

                emptyList()
            }
        }
    }

    /*
     * =====================================================
     * SAYFA İNDİR
     * =====================================================
     */

    private fun sayfaGetir(
        url: String
    ): String {

        val request =
            Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Android) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36"
                )
                .header(
                    "Accept",
                    "text/html,application/xhtml+xml"
                )
                .build()

        client
            .newCall(request)
            .execute()
            .use { response ->

                if (!response.isSuccessful) {

                    throw Exception(
                        "HTTP ${response.code}"
                    )
                }

                return response
                    .body
                    ?.string()
                    ?: ""
            }
    }

    /*
     * =====================================================
     * BUGÜNÜN FUTBOL URL'Sİ
     * =====================================================
     */

    private fun futbolBugunUrl():
            String {

        val gun =
            LocalDate
                .now()
                .dayOfWeek

        val dosya =
            when (gun) {

                DayOfWeek.MONDAY ->
                    "Monday.html"

                DayOfWeek.TUESDAY ->
                    "Tuesday.html"

                DayOfWeek.WEDNESDAY ->
                    "Wednesday.html"

                DayOfWeek.THURSDAY ->
                    "Thursday.html"

                DayOfWeek.FRIDAY ->
                    "Friday.html"

                DayOfWeek.SATURDAY ->
                    "Saturday.html"

                DayOfWeek.SUNDAY ->
                    "Sunday.html"
            }

        return FOOTBALL_BASE +
                dosya
    }

    /*
     * =====================================================
     * FUTBOL PARSER
     * =====================================================
     */

    private fun parseFootball(
        html: String
    ): List<ProgSportMac> {

        if (html.isBlank()) {
            return emptyList()
        }

        val document =
            Jsoup.parse(html)

        val sonuc =
            mutableListOf<ProgSportMac>()

        val rows =
            document.select(
                "tr"
            )

        for (row in rows) {

            val mac =
                parseFootballRow(
                    row
                )

            if (mac != null) {

                sonuc.add(
                    mac
                )
            }
        }

        return sonuc.distinctBy {

            normalizeTeamName(
                it.evSahibi
            ) +
                    "|" +
                    normalizeTeamName(
                        it.deplasman
                    )
        }
    }

    /*
     * =====================================================
     * FUTBOL SATIRI
     * =====================================================
     */

    private fun parseFootballRow(
        row: Element
    ): ProgSportMac? {

        val text =
            row.text()
                .replace(
                    '\u00A0',
                    ' '
                )
                .trim()

        if (text.isBlank()) {
            return null
        }

        /*
         * Maç hücresini bul.
         *
         * ProSoccer:
         * TEAM A - TEAM B
         */

        val matchElement =
            row.select(
                "td"
            )
                .firstOrNull {
                    val t =
                        it.text().trim()

                    t.contains(
                        " - "
                    ) &&
                            t.length >= 5
                }

        val matchText =
            matchElement
                ?.text()
                ?.trim()
                ?: extractMatchFromText(
                    text
                )
                ?: return null

        val parts =
            matchText
                .split(
                    Regex(
                        "\\s+-\\s+"
                    ),
                    limit = 2
                )

        if (parts.size != 2) {
            return null
        }

        val ev =
            cleanTeamName(
                parts[0]
            )

        val dep =
            cleanTeamName(
                parts[1]
            )

        if (
            ev.length < 2 ||
            dep.length < 2
        ) {
            return null
        }

        val numbers =
            extractNumbers(
                row.text().take(1200)
            )

        /*
         * ProSoccer tablosunda tipik yapı:
         *
         * 1
         * X
         * 2
         * odds
         * skor
         * under
         * over
         *
         * Burada önce 1/X/2 yüzdelerini bulmaya
         * çalışıyoruz.
         */

        val percentages =
            findProbabilityTriplet(
                numbers
            )

        val overUnder =
            findOverUnder(
                numbers
            )

        val scores =
            findPredictedScores(
                text
            )

        return ProgSportMac(

            evSahibi =
                ev,

            deplasman =
                dep,

            evOlasilik =
                percentages
                    ?.getOrNull(0),

            beraberlikOlasilik =
                percentages
                    ?.getOrNull(1),

            deplasmanOlasilik =
                percentages
                    ?.getOrNull(2),

            altOlasilik =
                overUnder
                    ?.first,

            ustOlasilik =
                overUnder
                    ?.second,

            tahminiEvSkor =
                scores
                    ?.first
                    ?.first,

            tahminiDeplasmanSkor =
                scores
                    ?.first
                    ?.second,

            toplamSayi =
                null
        )
    }

    /*
     * =====================================================
     * BASKETBOL PARSER
     * =====================================================
     */

    private fun parseBasketball(
        html: String
    ): List<ProgSportMac> {

        if (html.isBlank()) {
            return emptyList()
        }

        val document =
            Jsoup.parse(html)

        val sonuc =
            mutableListOf<ProgSportMac>()

        val rows =
            document.select(
                "tr"
            )

        for (row in rows) {

            val mac =
                parseBasketballRow(
                    row
                )

            if (mac != null) {

                sonuc.add(
                    mac
                )
            }
        }

        /*
         * Bazı sayfalarda maçlar tablo dışında
         * div yapısında bulunabilir.
         */
        if (sonuc.isEmpty()) {

            // Tüm div ağacını taramak aynı içeriği yüzlerce kez üretir.
            // Sadece olası maç kartlarını sınırlandırılmış şekilde dene.
            val blocks =
                document.select(
                    "div[class*=match], div[class*=game], " +
                            "div[class*=event], article, li"
                ).take(500)

            for (block in blocks) {
                val blockText = block.text().trim()

                if (
                    blockText.length <= 800 &&
                    blockText.contains(" - ")
                ) {
                    val mac =
                        parseBasketballTextBlock(
                            blockText
                        )

                    if (mac != null) {
                        sonuc.add(mac)
                    }
                }
            }
        }

        return sonuc.distinctBy {

            normalizeTeamName(
                it.evSahibi
            ) +
                    "|" +
                    normalizeTeamName(
                        it.deplasman
                    )
        }
    }

    /*
     * =====================================================
     * BASKETBOL SATIRI
     * =====================================================
     */

    private fun parseBasketballRow(
        row: Element
    ): ProgSportMac? {

        val text =
            row.text()
                .replace(
                    '\u00A0',
                    ' '
                )
                .trim()

        if (text.isBlank()) {
            return null
        }

        val matchElement =
            row.select(
                "td"
            )
                .firstOrNull {

                    val t =
                        it.text().trim()

                    t.contains(
                        " - "
                    )
                }

        val matchText =
            matchElement
                ?.text()
                ?.trim()
                ?: extractMatchFromText(
                    text
                )
                ?: return null

        val parts =
            matchText
                .split(
                    Regex(
                        "\\s+-\\s+"
                    ),
                    limit = 2
                )

        if (parts.size != 2) {
            return null
        }

        val ev =
            cleanTeamName(
                parts[0]
            )

        val dep =
            cleanTeamName(
                parts[1]
            )

        if (
            ev.length < 2 ||
            dep.length < 2
        ) {
            return null
        }

        val numbers =
            extractNumbers(
                row.text().take(1200)
            )

        val probabilities =
            findProbabilityPair(
                numbers
            )

        val score =
            findBasketballScore(
                text
            )

        return ProgSportMac(

            evSahibi =
                ev,

            deplasman =
                dep,

            evOlasilik =
                probabilities
                    ?.first,

            deplasmanOlasilik =
                probabilities
                    ?.second,

            tahminiEvSkor =
                score?.first,

            tahminiDeplasmanSkor =
                score?.second
        )
    }

    /*
     * =====================================================
     * BASKETBOL TEXT BLOCK
     * =====================================================
     */

    private fun parseBasketballTextBlock(
        text: String
    ): ProgSportMac? {

        val match =
            extractMatchFromText(
                text
            )
                ?: return null

        val parts =
            match.split(
                Regex(
                    "\\s+-\\s+"
                ),
                limit = 2
            )

        if (parts.size != 2) {
            return null
        }

        val numbers =
            extractNumbers(
                text
            )

        val probabilities =
            findProbabilityPair(
                numbers
            )

        val score =
            findBasketballScore(
                text
            )

        return ProgSportMac(

            evSahibi =
                cleanTeamName(
                    parts[0]
                ),

            deplasman =
                cleanTeamName(
                    parts[1]
                ),

            evOlasilik =
                probabilities
                    ?.first,

            deplasmanOlasilik =
                probabilities
                    ?.second,

            tahminiEvSkor =
                score?.first,

            tahminiDeplasmanSkor =
                score?.second
        )
    }

    /*
     * =====================================================
     * MAÇ METNİNDEN TAKIMLARI BUL
     * =====================================================
     */

    private fun extractMatchFromText(
        text: String
    ): String? {

        val regex =
            Regex(
                "([A-Za-zÀ-ÿ0-9.'’&()]+(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()]+){0,5})\\s+-\\s+([A-Za-zÀ-ÿ0-9.'’&()]+(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()]+){0,5})"
            )

        return regex
            .find(text)
            ?.value
            ?.trim()
    }

    /*
     * =====================================================
     * SAYILARI ÇIKAR
     * =====================================================
     */

    private fun extractNumbers(
        row: Element
    ): List<Double> {

        return extractNumbers(
            row.text()
        )
    }

    private fun extractNumbers(
        text: String
    ): List<Double> {

        if (text.isBlank()) return emptyList()

        // Regex.findAll().toList() yerine manuel tarama kullanıyoruz.
        // ProgSport'un büyük/karmaşık basketbol satırlarında Android ICU
        // regex motorunun fatal SIGABRT vermesini engeller.
        val sonuc = ArrayList<Double>(32)
        var i = 0
        val length = text.length

        while (i < length) {
            if (!text[i].isDigit()) {
                i++
                continue
            }

            // Eski regex'in (?<![A-Za-z]) davranışını koru.
            if (i > 0 && text[i - 1].isLetter()) {
                i++
                while (
                    i < length &&
                    (text[i].isDigit() || text[i] == '.' || text[i] == ',')
                ) {
                    i++
                }
                continue
            }

            val startIndex = i
            var separatorSeen = false

            while (i < length) {
                val ch = text[i]

                when {
                    ch.isDigit() -> i++
                    (ch == '.' || ch == ',') && !separatorSeen -> {
                        separatorSeen = true
                        i++
                    }
                    else -> break
                }
            }

            // Team12 gibi harf+sayısal birleşimleri alma.
            if (i < length && text[i].isLetter()) {
                continue
            }

            val raw = text.substring(startIndex, i)
            val value = raw.replace(',', '.').toDoubleOrNull()

            if (value != null && value.isFinite()) {
                sonuc.add(value)
            }
        }

        return sonuc
    }

    /*
     * =====================================================
     * FUTBOL 1/X/2 OLASILIKLARI
     * =====================================================
     */

    private fun findProbabilityTriplet(
        numbers: List<Double>
    ): List<Double>? {

        for (
        i in 0..numbers.size - 3
        ) {

            if (
                i + 2 >= numbers.size
            ) {
                break
            }

            val a =
                numbers[i]

            val b =
                numbers[i + 1]

            val c =
                numbers[i + 2]

            if (
                a in 0.0..100.0 &&
                b in 0.0..100.0 &&
                c in 0.0..100.0
            ) {

                val toplam =
                    a + b + c

                if (
                    toplam >= 90.0 &&
                    toplam <= 110.0
                ) {

                    return listOf(
                        a,
                        b,
                        c
                    )
                }
            }
        }

        return null
    }

    /*
     * =====================================================
     * FUTBOL ALT / ÜST
     * =====================================================
     */

    private fun findOverUnder(
        numbers: List<Double>
    ): Pair<Double, Double>? {

        for (
        i in 0..numbers.size - 2
        ) {

            val a =
                numbers[i]

            val b =
                numbers[i + 1]

            if (
                a in 0.0..100.0 &&
                b in 0.0..100.0
            ) {

                val toplam =
                    a + b

                if (
                    toplam >= 90.0 &&
                    toplam <= 110.0
                ) {

                    return Pair(
                        a,
                        b
                    )
                }
            }
        }

        return null
    }

    /*
     * =====================================================
     * BASKETBOL OLASILIKLARI
     * =====================================================
     */

    private fun findProbabilityPair(
        numbers: List<Double>
    ): Pair<Double, Double>? {

        for (
        i in 0..numbers.size - 2
        ) {

            val a =
                numbers[i]

            val b =
                numbers[i + 1]

            if (
                a in 0.0..100.0 &&
                b in 0.0..100.0
            ) {

                val toplam =
                    a + b

                if (
                    toplam >= 95.0 &&
                    toplam <= 105.0
                ) {

                    return Pair(
                        a,
                        b
                    )
                }
            }
        }

        return null
    }

    /*
     * =====================================================
     * FUTBOL TAHMİNİ SKORLARI
     * =====================================================
     */

    private fun findPredictedScores(
        text: String
    ): Pair<Pair<Int, Int>, Pair<Int, Int>>? {

        val matches = findScorePairs(
            text = text,
            minScore = 0,
            maxScore = 10,
            minDigits = 1,
            maxDigits = 2,
            maxResults = 4
        )

        if (matches.isEmpty()) return null

        val first = matches[0]
        val second = matches.getOrNull(1) ?: first

        return Pair(first, second)
    }

    /*
     * =====================================================
     * BASKETBOL SKORU
     * =====================================================
     */

    private fun findBasketballScore(
        text: String
    ): Pair<Int, Int>? {

        return findScorePairs(
            text = text,
            minScore = 50,
            maxScore = 180,
            minDigits = 2,
            maxDigits = 3,
            maxResults = 1
        ).firstOrNull()
    }

    /**
     * Skorları regex kullanmadan ve sınırlı sayıda eşleşme ile çıkarır.
     */
    private fun findScorePairs(
        text: String,
        minScore: Int,
        maxScore: Int,
        minDigits: Int,
        maxDigits: Int,
        maxResults: Int
    ): List<Pair<Int, Int>> {

        if (text.isBlank() || maxResults <= 0) return emptyList()

        val result = ArrayList<Pair<Int, Int>>(maxResults)
        var i = 0
        val length = text.length

        while (i < length && result.size < maxResults) {
            if (!text[i].isDigit()) {
                i++
                continue
            }

            val leftStart = i
            while (
                i < length &&
                text[i].isDigit() &&
                (i - leftStart) < maxDigits
            ) {
                i++
            }

            val leftText = text.substring(leftStart, i)

            if (i < length && text[i].isDigit()) {
                while (i < length && text[i].isDigit()) i++
                continue
            }

            val left = leftText.toIntOrNull()
            if (
                left == null ||
                left !in minScore..maxScore ||
                leftText.length < minDigits
            ) {
                continue
            }

            var j = i
            var spaces = 0

            while (
                j < length &&
                text[j].isWhitespace() &&
                spaces < 12
            ) {
                j++
                spaces++
            }

            if (j >= length || text[j] != '-') continue
            j++

            spaces = 0
            while (
                j < length &&
                text[j].isWhitespace() &&
                spaces < 12
            ) {
                j++
                spaces++
            }

            if (j >= length || !text[j].isDigit()) continue

            val rightStart = j
            while (
                j < length &&
                text[j].isDigit() &&
                (j - rightStart) < maxDigits
            ) {
                j++
            }

            val rightText = text.substring(rightStart, j)

            if (j < length && text[j].isDigit()) continue

            val right = rightText.toIntOrNull()

            if (
                right != null &&
                right in minScore..maxScore &&
                rightText.length >= minDigits
            ) {
                result.add(left to right)
                i = j
            }
        }

        return result
    }

    /*
     * =====================================================
     * TAKIM ADI TEMİZLE
     * =====================================================
     */

    private fun cleanTeamName(
        value: String
    ): String {

        return collapseWhitespace(value)
    }

    /*
     * =====================================================
     * TAKIM ADI NORMALİZASYONU
     * =====================================================
     *
     * İddaa:
     * "Juventut Badalona"
     *
     * ProgSport:
     * "Joventut Badalona"
     *
     * gibi küçük farklılıkların eşleşmesini
     * kolaylaştırıyoruz.
     */

    private fun collapseWhitespace(value: String): String {
        if (value.isBlank()) return ""

        val out = StringBuilder(value.length)
        var previousWasSpace = false

        for (ch in value) {
            if (ch.isWhitespace()) {
                if (!previousWasSpace) {
                    out.append(' ')
                    previousWasSpace = true
                }
            } else {
                out.append(ch)
                previousWasSpace = false
            }
        }

        return out.toString().trim()
    }

    fun normalizeTeamName(
        value: String
    ): String {

        var text =
            value
                .lowercase(
                    Locale.forLanguageTag("tr-TR")
                )
                .replace(
                    "ı",
                    "i"
                )
                .replace(
                    "ğ",
                    "g"
                )
                .replace(
                    "ü",
                    "u"
                )
                .replace(
                    "ş",
                    "s"
                )
                .replace(
                    "ö",
                    "o"
                )
                .replace(
                    "ç",
                    "c"
                )

        /*
         * Yaygın kulüp kelimelerini sadeleştir.
         */
        val replacements =
            listOf(
                " fc " to " ",
                " cf " to " ",
                " bc " to " ",
                " basketball " to " ",
                " futbol " to " ",
                " fk " to " ",
                " sk " to " ",
                " ac " to " "
            )

        text =
            " $text "

        for (
        replacement in replacements
        ) {

            text =
                text.replace(
                    replacement.first,
                    replacement.second
                )
        }

        val cleaned = buildString(text.length) {
            for (ch in text) {
                if (ch in 'a'..'z' || ch in '0'..'9' || ch == ' ') {
                    append(ch)
                } else {
                    append(' ')
                }
            }
        }

        return collapseWhitespace(cleaned)
    }

}
