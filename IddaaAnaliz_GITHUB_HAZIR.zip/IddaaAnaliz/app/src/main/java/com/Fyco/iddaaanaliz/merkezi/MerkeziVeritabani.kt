@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [MerkeziMatch::class, MerkeziTeam::class, MerkeziLeague::class, MerkeziSeason::class, MerkeziMarket::class, MerkeziOdds::class, MerkeziSourceData::class, MerkeziResult::class, MerkeziPrediction::class],
    version = 1,
    exportSchema = false
)
abstract class MerkeziVeritabani : RoomDatabase() {
    abstract fun dao(): MerkeziDao
}
