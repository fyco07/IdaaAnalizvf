@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Resmi İDDAA competition listesini tutar.
 *
 * competitions endpointindeki:
 *   i = competition/organization id
 *   n = resmi organizasyon adı
 *   ec = etkinlik sayısı
 *   si = spor/organizasyon türü bilgisi
 *
 * Maç tarafındaki event.ci değeri ile i eşleştirilir.
 */
object IddaaCompetitionRepository {

    @Volatile
    private var names: Map<Long, String> = emptyMap()

    @Volatile
    private var loaded = false

    private val loadMutex = Mutex()

    suspend fun hazirla(force: Boolean = false): Map<Long, String> = loadMutex.withLock {
        if (loaded && !force) return@withLock names

        return@withLock try {
            val response = RetrofitClient.api.getCompetitions()

            val map = response.data
                .asSequence()
                .mapNotNull { item ->
                    val id = item.i.toLongOrNull() ?: return@mapNotNull null
                    val name = item.n.trim()
                    if (name.isBlank()) null else id to name
                }
                .toMap()

            if (map.isNotEmpty()) {
                names = map
                loaded = true
            }

            names
        } catch (_: Exception) {
            names
        }
    }

    fun ad(event: IddaaEvent): String {
        val id = event.ci ?: return "ORGANİZASYON BİLGİSİ YOK"
        return names[id] ?: "ORGANİZASYON #$id"
    }

    fun ad(event: DisplayEvent): String = ad(event.event)

    fun mevcutMu(): Boolean = names.isNotEmpty()

    fun temizle() {
        names = emptyMap()
        loaded = false
    }
}
