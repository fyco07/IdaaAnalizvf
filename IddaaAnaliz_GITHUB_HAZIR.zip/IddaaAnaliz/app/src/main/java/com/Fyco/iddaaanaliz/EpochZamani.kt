package com.Fyco.iddaaanaliz

/**
 * Uygulama içindeki epoch zamanlarını tek birim altında normalize eder.
 * Eski kayıtların bir bölümü saniye, yeni/harici kaynakların bir bölümü milisaniye
 * taşıyabildiği için karşılaştırma öncesi mutlaka bu yardımcı kullanılmalıdır.
 */
object EpochZamani {
    private const val MILLIS_ESIK = 100_000_000_000L

    fun saniye(value: Long): Long {
        if (value <= 0L) return value
        return if (value >= MILLIS_ESIK) value / 1000L else value
    }

    fun millis(value: Long): Long {
        if (value <= 0L) return value
        return if (value >= MILLIS_ESIK) value else value * 1000L
    }
}
