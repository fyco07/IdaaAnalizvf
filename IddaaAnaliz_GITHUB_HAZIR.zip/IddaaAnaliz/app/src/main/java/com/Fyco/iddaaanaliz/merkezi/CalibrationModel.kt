@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import kotlin.math.ln

/** Calibration sample shared by DAO and the pure calibration engine. */
data class CalibrationRow(val modelProbability: Double, val result: String?)

/** Simple, deterministic temperature scaling fit on settled football predictions. */
object CalibrationModel {
    fun fitTemperature(rows: List<CalibrationRow>): Double? {
        if (rows.size < 100) return null
        var bestT = 1.08
        var bestLoss = Double.POSITIVE_INFINITY
        for (step in 70..160) {
            val t = step / 100.0
            var loss = 0.0
            var count = 0
            for (row in rows) {
                val y = when (row.result) {
                    "WON" -> 1.0
                    "LOST" -> 0.0
                    else -> continue
                }
                val p = temperature(row.modelProbability, t)
                loss -= y * ln(p) + (1.0 - y) * ln(1.0 - p)
                count++
            }
            if (count > 0 && loss < bestLoss) {
                bestLoss = loss
                bestT = t
            }
        }
        return bestT.coerceIn(0.70, 1.60)
    }

    fun temperature(pRaw: Double, t: Double): Double {
        val p = pRaw.coerceIn(1e-6, 1.0 - 1e-6)
        val logit = ln(p / (1.0 - p))
        val calibrated = 1.0 / (1.0 + kotlin.math.exp(-logit / t.coerceAtLeast(0.1)))
        return calibrated.coerceIn(1e-6, 1.0 - 1e-6)
    }
}
