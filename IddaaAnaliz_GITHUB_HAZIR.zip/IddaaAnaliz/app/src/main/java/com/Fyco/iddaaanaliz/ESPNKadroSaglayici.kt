@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.util.Log
import com.Fyco.iddaaanaliz.espn.ESPNClient
import com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
import com.Fyco.iddaaanaliz.veritabani.ESPNOyuncuHavuzu
import com.Fyco.iddaaanaliz.veritabani.ESPNTakimKadroCache
import com.Fyco.iddaaanaliz.veritabani.ESPNOyuncuDurumCache
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import java.security.MessageDigest
import kotlin.math.roundToInt

/**
 * ESPN'in kamuya açık soccer roster/injury/team-leader uçlarını kullanarak
 * maç günü kadro sinyali üretir.
 *
 * Ana tahmin zinciri hâlâ Merkezi Veri Havuzu'dur. Bu sınıf yalnızca maç günü
 * oyuncu/kadro düzeltmesini gerçek veri varsa sağlar; veri bulunamazsa sıfır
 * etki ile devam edilir.
 */
object ESPNKadroSaglayici {
    private const val TAG = "OYUNCU_MODEL"
    private const val SUCCESS_TTL_MS = 20 * 60 * 1000L
    private const val FAILURE_TTL_MS = 0L
    private const val TEAM_INDEX_TTL_MS = 60 * 60 * 1000L
    // Kalıcı oyuncu/istatistik havuzu 8 saatte bir roster yenilemesi yapar.
    // Maç günü durumları (sakat/cezalı/şüpheli/kadro dışı) ise çok daha sık kontrol edilir.
    private const val ROSTER_TTL_MS = 8 * 60 * 60 * 1000L
    private const val INJURY_TTL_MS = 20 * 60 * 1000L
    private const val PLAYER_STATS_MAX_CONCURRENCY = 4
    private const val PLAYER_STATS_RETRY_MS = 6 * 60 * 60 * 1000L

    data class MacKadroModel(
        val eslesti: Boolean,
        val homeTeam: String,
        val awayTeam: String,
        val homeMissing: List<OyuncuEtkiVerisi> = emptyList(),
        val awayMissing: List<OyuncuEtkiVerisi> = emptyList(),
        val homePlayers: List<OyuncuEtkiVerisi> = emptyList(),
        val awayPlayers: List<OyuncuEtkiVerisi> = emptyList(),
        val source: String = "ESPN",
        val coverage: Int = 0,
        val warning: String? = null,
        val homePlayerQuality: Double = 0.0,
        val awayPlayerQuality: Double = 0.0,
        val homePlayerEvidence: Int = 0,
        val awayPlayerEvidence: Int = 0,
        val homeRosterSyncedAt: Long = 0L,
        val awayRosterSyncedAt: Long = 0L,
        val homeInjuryCheckedAt: Long = 0L,
        val awayInjuryCheckedAt: Long = 0L
    )

    private open class PlayerBase(
        val id: String,
        val name: String,
        val position: OyuncuPozisyonu,
        val metrics: PlayerMetrics = PlayerMetrics()
    )

    private data class PlayerMetrics(
        var goals: Double = 0.0,
        var assists: Double = 0.0,
        var minutes: Double = 0.0,
        var appearances: Int = 0,
        var starts: Int = 0,
        var substitutionsIn: Int = 0,
        var shots: Double = 0.0,
        var shotsOnTarget: Double = 0.0,
        var saves: Double = 0.0,
        var goalsAgainst: Double = 0.0,
        var xg: Double = 0.0,
        var xa: Double = 0.0
    )

    private data class TeamKadro(
        val teamName: String,
        val teamId: String,
        val league: String,
        val players: List<OyuncuEtkiVerisi>,
        val missing: List<OyuncuEtkiVerisi>,
        val rosterAvailable: Boolean,
        val injuryAvailable: Boolean,
        val ok: Boolean,
        val rosterSyncedAt: Long = 0L,
        val injuryCheckedAt: Long = 0L,
        val fromPersistentPool: Boolean = false
    )

    private data class CacheEntry(
        val savedAt: Long,
        val value: MacKadroModel,
        val failed: Boolean
    )

    private val cache = ConcurrentHashMap<Long, CacheEntry>()
    private val teamCache = ConcurrentHashMap<String, TeamKadro>()
    private val keyLocks = ConcurrentHashMap<String, Mutex>()
    // ESPN takım uçları 403/rate-limit gördüğünde 36 maçın eşzamanlı dört ayrı
    // endpoint dalgasına dönüşmesini engelle. Ağ erişimi kontrollü tutulur.
    private val endpointSemaphore = Semaphore(permits = 2)
    private val playerStatsSemaphore = Semaphore(permits = PLAYER_STATS_MAX_CONCURRENCY)
    private val playerStatsFailureAt = ConcurrentHashMap<String, Long>()
    // Aynı tanınmayan lig için binlerce kez log basmayı önler. Bu yalnızca
    // log hacmini azaltır; roster eşleştirme davranışını değiştirmez.
    private val skippedLeagueLog = ConcurrentHashMap.newKeySet<String>()

    private data class TeamRef(
        val teamId: String,
        val teamName: String,
        val league: String,
        val lastSeen: Long
    )

    @Volatile private var teamIndexLoadedAt: Long = 0L
    @Volatile private var teamIndex: Map<String, List<TeamRef>> = emptyMap()

    suspend fun macIcin(event: IddaaEvent): MacKadroModel = withContext(Dispatchers.IO) {
        val cached = cache[event.i]
        if (cached != null) {
            val ttl = if (cached.failed) FAILURE_TTL_MS else SUCCESS_TTL_MS
            if (System.currentTimeMillis() - cached.savedAt <= ttl) return@withContext cached.value
            cache.remove(event.i)
        }

        val lockKey = "${event.i}:${event.hn}:${event.an}"
        val mutex = keyLocks.getOrPut(lockKey) { Mutex() }
        try {
            mutex.withLock {
                val second = cache[event.i]
                if (second != null) {
                    val ttl = if (second.failed) FAILURE_TTL_MS else SUCCESS_TTL_MS
                    if (System.currentTimeMillis() - second.savedAt <= ttl) return@withLock second.value
                }

                val result = try {
                    load(event)
                } catch (error: Exception) {
                    Log.w(TAG, "KADRO_ESPN_HATASI event=${event.i} ${event.hn}-${event.an} type=${error.javaClass.simpleName}")
                    MacKadroModel(
                        eslesti = false,
                        homeTeam = event.hn,
                        awayTeam = event.an,
                        coverage = 0,
                        warning = error.message
                    )
                }
                cache[event.i] = CacheEntry(
                    savedAt = System.currentTimeMillis(),
                    value = result,
                    failed = !result.eslesti
                )
                result
            }
        } finally {
            keyLocks.remove(lockKey, mutex)
        }
    }

    fun temizle() {
        cache.clear()
        teamCache.clear()
        keyLocks.clear()
        playerStatsFailureAt.clear()
        teamIndex = emptyMap()
        teamIndexLoadedAt = 0L
    }

    private suspend fun load(event: IddaaEvent): MacKadroModel {
        // Önce telefonun zaten indirdiği ESPN tarihsel veriden takım+lig+ESPN takım ID
        // eşlemesini buluyoruz. Böylece gelecek maçlarda "all/scoreboard" çağrısının
        // başarısız olması kadro modelini kilitlemez.
        val historicalPair = resolveHistoricalPair(event.hn, event.an)
        if (historicalPair != null) {
            val (homeRef, awayRef) = historicalPair
            Log.i(
                TAG,
                "KADRO_TARIHSEL_ESLESME_OK event=${event.i} " +
                    "home=${event.hn}->${homeRef.teamName}/${homeRef.teamId} " +
                    "away=${event.an}->${awayRef.teamName}/${awayRef.teamId} " +
                    "league=${homeRef.league}"
            )
            val (home, away) = coroutineScope {
                val homeDeferred = async(Dispatchers.IO) {
                    loadTeam(homeRef.teamId, homeRef.teamName, homeRef.league)
                }
                val awayDeferred = async(Dispatchers.IO) {
                    loadTeam(awayRef.teamId, awayRef.teamName, awayRef.league)
                }
                homeDeferred.await() to awayDeferred.await()
            }
            val source = if (home.fromPersistentPool && away.fromPersistentPool) {
                "ESPN_LOCAL_PLAYER_POOL"
            } else {
                "ESPN_HISTORY_TEAM_INDEX"
            }
            return buildModel(event, home, away, source = source)
        }

        // Tarihsel indexte olmayan yeni takım için son çare olarak günlük scoreboard
        // eşleştirmesi kullanılır. Bu artık ana yol değildir.
        val date = SimpleDateFormat("yyyyMMdd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(java.util.Date(event.d * 1000L))

        val scoreboard = runCatching {
            ESPNVeriSaglayici.futbolGununuGetir(
                "${date.substring(0, 4)}-${date.substring(4, 6)}-${date.substring(6, 8)}"
            )
        }.getOrDefault(emptyList())

        val target = scoreboard.firstOrNull { matchMatches(event, it.homeName, it.awayName) }
            ?: scoreboard.firstOrNull {
                (sameTeam(event.hn, it.homeName) && sameTeam(event.an, it.awayName)) ||
                    (sameTeam(event.hn, it.awayName) && sameTeam(event.an, it.homeName))
            }

        if (target == null || target.homeId.isNullOrBlank() || target.awayId.isNullOrBlank()) {
            Log.d(TAG, "KADRO_ESLESME_YOK event=${event.i} ${event.hn}-${event.an}")
            return MacKadroModel(false, event.hn, event.an, warning = "ESPN takım eşleşmesi bulunamadı")
        }

        val league = target.lig?.trim().orEmpty()
        if (league.isBlank() || league == "all") {
            Log.d(TAG, "KADRO_LIG_YOK event=${event.i} home=${target.homeId} away=${target.awayId}")
            return MacKadroModel(false, event.hn, event.an, warning = "ESPN lig kimliği bulunamadı")
        }

        val (home, away) = coroutineScope {
            val homeDeferred = async(Dispatchers.IO) { loadTeam(target.homeId, target.homeName, league) }
            val awayDeferred = async(Dispatchers.IO) { loadTeam(target.awayId, target.awayName, league) }
            homeDeferred.await() to awayDeferred.await()
        }

        val source = if (home.fromPersistentPool && away.fromPersistentPool) {
            "ESPN_LOCAL_PLAYER_POOL"
        } else {
            "ESPN_SCOREBOARD_FALLBACK"
        }
        return buildModel(event, home, away, source = source)
    }

    private fun buildModel(
        event: IddaaEvent,
        home: TeamKadro,
        away: TeamKadro,
        source: String
    ): MacKadroModel {
        fun teamCoverage(team: TeamKadro): Int = when {
            team.rosterAvailable && team.injuryAvailable -> 50
            team.rosterAvailable -> 35
            team.injuryAvailable -> 20
            else -> 0
        }

        val coverage = (teamCoverage(home) + teamCoverage(away)).coerceIn(0, 100)
        val homeQuality = OyuncuEtkiMotoru.takimOyuncuKalitesi(home.players.filter { it.durum == OyuncuDurumTipi.OYNAYACAK })
        val awayQuality = OyuncuEtkiMotoru.takimOyuncuKalitesi(away.players.filter { it.durum == OyuncuDurumTipi.OYNAYACAK })

        val model = MacKadroModel(
            eslesti = home.ok || away.ok,
            homeTeam = event.hn,
            awayTeam = event.an,
            homeMissing = home.missing,
            awayMissing = away.missing,
            homePlayers = home.players,
            awayPlayers = away.players,
            source = source,
            coverage = coverage,
            warning = when {
                coverage == 0 -> "ESPN oyuncu/kadro verisi alınamadı"
                coverage < 100 -> "ESPN kadro/durum verisi kısmi"
                else -> null
            },
            homePlayerQuality = homeQuality.genel,
            awayPlayerQuality = awayQuality.genel,
            homePlayerEvidence = homeQuality.kanitOyuncuSayisi,
            awayPlayerEvidence = awayQuality.kanitOyuncuSayisi,
            homeRosterSyncedAt = home.rosterSyncedAt,
            awayRosterSyncedAt = away.rosterSyncedAt,
            homeInjuryCheckedAt = home.injuryCheckedAt,
            awayInjuryCheckedAt = away.injuryCheckedAt
        )

        Log.i(
            TAG,
            "KADRO_MODEL_HAZIR event=${event.i} coverage=$coverage source=$source " +
                "evOyuncu=${home.players.size} depOyuncu=${away.players.size} " +
                "evEksik=${home.missing.size} depEksik=${away.missing.size} " +
                "homeOk=${home.ok} awayOk=${away.ok} leagueHome=${home.league} leagueAway=${away.league} " +
                "kalite=${"%.1f".format(homeQuality.genel)}/${"%.1f".format(awayQuality.genel)} " +
                "kaliteKanit=${homeQuality.kanitOyuncuSayisi}/${awayQuality.kanitOyuncuSayisi}"
        )
        return model
    }

    private suspend fun resolveHistoricalPair(
        homeName: String,
        awayName: String
    ): Pair<TeamRef, TeamRef>? {
        ensureHistoricalTeamIndex()
        val homeCandidates = candidatesFor(homeName)
        val awayCandidates = candidatesFor(awayName)
        if (homeCandidates.isEmpty() || awayCandidates.isEmpty()) {
            Log.d(TAG, "KADRO_TARIHSEL_ESLESME_EKSİK home=$homeName candidates=${homeCandidates.size} away=$awayName candidates=${awayCandidates.size}")
            return null
        }

        // Güvenlik: iki takım aynı gerçek ESPN ligi içinde eşleşmedikçe
        // tarihsel roster verisini kullanma. Farklı liglerden "en yakın"
        // takımı bir araya getirmek yanlış oyuncu modeli üretir.
        return homeCandidates
            .asSequence()
            .flatMap { h ->
                awayCandidates.asSequence()
                    .filter { a -> a.league == h.league && a.teamId != h.teamId }
                    .map { a -> h to a }
            }
            .maxByOrNull { (h, a) -> minOf(h.lastSeen, a.lastSeen) }
    }

    private suspend fun ensureHistoricalTeamIndex() {
        val now = System.currentTimeMillis()
        if (teamIndex.isNotEmpty() && now - teamIndexLoadedAt <= TEAM_INDEX_TTL_MS) return

        val context = AppContextHolder.context ?: return
        synchronized(this) {
            if (teamIndex.isNotEmpty() && now - teamIndexLoadedAt <= TEAM_INDEX_TTL_MS) return
        }

        val db = runCatching { IddaaAnalizDatabase.getInstance(context) }.getOrNull()
        val matches = runCatching {
            db?.espnTarihselMacDao()?.tamamlananMaclariGetir().orEmpty()
        }.getOrDefault(emptyList())
        val poolMetas = runCatching {
            db?.espnOyuncuHavuzuDao()?.tumTakimMetalariniGetir().orEmpty()
        }.getOrDefault(emptyList())
        // Eski DB kayıtlarında `lig` çoğu zaman "regular-season" veya başka
        // bir competition/season slug'ıdır. Aynı takımın başka kaydında gerçek
        // ESPN league slug'ı varsa teamId üzerinden yeniden kullan.
        val leagueEvidenceByTeamId = HashMap<String, MutableList<Pair<Long, String>>>(8192)

        fun addLeagueEvidence(teamId: String?, rawLeague: String?, seen: Long) {
            if (teamId.isNullOrBlank()) return
            val apiLeague = espnLeagueSlug(rawLeague.orEmpty()) ?: return
            leagueEvidenceByTeamId.getOrPut(teamId) { mutableListOf() }.add(seen to apiLeague)
        }

        for (match in matches) {
            addLeagueEvidence(match.evTakimId, match.lig, match.baslangic)
            addLeagueEvidence(match.deplasmanTakimId, match.lig, match.baslangic)
        }
        for (meta in poolMetas) {
            addLeagueEvidence(meta.teamId, meta.league, meta.rosterSyncedAt)
        }

        val knownLeagueByTeamId = leagueEvidenceByTeamId.mapValues { (_, values) ->
            values.maxWithOrNull(compareBy<Pair<Long, String>> { it.first }.thenBy { it.second })?.second.orEmpty()
        }.filterValues { it.isNotBlank() }

        val map = HashMap<String, MutableList<TeamRef>>(8192)
        fun add(name: String, id: String?, rawLeague: String?, lastSeen: Long) {
            if (name.isBlank() || id.isNullOrBlank()) return
            val apiLeague = espnLeagueSlug(rawLeague.orEmpty())
                ?: knownLeagueByTeamId[id]
                ?: return

            val ref = TeamRef(id, name, apiLeague, lastSeen)
            deterministicAliases(name).forEach { key ->
                map.getOrPut(key) { mutableListOf() }.add(ref)
            }
        }

        for (match in matches) {
            add(match.evTakim, match.evTakimId, match.lig, match.baslangic)
            add(match.deplasmanTakim, match.deplasmanTakimId, match.lig, match.baslangic)
        }
        for (meta in poolMetas) {
            add(meta.teamName, meta.teamId, meta.league, meta.rosterSyncedAt)
        }

        map.values.forEach { list ->
            list.sortWith(compareByDescending<TeamRef> { it.lastSeen }.thenBy { it.teamId })
        }
        teamIndex = map
        teamIndexLoadedAt = System.currentTimeMillis()
        Log.i(
            TAG,
            "KADRO_TAKIM_INDEX_HAZIR kayit=${matches.size} havuzMeta=${poolMetas.size} " +
                "anahtar=${map.size} teamLeagueHint=${knownLeagueByTeamId.size}"
        )
    }

    /**
     * ESPN'in Site API takım/kadro endpointlerinde kullanılan gerçek lig slug'ını
     * normalize eder. Eski tarihsel DB kayıtlarımızın bir bölümü season.slug
     * (ör. 2026-27-english-premier-league) sakladığı için bu dönüşüm runtime'da
     * geriye dönük uyumluluk sağlar. Bu model normalization değildir; yalnızca
     * ESPN endpoint routing'i için teknik bir ID eşlemesidir.
     */
    private fun espnLeagueSlug(raw: String): String? {
        val original = raw.trim().lowercase(Locale.ROOT).replace('_', '-')
        if (original.isBlank()) return null

        val v = normalize(original)
        if (v.isBlank() || v == "all" || v == "regular season" || v == "regular-season") return null

        // Gerçek ESPN teknik slug'ı (ör. eng.1, fra.2) doğrudan kullan.
        if (Regex("""^[a-z]{2,12}(?:\.[a-z0-9]+)+$""").matches(original)) return original

        val exact = mapOf(
            "english premier league" to "eng.1",
            "english championship" to "eng.2",
            "english league one" to "eng.3",
            "english league two" to "eng.4",
            "english national league" to "eng.5",
            "english fa cup" to "eng.fa",
            "english carabao cup" to "eng.league_cup",
            "spanish laliga" to "esp.1",
            "spanish laliga 2" to "esp.2",
            "spanish copa del rey" to "esp.copa_del_rey",
            "german bundesliga" to "ger.1",
            "german 2 bundesliga" to "ger.2",
            "italian serie a" to "ita.1",
            "italian serie b" to "ita.2",
            "french ligue 1" to "fra.1",
            "french ligue 2" to "fra.2",
            "french national" to "fra.3",
            "dutch eredivisie" to "ned.1",
            "keuken kampioen divisie" to "ned.2",
            "scottish premiership" to "sco.1",
            "scottish championship" to "sco.2",
            "portuguese primeira liga" to "por.1",
            "belgian pro league" to "bel.1",
            "austrian bundesliga" to "aut.1",
            "greek super league" to "gre.1",
            "turkish super lig" to "tur.1",
            "danish superliga" to "den.1",
            "norwegian eliteserien" to "nor.1",
            "swedish allsvenskan" to "swe.1",
            "cypriot first division" to "cyp.1",
            "irish premier division" to "irl.1",
            "russian premier league" to "rus.1",
            "mls" to "usa.1",
            "nwsl" to "usa.nwsl",
            "mexican liga bbva mx" to "mex.1",
            "mexican liga mx" to "mex.1",
            "argentine liga profesional de futbol" to "arg.1",
            "brazilian serie a" to "bra.1",
            "brazilian serie b" to "bra.2",
            "chilean primera division" to "chi.1",
            "colombian primera a" to "col.1",
            "peruvian liga 1" to "per.1",
            "liga auf uruguaya" to "uru.1",
            "ecuador ligapro" to "ecu.1",
            "venezuelan primera division" to "ven.1",
            "south african premiership" to "rsa.1",
            "nigerian professional league" to "nga.1",
            "ghanaian premier league" to "gha.1",
            "saudi pro league" to "ksa.1",
            "japanese j league" to "jpn.1",
            "chinese super league" to "chn.1",
            "indian super league" to "ind.1",
            "thai league 1" to "tha.1",
            "malaysian super league" to "mys.1",
            "indonesian super league" to "idn.1",
            "singaporean premier league" to "sgp.1",
            "australian a league men" to "aus.1",
            "uefa champions league" to "uefa.champions",
            "uefa europa league" to "uefa.europa",
            "uefa conference league" to "uefa.europa.conf",
            "womens champions league" to "uefa.wchampions",
            "english womens super league" to "eng.w.1",
            "fifa world cup" to "fifa.world",
            "club friendly" to "club.friendly"
        )
        exact[v]?.let { return it }

        // Eski kayıtlar season.slug ile geldiyse yıl/sezon önekini temizle.
        // Normalize edilmiş örnek: "2026 27 german bundesliga".
        val noSeason = v
            .replace(Regex("^\\d{4}\\s+\\d{2,4}\\s+"), "")
            .replace(Regex("^\\d{4}\\s+"), "")
        exact[noSeason]?.let { return it }

        return when {
            v.contains("english premier league") -> "eng.1"
            v.contains("english championship") -> "eng.2"
            v.contains("english league one") -> "eng.3"
            v.contains("english league two") -> "eng.4"
            v.contains("english national league") -> "eng.5"
            v.contains("laliga") && !v.contains("2") -> "esp.1"
            v.contains("laliga 2") -> "esp.2"
            v.contains("german bundesliga") && !v.contains("2") -> "ger.1"
            v.contains("german 2 bundesliga") -> "ger.2"
            v.contains("serie a") && v.contains("ital") -> "ita.1"
            v.contains("serie b") && v.contains("ital") -> "ita.2"
            v.contains("ligue 1") -> "fra.1"
            v.contains("ligue 2") -> "fra.2"
            v.contains("french national") -> "fra.3"
            v.contains("eredivisie") -> "ned.1"
            v.contains("keuken kampioen") -> "ned.2"
            v.contains("premiership") && v.contains("scott") -> "sco.1"
            v.contains("primeira liga") -> "por.1"
            v.contains("pro league") && v.contains("belg") -> "bel.1"
            v.contains("austrian bundesliga") -> "aut.1"
            v.contains("super league") && v.contains("gre") -> "gre.1"
            v.contains("turkish super lig") -> "tur.1"
            v.contains("superliga") && v.contains("dan") -> "den.1"
            v.contains("eliteserien") -> "nor.1"
            v.contains("allsvenskan") -> "swe.1"
            v.contains("mexican") && v.contains("liga") -> "mex.1"
            v.contains("brazilian") && v.contains("serie a") -> "bra.1"
            v.contains("brazilian") && v.contains("serie b") -> "bra.2"
            v.contains("argentine") && v.contains("liga profesional") -> "arg.1"
            v.contains("south african") && v.contains("premiership") -> "rsa.1"
            v.contains("saudi") && v.contains("pro league") -> "ksa.1"
            v.contains("nwsl") -> "usa.nwsl"
            v.contains("womens champions league") -> "uefa.wchampions"
            else -> null
        }
    }

    private fun candidatesFor(name: String): List<TeamRef> {
        val normalized = normalize(name)
        val aliases = deterministicAliases(name)
        val exact = teamIndex[normalized].orEmpty()
        val aliasMatches = aliases
            .asSequence()
            .filter { it != normalized }
            .flatMap { teamIndex[it].orEmpty().asSequence() }
            .toList()

        return (exact + aliasMatches)
            .distinctBy { "${it.teamId}|${it.league}" }
            .sortedWith(
                compareByDescending<TeamRef> { normalize(it.teamName) == normalized }
                    .thenByDescending { it.lastSeen }
                    .thenBy { it.teamId }
            )
    }

    private fun deterministicAliases(value: String): Set<String> {
        val normalized = normalize(value)
        if (normalized.isBlank()) return emptySet()
        val tokens = normalized.split(' ').filter { it.isNotBlank() }
        val out = linkedSetOf(normalized, normalized.replace(" ", ""))
        val wrappers = setOf(
            "fc", "afc", "sc", "cf", "cd", "ac", "ca", "fk", "nk", "sk", "sv",
            "ks", "ud", "ad", "us", "as", "club", "team", "sm"
        )
        if (tokens.firstOrNull() in wrappers && tokens.size > 1) {
            out += tokens.drop(1).joinToString(" ")
        }
        if (tokens.lastOrNull() in wrappers && tokens.size > 1) {
            out += tokens.dropLast(1).joinToString(" ")
        }
        val core = tokens.filter { it !in wrappers }
        if (core.isNotEmpty()) out += core.joinToString(" ")

        // İddaa tarafında kullanılan "Deportivo X" gibi adlandırmaları ESPN'in
        // kısa takım adına bağla. Bunu genel bir isim eşitliği yerine yalnızca
        // aday alias olarak kullanıyoruz; nihai seçim yine aynı lig + takım ID
        // çifti üzerinden yapılır.
        val commonPrefixes = setOf("deportivo", "universidad")
        if (tokens.firstOrNull() in commonPrefixes && tokens.size > 1) {
            out += tokens.drop(1).joinToString(" ")
        }

        // ESPN/İddaa'da sık görülen deterministik kısaltmalar.
        val manual = mapOf(
            "b leverkusen" to "bayer leverkusen",
            "leverkusen" to "bayer leverkusen",
            "deportivo toluca" to "toluca",
            "toluca" to "toluca",
            "santos" to "santos",
            "man utd" to "manchester united",
            "man united" to "manchester united",
            "psg" to "paris saint germain",
            "psv" to "psv eindhoven",
            "inter" to "inter milan",
            "inter milan" to "inter milan",
            "atletico madrid" to "atletico de madrid",
            "sporting" to "sporting cp",
            "juventus" to "juventus",
            "roma" to "as roma"
        )
        manual[normalized]?.let { out += it }
        return out
    }

    private suspend fun loadTeam(teamId: String, teamName: String, league: String): TeamKadro {
        val context = AppContextHolder.context
        val cacheKey = "$league|$teamId"
        val seasonKey = currentSeasonKey()
        val now = System.currentTimeMillis()
        val db = context?.let { IddaaAnalizDatabase.getInstance(it) }
        val dao = db?.espnOyuncuHavuzuDao()

        // 1) Önce RAM cache. Uygulama açıkken aynı takım tekrar tekrar okunmasın.
        teamCache[cacheKey]?.let { cached ->
            val rosterFresh = cached.rosterSyncedAt > 0L &&
                cached.league == league &&
                now - cached.rosterSyncedAt <= ROSTER_TTL_MS
            val injuryFresh = cached.injuryCheckedAt > 0L && now - cached.injuryCheckedAt <= INJURY_TTL_MS
            if (rosterFresh && injuryFresh) return cached

            if (rosterFresh && !injuryFresh && dao != null) {
                val injuriesJson = fetchInjuries(teamId, teamName, league)
                val injuryRows = injuriesJson?.let { parseInjuries(it) }.orEmpty()
                if (injuriesJson != null) {
                    val checkedAt = System.currentTimeMillis()
                    dao.injurySnapshotKaydet(cacheKey, checkedAt, injuryRows.map { toStatusRow(cacheKey, it, checkedAt) })
                    val currentPlayers = applyStatuses(cached.players, injuryRows)
                    val refreshed = cached.copy(
                        players = currentPlayers,
                        missing = currentPlayers.filter { it.durum != OyuncuDurumTipi.OYNAYACAK && it.durum != OyuncuDurumTipi.BELIRSIZ },
                        injuryAvailable = true,
                        injuryCheckedAt = checkedAt,
                        fromPersistentPool = true
                    )
                    teamCache[cacheKey] = refreshed
                    Log.i(TAG, "KADRO_DURUM_SADECE_YENILENDI team=$teamName id=$teamId source=RAM_POOL")
                    return refreshed
                }
                val safe = cached.copy(missing = emptyList(), injuryAvailable = false)
                teamCache[cacheKey] = safe
                Log.w(TAG, "KADRO_DURUM_GUNCELLENEMEDI team=$teamName id=$teamId source=RAM_POOL")
                return safe
            }
        }

        if (dao != null) {
            // Önce tam cacheKey, sonra takım ID'si üzerinden kalıcı havuzu ara.
            // Böylece lig/season anahtarı değişse bile aynı ESPN teamId'nin roster'ı
            // boşa düşmez. TeamId, isim ve sezon metninden daha sağlam bir referanstır.
            val exactMeta = dao.takimMeta(cacheKey)
            val exactPlayers = dao.oyuncular(cacheKey)
            val meta = if (exactMeta != null && exactPlayers.isNotEmpty()) exactMeta else dao.takimMetaByTeamId(teamId)
            val cachedPlayers = if (exactPlayers.isNotEmpty()) exactPlayers else dao.oyuncularByTeamId(teamId)
            val poolFromOtherKey = meta != null && meta.cacheKey != cacheKey
            if (meta != null && cachedPlayers.isNotEmpty() && seasonCompatible(meta.seasonKey, seasonKey)) {
                if (poolFromOtherKey) {
                    Log.i(TAG, "KADRO_POOL_TEAMID_FALLBACK team=$teamName id=$teamId oldKey=${meta.cacheKey} newKey=$cacheKey roster=${cachedPlayers.size}")
                }
                val rosterFresh = now - meta.rosterSyncedAt <= ROSTER_TTL_MS
                val injuryFresh = now - meta.injuryCheckedAt <= INJURY_TTL_MS
                if (rosterFresh) {
                    var workingPlayers = cachedPlayers.map { it.toPlayerForPool() }
                    val existingEvidence = workingPlayers.count { it.hasPlayerEvidence() }
                    val statsRetryBlocked = now - (playerStatsFailureAt[cacheKey] ?: 0L) < PLAYER_STATS_RETRY_MS

                    if (existingEvidence == 0 && !statsRetryBlocked) {
                        val basesFromPool = workingPlayers.map { it.toPlayerBaseForStats() }
                        val seasonMetrics = enrichRosterWithSeasonStats(basesFromPool, league, seasonKey)
                        if (seasonMetrics.isNotEmpty()) {
                            workingPlayers = workingPlayers.map { player ->
                                val metrics = seasonMetrics[player.oyuncuId.orEmpty()]
                                if (metrics == null) player else player.mergeMetrics(metrics)
                            }
                            val enrichedRows = workingPlayers.map { toPoolRow(cacheKey, it, league, teamId, now) }
                            dao.rosterSnapshotKaydet(meta.copy(lastSuccessfulAt = now), enrichedRows)
                            Log.i(TAG, "KADRO_HAVUZU_ISTATISTIK_ZENGINLENDI team=$teamName id=$teamId roster=${workingPlayers.size} kanit=${workingPlayers.count { it.hasPlayerEvidence() }}")
                            playerStatsFailureAt.remove(cacheKey)
                        } else {
                            playerStatsFailureAt[cacheKey] = now
                            Log.w(TAG, "KADRO_HAVUZU_ISTATISTIK_YOK team=$teamName id=$teamId retryMs=$PLAYER_STATS_RETRY_MS")
                        }
                    }

                    val cachedTeam = teamKadroFromPool(meta, workingPlayers.map { it.toPoolRowModel() }, dao.durumlar(cacheKey), injuryFresh)
                    if (injuryFresh) {
                        teamCache[cacheKey] = cachedTeam
                        Log.i(TAG, "KADRO_HAVUZDAN_OKUNDU team=$teamName id=$teamId roster=${workingPlayers.size} durumFresh=true evidence=${workingPlayers.count { it.hasPlayerEvidence() }}")
                        return cachedTeam
                    }

                    // Roster aynı; sadece maç günü durumunu yeniden sor.
                    val injuriesJson = fetchInjuries(teamId, teamName, league)
                    val injuryRows = injuriesJson?.let { parseInjuries(it) }.orEmpty()
                    if (injuriesJson != null) {
                        val checkedAt = System.currentTimeMillis()
                        val statusRows = injuryRows.map { toStatusRow(cacheKey, it, checkedAt) }
                        dao.injurySnapshotKaydet(cacheKey, checkedAt, statusRows)
                        val refreshed = teamKadroFromPool(meta.copy(injuryCheckedAt = checkedAt, lastSuccessfulAt = checkedAt), workingPlayers.map { it.toPoolRowModel() }, statusRows, injuryFresh = true)
                        teamCache[cacheKey] = refreshed
                        Log.i(TAG, "KADRO_HAVUZDAN_OKUNDU team=$teamName id=$teamId roster=${workingPlayers.size} durumFresh=false->yenilendi evidence=${workingPlayers.count { it.hasPlayerEvidence() }}")
                        return refreshed
                    }

                    // Durum endpointi geçici olarak yoksa eski sakat/ceza verisini
                    // yeni maçta aktif etme; yalnızca güvenli roster kalitesi kullan.
                    val safe = cachedTeam.copy(missing = emptyList(), injuryAvailable = false, injuryCheckedAt = meta.injuryCheckedAt)
                    teamCache[cacheKey] = safe
                    Log.w(TAG, "KADRO_DURUM_GUNCELLENEMEDI team=$teamName id=$teamId source=LOCAL_POOL_STALE_STATUS")
                    return safe
                }
            }
        }

        // 2) Kalıcı havuz bayatsa roster + leaders + durum bir kez yenilenir.
        val prefix = "apis/site/v2/sports/soccer/$league/teams/$teamId"
        val (roster, injuries, leaders, teamDetail) = coroutineScope {
            val rosterDeferred = async(Dispatchers.IO) {
                runCatching { limitedGetJson("$prefix/roster") }
                    .onFailure { Log.w(TAG, "KADRO_ENDPOINT_HATASI team=$teamName id=$teamId league=$league endpoint=roster error=${it.message}") }
                    .getOrNull()
            }
            val injuriesDeferred = async(Dispatchers.IO) { fetchInjuries(teamId, teamName, league) }
            val leadersDeferred = async(Dispatchers.IO) {
                runCatching { limitedGetJson("$prefix/leaders") }
                    .onFailure { Log.w(TAG, "KADRO_ENDPOINT_HATASI team=$teamName id=$teamId league=$league endpoint=leaders error=${it.message}") }
                    .getOrNull()
            }
            val detailDeferred = async(Dispatchers.IO) {
                runCatching { limitedGetJson("$prefix?enable=roster") }
                    .onFailure { Log.w(TAG, "KADRO_ENDPOINT_HATASI team=$teamName id=$teamId league=$league endpoint=team?enable=roster error=${it.message}") }
                    .getOrNull()
            }
            Quad(rosterDeferred.await(), injuriesDeferred.await(), leadersDeferred.await(), detailDeferred.await())
        }

        val rosterJson = roster ?: teamDetail

        // Ağ geçici olarak 403/timeout verirse, varsa son bilinen roster'ı
        // kaybetme. Oyuncu kalite hesabı eski roster ile devam eder; yalnızca
        // güncel sakatlık/ceza durumu bilinmiyorsa missing listesi boş tutulur.
        if (rosterJson == null) {
            val fallbackExactMeta = dao?.takimMeta(cacheKey)
            val fallbackExactPlayers = dao?.oyuncular(cacheKey).orEmpty()
            val fallbackMeta = if (fallbackExactMeta != null && fallbackExactPlayers.isNotEmpty()) {
                fallbackExactMeta
            } else {
                dao?.takimMetaByTeamId(teamId)
            }
            val fallbackPlayers = if (fallbackExactPlayers.isNotEmpty()) {
                fallbackExactPlayers
            } else {
                dao?.oyuncularByTeamId(teamId).orEmpty()
            }
            if (fallbackMeta != null && fallbackPlayers.isNotEmpty() && seasonCompatible(fallbackMeta.seasonKey, seasonKey)) {
                Log.w(TAG, "KADRO_STALE_POOL_TEAMID_FALLBACK team=$teamName id=$teamId oldKey=${fallbackMeta.cacheKey} newKey=$cacheKey roster=${fallbackPlayers.size}")
                val safe = teamKadroFromPool(
                    meta = fallbackMeta.copy(cacheKey = cacheKey, league = league, teamId = teamId, teamName = teamName),
                    rows = fallbackPlayers,
                    statuses = dao?.durumlar(cacheKey).orEmpty(),
                    injuryFresh = false
                ).copy(injuryAvailable = false, missing = emptyList())
                teamCache[cacheKey] = safe
                Log.w(
                    TAG,
                    "KADRO_STALE_POOL_FALLBACK team=$teamName id=$teamId " +
                        "roster=${fallbackPlayers.size} rosterSyncedAt=${fallbackMeta.rosterSyncedAt}"
                )
                return safe
            }
        }

        if (rosterJson == null && injuries == null) {
            val failed = TeamKadro(teamName, teamId, league, emptyList(), emptyList(), rosterAvailable = false, injuryAvailable = false, ok = false)
            teamCache[cacheKey] = failed
            Log.w(TAG, "KADRO_VERI_YOK team=$teamName id=$teamId league=$league")
            return failed
        }

        val bases = parseRoster(rosterJson)
        val metrics = parseLeaders(leaders)
        val leaderMergedMetrics = mergePlayerMetrics(bases.associate { it.id to it.metrics }, metrics)

        // Roster endpointi çoğu zaman yalnızca oyuncu kimliği/pozisyon döndürür.
        // Gerçek dakika, ilk 11, gol/asist/şut gibi üretim verilerini ESPN Core
        // sezon istatistiğinden tek seferde havuza zenginleştiriyoruz. Böylece
        // oyuncu puanı 50'ye sıkışmaz ve sonraki maçlarda ağdan tekrar çekilmez.
        val seasonMetrics = enrichRosterWithSeasonStats(
            bases = bases,
            league = league,
            seasonKey = seasonKey
        )
        val mergedMetrics = mergePlayerMetrics(leaderMergedMetrics, seasonMetrics)

        if (rosterJson != null && bases.isEmpty() && dao != null) {
            // Yeni endpoint boş parse edildiyse mevcut yerel roster'ı koru.
            val meta = dao.takimMeta(cacheKey)
            val cachedPlayers = dao.oyuncular(cacheKey)
            if (meta != null && cachedPlayers.isNotEmpty()) {
                val safe = teamKadroFromPool(meta, cachedPlayers, dao.durumlar(cacheKey), injuryFresh = now - meta.injuryCheckedAt <= INJURY_TTL_MS)
                teamCache[cacheKey] = safe
                Log.w(TAG, "KADRO_ROSTER_PARSE_BOS_ESKI_HAVUZ_KORUNDU team=$teamName id=$teamId")
                return safe
            }
        }

        val injuryRows = injuries?.let { parseInjuries(it) } ?: emptyList()
        val injuryMap = injuryRows.associateBy { it.id }
        val allPlayers = bases.mapNotNull { base ->
            val m = mergedMetrics[base.id] ?: base.metrics
            toPlayer(base.copyMetrics(m), injuryMap[base.id]?.status ?: OyuncuDurumTipi.OYNAYACAK)
        }
        val missing = injuryRows.mapNotNull { injury ->
            val base = bases.firstOrNull { it.id == injury.id } ?: PlayerBase(injury.id, injury.name, injury.position)
            val m = mergedMetrics[base.id] ?: base.metrics
            toPlayer(base.copyMetrics(m), injury.status)
        }
            .filter { it.durum != OyuncuDurumTipi.BELIRSIZ && it.durum != OyuncuDurumTipi.OYNAYACAK }
            .distinctBy { it.oyuncuId ?: it.oyuncuAdi.lowercase(Locale.ROOT) }

        val rosterSyncedAt = now
        val injuryCheckedAt = if (injuries != null) now else 0L
        val signature = rosterSignature(bases.map { it.id })
        val rosterRows = allPlayers.map { toPoolRow(cacheKey, it, league, teamId, rosterSyncedAt) }
        if (dao != null && rosterRows.isNotEmpty()) {
            val oldMeta = dao.takimMeta(cacheKey)
            val oldPlayers = dao.oyuncular(cacheKey)
            if (oldMeta != null && oldMeta.rosterSignature.isNotBlank() && oldMeta.rosterSignature != signature) {
                val oldIds = oldPlayers.map { it.playerId }.toSet()
                val newIds = rosterRows.map { it.playerId }.toSet()
                val added = (newIds - oldIds).size
                val removed = (oldIds - newIds).size
                Log.i(TAG, "KADRO_ROSTER_DEGISIKLIK team=$teamName id=$teamId eklenen=$added cikarilan=$removed")
            }

            val meta = ESPNTakimKadroCache(
                cacheKey = cacheKey,
                league = league,
                teamId = teamId,
                teamName = teamName,
                seasonKey = seasonKey,
                rosterSyncedAt = rosterSyncedAt,
                rosterSignature = signature,
                injuryCheckedAt = injuryCheckedAt,
                lastSuccessfulAt = now
            )
            dao.rosterSnapshotKaydet(meta, rosterRows)
            dao.injurySnapshotKaydet(cacheKey, injuryCheckedAt, injuryRows.map { toStatusRow(cacheKey, it, injuryCheckedAt) })
        }

        val ready = TeamKadro(
            teamName = teamName,
            teamId = teamId,
            league = league,
            players = allPlayers,
            missing = missing,
            rosterAvailable = rosterJson != null && allPlayers.isNotEmpty(),
            injuryAvailable = injuries != null,
            ok = true,
            rosterSyncedAt = rosterSyncedAt,
            injuryCheckedAt = injuryCheckedAt,
            fromPersistentPool = false
        )
        teamCache[cacheKey] = ready
        logTeamData(ready, source = if (dao != null) "NETWORK_SAVED_TO_LOCAL_POOL" else "NETWORK")
        return ready
    }

    private suspend fun limitedGetJson(path: String): JsonObject =
        endpointSemaphore.withPermit { ESPNClient.getJson(path) }

    private suspend fun fetchInjuries(teamId: String, teamName: String, league: String): JsonObject? {
        val path = "apis/site/v2/sports/soccer/$league/teams/$teamId/injuries"
        return runCatching { limitedGetJson(path) }
            .onFailure { Log.w(TAG, "KADRO_ENDPOINT_HATASI team=$teamName id=$teamId league=$league endpoint=injuries error=${it.message}") }
            .getOrNull()
    }

    private fun teamKadroFromPool(
        meta: ESPNTakimKadroCache,
        rows: List<ESPNOyuncuHavuzu>,
        statuses: List<ESPNOyuncuDurumCache>,
        injuryFresh: Boolean
    ): TeamKadro {
        val statusById = if (injuryFresh) statuses.associateBy { it.playerId } else emptyMap()
        val players = rows.map { row ->
            OyuncuEtkiVerisi(
                oyuncuAdi = row.playerName,
                oyuncuId = row.playerId,
                pozisyon = runCatching { OyuncuPozisyonu.valueOf(row.position) }.getOrDefault(OyuncuPozisyonu.BELIRSIZ),
                dakikaOrtalamasi = if (row.appearances > 0) (row.minutes / row.appearances).coerceIn(0.0, 90.0) else 0.0,
                ilkOnBirOrani = if (row.appearances > 0) (row.starts.toDouble() / row.appearances).coerceIn(0.0, 1.0) else 0.0,
                macSayisi = row.appearances,
                ilkOnBirSayisi = row.starts,
                gol = row.goals,
                asist = row.assists,
                sut = row.shots,
                isabetliSut = row.shotsOnTarget,
                kurtaris = row.saves,
                golYeme = row.goalsAgainst,
                xg = row.xg,
                xa = row.xa,
                durum = statusById[row.playerId]?.let { parseStatusName(it.status) } ?: OyuncuDurumTipi.OYNAYACAK,
                manuelOnemSkoru = null
            )
        }
        val missing = if (injuryFresh) {
            statuses.mapNotNull { status ->
                val player = players.firstOrNull { it.oyuncuId == status.playerId } ?: return@mapNotNull null
                player.takeIf { it.durum != OyuncuDurumTipi.OYNAYACAK && it.durum != OyuncuDurumTipi.BELIRSIZ }
            }.distinctBy { it.oyuncuId ?: it.oyuncuAdi.lowercase(Locale.ROOT) }
        } else emptyList()
        return TeamKadro(
            teamName = meta.teamName,
            teamId = meta.teamId,
            league = meta.league,
            players = players,
            missing = missing,
            rosterAvailable = players.isNotEmpty(),
            injuryAvailable = injuryFresh,
            ok = players.isNotEmpty(),
            rosterSyncedAt = meta.rosterSyncedAt,
            injuryCheckedAt = meta.injuryCheckedAt,
            fromPersistentPool = true
        )
    }

    private fun applyStatuses(players: List<OyuncuEtkiVerisi>, injuries: List<PlayerBaseStatus>): List<OyuncuEtkiVerisi> {
        val statusById = injuries.associateBy { it.id }
        return players.map { player ->
            player.copy(
                durum = statusById[player.oyuncuId]?.status ?: OyuncuDurumTipi.OYNAYACAK
            )
        }
    }


    private fun ESPNOyuncuHavuzu.toPlayerForPool(): OyuncuEtkiVerisi = OyuncuEtkiVerisi(
        oyuncuAdi = playerName,
        oyuncuId = playerId,
        pozisyon = runCatching { OyuncuPozisyonu.valueOf(position) }.getOrDefault(OyuncuPozisyonu.BELIRSIZ),
        dakikaOrtalamasi = if (appearances > 0) (minutes / appearances).coerceIn(0.0, 90.0) else 0.0,
        ilkOnBirOrani = if (appearances > 0) (starts.toDouble() / appearances).coerceIn(0.0, 1.0) else 0.0,
        macSayisi = appearances,
        ilkOnBirSayisi = starts,
        gol = goals,
        asist = assists,
        sut = shots,
        isabetliSut = shotsOnTarget,
        kurtaris = saves,
        golYeme = goalsAgainst,
        xg = xg,
        xa = xa,
        durum = OyuncuDurumTipi.OYNAYACAK
    )

    private fun OyuncuEtkiVerisi.hasPlayerEvidence(): Boolean =
        macSayisi > 0 || dakikaOrtalamasi > 0.0 || gol > 0.0 || asist > 0.0 || xg > 0.0 || xa > 0.0 ||
            sut > 0.0 || isabetliSut > 0.0 || kurtaris > 0.0 || golYeme > 0.0

    private fun OyuncuEtkiVerisi.toPlayerBaseForStats(): PlayerBase = PlayerBase(
        id = oyuncuId ?: oyuncuAdi.lowercase(Locale.ROOT),
        name = oyuncuAdi,
        position = pozisyon,
        metrics = PlayerMetrics(
            goals = gol,
            assists = asist,
            minutes = dakikaOrtalamasi * macSayisi,
            appearances = macSayisi,
            starts = ilkOnBirSayisi,
            shots = sut,
            shotsOnTarget = isabetliSut,
            saves = kurtaris,
            goalsAgainst = golYeme,
            xg = xg,
            xa = xa
        )
    )

    private fun OyuncuEtkiVerisi.mergeMetrics(m: PlayerMetrics): OyuncuEtkiVerisi {
        val apps = maxOf(macSayisi, m.appearances)
        val mins = maxOf(dakikaOrtalamasi * macSayisi, m.minutes)
        val starts = maxOf(ilkOnBirSayisi, m.starts).coerceAtMost(apps)
        return copy(
            dakikaOrtalamasi = if (apps > 0) (mins / apps).coerceIn(0.0, 90.0) else 0.0,
            ilkOnBirOrani = if (apps > 0) (starts.toDouble() / apps).coerceIn(0.0, 1.0) else 0.0,
            macSayisi = apps,
            ilkOnBirSayisi = starts,
            gol = maxOf(gol, m.goals),
            asist = maxOf(asist, m.assists),
            sut = maxOf(sut, m.shots),
            isabetliSut = maxOf(isabetliSut, m.shotsOnTarget),
            kurtaris = maxOf(kurtaris, m.saves),
            golYeme = maxOf(golYeme, m.goalsAgainst),
            xg = maxOf(xg, m.xg),
            xa = maxOf(xa, m.xa)
        )
    }

    private fun OyuncuEtkiVerisi.toPoolRowModel(): ESPNOyuncuHavuzu = ESPNOyuncuHavuzu(
        teamKey = "",
        league = "",
        teamId = "",
        playerId = oyuncuId ?: oyuncuAdi.lowercase(Locale.ROOT),
        playerName = oyuncuAdi,
        position = pozisyon.name,
        minutes = dakikaOrtalamasi * macSayisi,
        appearances = macSayisi,
        starts = ilkOnBirSayisi,
        substitutionsIn = (macSayisi - ilkOnBirSayisi).coerceAtLeast(0),
        goals = gol,
        assists = asist,
        shots = sut,
        shotsOnTarget = isabetliSut,
        saves = kurtaris,
        goalsAgainst = golYeme,
        xg = xg,
        xa = xa,
        savedAt = System.currentTimeMillis()
    )

    private fun toPoolRow(
        teamKey: String,
        player: OyuncuEtkiVerisi,
        league: String,
        teamId: String,
        savedAt: Long
    ): ESPNOyuncuHavuzu = ESPNOyuncuHavuzu(
        teamKey = teamKey,
        league = league,
        teamId = teamId,
        playerId = player.oyuncuId ?: player.oyuncuAdi.lowercase(Locale.ROOT),
        playerName = player.oyuncuAdi,
        position = player.pozisyon.name,
        minutes = player.dakikaOrtalamasi * player.macSayisi,
        appearances = player.macSayisi,
        starts = player.ilkOnBirSayisi,
        substitutionsIn = (player.macSayisi - player.ilkOnBirSayisi).coerceAtLeast(0),
        goals = player.gol,
        assists = player.asist,
        shots = player.sut,
        shotsOnTarget = player.isabetliSut,
        saves = player.kurtaris,
        goalsAgainst = player.golYeme,
        xg = player.xg,
        xa = player.xa,
        savedAt = savedAt
    )

    private fun toStatusRow(teamKey: String, row: PlayerBaseStatus, checkedAt: Long): ESPNOyuncuDurumCache = ESPNOyuncuDurumCache(
        teamKey = teamKey,
        playerId = row.id,
        playerName = row.name,
        position = row.position.name,
        status = row.status.name,
        checkedAt = checkedAt
    )

    private fun parseStatusName(value: String): OyuncuDurumTipi =
        runCatching { OyuncuDurumTipi.valueOf(value) }.getOrDefault(OyuncuDurumTipi.BELIRSIZ)

    private fun seasonCompatible(stored: String, current: String): Boolean {
        if (stored.isBlank() || current.isBlank()) return false
        if (stored == current) return true
        val storedYear = Regex("\\d{4}").find(stored)?.value
        val currentYear = Regex("\\d{4}").find(current)?.value
        return storedYear != null && currentYear != null && storedYear == currentYear
    }

    private fun currentSeasonKey(): String {
        return java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
            .get(java.util.Calendar.YEAR)
            .toString()
    }

    private fun rosterSignature(ids: List<String>): String {
        val raw = ids.filter { it.isNotBlank() }.distinct().sorted().joinToString(",")
        return MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    private fun logTeamData(team: TeamKadro, source: String) {
        val topPlayers = team.players
            .map { it.oyuncuAdi to OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, it).etkiSkoru }
            .filter { it.second > 0.0 }
            .sortedByDescending { it.second }
            .take(3)
            .joinToString("|") { "${it.first}:${"%.1f".format(it.second)}" }
        Log.i(
            TAG,
            "KADRO_VERI_DETAY team=${team.teamName} id=${team.teamId} league=${team.league} " +
                "roster=true players=${team.players.size} injuries=${team.injuryAvailable} " +
                "actionableMissing=${team.missing.size} cache=${team.fromPersistentPool} source=$source top=$topPlayers"
        )
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

    private fun PlayerBase.copyMetrics(metrics: PlayerMetrics): PlayerBase =
        PlayerBase(id, name, position, metrics)


    private suspend fun enrichRosterWithSeasonStats(
        bases: List<PlayerBase>,
        league: String,
        seasonKey: String
    ): Map<String, PlayerMetrics> = coroutineScope {
        if (bases.isEmpty()) return@coroutineScope emptyMap()

        val year = seasonKey.take(4).toIntOrNull() ?: return@coroutineScope emptyMap()
        val current = bases.map { base ->
            async(Dispatchers.IO) {
                base.id to fetchPlayerStatsWithFallback(base.id, league, year)
            }
        }.map { deferred -> deferred.await() }
            .filter { it.second.hasMeaningfulEvidence() }
            .toMap()

        Log.i(
            TAG,
            "OYUNCU_ISTATISTIK_ZENGINLESTIRILDI league=$league oyuncu=${bases.size} kanit=${current.size}"
        )
        current
    }

    private suspend fun fetchPlayerStatsWithFallback(
        playerId: String,
        league: String,
        currentYear: Int
    ): PlayerMetrics = playerStatsSemaphore.withPermit {
        val years = listOf(currentYear, currentYear - 1)
        for ((index, year) in years.withIndex()) {
            val paths = listOf(
                "v2/sports/soccer/leagues/$league/seasons/$year/types/2/athletes/$playerId/statistics/0",
                "v2/sports/soccer/leagues/$league/seasons/$year/types/2/athletes/$playerId/statistics",
                "v2/sports/soccer/leagues/$league/athletes/$playerId/statistics/0"
            )
            for (path in paths) {
                val metrics = runCatching { parseStatisticsMetrics(ESPNClient.getCoreJson(path)) }
                    .getOrElse { PlayerMetrics() }
                if (metrics.hasMeaningfulEvidence()) {
                    // Eski sezon yalnızca mevcut sezonun oyuncuda kanıt üretmediği
                    // durum için taban kalite olarak kullanılır.
                    return@withPermit if (index == 0) metrics else metrics.scaled(0.65)
                }
            }
        }
        PlayerMetrics()
    }

    private fun PlayerMetrics.hasMeaningfulEvidence(): Boolean =
        minutes > 0.0 || appearances > 0 || starts > 0 || goals > 0.0 || assists > 0.0 ||
            shots > 0.0 || shotsOnTarget > 0.0 || saves > 0.0 || goalsAgainst > 0.0 ||
            xg > 0.0 || xa > 0.0

    private fun PlayerMetrics.scaled(factor: Double): PlayerMetrics = copy(
        goals = goals * factor,
        assists = assists * factor,
        minutes = minutes * factor,
        appearances = (appearances * factor).roundToInt(),
        starts = (starts * factor).roundToInt(),
        substitutionsIn = (substitutionsIn * factor).roundToInt(),
        shots = shots * factor,
        shotsOnTarget = shotsOnTarget * factor,
        saves = saves * factor,
        goalsAgainst = goalsAgainst * factor,
        xg = xg * factor,
        xa = xa * factor
    )

    private fun parseStatisticsMetrics(root: JsonObject?): PlayerMetrics {
        if (root == null) return PlayerMetrics()
        val out = PlayerMetrics()

        fun assign(rawName: String?, rawValue: Double?) {
            val name = rawName.orEmpty().lowercase(Locale.ROOT)
                .replace("_", "")
                .replace("-", "")
                .replace(" ", "")
                .replace("/", "")
            val value = rawValue ?: return
            when {
                name in setOf("gp", "gamesplayed", "appearances", "apps", "app", "appear") -> out.appearances = maxOf(out.appearances, value.roundToInt())
                name in setOf("gs", "starts", "start", "started") -> out.starts = maxOf(out.starts, value.roundToInt())
                name in setOf("min", "mins", "minutes", "minute") -> out.minutes = maxOf(out.minutes, value)
                name in setOf("g", "goals", "goal", "scored") -> out.goals = maxOf(out.goals, value)
                name in setOf("a", "ast", "assists", "assist") -> out.assists = maxOf(out.assists, value)
                name in setOf("sh", "shots", "shot") -> out.shots = maxOf(out.shots, value)
                name in setOf("sot", "st", "shotsontarget", "shotsongoal") -> out.shotsOnTarget = maxOf(out.shotsOnTarget, value)
                name in setOf("sv", "saves", "save") -> out.saves = maxOf(out.saves, value)
                name in setOf("ga", "goalsagainst", "goalagainst") -> out.goalsAgainst = maxOf(out.goalsAgainst, value)
                name in setOf("xg", "expectedgoals") -> out.xg = maxOf(out.xg, value)
                name in setOf("xa", "expectedassists") -> out.xa = maxOf(out.xa, value)
            }
        }

        fun num(el: JsonElement?): Double? = when {
            el == null || el.isJsonNull -> null
            el.isJsonPrimitive -> el.asString.replace(',', '.').toDoubleOrNull()
            else -> null
        }

        fun readParallelArrays(obj: JsonObject) {
            val labels = listOf("labels", "names", "abbreviations")
                .asSequence()
                .mapNotNull { key -> obj.get(key)?.let { e -> if (e.isJsonArray) e.asJsonArray else null } }
                .firstOrNull()
            val values = listOf("totals", "values", "displayValues")
                .asSequence()
                .mapNotNull { key -> obj.get(key)?.let { e -> if (e.isJsonArray) e.asJsonArray else null } }
                .firstOrNull()
            if (labels == null || values == null) return

            val n = minOf(labels.size(), values.size())
            for (i in 0 until n) {
                val label = labels[i].takeIf { e -> e.isJsonPrimitive }?.asString
                assign(label, num(values[i]))
            }
        }

        fun walk(node: JsonElement) {
            if (node.isJsonArray) {
                node.asJsonArray.forEach(::walk)
                return
            }
            if (!node.isJsonObject) return
            val obj = node.asJsonObject
            readParallelArrays(obj)

            val name = obj.getString("name")
                ?: obj.getString("displayName")
                ?: obj.getString("abbreviation")
            val value = obj.getDouble("value")
                ?: obj.getString("displayValue")?.replace(',', '.')?.toDoubleOrNull()
            if (name != null && value != null) assign(name, value)

            obj.entrySet().forEach { (_, child) -> walk(child) }
        }

        walk(root)
        if (out.appearances == 0 && out.starts > 0) out.appearances = out.starts
        if (out.substitutionsIn == 0 && out.appearances > out.starts) {
            out.substitutionsIn = out.appearances - out.starts
        }
        return out
    }

    private fun mergePlayerMetrics(
        rosterMetrics: Map<String, PlayerMetrics>,
        leaderMetrics: Map<String, PlayerMetrics>
    ): Map<String, PlayerMetrics> {
        val ids = (rosterMetrics.keys + leaderMetrics.keys).toSet()
        return ids.associateWith { id ->
            val a = rosterMetrics[id] ?: PlayerMetrics()
            val b = leaderMetrics[id] ?: PlayerMetrics()
            PlayerMetrics(
                goals = maxOf(a.goals, b.goals),
                assists = maxOf(a.assists, b.assists),
                minutes = maxOf(a.minutes, b.minutes),
                appearances = maxOf(a.appearances, b.appearances),
                starts = maxOf(a.starts, b.starts),
                substitutionsIn = maxOf(a.substitutionsIn, b.substitutionsIn),
                shots = maxOf(a.shots, b.shots),
                shotsOnTarget = maxOf(a.shotsOnTarget, b.shotsOnTarget),
                saves = maxOf(a.saves, b.saves),
                goalsAgainst = maxOf(a.goalsAgainst, b.goalsAgainst),
                xg = maxOf(a.xg, b.xg),
                xa = maxOf(a.xa, b.xa)
            )
        }
    }

    private fun toPlayer(
        base: PlayerBase,
        status: OyuncuDurumTipi
    ): OyuncuEtkiVerisi? {
        if (base.name.isBlank()) return null
        val m = base.metrics
        val appearances = if (m.appearances > 0) m.appearances else m.starts
        val derivedStarts = when {
            m.starts > 0 -> m.starts
            appearances > 0 && m.substitutionsIn > 0 -> (appearances - m.substitutionsIn).coerceAtLeast(0)
            else -> 0
        }
        val starts = derivedStarts.coerceAtMost(appearances)
        val startRatio = if (appearances > 0) (starts.toDouble() / appearances).coerceIn(0.0, 1.0) else 0.0
        val minuteAverage = if (m.minutes > 0.0 && appearances > 0) {
            (m.minutes / appearances).coerceIn(0.0, 90.0)
        } else 0.0

        return OyuncuEtkiVerisi(
            oyuncuAdi = base.name,
            oyuncuId = base.id,
            pozisyon = base.position,
            dakikaOrtalamasi = minuteAverage,
            ilkOnBirOrani = startRatio,
            macSayisi = appearances,
            ilkOnBirSayisi = starts,
            gol = m.goals.coerceAtLeast(0.0),
            asist = m.assists.coerceAtLeast(0.0),
            sut = m.shots.coerceAtLeast(0.0),
            isabetliSut = m.shotsOnTarget.coerceAtLeast(0.0),
            kurtaris = m.saves.coerceAtLeast(0.0),
            golYeme = m.goalsAgainst.coerceAtLeast(0.0),
            durum = status,
            manuelOnemSkoru = null
        )
    }

    private fun parseRoster(root: JsonObject?): List<PlayerBase> {
        if (root == null) return emptyList()
        val out = LinkedHashMap<String, PlayerBase>()
        walkObjects(root) { obj ->
            val id = obj.getString("id") ?: return@walkObjects
            val name = obj.getString("displayName")
                ?: obj.getString("fullName")
                ?: return@walkObjects
            val positionObj = obj.getAsJsonObjectOrNull("position")
            val position = positionFrom(
                positionObj?.getString("abbreviation")
                    ?: positionObj?.getString("displayName")
                    ?: obj.getString("position")
            )
            if (position != OyuncuPozisyonu.BELIRSIZ || obj.has("jersey") || obj.has("uniformNumber")) {
                val metrics = parseEmbeddedPlayerMetrics(obj)
                val old = out[id]
                out[id] = PlayerBase(
                    id = id,
                    name = name,
                    position = if (position != OyuncuPozisyonu.BELIRSIZ) position else old?.position ?: OyuncuPozisyonu.BELIRSIZ,
                    metrics = mergePlayerMetrics(
                        old?.metrics?.let { mapOf(id to it) }.orEmpty(),
                        mapOf(id to metrics)
                    ).getValue(id)
                )
            }
        }
        return out.values.toList()
    }

    private fun parseEmbeddedPlayerMetrics(player: JsonObject): PlayerMetrics {
        val out = PlayerMetrics()
        fun apply(name: String, value: Double) {
            val key = name.lowercase(Locale.ROOT).replace("_", "").replace("-", "").replace(" ", "")
            when {
                key in setOf("goal", "goals", "g") -> out.goals = maxOf(out.goals, value)
                key in setOf("assist", "assists", "a") -> out.assists = maxOf(out.assists, value)
                key in setOf("minutes", "minute", "min", "mins") -> out.minutes = maxOf(out.minutes, value)
                key in setOf("appearances", "appearance", "apps", "app", "games", "appear") -> out.appearances = maxOf(out.appearances, value.roundToInt())
                key in setOf("starts", "start", "startingappearances", "started") -> out.starts = maxOf(out.starts, value.roundToInt())
                key in setOf("subins", "subsin", "substituteappearances", "subappearances", "sub", "sb") -> out.substitutionsIn = maxOf(out.substitutionsIn, value.roundToInt())
                key in setOf("shots", "sh", "shot") -> out.shots = maxOf(out.shots, value)
                key in setOf("shotsontarget", "sot", "st", "shotsongoal") -> out.shotsOnTarget = maxOf(out.shotsOnTarget, value)
                key in setOf("saves", "sv", "save") -> out.saves = maxOf(out.saves, value)
                key in setOf("goalsagainst", "ga", "goalagainst") -> out.goalsAgainst = maxOf(out.goalsAgainst, value)
                key in setOf("xg", "expectedgoals") -> out.xg = maxOf(out.xg, value)
                key in setOf("xa", "expectedassists") -> out.xa = maxOf(out.xa, value)
            }
        }

        walkObjects(player) { obj ->
            obj.entrySet().forEach { (k, v) ->
                if (v.isJsonPrimitive) {
                    v.asString.toDoubleOrNull()?.let { apply(k, it) }
                }
            }
            val statName = obj.getString("name")
                ?: obj.getString("displayName")
                ?: obj.getString("abbreviation")
            val statValue = obj.getDouble("value")
                ?: obj.getString("displayValue")?.replace(",", ".")?.toDoubleOrNull()
            if (statName != null && statValue != null) apply(statName, statValue)
        }
        if (out.appearances == 0 && out.starts > 0) out.appearances = out.starts
        return out
    }

    private fun parseInjuries(root: JsonObject?): List<PlayerBaseStatus> {
        if (root == null) return emptyList()
        val out = LinkedHashMap<String, PlayerBaseStatus>()
        walkObjects(root) { obj ->
            val athlete = obj.getAsJsonObjectOrNull("athlete") ?: obj.getAsJsonObjectOrNull("player") ?: return@walkObjects
            val id = athlete.getString("id") ?: return@walkObjects
            val name = athlete.getString("displayName")
                ?: athlete.getString("fullName")
                ?: return@walkObjects
            val positionObj = athlete.getAsJsonObjectOrNull("position")
            val position = positionFrom(
                positionObj?.getString("abbreviation")
                    ?: positionObj?.getString("displayName")
                    ?: athlete.getString("position")
            )
            val statusText = listOf(
                obj.getAsJsonObjectOrNull("status")?.getString("name"),
                obj.getAsJsonObjectOrNull("status")?.getString("type"),
                obj.getString("status"),
                obj.getString("type"),
                obj.getString("shortComment"),
                obj.getString("longComment"),
                obj.getAsJsonObjectOrNull("details")?.getString("type")
            ).filterNotNull().joinToString(" ")
            out[id] = PlayerBaseStatus(id, name, position, injuryStatus(statusText))
        }
        return out.values.toList()
    }

    private data class PlayerBaseStatus(
        val id: String,
        val name: String,
        val position: OyuncuPozisyonu,
        val status: OyuncuDurumTipi
    )

    private fun parseLeaders(root: JsonObject?): Map<String, PlayerMetrics> {
        if (root == null) return emptyMap()
        val out = mutableMapOf<String, PlayerMetrics>()

        // ESPN'nin leaders şeması lig/season/endpoint'e göre değişebiliyor.
        // Sadece root.leaders dizisine güvenmek yerine ağaç boyunca athlete/player
        // + numeric value çiftlerini arıyor; kategori adı için en yakın üst başlığı
        // koruyoruz. Bu, Manchester City gibi bazı takımlarda görülen
        // "leaders=true ama top=boş" durumunu önler.
        fun applyMetric(m: PlayerMetrics, rawName: String, value: Double) {
            val name = rawName.lowercase(Locale.ROOT).replace('_', ' ').replace('-', ' ')
            when {
                name.contains("goal") && !name.contains("against") -> m.goals = maxOf(m.goals, value)
                name.contains("assist") -> m.assists = maxOf(m.assists, value)
                name.contains("minute") -> m.minutes = maxOf(m.minutes, value)
                name.contains("appearance") || name == "apps" || name == "app" -> m.appearances = maxOf(m.appearances, value.roundToInt())
                name.contains("start") -> m.starts = maxOf(m.starts, value.roundToInt())
                name.contains("shot on") || name.contains("shots on") || name == "sot" || name == "st" -> m.shotsOnTarget = maxOf(m.shotsOnTarget, value)
                name == "shots" || name.endsWith(" shots") || name == "sh" -> m.shots = maxOf(m.shots, value)
                name.contains("save") -> m.saves = maxOf(m.saves, value)
                name.contains("goals against") || name == "ga" -> m.goalsAgainst = maxOf(m.goalsAgainst, value)
                name == "xg" || name.contains("expected goals") -> m.xg = maxOf(m.xg, value)
                name == "xa" || name.contains("expected assists") -> m.xa = maxOf(m.xa, value)
            }
        }

        fun numeric(obj: JsonObject): Double? =
            obj.getDouble("value")
                ?: obj.getString("displayValue")?.replace(',', '.')?.toDoubleOrNull()
                ?: obj.getString("value")?.replace(',', '.')?.toDoubleOrNull()

        fun walk(node: JsonElement, hint: String = "") {
            if (node.isJsonArray) {
                node.asJsonArray.forEach { walk(it, hint) }
                return
            }
            if (!node.isJsonObject) return
            val obj = node.asJsonObject

            val athlete = obj.getAsJsonObjectOrNull("athlete") ?: obj.getAsJsonObjectOrNull("player")
            if (athlete != null) {
                val id = athlete.getString("id")
                val statName = obj.getString("name")
                    ?: obj.getString("displayName")
                    ?: obj.getString("abbreviation")
                    ?: hint
                val value = numeric(obj)
                if (!id.isNullOrBlank() && value != null && statName.isNotBlank()) {
                    applyMetric(out.getOrPut(id) { PlayerMetrics() }, statName, value)
                }
            }

            obj.entrySet().forEach { (key, value) ->
                val nextHint = when {
                    key.equals("leaders", ignoreCase = true) ||
                        key.equals("categories", ignoreCase = true) ||
                        key.equals("statistics", ignoreCase = true) ||
                        key.equals("stats", ignoreCase = true) ->
                        obj.getString("name")
                            ?: obj.getString("displayName")
                            ?: obj.getString("abbreviation")
                            ?: hint
                    else -> hint
                }
                walk(value, nextHint)
            }
        }

        walk(root)
        return out
    }

    private fun positionFrom(value: String?): OyuncuPozisyonu {
        val v = value.orEmpty().lowercase(Locale.ROOT)
        return when {
            v.contains("goal") || v == "g" || v == "gk" || v.contains("keeper") || v.contains("kaleci") -> OyuncuPozisyonu.KALECI
            v.contains("def") || v == "d" || v == "df" || v.contains("back") || v.contains("defender") -> OyuncuPozisyonu.DEFANS
            v.contains("mid") || v == "m" || v == "mf" || v.contains("wing") || v.contains("orta") -> OyuncuPozisyonu.ORTA_SAHA
            v.contains("for") || v == "f" || v == "fw" || v.contains("striker") || v.contains("forward") || v.contains("attack") -> OyuncuPozisyonu.FORVET
            else -> OyuncuPozisyonu.BELIRSIZ
        }
    }

    private fun injuryStatus(text: String): OyuncuDurumTipi {
        val v = text.lowercase(Locale.ROOT)
        return when {
            v.contains("suspend") || v.contains("ceza") || v.contains("red card") ||
                (v.contains("yellow card") && (v.contains("accumul") || v.contains("suspend"))) ||
                (v.contains("booking") && v.contains("suspend")) -> OyuncuDurumTipi.CEZALI
            v.contains("question") || v.contains("doubt") || v.contains("day-to-day") -> OyuncuDurumTipi.SUPHELI
            v.contains("rest") || v.contains("rotation") -> OyuncuDurumTipi.DINLENDIRILIYOR
            v.contains("out") || v.contains("injur") || v.contains("ill") -> OyuncuDurumTipi.SAKAT
            v.isBlank() -> OyuncuDurumTipi.BELIRSIZ
            v.contains("not playing") || v.contains("unavailable") || v.contains("ruled out") -> OyuncuDurumTipi.SAKAT
            v.contains("inactive") || v.contains("not in squad") -> OyuncuDurumTipi.KADRO_DISI
            else -> OyuncuDurumTipi.BELIRSIZ
        }
    }

    private fun matchMatches(event: IddaaEvent, home: String, away: String): Boolean =
        sameTeam(event.hn, home) && sameTeam(event.an, away)

    private fun sameTeam(a: String, b: String): Boolean {
        val aa = aliases(a)
        val bb = aliases(b)
        return aa.any(bb::contains)
    }

    private fun aliases(v: String): Set<String> {
        val base = normalize(v)
        if (base.isBlank()) return emptySet()
        val tokens = base.split(' ').filter { it.isNotBlank() }
        val out = linkedSetOf(base, base.replace(" ", ""))
        val wrappers = setOf("fc", "afc", "sc", "cf", "cd", "ac", "ca", "fk", "nk", "sk", "sv", "ks", "ud", "ad", "us", "as", "club")
        if (tokens.firstOrNull() in wrappers && tokens.size > 1) out += tokens.drop(1).joinToString(" ")
        if (tokens.lastOrNull() in wrappers && tokens.size > 1) out += tokens.dropLast(1).joinToString(" ")
        val core = tokens.filter { it !in wrappers }
        if (core.isNotEmpty()) out += core.joinToString(" ")
        return out
    }

    private fun normalize(value: String): String = value
        .lowercase(Locale.forLanguageTag("tr-TR"))
        .replace('ı', 'i').replace('İ', 'i').replace('ş', 's').replace('Ş', 's')
        .replace('ğ', 'g').replace('Ğ', 'g').replace('ü', 'u').replace('Ü', 'u')
        .replace('ö', 'o').replace('Ö', 'o').replace('ç', 'c').replace('Ç', 'c')
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim().replace(Regex("\\s+"), " ")

    private fun walkObjects(root: JsonElement, action: (JsonObject) -> Unit) {
        when {
            root.isJsonObject -> {
                val obj = root.asJsonObject
                action(obj)
                obj.entrySet().forEach { walkObjects(it.value, action) }
            }
            root.isJsonArray -> root.asJsonArray.forEach { walkObjects(it, action) }
        }
    }

    private fun JsonObject.getString(key: String): String? =
        get(key)?.let { if (!it.isJsonNull && it.isJsonPrimitive) it.asString else null }

    private fun JsonObject.getDouble(key: String): Double? =
        get(key)?.let { if (!it.isJsonNull && it.isJsonPrimitive) runCatching { it.asDouble }.getOrNull() else null }

    private fun JsonObject.getAsJsonObjectOrNull(key: String): JsonObject? =
        get(key)?.let { if (it.isJsonObject) it.asJsonObject else null }

}
