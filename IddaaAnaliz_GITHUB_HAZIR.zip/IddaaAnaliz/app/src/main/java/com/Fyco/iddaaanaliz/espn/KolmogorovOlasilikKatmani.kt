@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import kotlin.math.exp
import kotlin.math.max

/**
 * Olasılık uzayının matematiksel tutarlılık katmanı.
 *
 * Kurallar:
 * 1) P(E) >= 0
 * 2) P(Ω) = 1
 * 3) Ayrık olayların birleşimi = olasılıkların toplamı
 *
 * Futbolda temel örnek uzayını skor çiftleri (ev golü, deplasman golü)
 * olarak alıyoruz. Bütün bahis marketleri bu ortak dağılımdan türetilir.
 */
object KolmogorovOlasilikKatmani {

    data class SkorDagilimi(
        val hucreler: Map<Pair<Int, Int>, Double>,
        val toplam: Double
    )

    fun poissonDagilimi(
        lambdaEv: Double,
        lambdaDep: Double,
        maxGol: Int = 8,
        rho: Double = DIXON_COLES_RHO
    ): SkorDagilimi {
        val le = lambdaEv.coerceIn(0.05, 6.0)
        val ld = lambdaDep.coerceIn(0.05, 6.0)
        val ev = poisson(le, maxGol)
        val dep = poisson(ld, maxGol)
        val raw = linkedMapOf<Pair<Int, Int>, Double>()

        for (h in 0..maxGol) {
            for (a in 0..maxGol) {
                val correction = when {
                    h == 0 && a == 0 -> 1.0 - le * ld * rho
                    h == 0 && a == 1 -> 1.0 + le * rho
                    h == 1 && a == 0 -> 1.0 + ld * rho
                    h == 1 && a == 1 -> 1.0 - rho
                    else -> 1.0
                }
                raw[h to a] = (ev[h] * dep[a] * correction).coerceAtLeast(0.0)
            }
        }

        return normalize(raw)
    }

    fun macSonucu(d: SkorDagilimi): Triple<Double, Double, Double> {
        var home = 0.0
        var draw = 0.0
        var away = 0.0
        d.hucreler.forEach { (score, p) ->
            when {
                score.first > score.second -> home += p
                score.first == score.second -> draw += p
                else -> away += p
            }
        }
        return normalizeTriplet(home, draw, away)
    }

    fun over(d: SkorDagilimi, line: Double): Double {
        val underOrEqual = d.hucreler
            .filterKeys { it.first + it.second <= kotlin.math.floor(line).toInt() }
            .values
            .sum()
        return (1.0 - underOrEqual).coerceIn(0.0, 1.0)
    }

    fun btts(d: SkorDagilimi): Double {
        return d.hucreler
            .filterKeys { it.first > 0 && it.second > 0 }
            .values
            .sum()
            .coerceIn(0.0, 1.0)
    }

    fun normalize(values: Map<Pair<Int, Int>, Double>): SkorDagilimi {
        val nonNegative = values.mapValues { (_, p) ->
            if (p.isFinite()) max(0.0, p) else 0.0
        }
        val sum = nonNegative.values.sum()
        if (sum <= 0.0) {
            val uniform = 1.0 / nonNegative.size.coerceAtLeast(1)
            return SkorDagilimi(nonNegative.mapValues { uniform }, 1.0)
        }
        val normalized = nonNegative.mapValues { (_, p) -> p / sum }
        val correctedSum = normalized.values.sum()
        return SkorDagilimi(normalized, correctedSum)
    }

    fun isValid(d: SkorDagilimi): Boolean {
        if (d.hucreler.values.any { !it.isFinite() || it < -1e-12 }) return false
        return kotlin.math.abs(d.hucreler.values.sum() - 1.0) <= 1e-9
    }

    private const val DIXON_COLES_RHO = -0.08

    private fun poisson(lambda: Double, maxGol: Int): DoubleArray {
        val result = DoubleArray(maxGol + 1)
        result[0] = exp(-lambda)
        for (k in 1..maxGol) {
            result[k] = result[k - 1] * lambda / k.toDouble()
        }
        return result
    }

    private fun normalizeTriplet(a: Double, b: Double, c: Double): Triple<Double, Double, Double> {
        val x = listOf(a, b, c).map { max(0.0, it) }
        val sum = x.sum().coerceAtLeast(1e-12)
        return Triple(x[0] / sum, x[1] / sum, x[2] / sum)
    }
}
