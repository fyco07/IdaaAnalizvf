@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import android.content.Context
import android.util.Log
import kotlinx.coroutines.runBlocking
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

/**
 * ============================================================
 * ESPN KENDİ MODEL REPOSITORY
 * ============================================================
 *
 * Görevi:
 *
 * 1. Eğitimden çıkan takım ratinglerini Room'dan yükler.
 * 2. Model meta bilgisini yükler.
 * 3. Canlı maçtaki İddaa takım adını ESPN eğitim takımına
 *    güvenli şekilde eşleştirir.
 *
 * Eşleştirme sırası:
 *
 * 1) Tam normalize
 * 2) Compact normalize
 * 3) Güvenli prefix/suffix varyantı
 * 4) Token eşleşmesi
 * 5) Güvenli fuzzy eşleşme
 *
 * ÖNEMLİ:
 *
 * Fuzzy eşleşme agresif değildir.
 *
 * "United"
 * "United B"
 *
 * gibi iki farklı takımı yanlış bağlamamak için
 * minimum skor ve belirsizlik kontrolü uygulanır.
 */
object ESPNKendiModelRepository {

    private const val TAG = "ESPN_MODEL_REPO"

    @Volatile
    private var initialized = false

    @Volatile
    private var ratings: Map<String, ESPNModelTakimRating> = emptyMap()

    @Volatile
    private var meta: ESPNModelMeta? = null

    /** Hızlı alias/normalize indeksleri. 1270+ maçlık taramada her takım
     * için binlerce rating taramak yerine O(1)/küçük aday kümeleri kullanılır. */
    @Volatile
    private var tokenIndex: Map<String, List<ESPNModelTakimRating>> = emptyMap()

    @Volatile
    private var fuzzyIndex: Map<String, List<ESPNModelTakimRating>> = emptyMap()

    private val matchCache = ConcurrentHashMap<String, ESPNModelTakimRating>()
    private val missingCache = ConcurrentHashMap.newKeySet<String>()

    /**
     * ------------------------------------------------------------
     * BAŞLAT
     * ------------------------------------------------------------
     */
    fun init(context: Context) {
        if (initialized) return
        refresh(context)
    }

    /**
     * ------------------------------------------------------------
     * ROOM'DAN MODELİ YENİLE
     * ------------------------------------------------------------
     */
    fun refresh(context: Context) {

        val sonuc = runBlocking {

            val db =
                com.Fyco.iddaaanaliz.veritabani.IddaaAnalizDatabase
                    .getInstance(context)

            val dbRatings =
                db.espnModelTakimRatingDao()
                    .hepsiniGetir()

            val yeniRatings =
                mutableMapOf<String, ESPNModelTakimRating>()

            for (rating in dbRatings) {

                val canonical =
                    anahtar(rating.takimAdi)

                if (canonical.isBlank()) {
                    continue
                }

                /*
                 * Ana anahtar.
                 */
                yeniRatings[canonical] = rating

                /*
                 * Boşluksuz alternatif.
                 */
                val compact =
                    compactAnahtar(canonical)

                if (compact.isNotBlank()) {
                    yeniRatings.putIfAbsent(
                        compact,
                        rating
                    )
                }
            }

            val yeniMeta =
                db.espnModelMetaDao()
                    .metaGetir()

            val benzersiz = yeniRatings.values.distinctBy {
                "${it.takimAdi}|${it.lig ?: ""}"
            }

            val yeniTokenIndex = mutableMapOf<String, MutableList<ESPNModelTakimRating>>()
            val yeniFuzzyIndex = mutableMapOf<String, MutableList<ESPNModelTakimRating>>()

            for (rating in benzersiz) {
                val ratingKey = anahtar(rating.takimAdi)
                anlamliTokenler(ratingKey).forEach { token ->
                    yeniTokenIndex.getOrPut(token) { mutableListOf() }.add(rating)
                }

                val compactKey = compactAnahtar(ratingKey)
                if (compactKey.length >= 3) {
                    yeniFuzzyIndex.getOrPut(compactKey.take(3)) { mutableListOf() }.add(rating)
                }
            }

            Triple(
                Pair(yeniRatings.toMap(), yeniMeta),
                yeniTokenIndex.mapValues { it.value.distinctBy { r -> "${r.takimAdi}|${r.lig ?: ""}" } },
                yeniFuzzyIndex.mapValues { it.value.distinctBy { r -> "${r.takimAdi}|${r.lig ?: ""}" } }
            )
        }

        ratings = sonuc.first.first
        meta = sonuc.first.second
        tokenIndex = sonuc.second
        fuzzyIndex = sonuc.third
        matchCache.clear()
        missingCache.clear()
        initialized = true

        Log.i(
            TAG,
            "REPOSITORY_HAZIR " +
                    "ratingDB=${ratings.size} " +
                    "meta=${meta != null} " +
                    "tokenIndex=${tokenIndex.size} " +
                    "fuzzyIndex=${fuzzyIndex.size}"
        )
    }

    /**
     * ------------------------------------------------------------
     * TAKIM RATING GETİR
     * ------------------------------------------------------------
     *
     * İddaa'dan gelen takım adı burada ESPN eğitimindeki
     * takım adıyla eşleştirilir.
     */
    fun takim(
        takimAdi: String?
    ): ESPNModelTakimRating? {

        val isim =
            takimAdi
                ?.trim()
                .orEmpty()

        if (isim.isBlank()) {
            return null
        }

        val key = anahtar(isim)
        matchCache[key]?.let { return it }
        if (missingCache.contains(key)) return null

        /*
         * --------------------------------------------------------
         * 1. TAM NORMALIZE
         * --------------------------------------------------------
         */
        ratings[key]?.let {
            Log.d(
                TAG,
                "TAKIM_ESLESTI_TAM " +
                        "$isim -> ${it.takimAdi}"
            )
            return it
        }

        /*
         * --------------------------------------------------------
         * 2. COMPACT
         * --------------------------------------------------------
         */
        val compact =
            compactAnahtar(key)

        if (compact.isNotBlank()) {

            ratings[compact]?.let {

                Log.d(
                    TAG,
                    "TAKIM_ESLESTI_COMPACT " +
                            "$isim -> ${it.takimAdi}"
                )

                return it
            }
        }

        /*
         * --------------------------------------------------------
         * 3. KATEGORİ GÜVENLİĞİ
         * --------------------------------------------------------
         *
         * Exact/compact kayıt yoksa U19/U21/Women/II/B/MG gibi kategori
         * etiketlerini düşürüp başka bir takım adına dönmek yasaktır.
         * Bu kontrol token ve fuzzy öncesinde yapılır.
         */
        if (kategoriEtiketiVar(key)) {
            Log.d(
                TAG,
                "KATEGORI_GUVENLIK_NEDENIYLE_ESLESMEDI aranan=$isim key=$key"
            )
            missingCache.add(key)
            return null
        }

        /*
         * --------------------------------------------------------
         * 4. GÜVENLİ VARYANTLAR
         * --------------------------------------------------------
         */
        val variants =
            takimVaryantlari(isim)

        for (variant in variants) {

            val variantKey =
                anahtar(variant)

            ratings[variantKey]?.let {

                Log.d(
                    TAG,
                    "TAKIM_ESLESTI_VARYANT " +
                            "$isim -> ${it.takimAdi}"

                )

                return it
            }

            val variantCompact =
                compactAnahtar(variantKey)

            if (variantCompact.isNotBlank()) {

                ratings[variantCompact]?.let {

                    Log.d(
                        TAG,
                        "TAKIM_ESLESTI_VARYANT_COMPACT " +
                                "$isim -> ${it.takimAdi}"
                    )

                    return it
                }
            }
        }

        /*
         * --------------------------------------------------------
         * 4. TOKEN EŞLEŞMESİ
         * --------------------------------------------------------
         *
         * Örnek:
         *
         * "Amiens SC"
         * "Amiens"
         *
         * veya
         *
         * "Colon FC"
         * "Colon"
         */
        val tokenMatch =
            tokenEslesmesi(key)

        if (tokenMatch != null) {

            Log.d(
                TAG,
                "TAKIM_ESLESTI_TOKEN " +
                        "$isim -> ${tokenMatch.takimAdi}"
            )

            return tokenMatch
        }

        // Token eşleşmesi bulunamadıysa fuzzy de kategori güvenliğini
        // hiçbir koşulda aşmamalıdır. Bu kontrol özellikle "Athletic Club MG"
        // gibi isimlerin "Athletic Club"a düşmesini engeller.
        if (kategoriEtiketiVar(key)) {
            return null
        }

        /*
         * --------------------------------------------------------
         * 5. GÜVENLİ FUZZY
         * --------------------------------------------------------
         *
         * Burada çok dikkatli davranıyoruz.
         *
         * Minimum skor:
         * 0.92
         *
         * İkinci aday ile fark:
         * en az 0.05
         *
         * Böylece birbirine çok benzeyen iki takım arasında
         * rastgele seçim yapılmaz.
         */
        val fuzzyMatch =
            fuzzyEslesmesi(key)

        if (fuzzyMatch != null) {

            Log.d(
                TAG,
                "TAKIM_ESLESTI_FUZZY " +
                        "$isim -> ${fuzzyMatch.takimAdi}"
            )

            return fuzzyMatch
        }

        /*
         * --------------------------------------------------------
         * BULUNAMADI
         * --------------------------------------------------------
         */
        Log.d(
            TAG,
            "TAKIM_BULUNAMADI " +
                    "aranan=$isim " +
                    "anahtar=$key"
        )

        missingCache.add(key)
        return null
    }

    /**
     * ------------------------------------------------------------
     * MODEL META
     * ------------------------------------------------------------
     */
    fun modelMeta(): ESPNModelMeta? {
        return meta
    }

    /**
     * ------------------------------------------------------------
     * MODEL HAZIR MI?
     * ------------------------------------------------------------
     */
    fun veriHazir(): Boolean {

        return ratings.isNotEmpty() &&
                meta != null &&
                meta?.gecerliMi() == true
    }

    /**
     * ------------------------------------------------------------
     * NORMALIZE
     * ------------------------------------------------------------
     */
    fun anahtar(
        value: String?
    ): String {

        if (value.isNullOrBlank()) {
            return ""
        }

        var text =
            value
                .trim()
                .lowercase(Locale.ROOT)

        /*
         * Türkçe karakterler.
         */
        text = text
            .replace('ı', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')

        /*
         * Özel Latin karakterler.
         */
        text = text
            .replace('đ', 'd')
            .replace('ð', 'd')
            .replace('ħ', 'h')
            .replace('ĸ', 'k')
            .replace('ł', 'l')
            .replace('ø', 'o')
            .replace('ŧ', 't')
            .replace('æ', 'a')
            .replace('œ', 'o')
            .replace('þ', 't')
            .replace('ß', 's')

        /*
         * Unicode NFD.
         */
        text =
            Normalizer
                .normalize(
                    text,
                    Normalizer.Form.NFD
                )
                .replace(
                    Regex("\\p{Mn}+"),
                    ""
                )

        /*
         * Nadir karakterlerin tekrar temizlenmesi.
         */
        text = text
            .replace('đ', 'd')
            .replace('ð', 'd')
            .replace('ħ', 'h')
            .replace('ł', 'l')
            .replace('ø', 'o')
            .replace('æ', 'a')
            .replace('œ', 'o')
            .replace('ß', 's')
            .replace('þ', 't')

        /*
         * Harf/rakam dışındaki karakterleri boşluk yap.
         */
        text =
            text.replace(
                Regex("[^a-z0-9]+"),
                " "
            )

        /*
         * Fazla boşlukları temizle.
         */
        return text
            .replace(
                Regex("\\s+"),
                " "
            )
            .trim()
    }

    /**
     * ------------------------------------------------------------
     * COMPACT ANAHTAR
     * ------------------------------------------------------------
     */
    private fun compactAnahtar(
        value: String
    ): String {

        return value
            .replace(
                Regex("[^a-z0-9]"),
                ""
            )
    }

    /**
     * ------------------------------------------------------------
     * TAKIM VARYANTLARI
     * ------------------------------------------------------------
     */
    private fun takimVaryantlari(
        value: String
    ): List<String> {

        val original =
            value.trim()

        if (original.isBlank()) {
            return emptyList()
        }

        val variants =
            linkedSetOf<String>()

        variants.add(original)

        val normalized =
            anahtar(original)

        if (normalized.isNotBlank()) {
            variants.add(normalized)
        }

        /*
         * --------------------------------------------------------
         * KADIN TAKIMI ETİKETLERİ
         * --------------------------------------------------------
         *
         * Kadın/erkek karışmasını önlemek için W/K/F gibi
         * ifadeleri doğrudan silmiyoruz.
         *
         * Önce sadece parantezli veri sağlayıcı etiketlerini
         * ayrı varyant olarak değerlendiriyoruz.
         */
        /*
         * --------------------------------------------------------
         * YAYGIN PREFIX
         * --------------------------------------------------------
         */
        val prefixRegex =
            Regex(
                "^(fc|fk|afc|sc|ac|as|ss|sv|sk|nk|cd|cf|rc|rcd|"
                        + "real|sporting|club)\\s+",
                RegexOption.IGNORE_CASE
            )

        if (prefixRegex.containsMatchIn(normalized)) {

            val withoutPrefix =
                normalized
                    .replaceFirst(
                        prefixRegex,
                        ""
                    )
                    .trim()

            if (withoutPrefix.isNotBlank()) {
                variants.add(withoutPrefix)
            }
        }

        /*
         * --------------------------------------------------------
         * YAYGIN SUFFIX
         * --------------------------------------------------------
         */
        val suffixRegex =
            Regex(
                "\\s+(fc|fk|sc|ac|as|afc|cf|cd|sk|sv|ss|club)$",
                RegexOption.IGNORE_CASE
            )

        if (suffixRegex.containsMatchIn(normalized)) {

            val withoutSuffix =
                normalized
                    .replaceFirst(
                        suffixRegex,
                        ""
                    )
                    .trim()

            if (withoutSuffix.isNotBlank()) {
                variants.add(withoutSuffix)
            }
        }

        /*
         * --------------------------------------------------------
         * PREFIX + SUFFIX
         * --------------------------------------------------------
         */
        val both =
            normalized
                .replaceFirst(
                    prefixRegex,
                    ""
                )
                .replaceFirst(
                    suffixRegex,
                    ""
                )
                .trim()

        if (both.isNotBlank()) {
            variants.add(both)
        }

        return variants.toList()
    }

    /**
     * ------------------------------------------------------------
     * TOKEN EŞLEŞMESİ
     * ------------------------------------------------------------
     *
     * Sadece takım isimlerinden oluşan güçlü tokenları
     * karşılaştırır.
     */
    private fun tokenEslesmesi(
        key: String
    ): ESPNModelTakimRating? {

        if (key.isBlank()) {
            return null
        }

        val inputTokens =
            anlamliTokenler(key)

        if (inputTokens.isEmpty()) {
            return null
        }

        var best: ESPNModelTakimRating? = null
        var bestScore = 0.0
        var secondScore = 0.0

        val adaylar = inputTokens
            .flatMap { tokenIndex[it].orEmpty() }
            .distinctBy { "${it.takimAdi}|${it.lig ?: ""}" }

        for (rating in adaylar) {

            val candidateKey =
                anahtar(rating.takimAdi)

            val candidateTokens =
                anlamliTokenler(candidateKey)

            if (candidateTokens.isEmpty()) {
                continue
            }

            val ortak =
                inputTokens.intersect(
                    candidateTokens.toSet()
                ).size

            if (ortak == 0) {
                continue
            }

            val coverage =
                ortak.toDouble() /
                        max(
                            inputTokens.size,
                            candidateTokens.size
                        ).toDouble()

            /*
             * Tek token için token eşleşmesi yeterince güvenilir
             * değil. Örneğin:
             *
             * "United"
             *
             * yüzlerce takımda olabilir.
             */
            if (inputTokens.size == 1 &&
                candidateTokens.size > 1
            ) {
                continue
            }

            val score =
                when {
                    coverage >= 1.0 -> 0.97
                    coverage >= 0.75 -> 0.93
                    coverage >= 0.66 -> 0.90
                    else -> 0.0
                }

            if (score <= 0.0) {
                continue
            }

            if (score > bestScore) {
                secondScore = bestScore
                bestScore = score
                best = rating
            } else if (score > secondScore) {
                secondScore = score
            }
        }

        if (best == null) {
            return null
        }

        /*
         * İkinci aday çok yakınsa seçim yapma.
         */
        if (bestScore - secondScore < 0.035) {
            Log.d(
                TAG,
                "TOKEN_BELIRSIZ " +
                        "key=$key " +
                        "best=$bestScore " +
                        "second=$secondScore"
            )
            return null
        }

        return best
    }

    private fun kategoriEtiketiVar(key: String): Boolean {
        val k = " $key "
        val youth = Regex("\\b(u17|u18|u19|u20|u21|u23|youth|junior|rezerv|reserve|ii|b|mg)\\b", RegexOption.IGNORE_CASE)
        val women = Regex("\\b(k|kadın|women|woman|w|female|f)\\b|\\((k|kadın|women|woman|w|female|f)\\)", RegexOption.IGNORE_CASE)
        return youth.containsMatchIn(k) || women.containsMatchIn(k)
    }

    /**
     * ------------------------------------------------------------
     * FUZZY EŞLEŞMESİ
     * ------------------------------------------------------------
     */
    private fun fuzzyEslesmesi(
        key: String
    ): ESPNModelTakimRating? {

        if (key.isBlank()) {
            return null
        }

        /*
         * Çok kısa takım adlarında fuzzy eşleşme yapma.
         *
         * Örneğin:
         * "Roma"
         * "PSV"
         *
         * için tam/compact/varyant daha güvenlidir.
         */
        val compactInput =
            compactAnahtar(key)

        if (compactInput.length < 4) {
            return null
        }

        var best: ESPNModelTakimRating? = null
        var bestScore = 0.0
        var secondScore = 0.0

        val prefix = compactInput.take(3)
        val indexed = if (prefix.length == 3) fuzzyIndex[prefix].orEmpty() else emptyList()
        val adaylar = if (indexed.isNotEmpty()) indexed else benzersizRatingler()

        for (rating in adaylar) {

            val candidateKey =
                anahtar(rating.takimAdi)

            val candidateCompact =
                compactAnahtar(candidateKey)

            if (candidateCompact.length < 4) {
                continue
            }

            /*
             * Kadın/erkek takımlarını fuzzy ile birbirine
             * bağlamamak için.
             */
            if (cinsiyetEtiketiFarkli(
                    key,
                    candidateKey
                )
            ) {
                continue
            }

            val score =
                benzerlikSkoru(
                    compactInput,
                    candidateCompact
                )

            if (score < FUZZY_MIN_SCORE) {
                continue
            }

            if (score > bestScore) {
                secondScore = bestScore
                bestScore = score
                best = rating
            } else if (score > secondScore) {
                secondScore = score
            }
        }

        if (best == null) {
            return null
        }

        /*
         * En iyi aday ile ikinci aday birbirine çok yakınsa
         * eşleştirmiyoruz.
         */
        if (bestScore - secondScore < FUZZY_MIN_GAP) {

            Log.d(
                TAG,
                "FUZZY_BELIRSIZ " +
                        "key=$key " +
                        "best=${best?.takimAdi} " +
                        "bestScore=$bestScore " +
                        "secondScore=$secondScore"
            )

            return null
        }

        Log.d(
            TAG,
            "FUZZY_SKOR " +
                    "aranan=$key " +
                    "eslesen=${best.takimAdi} " +
                    "score=$bestScore " +
                    "second=$secondScore"
        )

        return best
    }

    /**
     * ------------------------------------------------------------
     * BENZERLİK
     * ------------------------------------------------------------
     *
     * Levenshtein tabanlı normalize benzerlik.
     */
    private fun benzerlikSkoru(
        a: String,
        b: String
    ): Double {

        if (a == b) {
            return 1.0
        }

        if (a.isBlank() || b.isBlank()) {
            return 0.0
        }

        /*
         * Biri diğerinin tamamını içeriyorsa ayrıca kontrol et.
         */
        if (a.length >= 5 && b.length >= 5) {

            if (a.contains(b) || b.contains(a)) {

                val shortLength =
                    min(a.length, b.length).toDouble()

                val longLength =
                    max(a.length, b.length).toDouble()

                val containment =
                    shortLength / longLength

                /*
                 * Örneğin:
                 *
                 * colonfc
                 * colon
                 *
                 * kabul edilebilir.
                 *
                 * united
                 * manchesterunited
                 *
                 * doğrudan kabul edilmez.
                 */
                if (containment >= 0.70) {
                    return max(
                        0.90,
                        containment
                    )
                }
            }
        }

        val distance =
            levenshtein(
                a,
                b
            )

        val maxLength =
            max(
                a.length,
                b.length
            )

        if (maxLength == 0) {
            return 1.0
        }

        return 1.0 -
                distance.toDouble() /
                maxLength.toDouble()
    }

    /**
     * ------------------------------------------------------------
     * LEVENSHTEIN
     * ------------------------------------------------------------
     */
    private fun levenshtein(
        a: String,
        b: String
    ): Int {

        if (a == b) {
            return 0
        }

        if (a.isEmpty()) {
            return b.length
        }

        if (b.isEmpty()) {
            return a.length
        }

        var previous =
            IntArray(
                b.length + 1
            ) { it }

        var current =
            IntArray(
                b.length + 1
            )

        for (i in a.indices) {

            current[0] = i + 1

            for (j in b.indices) {

                val cost =
                    if (a[i] == b[j]) {
                        0
                    } else {
                        1
                    }

                current[j + 1] =
                    min(
                        min(
                            current[j] + 1,
                            previous[j + 1] + 1
                        ),
                        previous[j] + cost
                    )
            }

            val temp =
                previous

            previous = current
            current = temp
        }

        return previous[b.length]
    }

    /**
     * ------------------------------------------------------------
     * ANLAMLI TOKENLER
     * ------------------------------------------------------------
     */
    private fun anlamliTokenler(
        key: String
    ): List<String> {

        val ignored =
            setOf(
                "fc",
                "fk",
                "afc",
                "sc",
                "ac",
                "as",
                "ss",
                "sv",
                "sk",
                "nk",
                "cd",
                "cf",
                "rc",
                "rcd",
                "real",
                "sporting",
                "club"
            )

        return key
            .split(" ")
            .map { it.trim() }
            .filter {
                it.isNotBlank() &&
                        it !in ignored &&
                        it.length >= 3
            }
    }

    /**
     * ------------------------------------------------------------
     * CİNSİYET ETİKETİ
     * ------------------------------------------------------------
     */
    private fun cinsiyetEtiketiFarkli(
        a: String,
        b: String
    ): Boolean {

        val aWomen =
            Regex(
                "(^|\\s)(k|kadın|women|woman|w|female|f)(\\s|$)"
            ).containsMatchIn(a)

        val bWomen =
            Regex(
                "(^|\\s)(k|kadın|women|woman|w|female|f)(\\s|$)"
            ).containsMatchIn(b)

        return aWomen != bWomen
    }

    /**
     * ------------------------------------------------------------
     * BENZERSİZ RATINGLER
     * ------------------------------------------------------------
     *
     * ratings mapinde compact anahtarlar da bulunduğu için
     * aynı takım iki kere dolaşılmamalı.
     */
    private fun benzersizRatingler():
            Collection<ESPNModelTakimRating> {

        return ratings
            .values
            .distinctBy {
                "${it.takimAdi}|${it.lig ?: ""}"
            }
    }

    /**
     * ------------------------------------------------------------
     * FUZZY SABİTLERİ
     * ------------------------------------------------------------
     */
    private const val FUZZY_MIN_SCORE = 0.92
    private const val FUZZY_MIN_GAP = 0.05

    /**
     * ------------------------------------------------------------
     * RESET
     * ------------------------------------------------------------
     */
    fun temizle() {

        ratings = emptyMap()
        meta = null
        tokenIndex = emptyMap()
        fuzzyIndex = emptyMap()
        matchCache.clear()
        missingCache.clear()
        initialized = false

        Log.i(
            TAG,
            "REPOSITORY_TEMIZLENDI"
        )
    }
}