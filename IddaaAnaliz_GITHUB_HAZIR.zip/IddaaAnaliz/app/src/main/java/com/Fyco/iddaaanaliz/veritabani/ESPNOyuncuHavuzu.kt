@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import androidx.room.Entity
import androidx.room.Index

/**
 * ESPN'den alınan takım oyuncu verisinin kalıcı yerel havuzu.
 *
 * Roster/stats tekrar tekrar ağdan çekilmez; takım bazında yenileme zamanı
 * gelene kadar bu tablo kullanılır. Maç günü durumları ayrı tabloda tutulur.
 */
@Entity(
    tableName = "espn_oyuncu_havuzu",
    primaryKeys = ["teamKey", "playerId"],
    indices = [
        Index(value = ["teamKey"]),
        Index(value = ["playerId"]),
        Index(value = ["league", "teamId"])
    ]
)
data class ESPNOyuncuHavuzu(
    val teamKey: String,
    val league: String,
    val teamId: String,
    val playerId: String,
    val playerName: String,
    val position: String,
    val minutes: Double,
    val appearances: Int,
    val starts: Int,
    val substitutionsIn: Int,
    val goals: Double,
    val assists: Double,
    val shots: Double,
    val shotsOnTarget: Double,
    val saves: Double,
    val goalsAgainst: Double,
    val xg: Double,
    val xa: Double,
    val savedAt: Long
)

/** Takımın roster yenileme ve durum kontrolü metaverisi. */
@Entity(tableName = "espn_takim_kadro_cache")
data class ESPNTakimKadroCache(
    @androidx.room.PrimaryKey val cacheKey: String,
    val league: String,
    val teamId: String,
    val teamName: String,
    val seasonKey: String,
    val rosterSyncedAt: Long,
    val rosterSignature: String,
    val injuryCheckedAt: Long,
    val lastSuccessfulAt: Long
)

/** Maç günü ESPN sakatlık/ceza/kadro dışı durumlarının son snapshot'ı. */
@Entity(
    tableName = "espn_oyuncu_durum_cache",
    primaryKeys = ["teamKey", "playerId"],
    indices = [Index(value = ["teamKey"])]
)
data class ESPNOyuncuDurumCache(
    val teamKey: String,
    val playerId: String,
    val playerName: String,
    val position: String,
    val status: String,
    val checkedAt: Long
)
