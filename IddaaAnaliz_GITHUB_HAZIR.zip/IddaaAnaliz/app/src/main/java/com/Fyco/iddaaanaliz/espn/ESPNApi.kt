@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import retrofit2.http.GET
import retrofit2.http.Query

interface ESPNApi {
    @GET("apis/site/v2/sports/soccer/all/scoreboard")
    suspend fun skorTahtasi(
        @Query("dates") tarih: String,
        @Query("limit") limit: Int = 1000
    ): JsonObject
}

data class ESPNScoreboardResponse(
    val events: List<ESPNEvent> = emptyList()
)

data class ESPNEvent(
    val id: String? = null,
    val date: String? = null,
    val season: ESPNSeason? = null,
    val status: ESPNStatus? = null,
    val competitions: List<ESPNCompetition> = emptyList()
)

data class ESPNSeason(
    val year: Int? = null,
    val slug: String? = null
)

data class ESPNCompetition(
    val competitors: List<ESPNCompetitor> = emptyList(),
    val status: ESPNStatus? = null
)

data class ESPNCompetitor(
    val id: String? = null,
    val homeAway: String? = null,
    val winner: Boolean? = null,
    val score: JsonElement? = null,
    val team: ESPNTeam? = null
)

data class ESPNTeam(
    val id: String? = null,
    val displayName: String? = null
)

data class ESPNStatus(
    val type: ESPNStatusType? = null
)

data class ESPNStatusType(
    val completed: Boolean? = null,
    val name: String? = null,
    val state: String? = null,
    val description: String? = null,
    val detail: String? = null
)
