@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.espn

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.Fyco.iddaaanaliz.MerkeziVeriHavuzu
import java.util.concurrent.TimeUnit

/**
 * Tarihsel veri tamamlandıktan sonra merkezi futbol modelini kurar.
 * Eski ESPN rating DB'si artık tahmin zincirinin bir parçası değildir.
 */
class ESPNModelTrainingWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val context = applicationContext
        return try {
            MerkeziVeriHavuzu.init(context)
                        // ESPN tarihsel kayıtları merkezi havuza taşınır; mevcut merkezi kayıtlar silinmez.
            MerkeziVeriHavuzu.espnTarihselYaz(context)
            val model = MerkeziVeriHavuzu.futbolModeliniHazirla(force = true)

            if (model != null && model.ready) {
                Log.i(
                    TAG,
                    "MERKEZI_MODEL_WORKER_TAMAMLANDI history=${model.historyMatches} takim=${model.teams.size}"
                )
                Result.success()
            } else {
                Log.w(TAG, "MERKEZI_MODEL_WORKER_YETERSIZ history=${model?.historyMatches ?: 0}")
                Result.success()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "MERKEZI_MODEL_WORKER_HATA ${t::class.java.simpleName}: ${t.message}", t)
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "ESPN_KENDI_MODEL_EGITIM_V17"
        private const val TAG = "ESPN_MODEL_WORKER"

        fun enqueue(context: Context) {
            val request = OneTimeWorkRequestBuilder<ESPNModelTrainingWorker>()
                .setBackoffCriteria(
                    androidx.work.BackoffPolicy.EXPONENTIAL,
                    30,
                    TimeUnit.SECONDS
                )
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME,
                ExistingWorkPolicy.KEEP,
                request
            )
            Log.i(TAG, "MERKEZI_MODEL_WORKER_KUYRUGA_ALINDI")
        }
    }
}
