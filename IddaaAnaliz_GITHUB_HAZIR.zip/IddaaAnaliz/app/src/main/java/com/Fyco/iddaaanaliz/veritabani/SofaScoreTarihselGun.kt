@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.veritabani

import androidx.room.Entity

@Entity(
    tableName = "sofascore_tarihsel_gunler",
    primaryKeys = ["gun", "spor"]
)
data class SofaScoreTarihselGun(
    val gun: String,
    val spor: String,
    val tamamlandi: Boolean = false,
    val macSayisi: Int = 0,
    val sonDeneme: Long = System.currentTimeMillis()
)
