@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * Tahmin geçmişini cihaz üzerinde saklar.
 *
 * Room eklemeden SharedPreferences + JSON kullanıyoruz.
 * Amaç:
 * - aynı tahmini tekrar tekrar çoğaltmamak
 * - maç sonucu belli olduğunda tahmini sonuçla eşleştirmek
 * - kaynakların uzun vadeli performansını ölçmek
 */
data class TahminKaydi(
    val anahtar: String,
    val eventId: Long,
    val marketId: Long,
    val secimNo: Int,
    val secim: String,
    val marketBasligi: String = "",
    val sov: String? = null,
    val organizasyon: String = "",
    val spor: String,
    val evSahibi: String,
    val deplasman: String,
    val macZamani: Long,
    val kayitZamani: Long,
    val oran: Double,
    val olasilik: Double,
    val iddaaOlasiligi: Double?,
    val progSportOlasiligi: Double?,
    val kendiModelOlasiligi: Double?,
    val karar: String,
    val guvenPuani: Int,
    val sonuc: Boolean? = null,
    val sonucZamani: Long? = null
)

object TahminOgrenmeRepository {
    private const val TAG = "IddaaOgrenme"

    private const val PREFS = "iddaa_analiz_ogrenme"
    private const val KEY = "tahminler_v1"
    private const val MAX_KAYIT = 50000

    private var appContext: Context? = null
    private val initialized = AtomicBoolean(false)

    // Kritik performans düzeltmesi:
    // Her tahminde SharedPreferences JSON'unu tekrar okuyup baştan yazmak
    // ana thread üzerinde O(n^2) maliyet oluşturuyordu.
    // Tahminler artık bellekte tutulur; disk yazımı tek arka plan işçisinde
    // birleştirilir (coalescing). Böylece 10+ tahmin kaydı sırasında UI kilitlenmez.
    private val diskExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "IddaaOgrenme-DB").apply { isDaemon = true }
    }
    private val diskWriteScheduled = AtomicBoolean(false)
    @Volatile
    private var memoryCache: MutableMap<String, TahminKaydi>? = null

    fun init(context: Context) {
        if (initialized.compareAndSet(false, true)) {
            appContext = context.applicationContext
            // İlk JSON parse yalnızca bir kez yapılır. Sonraki tüm okumalar
            // bellekteki snapshot üzerinden gider.
            memoryCache = readFromDisk(context.applicationContext)
                .associateByTo(linkedMapOf()) { it.anahtar }
        }
    }

    @Synchronized
    fun kaydetVeyaGuncelle(kayit: TahminKaydi) {
        if (appContext == null) return

        val mevcut = memoryCache ?: linkedMapOf<String, TahminKaydi>().also {
            memoryCache = it
        }

        val eski = mevcut[kayit.anahtar]
        mevcut[kayit.anahtar] = if (eski != null) {
            kayit.copy(
                kayitZamani = eski.kayitZamani,
                sonuc = eski.sonuc,
                sonucZamani = eski.sonucZamani
            )
        } else {
            kayit
        }

        // Sınırı yalnızca gerçekten aşıldığında uygula. Her tahminde 22K
        // kaydı sorted/take ile yeniden kopyalamak büyük GC baskısı yaratıyordu.
        if (mevcut.size > MAX_KAYIT) {
            val oldestKey = mevcut.values
                .minByOrNull { it.kayitZamani }
                ?.anahtar
            if (oldestKey != null) mevcut.remove(oldestKey)
        }

        queueDiskWrite()

        val toplam = mevcut.size

        Log.i(
            TAG,
            "TAHMİN_KAYDEDİLDİ event=${kayit.eventId} market=${kayit.marketId} " +
                    "secim=${kayit.secimNo} spor=${kayit.spor} marketBasligi=${kayit.marketBasligi} " +
                    "oran=${kayit.oran} olasilik=${kayit.olasilik} toplam=$toplam"
        )
    }

    @Synchronized
    fun tumunuGetir(): List<TahminKaydi> {
        memoryCache?.let {
            return it.values.sortedByDescending { kayit -> kayit.kayitZamani }
        }
        val context = appContext ?: return emptyList()
        val loaded = readFromDisk(context)
            .associateByTo(linkedMapOf()) { it.anahtar }
        memoryCache = loaded
        return loaded.values.sortedByDescending { it.kayitZamani }
    }

    fun cozulenleriGetir(): List<TahminKaydi> =
        tumunuGetir().filter { it.sonuc != null }

    fun bekleyenleriGetir(): List<TahminKaydi> =
        tumunuGetir().filter { it.sonuc == null }

    @Synchronized
    fun sonucuIsle(
        eventId: Long,
        marketId: Long,
        secimNo: Int,
        kazandi: Boolean
    ): Boolean {
        val context = appContext ?: return false
        val mevcut = memoryCache ?: return false
        val key = mevcut.entries.firstOrNull { (_, kayit) ->
            kayit.eventId == eventId &&
                    kayit.marketId == marketId &&
                    kayit.secimNo == secimNo
        }?.key ?: return false

        val eski = mevcut[key] ?: return false
        mevcut[key] = eski.copy(
            sonuc = kazandi,
            sonucZamani = System.currentTimeMillis()
        )

        queueDiskWrite()

        Log.i(
            TAG,
            "TAHMİN_SONUCU_İŞLENDİ event=$eventId market=$marketId secim=$secimNo " +
                    "sonuc=${if (kazandi) "KAZANDI" else "KAYBETTİ"} " +
                    "çözülen=${mevcut.values.count { it.sonuc != null }}"
        )

        return true
    }

    @Synchronized
    fun temizle() {
        diskDirty.set(false)
        memoryCache = linkedMapOf()
        appContext
            ?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            ?.edit()
            ?.remove(KEY)
            ?.apply()
    }

    private fun readFromDisk(context: Context): List<TahminKaydi> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null)
            ?: return emptyList()
        return try {
            fromJson(JSONArray(raw))
        } catch (_: Exception) {
            emptyList()
        }
    }

    private val diskDirty = AtomicBoolean(false)

    private fun queueDiskWrite() {
        diskDirty.set(true)
        if (!diskWriteScheduled.compareAndSet(false, true)) return

        diskExecutor.execute {
            try {
                while (diskDirty.getAndSet(false)) {
                    Thread.sleep(500L)
                    val context = appContext ?: break
                    val snapshot = synchronized(this@TahminOgrenmeRepository) {
                        memoryCache?.values
                            ?.sortedByDescending { it.kayitZamani }
                            ?.take(MAX_KAYIT)
                            .orEmpty()
                    }
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit()
                        .putString(KEY, toJson(snapshot))
                        .apply()
                }
            } finally {
                diskWriteScheduled.set(false)
                if (diskDirty.get()) queueDiskWrite()
            }
        }
    }

    private fun toJson(kayitlar: List<TahminKaydi>): String {
        val array = JSONArray()

        kayitlar.forEach { k ->
            array.put(
                JSONObject().apply {
                    put("anahtar", k.anahtar)
                    put("eventId", k.eventId)
                    put("marketId", k.marketId)
                    put("secimNo", k.secimNo)
                    put("secim", k.secim)
                    put("marketBasligi", k.marketBasligi)
                    putNullable("sov", k.sov)
                    put("organizasyon", k.organizasyon)
                    put("spor", k.spor)
                    put("evSahibi", k.evSahibi)
                    put("deplasman", k.deplasman)
                    put("macZamani", k.macZamani)
                    put("kayitZamani", k.kayitZamani)
                    put("oran", k.oran)
                    put("olasilik", k.olasilik)
                    putNullable("iddaaOlasiligi", k.iddaaOlasiligi)
                    putNullable("progSportOlasiligi", k.progSportOlasiligi)
                    putNullable("kendiModelOlasiligi", k.kendiModelOlasiligi)
                    put("karar", k.karar)
                    put("guvenPuani", k.guvenPuani)
                    putNullable("sonuc", k.sonuc)
                    putNullable("sonucZamani", k.sonucZamani)
                }
            )
        }

        return array.toString()
    }

    private fun JSONObject.putNullable(key: String, value: Any?) {
        if (value == null) {
            put(key, JSONObject.NULL)
        } else {
            put(key, value)
        }
    }

    private fun fromJson(array: JSONArray): List<TahminKaydi> {
        val result = mutableListOf<TahminKaydi>()

        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue

            result += TahminKaydi(
                anahtar = o.optString("anahtar"),
                eventId = o.optLong("eventId"),
                marketId = o.optLong("marketId"),
                secimNo = o.optInt("secimNo"),
                secim = o.optString("secim"),
                marketBasligi = o.optString("marketBasligi", ""),
                sov = o.optNullableString("sov"),
                organizasyon = o.optString("organizasyon", ""),
                spor = o.optString("spor"),
                evSahibi = o.optString("evSahibi"),
                deplasman = o.optString("deplasman"),
                macZamani = o.optLong("macZamani"),
                kayitZamani = o.optLong("kayitZamani"),
                oran = o.optDouble("oran", 0.0),
                olasilik = o.optDouble("olasilik", 0.0),
                iddaaOlasiligi = o.optNullableDouble("iddaaOlasiligi"),
                progSportOlasiligi = o.optNullableDouble("progSportOlasiligi"),
                kendiModelOlasiligi = o.optNullableDouble("kendiModelOlasiligi"),
                karar = o.optString("karar"),
                guvenPuani = o.optInt("guvenPuani"),
                sonuc = o.optNullableBoolean("sonuc"),
                sonucZamani = o.optNullableLong("sonucZamani")
            )
        }

        return result
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

    private fun JSONObject.optNullableDouble(key: String): Double? =
        if (isNull(key)) null else optDouble(key, Double.NaN).takeIf { it.isFinite() }

    private fun JSONObject.optNullableBoolean(key: String): Boolean? =
        if (isNull(key)) null else optBoolean(key)

    private fun JSONObject.optNullableLong(key: String): Long? =
        if (isNull(key)) null else optLong(key)

    fun performansOzeti(): OgrenmePerformans {
        val resolved = cozulenleriGetir()
        if (resolved.isEmpty()) return OgrenmePerformans()

        val kazanan = resolved.count { it.sonuc == true }
        val brierFinal = resolved.map {
            val y = if (it.sonuc == true) 1.0 else 0.0
            val d = it.olasilik - y
            d * d
        }.average()

        return OgrenmePerformans(
            cozulenTahmin = resolved.size,
            kazanan = kazanan,
            kaybeden = resolved.size - kazanan,
            basariOrani = kazanan.toDouble() / max(1, resolved.size),
            finalBrier = brierFinal
        )
    }
}

data class OgrenmePerformans(
    val cozulenTahmin: Int = 0,
    val kazanan: Int = 0,
    val kaybeden: Int = 0,
    val basariOrani: Double = 0.0,
    val finalBrier: Double = 0.0
)
