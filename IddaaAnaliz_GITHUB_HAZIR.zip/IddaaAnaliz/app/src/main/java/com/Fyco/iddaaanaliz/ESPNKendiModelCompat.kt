@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

/** Eski package kullanan dosyalar için geriye dönük uyumluluk. */
typealias ESPNKendiModelRepository = com.Fyco.iddaaanaliz.espn.ESPNKendiModelRepository
typealias ESPNKendiModelTahmincisi = com.Fyco.iddaaanaliz.espn.ESPNKendiModelTahmincisi
typealias ESPNHistoryWorker = com.Fyco.iddaaanaliz.espn.ESPNHistoryWorker
