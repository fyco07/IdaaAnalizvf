@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz.merkezi

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "merkezi_match", indices = [Index(value = ["sport", "startTs"]), Index(value = ["homeTeamId", "awayTeamId", "startTs"]), Index(value = ["leagueId"])])
data class MerkeziMatch(
    @PrimaryKey val matchId: String,
    val externalId: String?,
    val sport: String,
    val homeTeamId: String,
    val awayTeamId: String,
    val homeTeamName: String,
    val awayTeamName: String,
    val leagueId: String?,
    val leagueName: String?,
    val seasonId: String?,
    val seasonName: String?,
    val startTs: Long,
    val status: String = "scheduled",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "merkezi_team", indices = [Index(value = ["sport", "normalizedName"], unique = true)])
data class MerkeziTeam(
    @PrimaryKey val teamId: String,
    val sport: String,
    val name: String,
    val normalizedName: String,
    val leagueId: String? = null,
    val leagueName: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "merkezi_league", indices = [Index(value = ["sport", "normalizedName"], unique = true)])
data class MerkeziLeague(
    @PrimaryKey val leagueId: String,
    val sport: String,
    val name: String,
    val normalizedName: String,
    val country: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "merkezi_season", indices = [Index(value = ["leagueId", "normalizedName"], unique = true)])
data class MerkeziSeason(
    @PrimaryKey val seasonId: String,
    val leagueId: String,
    val name: String,
    val normalizedName: String,
    val startTs: Long? = null,
    val endTs: Long? = null
)

@Entity(tableName = "merkezi_market", indices = [Index(value = ["matchId", "marketKey"], unique = true)])
data class MerkeziMarket(
    @PrimaryKey val marketId: String,
    val matchId: String,
    val marketKey: String,
    val title: String,
    val sport: String,
    val settlementType: String = "single"
)

@Entity(tableName = "merkezi_odds", indices = [Index(value = ["marketId", "outcomeKey"], unique = true), Index(value = ["matchId", "capturedAt"])])
data class MerkeziOdds(
    @PrimaryKey val oddsId: String,
    val matchId: String,
    val marketId: String,
    val outcomeKey: String,
    val outcomeName: String,
    val odd: Double,
    val source: String,
    val capturedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "merkezi_source_data", indices = [Index(value = ["matchId", "source", "capturedAt"])])
data class MerkeziSourceData(
    @PrimaryKey val sourceDataId: String,
    val matchId: String,
    val source: String,
    val payloadJson: String,
    val capturedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "merkezi_result", indices = [Index(value = ["matchId"], unique = true)])
data class MerkeziResult(
    @PrimaryKey val resultId: String,
    val matchId: String,
    val homeScore: Double,
    val awayScore: Double,
    val homeFirstHalf: Double? = null,
    val awayFirstHalf: Double? = null,
    val completedAt: Long,
    val source: String
)

@Entity(tableName = "merkezi_prediction", indices = [Index(value = ["matchId", "marketKey", "outcomeKey", "createdAt"])])
data class MerkeziPrediction(
    @PrimaryKey val predictionId: String,
    val matchId: String,
    val marketKey: String,
    val outcomeKey: String,
    val modelProbability: Double,
    val marketProbability: Double?,
    val edge: Double?,
    val ev: Double?,
    val confidence: Double,
    val createdAt: Long = System.currentTimeMillis(),
    val result: String? = null,
    val brierError: Double? = null
)
