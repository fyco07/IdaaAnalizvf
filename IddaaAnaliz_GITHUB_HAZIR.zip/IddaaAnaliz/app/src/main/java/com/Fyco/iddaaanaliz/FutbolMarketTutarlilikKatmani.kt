@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.util.Log
import java.util.Locale
import kotlin.math.abs

/**
 * Futbol marketleri arasındaki çapraz-market matematiksel tutarlılık katmanı.
 *
 * Temel kural:
 * Kendi Modeli bütün ana futbol marketlerini aynı skor dağılımından üretir.
 * Bu sınıf yeni bir olasılık üretmez; yalnızca marketler arasında imkânsız
 * veya ciddi biçimde çelişkili bir sonuç varsa ilgili seçimi güvenli biçimde
 * OYNAMA'ya düşürür.
 *
 * Kontroller:
 * - MS 1/X/2 toplamı yaklaşık 1
 * - Alt/Üst tamamlayıcılığı
 * - Alt/Üst çizgilerinin monotonluğu
 * - KG Var <= Üst 1.5
 * - Aynı maçta bağımsız kaynakların aşırı ayrışması
 *
 * İddaa oranı bu matematiksel katmana girdi değildir; yalnızca karar/EV
 * katmanında kullanılır.
 */
object FutbolMarketTutarlilikKatmani {

    private const val EPS = 0.035
    private const val HARD_EPS = 0.08

    fun uygula(
        marketler: List<MarketAnalizSonucu>
    ): List<MarketAnalizSonucu> {
        if (marketler.isEmpty()) return marketler

        val normalized = marketler.map { sonuc ->
            sonuc to normalize(sonuc.baslik)
        }

        val resultMarket = normalized.firstOrNull { (_, title) ->
            isMatchResult(title)
        }?.first

        val totalMarkets = normalized.mapNotNull { (sonuc, title) ->
            if (isFullMatchTotal(title)) {
                val line = extractLine(title)
                if (line != null) Triple(sonuc, title, line) else null
            } else null
        }

        val bttsMarket = normalized.firstOrNull { (_, title) ->
            isBtts(title)
        }?.first

        val result = normalized.map { (marketSonucu, title) ->
            var secimler = marketSonucu.secimler

            if (resultMarket != null && marketSonucu.market.i == resultMarket.market.i) {
                secimler = kontrolEtMacSonucu(secimler)
            }

            if (isFullMatchTotal(title)) {
                secimler = kontrolEtAltUst(secimler)
            }

            marketSonucu.copy(secimler = secimler)
        }.toMutableList()

        // Alt/Üst çizgileri: Üst olasılığı çizgi yükseldikçe artamaz.
        // Örn. P(Üst 3.5) <= P(Üst 2.5) <= P(Üst 1.5)
        val sortedTotals = totalMarkets.sortedBy { it.third }
        for (i in 0 until sortedTotals.size - 1) {
            val lowerLine = sortedTotals[i]
            val higherLine = sortedTotals[i + 1]

            val lowerOver = secimOlasiligi(lowerLine.first, "ust")
            val higherOver = secimOlasiligi(higherLine.first, "ust")

            if (lowerOver != null && higherOver != null && lowerOver > 0.0 && higherOver > 0.0) {
                val fark = higherOver - lowerOver
                if (fark > HARD_EPS) {
                    Log.w(
                        "IddaaOgrenme",
                        "MARKET_TUTARSIZ toplam alt=${lowerLine.third} üst=${higherLine.third} " +
                                "pAlt=$lowerOver pUst=$higherOver fark=$fark"
                    )
                    // Hangi tarafın güvenilir olduğunu tek başına bilmiyoruz.
                    // Bu yüzden yalnızca yüksek çizginin ÜST seçimini düşürüyoruz;
                    // düşük çizginin ÜST olasılığı korunuyor.
                    result.replaceMarket(
                        higherLine.first.market.i,
                        downgradeSelections(higherLine.first.secimler) { selection ->
                            normalize(selection.secim) == "ust"
                        },
                        reason = "Alt/Üst çizgileri arasında matematiksel tutarsızlık."
                    )
                }
            }
        }

        // KG Var, toplam 1.5 Üst olasılığından büyük olamaz.
        if (bttsMarket != null) {
            val bttsVar = secimOlasiligi(bttsMarket, "var")
            val over15 = totalMarkets
                .firstOrNull { abs(it.third - 1.5) < 0.001 }
                ?.first
                ?.let { secimOlasiligi(it, "üst") }

            if (bttsVar != null && over15 != null && bttsVar > 0.0 && over15 > 0.0 && bttsVar - over15 > EPS) {
                Log.w(
                    "IddaaOgrenme",
                    "MARKET_TUTARSIZ KG_VAR>$over15 UST_1_5 btts=$bttsVar"
                )
                result.replaceMarket(
                    bttsMarket.market.i,
                    downgradeSelections(bttsMarket.secimler) { selection ->
                        normalize(selection.secim) == "var"
                    },
                    reason = "KG Var olasılığı Üst 1.5 olasılığını aşamaz."
                )
            }
        }

        return result.map { marketSonucu ->
            marketSonucu.copy(
                secimler = marketSonucu.secimler.map { it }
            )
        }
    }

    private fun kontrolEtMacSonucu(
        secimler: List<AnalizSonucu>
    ): List<AnalizSonucu> {
        val one = secimOlasiligi(secimler, "1")
        val draw = secimOlasiligi(secimler, "x") ?: secimOlasiligi(secimler, "0")
        val two = secimOlasiligi(secimler, "2")

        if (one == null || draw == null || two == null) return secimler
        if (one <= 0.0 || draw <= 0.0 || two <= 0.0) return secimler

        val sum = one + draw + two
        if (!sum.isFinite() || abs(sum - 1.0) > HARD_EPS) {
            Log.w("IddaaOgrenme", "MARKET_TUTARSIZ MS toplam=$sum")
            return secimler.map { secim ->
                if (normalize(secim.secim) in setOf("1", "x", "0", "2")) {
                    downgrade(secim, "MS 1/X/2 ortak olasılık dağılımıyla tutarsız.")
                } else secim
            }
        }

        return secimler
    }

    private fun kontrolEtAltUst(
        secimler: List<AnalizSonucu>
    ): List<AnalizSonucu> {
        val alt = secimOlasiligi(secimler, "alt")
        val ust = secimOlasiligi(secimler, "üst")

        if (alt == null || ust == null) return secimler
        if (alt <= 0.0 || ust <= 0.0) return secimler

        if (abs((alt + ust) - 1.0) > HARD_EPS) {
            Log.w("IddaaOgrenme", "MARKET_TUTARSIZ ALT_UST toplam=${alt + ust}")
            return secimler.map { secim ->
                if (normalize(secim.secim) == "alt" || normalize(secim.secim) == "ust") {
                    downgrade(secim, "Alt/Üst tamamlayıcılığı bozuldu.")
                } else secim
            }
        }

        return secimler
    }

    private fun secimOlasiligi(
        market: MarketAnalizSonucu,
        selection: String
    ): Double? = secimOlasiligi(market.secimler, selection)

    private fun secimOlasiligi(
        secimler: List<AnalizSonucu>,
        selection: String
    ): Double? {
        val target = normalize(selection)
        return secimler
            .firstOrNull { normalize(it.secim) == target }
            ?.gelmeOlasiligi
            ?.takeIf { it.isFinite() && it in 0.0..1.0 }
    }

    private fun downgrade(
        secim: AnalizSonucu,
        reason: String
    ): AnalizSonucu {
        if (secim.karar == Karar.VERI_YETERSIZ) return secim
        return secim.copy(
            karar = Karar.OYNAMA,
            aciklama = reason + " Oynama önerisi verilmedi."
        )
    }

    private fun downgradeSelections(
        secimler: List<AnalizSonucu>,
        predicate: (AnalizSonucu) -> Boolean
    ): List<AnalizSonucu> = secimler.map { secim ->
        if (predicate(secim)) {
            downgrade(secim, "Çapraz-market tutarlılık filtresi devreye girdi.")
        } else secim
    }

    private fun MutableList<MarketAnalizSonucu>.replaceMarket(
        marketId: Long,
        newSelections: List<AnalizSonucu>,
        reason: String
    ) {
        val index = indexOfFirst { it.market.i == marketId }
        if (index < 0) return
        this[index] = this[index].copy(
            secimler = newSelections.map { selection ->
                if (selection.karar == Karar.OYNA &&
                    selection.aciklama == "Çapraz-market tutarlılık filtresi devreye girdi. Oynama önerisi verilmedi."
                ) {
                    selection.copy(aciklama = reason + " Oynama önerisi verilmedi.")
                } else selection
            }
        )
    }

    private fun isMatchResult(title: String): Boolean {
        // Sadece gerçek tam maç MS marketini kontrol et.
        // "MS + Alt/Üst", "MS + KG" gibi birleşik marketleri
        // ayrı bir MS 1/X/2 marketi sanmak yanlış toplam kontrolü üretir.
        return title == "mac sonucu"
    }

    private fun isFullMatchTotal(title: String): Boolean {
        if (!title.contains("alt/ust") && !title.contains("alt ust")) return false
        if (title.contains("ev sahibi") || title.contains("deplasman")) return false
        if (title.contains("yari") || title.contains("ceyrek") || title.contains("devre")) return false
        if (title.contains("mac sonucu")) return false
        return !title.contains("karsilikli gol")
    }

    private fun isBtts(title: String): Boolean =
        title.contains("karsilikli gol") &&
                !title.contains("alt/ust") &&
                !title.contains("alt ust")

    private fun extractLine(title: String): Double? =
        Regex("(0\\.5|1\\.5|2\\.5|3\\.5|4\\.5|5\\.5|6\\.5|7\\.5)")
            .find(title)?.value?.toDoubleOrNull()

    private fun normalize(value: String): String = value
        .trim()
        .lowercase(Locale.forLanguageTag("tr-TR"))
        .replace('ı', 'i')
        .replace('ş', 's')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ö', 'o')
        .replace('ç', 'c')
        .replace(Regex("\\s+"), " ")
}
