@file:Suppress("PackageName")
package com.Fyco.iddaaanaliz

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Günün bütün futbol + basketbol maçlarını ve marketlerini analiz eder.
 * Amaç, modelin güncel ve yeterli veriye dayanan en güçlü seçimlerini dinamik
 * biçimde bulmaktır. Probability ana sıralama eksenidir; confidence kalite
 * filtresidir; Edge/EV ayrı ekonomik metrikler olarak tutulur.
 */
object GunlukGucluSecimAnalizcisi {

    /**
     * Bültenin tamamı analiz edilir.
     *
     * ÖNEMLİ: Burada async/awaitAll kullanılmaz. 217+ maçın tamamını aynı anda
     * coroutine olarak kuyruğa koymak, semaphore 1-2 olsa bile coroutine,
     * closure ve sonuç referanslarını RAM'de tutar. Bu yüzden ağır analizler
     * kesinlikle sırayla yürütülür.
     *
     * Amaç: tüm bülteni taramak + telefonda gereksiz RAM/GC baskısı oluşturmamak.
     */
    private const val PROGRESS_ADIMI = 5

    // GÜNÜN GÜÇLÜLERİ: model olasılığı + veri/model güvenilirliği.
    // Edge/EV yalnızca ekonomik metrik olarak taşınır.
    // Güçlüler, genel "OYNA" kararına bağlı değildir.
    // Genel OYNA/SINIRDA kararı bu listenin sıralama kaynağı değildir.
    private const val MIN_STRONG_PROB = 0.65
    private const val MIN_STRONG_CONFIDENCE = 65
    private const val MIN_STRONG_SAMPLE = 20
    private const val MAX_DAILY_STRONG = 12

    suspend fun analizEt(
        events: List<DisplayEvent>,
        onProgress: suspend (Int) -> Unit = {}
    ): List<GucluSecim> = withContext(Dispatchers.IO) {
        val simdi = System.currentTimeMillis()

        // Bültenin tamamı alınır. Sadece geçmiş maçlar ve aynı event tekrarları
        // elenir. Market sayısı az diye maç analizden çıkarılmaz.
        val gelecekMaclar = events
            .asSequence()
            .filter { it.event.d * 1000L >= simdi }
            .distinctBy { it.event.i }
            .toList()

        Log.i(
            "IddaaOgrenme",
            "GUNUN_GUCLULERI_TARAMA_BASLADI allEvents=${events.size} " +
                    "gelecekMac=${gelecekMaclar.size} " +
                    "futbol=${gelecekMaclar.count { it.sport == SportType.FOOTBALL }} " +
                    "basketbol=${gelecekMaclar.count { it.sport == SportType.BASKETBALL }}"
        )

        if (gelecekMaclar.isEmpty()) {
            Log.i("IddaaOgrenme", "GUNUN_GUCLULERI_BULTENDE_GELECEK_MAC_YOK")
            return@withContext emptyList()
        }

        // FUTBOLDA bağımsız Kendi Modeli hazır değilse 0 olasılıklı 200+
        // maçın dış veri çağrılarını boşuna çalıştırma. Model hazır olur olmaz
        // aynı bültenin tamamı tekrar taranır. Basketbol yolu bundan etkilenmez.
        val modelHazir =
            MerkeziVeriHavuzu.futbolModelHazirMi()

        val analizEdilecekMaclar = if (modelHazir) {
            gelecekMaclar
        } else {
            gelecekMaclar.filter { it.sport != SportType.FOOTBALL }
        }

        val atlananFutbol = gelecekMaclar.size - analizEdilecekMaclar.size

        if (!modelHazir && atlananFutbol > 0) {
            Log.w(
                "IddaaOgrenme",
                "GUNUN_GUCLULERI_FUTBOL_BEKLEMEDE " +
                        "atlanan=$atlananFutbol sebep=KENDI_MODEL_HAZIR_DEGIL"
            )
        }

        Log.i(
            "IddaaOgrenme",
            "GUNUN_GUCLULERI_TAM_TARAMA_BASLADI mac=${analizEdilecekMaclar.size} " +
                    "atlananFutbol=$atlananFutbol mod=SEQUENTIAL progressEvery=$PROGRESS_ADIMI"
        )

        val gucluAdaylar = ArrayList<GucluSecim>()
        var tamamlanan = 0
        var hata = 0
        val redNedenleri = linkedMapOf(
            "MODEL_OLASILIK_ESIK" to 0,
            "GUVEN_ESIK" to 0,
            "ORAN_ARALIGI" to 0,
            "ORNEKLEM_ESIK" to 0,
            "MODEL_PIYASA_FARKI" to 0,
            "KARAR_ESIK" to 0,
            "GECTI" to 0
        )

        // TEK TEK ilerliyoruz. Böylece tüm bülten analiz edilirken yalnızca
        // o anki maçın ağır analiz sonucu RAM'de tutulur.
        for (displayEvent in analizEdilecekMaclar) {
            try {
                val spor = when (displayEvent.sport) {
                    SportType.FOOTBALL -> SporTuru.FUTBOL
                    SportType.BASKETBALL -> SporTuru.BASKETBOL
                }

                val sonuc = MacAnalizServisi.analizEt(
                    event = displayEvent.event,
                    spor = spor,
                    // Günün Güçlüleri binlerce maçı tarayabilir. Model hazırken
                    // her maç için SofaScore/ProgSport ağına çıkma; İddaa marketi
                    // + öğrenilmiş ESPN modeli yeterlidir.
                    disVeriKullan = false,
                    kaydet = false
                )

                // Sadece güçlü adayları ana listede tutuyoruz; bütün marketlerin
                // büyük ara sonuçlarını bülten boyunca RAM'de biriktirmiyoruz.
                for (secim in sonuc.enIyiSecimler) {
                    if (secim.marketId == null || secim.secimNo == null) continue
                    if (!secim.oran.isFinite() || secim.oran <= 1.0) continue

                    val redNedeni = valueFiltresiRedNedeni(secim)
                    redNedenleri[redNedeni] = (redNedenleri[redNedeni] ?: 0) + 1
                    if (redNedeni != "GECTI") continue

                    val market = sonuc.marketler
                        .firstOrNull { it.market.i == secim.marketId }
                        ?.market

                    val baslik = secim.marketBasligi
                        ?: market?.let { IddaaMarketConfigRepository.marketBasligi(it) }
                        ?: "İDDAA MARKETİ"

                    Log.i(
                        "IddaaOgrenme",
                        "GUNUN_GUCLULERI_ADAY event=${displayEvent.event.i} " +
                            "${displayEvent.event.hn}-${displayEvent.event.an} " +
                            "market=${baslik} secim=${secim.secim} " +
                            "p=${"%.4f".format(java.util.Locale.US, secim.gelmeOlasiligi)} " +
                            "oran=${"%.2f".format(java.util.Locale.US, secim.oran)} " +
                            "edge=${"%.4f".format(java.util.Locale.US, secim.edge ?: 0.0)} " +
                            "ev=${"%.4f".format(java.util.Locale.US, secim.ev ?: 0.0)} " +
                            "guven=${secim.guvenPuani}"
                    )

                    gucluAdaylar.add(
                        GucluSecim(
                            displayEvent = displayEvent,
                            analiz = secim,
                            marketBasligi = baslik,
                            siralamaPuani = secimSiralaPuani(secim)
                        )
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                hata++
                Log.e(
                    "IddaaOgrenme",
                    "GUNUN_GUCLULERI_ANALIZ_HATASI event=${displayEvent.event.i} " +
                            "${displayEvent.event.hn} - ${displayEvent.event.an}",
                    e
                )
            } finally {
                tamamlanan++

                // UI her markette değil, yalnızca 5 maçta bir güncellenir.
                // Böylece analiz sırasında render/GC baskısı düşer.
                if (tamamlanan % PROGRESS_ADIMI == 0 || tamamlanan == analizEdilecekMaclar.size) {
                    onProgress(tamamlanan)
                    Log.i(
                        "IddaaOgrenme",
                        "GUNUN_GUCLULERI_ILERI ${tamamlanan}/${analizEdilecekMaclar.size} " +
                                "aday=${gucluAdaylar.size} hata=$hata"
                    )
                }
            }
        }

        // İlk geçişte çıkan adayları maç bazında tekilleştiriyoruz.
        // Oyuncu/kadro verisi pahalı olduğu için yalnızca üst adaylar için
        // ikinci bir "kadro düzeltmeli" geçiş yapıyoruz. Böylece yeni bir
        // kritik eksik daha önce üst sıralarda olmayan maçı da yukarı taşıyabilir.
        val tekilAdaylar = gucluAdaylar
            .distinctBy {
                "${it.displayEvent.event.i}:${it.analiz.marketId}:${it.analiz.secimNo}"
            }

        val ilkTurMaclar = tekilAdaylar
            .groupBy { it.displayEvent.event.i }
            .values
            .mapNotNull { it.maxByOrNull { aday -> aday.siralamaPuani } }
            .sortedByDescending { it.siralamaPuani }

        val kadroIcinAdayMaclar = ilkTurMaclar
            .asSequence()
            .filter { it.displayEvent.sport == SportType.FOOTBALL }
            .take(36)
            .toList()

        val kadroDuzeltilmis = ArrayList<GucluSecim>(ilkTurMaclar.size)
        val kadroCache = HashMap<Long, ESPNKadroSaglayici.MacKadroModel>()
        var kadroEslesen = 0
        var kadroVerisiOlan = 0
        var kadroUygulanan = 0

        for (aday in kadroIcinAdayMaclar) {
            try {
                val kadro = ESPNKadroSaglayici.macIcin(aday.displayEvent.event)
                kadroCache[aday.displayEvent.event.i] = kadro

                if (kadro.eslesti) kadroEslesen++
                if (kadro.homePlayers.isNotEmpty() || kadro.awayPlayers.isNotEmpty() ||
                    kadro.homeMissing.isNotEmpty() || kadro.awayMissing.isNotEmpty()) {
                    kadroVerisiOlan++
                }

                if (kadro.homePlayers.isNotEmpty() || kadro.awayPlayers.isNotEmpty() ||
                    kadro.homeMissing.isNotEmpty() || kadro.awayMissing.isNotEmpty()) {
                    // Roster kalite sinyali artık modeli gerçekten yeniden çalıştırdığı
                    // için eksik oyuncu olmasa da uygulanır. Eksikler ayrıca replacement-
                    // aware kayıp düzeltmesi olarak aynı analizde işlenir.
                    kadroUygulanan++
                    Log.i(
                        "OYUNCU_MODEL",
                        "KADRO_ETKI_UYGULANIYOR event=${aday.displayEvent.event.i} " +
                            "evOyuncu=${kadro.homePlayers.size} depOyuncu=${kadro.awayPlayers.size} " +
                            "evEksik=${kadro.homeMissing.size} depEksik=${kadro.awayMissing.size} " +
                            "kalite=${"%.1f".format(kadro.homePlayerQuality)}/${"%.1f".format(kadro.awayPlayerQuality)} " +
                            "coverage=${kadro.coverage} source=${kadro.source}"
                    )
                    val tekrar = MacAnalizServisi.analizEt(
                        event = aday.displayEvent.event,
                        spor = SporTuru.FUTBOL,
                        disVeriKullan = false,
                        kaydet = false,
                        evEksikOyuncular = kadro.homeMissing,
                        depEksikOyuncular = kadro.awayMissing,
                        evKadro = kadro.homePlayers,
                        depKadro = kadro.awayPlayers
                    )
                    val yeni = tekrar.enIyiSecimler
                        .filter { gucluIcinGecerli(it) }
                        .map { secim ->
                            val market = tekrar.marketler.firstOrNull { it.market.i == secim.marketId }?.market
                            GucluSecim(
                                displayEvent = aday.displayEvent,
                                analiz = secim,
                                marketBasligi = secim.marketBasligi
                                    ?: market?.let { IddaaMarketConfigRepository.marketBasligi(it) }
                                    ?: "İDDAA MARKETİ",
                                siralamaPuani = secimSiralaPuani(secim)
                            )
                        }
                        .maxByOrNull { it.siralamaPuani }
                    if (yeni != null) {
                        kadroDuzeltilmis += yeni
                        continue
                    }
                }

                kadroDuzeltilmis += aday
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(
                    "OYUNCU_MODEL",
                    "KADRO_TARAMA_HATASI event=${aday.displayEvent.event.i} " +
                        "${aday.displayEvent.event.hn}-${aday.displayEvent.event.an}",
                    e
                )
                kadroDuzeltilmis += aday
            }
        }

        val kadroEventIds = kadroIcinAdayMaclar.map { it.displayEvent.event.i }.toSet()
        ilkTurMaclar.forEach {
            if (it.displayEvent.event.i !in kadroEventIds) kadroDuzeltilmis += it
        }

        val tekMacGucluleri = kadroDuzeltilmis
            .groupBy { it.displayEvent.event.i }
            .values
            .mapNotNull { adaylar ->
                adaylar.filter { gucluIcinGecerli(it.analiz) }
                    .maxByOrNull { it.siralamaPuani }
            }
            .sortedByDescending { it.siralamaPuani }
            .take(MAX_DAILY_STRONG)

        Log.i(
            "OYUNCU_MODEL",
            "KADRO_2_TUR_TAMAMLANDI adayMac=${kadroIcinAdayMaclar.size} " +
                "kadroEslesen=$kadroEslesen kadroVerisiOlan=$kadroVerisiOlan " +
                "kadroUygulanan=$kadroUygulanan sonuc=${tekMacGucluleri.size}"
        )

        // Liste artık dinamik snapshot'tır; önceki günün/önceki taramanın
        // güçlü seçimi kilitlenmez. Persist işlemi üst katmanda, bülten imzası
        // ile birlikte tam bir kez yapılır.
        Log.i(
            "IddaaOgrenme",
            "GUNUN_GUCLULERI_TARAMA_TAMAMLANDI " +
                    "kaynakEvents=${events.size} " +
                    "gelecekMac=${gelecekMaclar.size} " +
                    "analiz=${tamamlanan} " +
                    "hata=$hata " +
                    "valueAday=${tekilAdaylar.size} " +
                    "sonValue=${tekMacGucluleri.size}"
        )
        Log.i(
            "IddaaOgrenme",
            "GUNUN_GUCLULERI_RED_NEDENLERI " +
                    redNedenleri.entries.joinToString(" ") { "${it.key}=${it.value}" }
        )

        tekMacGucluleri
    }

    /**
     * Güçlüler için bağımsız kalite + ekonomik değer kapısıdır.
     * Edge/EV model olasılığını üretmez; yalnızca modelden sonra piyasa değerini ölçer.
     */
    private fun gucluIcinGecerli(secim: AnalizSonucu): Boolean =
        valueFiltresiRedNedeni(secim) == "GECTI"

    private fun valueFiltresiniGeciyor(secim: AnalizSonucu): Boolean =
        valueFiltresiRedNedeni(secim) == "GECTI"

    private fun valueFiltresiRedNedeni(secim: AnalizSonucu): String {
        // Günün Güçlüleri, detay ekranındaki OYNA/SINIRDA kararlarıyla tutarlı
        // olmalıdır. Böylece negatif EV veya OYNAMA sonucu güçlü seçim olarak
        // taşınmaz. Karar zaten bağımsız model + piyasa + EV/edge eşiklerini
        // geçtiği için burada ikinci bir ekonomik hesap yapılmaz.
        if (secim.karar != Karar.OYNA && secim.karar != Karar.SINIRDA) {
            return "KARAR_ESIK"
        }

        val modelProbability = secim.gelmeOlasiligi
        if (!modelProbability.isFinite() ||
            modelProbability < MIN_STRONG_PROB ||
            modelProbability > 1.0
        ) return "MODEL_OLASILIK_ESIK"

        if (secim.guvenPuani < MIN_STRONG_CONFIDENCE) return "GUVEN_ESIK"
        if (secim.oran <= 1.0 || !secim.oran.isFinite()) return "ORAN_ARALIGI"

        // Güçlü seçim kapısı yalnızca gerçek model örneklemine güvenmelidir.
        // Confidence puanından geriye doğru örneklem tahmin etmek yasaktır;
        // aksi halde nötr prior (sample=0) yüksek güven puanıyla güçlü seçime
        // sızabilir.
        val sample = secim.modelSampleCount
        if (sample < MIN_STRONG_SAMPLE) return "ORNEKLEM_ESIK"

        return "GECTI"
    }

    /**
     * Uzun oranların sırf EV/edge büyüklüğü nedeniyle tüm listeyi ele geçirmesini
     * engelleyen deterministik sıralama puanı.
     * Edge ve EV burada güven puanını değiştirmez; yalnızca sıralamada kullanılır.
     */
    private fun secimSiralaPuani(secim: AnalizSonucu): Double {
        val p = secim.gelmeOlasiligi.coerceIn(0.0, 1.0)
        val ev = (secim.ev ?: 0.0).coerceAtLeast(0.0)
        val edge = (secim.edge ?: 0.0).coerceAtLeast(0.0)
        val confidence = secim.guvenPuani.coerceIn(0, 100).toDouble()

        // Sıralamanın ana ekseni model olasılığıdır. Confidence kalite filtresidir.
        // Edge/EV yalnızca çok küçük tie-break etkisi taşır; yüksek oran artık
        // düşük olasılıklı seçimi yukarı taşıyamaz.
        val boundedEdge = edge.coerceIn(0.0, 0.15)
        val boundedEv = ev.coerceIn(0.0, 0.30)
        return p * 10000.0 +
                confidence * 25.0 +
                boundedEdge * 5.0 +
                boundedEv * 2.0
    }
}
