package com.Fyco.iddaaanaliz

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class Karar {
    OYNA,
    SINIRDA,
    OYNAMA,
    VERI_YETERSIZ
}

data class AnalizSonucu(
    val secim: String,
    val oran: Double,
    val gelmeOlasiligi: Double,
    val fairOran: Double,
    val edge: Double?,
    val ev: Double?,
    val guvenPuani: Int,
    val karar: Karar,
    val aciklama: String,
    val marketId: Long? = null,
    val marketBasligi: String? = null,
    val secimNo: Int? = null,

    // MainActivity / Günün Güçlüleri için tarihsel örneklem.
    // Eski çağrılarla uyumlu olması için varsayılanı 0'dır.
    val modelSampleCount: Int = 0,

    val kaynakHarmani: KaynakHarmani? = null
)

data class MarketAnalizSonucu(
    val market: IddaaMarket,
    val baslik: String,
    val secimler: List<AnalizSonucu>
)

data class MacAnalizSonucu(
    val marketler: List<MarketAnalizSonucu>,
    val enIyiSecimler: List<AnalizSonucu>
)

data class KaynakHarmani(
    val iddaaOlasiligi: Double? = null,
    val progSportOlasiligi: Double? = null,
    val kendiModelOlasiligi: Double? = null,
    val ogrenilmisModelOlasiligi: Double? = null,
    val oyuncuDuzeltmesi: Double = 0.0,
    val nihaiOlasilik: Double
)

/**
 * Başlangıç ağırlıkları.
 *
 * İddaa = piyasanın resmi fiyatlaması
 * ProgSport = bağımsız dış tahmin sinyali
 * Kendi model = form/istatistik/H2H/oyuncu etkisi gibi iç sinyaller
 *
 * Ağırlıklar kullanılabilir kaynaklara göre otomatik normalize edilir.
 */
object HarmanAgirliklari {
    const val IDDAA = 0.0
    const val PROGSPORT = 0.30
    const val KENDI_MODEL = 0.70

    fun aktif(): OgrenmeMotoru.Agirliklar =
        OgrenmeMotoru.dinamikAgirliklar()
}

object AnalizMotoru {

    private fun normalizeMarketBasligi(value: String): String {
        return value
            .trim()
            .lowercase(Locale("tr", "TR"))
            .replace('ı', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')
    }

    fun oranOlasilik(oran: Double): Double {
        if (oran <= 1.0) return 0.0
        return (1.0 / oran).coerceIn(0.0, 1.0)
    }

    fun marketMarji(market: IddaaMarket): Double {
        val toplam = market.o
            .filter { it.odd > 1.0 }
            .sumOf { 1.0 / it.odd }

        return max(0.0, toplam - 1.0)
    }

    fun marketMarjiYuzde(market: IddaaMarket): Double {
        return marketMarji(market) * 100.0
    }

    /**
     * Aynı marketin tüm geçerli sonuçları üzerinden no-vig olasılığı.
     * Tek sonuçlu marketlerde sahte %100 üretilmez.
     */
    fun piyasaOlasiligi(
        market: IddaaMarket,
        outcome: IddaaOutcome
    ): Double {
        if (outcome.odd <= 1.0) return 0.0

        val gercek = market.o.firstOrNull { it.no == outcome.no }
            ?: return 0.0

        if (abs(gercek.odd - outcome.odd) > 0.000001) return 0.0

        val valid = market.o.filter { it.odd > 1.0 }
        if (valid.size < 2) return 0.0

        val toplam = valid.sumOf { 1.0 / it.odd }
        if (toplam <= 0.0) return 0.0

        return ((1.0 / gercek.odd) / toplam).coerceIn(0.0, 1.0)
    }

    fun fairOran(probability: Double): Double {
        if (probability <= 0.0) return 0.0
        return 1.0 / probability
    }

    fun edge(
        modelProbability: Double,
        marketProbability: Double
    ): Double {
        return modelProbability - marketProbability
    }

    fun expectedValue(
        modelProbability: Double,
        odd: Double
    ): Double {
        if (odd <= 1.0) return -1.0
        return (modelProbability * odd) - 1.0
    }

    /**
     * Kaynakları basit ortalama ile değil, kullanılabilir kaynaklara
     * ait ağırlıkları normalize ederek birleştirir.
     */
    fun harmanla(
        iddaaOlasiligi: Double?,
        progSportOlasiligi: Double?,
        kendiModelOlasiligi: Double?,
        oyuncuDuzeltmesi: Double = 0.0,
        spor: SporTuru = SporTuru.FUTBOL,
        marketBasligi: String = "",
        organizasyon: String = "",
        oran: Double = 0.0
    ): KaynakHarmani? {

        val kaynaklar = mutableListOf<Pair<Double, Double>>()

        if (spor == SporTuru.FUTBOL) {
            // FUTBOLDA İDDAA nihai model olasılığına karışmaz.
            // İddaa yalnızca piyasa benchmarkı olarak edge/EV hesabında kullanılır.
            // Kendi Modeli 2.0 ESPN geçmişinden öğrenilmiş ana kaynaktır.
            if (progSportOlasiligi != null && progSportOlasiligi in 0.0..1.0 && progSportOlasiligi > 0.0) {
                kaynaklar += progSportOlasiligi to 0.30
            }
            if (kendiModelOlasiligi != null && kendiModelOlasiligi in 0.0..1.0 && kendiModelOlasiligi > 0.0) {
                kaynaklar += kendiModelOlasiligi to 0.70
            }
        } else {
            val agirlik = OgrenmeMotoru.segmentAgirliklari(
                spor = spor,
                marketBasligi = marketBasligi,
                organizasyon = organizasyon,
                oran = oran
            )
            if (iddaaOlasiligi != null && iddaaOlasiligi in 0.0..1.0 && iddaaOlasiligi > 0.0) {
                kaynaklar += iddaaOlasiligi to agirlik.iddaa
            }
            if (progSportOlasiligi != null && progSportOlasiligi in 0.0..1.0 && progSportOlasiligi > 0.0) {
                kaynaklar += progSportOlasiligi to agirlik.progSport
            }
            if (kendiModelOlasiligi != null && kendiModelOlasiligi in 0.0..1.0 && kendiModelOlasiligi > 0.0) {
                kaynaklar += kendiModelOlasiligi to agirlik.kendiModel
            }
        }

        if (kaynaklar.isEmpty()) return null

        val toplamAgirlik = kaynaklar.sumOf { it.second }
        if (toplamAgirlik <= 0.0) return null

        val kaynakHarmani = kaynaklar.sumOf { it.first * it.second } / toplamAgirlik

        /*
         * Oyuncu etkisi ayrı bir kaynak gibi tekrar ağırlıklandırılmaz.
         * Kendi modelin içine dahil edilmişse ikinci kez cezalandırmamak için
         * sadece açıkça verilen düzeltme burada sınırlı biçimde uygulanır.
         */
        val duzeltilmis =
            (kaynakHarmani + oyuncuDuzeltmesi.coerceIn(-0.12, 0.12))
                .coerceIn(0.01, 0.99)

        return KaynakHarmani(
            iddaaOlasiligi = iddaaOlasiligi,
            progSportOlasiligi = progSportOlasiligi,
            kendiModelOlasiligi = kendiModelOlasiligi,
            oyuncuDuzeltmesi = oyuncuDuzeltmesi,
            nihaiOlasilik = duzeltilmis
        )
    }

    /**
     * Oyuncu etkisini ham oyuncu bilgisi yerine mevcut OyuncuEtkiMotoru
     * çıktısından alabilmek için güvenli yardımcı.
     *
     * Pozitif değer olasılığı artırır, negatif değer azaltır.
     */
    /**
     * Tek seçim analizi.
     *
     * UI'a yalnızca nihai olasılık gönderilir.
     */
    fun analizEt(
        market: IddaaMarket,
        outcome: IddaaOutcome,
        progSportOlasiligi: Double? = null,
        kendiModelOlasiligi: Double? = null,
        oyuncuDuzeltmesi: Double = 0.0,
        spor: SporTuru = SporTuru.FUTBOL,
        organizasyon: String = "",

        // Merkezi modelden gelen örneklem/kalite bilgisi.
        modelOrneklemMin: Int = 0,
        modelQuality: Int = 0,
        modelSampleCount: Int = modelOrneklemMin
    ): AnalizSonucu {

        val gercekOutcome = market.o.firstOrNull { it.no == outcome.no }
            ?: return veriYetersizSonucu(
                market,
                outcome,
                "Seçim marketiyle eşleşmedi."
            )

        if (abs(gercekOutcome.odd - outcome.odd) > 0.000001) {
            return veriYetersizSonucu(
                market,
                gercekOutcome,
                "Seçim oranı market oranıyla eşleşmedi."
            )
        }

        val iddaaOlasiligi = piyasaOlasiligi(
            market = market,
            outcome = gercekOutcome
        )

        /*
         * ÖZEL MARKET GÜVENLİĞİ
         *
         * 1. Çeyrek Sonucu / 2. Çeyrek Sonucu /
         * 3. Çeyrek Sonucu / 4. Çeyrek Sonucu /
         * 1. Yarı Sonucu / 2. Yarı Sonucu /
         * 1. Yarı / Maç Sonucu gibi marketlerde
         * tam maç için üretilen model olasılığı kullanılamaz.
         *
         * Bu marketler için özel model sinyali yoksa yalnızca
         * aynı marketin İddaa no-vig olasılığı kullanılır.
         * Böylece örneğin 6.78 oranlı bir çeyrek seçimi,
         * tam maçtan gelen %66 ile şişirilemez.
         */
        val marketBasligiNormalize = normalizeMarketBasligi(
            marketBasligi(market)
        )

        val ozelDonemMarketi =
            marketBasligiNormalize.contains("ceyrek") ||
                    marketBasligiNormalize.contains("yari") ||
                    marketBasligiNormalize.contains("devre")

        val kullanilacakProgSport =
            if (ozelDonemMarketi) null else progSportOlasiligi

        val kullanilacakKendiModel =
            if (ozelDonemMarketi) null else kendiModelOlasiligi

        val kullanilacakOyuncuDuzeltmesi =
            if (ozelDonemMarketi) 0.0 else oyuncuDuzeltmesi

        val ogrenilmisModel = if (
            spor == SporTuru.FUTBOL ||
            ozelDonemMarketi ||
            (kullanilacakProgSport == null && kullanilacakKendiModel == null)
        ) null else {
            OgrenmeMotoru.ogrenilmisOlasilik(
                spor = spor,
                marketBasligi = marketBasligiNormalize,
                organizasyon = organizasyon,
                oran = gercekOutcome.odd,
                iddaaOlasiligi = iddaaOlasiligi.takeIf { it > 0.0 },
                progSportOlasiligi = kullanilacakProgSport,
                kendiModelOlasiligi = kullanilacakKendiModel,
                guvenPuani = 0
            )
        }

        val harman = harmanla(
            iddaaOlasiligi = iddaaOlasiligi.takeIf { it > 0.0 },
            progSportOlasiligi = kullanilacakProgSport,
            kendiModelOlasiligi = kullanilacakKendiModel,
            oyuncuDuzeltmesi = kullanilacakOyuncuDuzeltmesi,
            spor = spor,
            marketBasligi = marketBasligiNormalize,
            organizasyon = organizasyon,
            oran = gercekOutcome.odd
        )

        if (harman == null) {
            return veriYetersizSonucu(
                market,
                gercekOutcome,
                "Bu market için geçerli olasılık kaynağı bulunamadı."
            )
        }

        val ogrenmeKatkisi = ogrenilmisModel?.let {
            // Öğrenilmiş kalibratör yalnızca yeterli veri varsa %15 katkı yapar.
            (it - harman.nihaiOlasilik) * 0.15
        } ?: 0.0

        val harmanliOgrenme = harman.copy(
            ogrenilmisModelOlasiligi = ogrenilmisModel,
            nihaiOlasilik = (harman.nihaiOlasilik + ogrenmeKatkisi).coerceIn(0.01, 0.99)
        )

        val sadeceIddaaVar =
            harman.iddaaOlasiligi != null &&
                    harman.progSportOlasiligi == null &&
                    harman.kendiModelOlasiligi == null

        /*
         * KRİTİK OLASILIK KORUMASI
         *
         * Bağımsız model/ProgSport yoksa nihai olasılık yalnızca
         * İddaa marketinin no-vig olasılığı olabilir.
         * Decimal oran kesin üst sınırdır:
         * 6.78 -> ham ima edilen olasılık yaklaşık %14.75.
         * Böylece yalnızca İddaa verisi varken %66 gibi hatalı bir
         * nihai olasılık üretilmesi engellenir.
         */
        val hamOranSiniri = oranOlasilik(gercekOutcome.odd)

        /*
         * EDGE GÜVENİLİRLİK KATMANI
         *
         * Ham model olasılığı ile piyasa olasılığı arasındaki farkı
         * doğrudan Edge olarak kullanmak, kaynaklar birbirinden çok
         * ayrıştığında sahte büyük avantaj üretebilir.
         *
         * Örnek:
         * Kendi Model = %65, ProgSport = %38, Piyasa = %40
         * Eski mantıkta harman yüksek kaldığı için Edge gereğinden fazla
         * büyüyebiliyordu.
         *
         * Artık Edge önce ham olarak hesaplanıyor, sonra bağımsız model
         * kaynaklarının uyum katsayısı ile küçültülüyor. Böylece Edge
         * ekonomik avantajı temsil ediyor; Güven puanı ise ayrıca kaynak
         * kalitesini temsil ediyor.
         */
        val hamEdge = iddaaOlasiligi.takeIf { it > 0.0 }?.let {
            edge(harmanliOgrenme.nihaiOlasilik, it)
        } ?: 0.0

        val edgeGuvenilirlik = edgeGuvenilirlikKatsayisi(harmanliOgrenme)
        val reliableEdge = (hamEdge * edgeGuvenilirlik).coerceIn(-0.95, 0.95)

        /*
         * Nihai karar olasılığı, piyasa benchmarkından güvenilir Edge
         * kadar uzaklaşır. Böylece gösterilen olasılık, gösterilen Edge
         * ve EV aynı matematiksel temele oturur.
         *
         * Bağımsız model yoksa İddaa tek başına avantaj kaynağı değildir
         * ve bu seçim zaten OYNAMA'ya düşecektir.
         */
        val edgeTemelliNihai = if (iddaaOlasiligi > 0.0 && !sadeceIddaaVar) {
            (iddaaOlasiligi + reliableEdge).coerceIn(0.01, 0.99)
        } else {
            min(harmanliOgrenme.nihaiOlasilik, hamOranSiniri)
        }

        val nihai = edgeTemelliNihai.coerceIn(0.01, 0.99)
        val fair = fairOran(nihai)
        val calculatedEdge = iddaaOlasiligi.takeIf { it > 0.0 }?.let {
            edge(nihai, it)
        }

        val calculatedEv = expectedValue(
            modelProbability = nihai,
            odd = gercekOutcome.odd
        )

        val confidence = calculateConfidence(
            modelProbability = nihai,
            marketProbability = iddaaOlasiligi,
            ev = calculatedEv,
            harman = harmanliOgrenme
        )

        val decision =
            if (sadeceIddaaVar) {
                Karar.OYNAMA
            } else {
                calculateDecision(
                    confidence = confidence,
                    edge = calculatedEdge ?: 0.0,
                    ev = calculatedEv,
                    veriVar = true
                )
            }

        val explanation =
            if (sadeceIddaaVar) {
                "Resmî İddaa oranı analiz edildi. Bağımsız model desteği olmadan oynama önerisi verilmedi."
            } else {
                decisionExplanation(
                    decision = decision,
                    edge = calculatedEdge ?: 0.0,
                    ev = calculatedEv,
                    confidence = confidence
                )
            }

        return AnalizSonucu(
            secim = gercekOutcome.n,
            oran = gercekOutcome.odd,
            gelmeOlasiligi = nihai,
            fairOran = fair,
            edge = calculatedEdge,
            ev = calculatedEv,
            guvenPuani = confidence,
            karar = decision,
            aciklama = explanation,
            marketId = market.i,
            marketBasligi = marketBasligi(market),
            secimNo = gercekOutcome.no,
            modelSampleCount = modelSampleCount.coerceAtLeast(modelOrneklemMin),
            kaynakHarmani = harman
        )
    }

    private fun veriYetersizSonucu(
        market: IddaaMarket,
        outcome: IddaaOutcome,
        aciklama: String
    ): AnalizSonucu {
        return AnalizSonucu(
            secim = outcome.n,
            oran = outcome.odd,
            gelmeOlasiligi = 0.0,
            fairOran = 0.0,
            edge = null,
            ev = null,
            guvenPuani = 0,
            karar = Karar.VERI_YETERSIZ,
            aciklama = aciklama,
            marketId = market.i,
            marketBasligi = marketBasligi(market),
            secimNo = outcome.no,
            kaynakHarmani = null
        )
    }

    fun analizMarket(
        market: IddaaMarket,
        progSportOlasiliklari: Map<Int, Double> = emptyMap(),
        kendiModelOlasiliklari: Map<Int, Double> = emptyMap(),
        oyuncuDuzeltmeleri: Map<Int, Double> = emptyMap(),
        spor: SporTuru = SporTuru.FUTBOL,
        organizasyon: String = "",
        modelOrneklemMin: Int = 0,
        modelQuality: Int = 0,
        modelSampleCount: Int = modelOrneklemMin
    ): MarketAnalizSonucu {

        val baslik = marketBasligi(market)

        val secimler = market.o.map { outcome ->
            analizEt(
                market = market,
                outcome = outcome,
                progSportOlasiligi = progSportOlasiliklari[outcome.no],
                kendiModelOlasiligi = kendiModelOlasiliklari[outcome.no],
                oyuncuDuzeltmesi = oyuncuDuzeltmeleri[outcome.no] ?: 0.0,
                spor = spor,
                organizasyon = organizasyon,
                modelOrneklemMin = modelOrneklemMin,
                modelQuality = modelQuality,
                modelSampleCount = modelSampleCount
            )
        }

        return MarketAnalizSonucu(
            market = market,
            baslik = baslik,
            secimler = secimler
        )
    }

    fun analizMac(
        markets: List<IddaaMarket>,
        progSportOlasiliklari: Map<Long, Map<Int, Double>> = emptyMap(),
        kendiModelOlasiliklari: Map<Long, Map<Int, Double>> = emptyMap(),
        oyuncuDuzeltmeleri: Map<Long, Map<Int, Double>> = emptyMap(),
        spor: SporTuru = SporTuru.FUTBOL,
        organizasyon: String = ""
    ): MacAnalizSonucu {

        val marketResults = markets
            .filter { it.o.isNotEmpty() }
            .filter { MarketPolitikasiV1.aktifMi(it, spor) }
            .map { market ->
                analizMarket(
                    market = market,
                    progSportOlasiliklari = progSportOlasiliklari[market.i] ?: emptyMap(),
                    kendiModelOlasiliklari = kendiModelOlasiliklari[market.i] ?: emptyMap(),
                    oyuncuDuzeltmeleri = oyuncuDuzeltmeleri[market.i] ?: emptyMap(),
                    spor = spor,
                    organizasyon = organizasyon,
                    modelOrneklemMin = 0,
                    modelQuality = 0,
                    modelSampleCount = 0
                )
            }

        val enIyiSecimler = marketResults
            .flatMap { marketSonucu ->
                marketSonucu.secimler.filter { secim ->
                    secim.marketId == marketSonucu.market.i &&
                            secim.secimNo != null &&
                            marketSonucu.market.o.any { it.no == secim.secimNo } &&
                            secim.oran > 1.0 &&
                            secim.gelmeOlasiligi > 0.0
                }
            }
            .sortedWith(
                compareByDescending<AnalizSonucu> { it.ev ?: Double.NEGATIVE_INFINITY }
                    .thenByDescending { it.edge ?: Double.NEGATIVE_INFINITY }
                    .thenByDescending { it.guvenPuani }
                    .thenByDescending { it.gelmeOlasiligi }
            )

        return MacAnalizSonucu(
            marketler = marketResults,
            enIyiSecimler = enIyiSecimler
        )
    }

    /**
     * Resmi market config yüklenmişse gerçek market adı kullanılır.
     * Repository mevcut değilse güvenli fallback kullanılır.
     */
    fun marketBasligi(market: IddaaMarket): String {
        val raw = try {
            if (IddaaMarketConfigRepository.configYukluMu()) {
                IddaaMarketConfigRepository.marketBasligi(market)
            } else {
                ""
            }
        } catch (_: Exception) {
            ""
        }

        val base = raw
            .trim()
            .ifBlank {
                val sov = market.sov?.trim()?.replace(",", ".")
                when {
                    isHandicapMarket(market) && !sov.isNullOrEmpty() -> "HANDİKAP $sov"
                    isHandicapMarket(market) -> "HANDİKAP"
                    isResultMarket(market) -> "MAÇ SONUCU"
                    market.o.any {
                        val n = it.n.trim().lowercase(Locale("tr", "TR"))
                        n == "var" || n == "yok"
                    } -> "KARŞILIKLI GOL"
                    !sov.isNullOrEmpty() -> "MARKET $sov"
                    else -> "MARKET"
                }
            }

        return MarketPolitikasiV1.gorunumBasligi(
            market = market,
            resmiBaslik = base
        )
    }

    /**
     * Artık yalnızca outcome "Alt/Üst" diye marketin TOPLAM olduğu varsayılmaz.
     * Bu fonksiyon yalnızca genel sınıflandırma yardımcısıdır.
     */
    fun isTotalMarket(market: IddaaMarket): Boolean {
        val names = market.o.map {
            it.n.trim().lowercase(Locale("tr", "TR"))
        }

        return names.any {
            it == "alt" || it == "üst"
        }
    }

    fun isHandicapMarket(market: IddaaMarket): Boolean {
        val sov = market.sov?.trim() ?: ""

        val names = market.o
            .joinToString(" ") { it.n }
            .lowercase(Locale("tr", "TR"))

        if (
            names.contains("handikap") ||
            names.contains("handicap")
        ) {
            return true
        }

        return sov.startsWith("+") || sov.startsWith("-")
    }

    fun isResultMarket(market: IddaaMarket): Boolean {
        val names = market.o.map {
            it.n.trim().lowercase(Locale("tr", "TR"))
        }

        val hasOne = names.any { it == "1" }
        val hasTwo = names.any { it == "2" }
        val hasDraw = names.any { it == "x" || it == "0" }

        return hasOne && hasTwo && hasDraw
    }

    /**
     * Bağımsız model kaynaklarının Edge için ne kadar güvenilir olduğunu
     * belirler. İddaa burada deliberately kullanılmaz; İddaa piyasa
     * benchmarkıdır ve Edge zaten ona karşı ölçülmektedir.
     */
    private fun edgeGuvenilirlikKatsayisi(
        harman: KaynakHarmani
    ): Double {
        val kaynaklar = listOfNotNull(
            harman.progSportOlasiligi,
            harman.kendiModelOlasiligi
        ).filter { it.isFinite() && it in 0.0..1.0 }

        return when (kaynaklar.size) {
            0 -> 0.0
            1 -> 0.85
            else -> {
                val fark = abs(kaynaklar.maxOrNull()!! - kaynaklar.minOrNull()!!)
                when {
                    fark <= 0.03 -> 1.00
                    fark <= 0.05 -> 0.95
                    fark <= 0.08 -> 0.90
                    fark <= 0.10 -> 0.82
                    fark <= 0.15 -> 0.68
                    fark <= 0.20 -> 0.50
                    fark <= 0.25 -> 0.32
                    else -> 0.20
                }
            }
        }
    }

    private fun calculateConfidence(
        modelProbability: Double,
        marketProbability: Double,
        ev: Double,
        harman: KaynakHarmani
    ): Int {
        // Güven artık Edge/EV tarafından şişirilmez.
        // Edge ve EV yalnızca ekonomik karar katmanında kullanılır.
        var score = 0

        if (harman.kendiModelOlasiligi != null) score += 50
        if (harman.progSportOlasiligi != null) score += 20

        val modelProb = modelProbability.coerceIn(0.0, 1.0)
        score += when {
            modelProb >= 0.75 -> 25
            modelProb >= 0.65 -> 20
            modelProb >= 0.55 -> 15
            modelProb >= 0.45 -> 10
            modelProb >= 0.35 -> 5
            else -> 0
        }

        val independentSources = listOfNotNull(
            harman.progSportOlasiligi,
            harman.kendiModelOlasiligi
        )

        if (independentSources.size == 2) {
            val fark = kotlin.math.abs(independentSources[0] - independentSources[1])
            score += when {
                fark <= 0.05 -> 5
                fark <= 0.10 -> 3
                fark <= 0.15 -> 1
                else -> -5
            }
        }

        return score.coerceIn(0, 100)
    }

    private fun calculateDecision(
        confidence: Int,
        edge: Double,
        ev: Double,
        veriVar: Boolean
    ): Karar {

        if (!veriVar) return Karar.VERI_YETERSIZ

        /*
         * KARAR EŞİKLERİ
         *
         * Eski sürümde OYNA için 75 güven + %5 edge + %5 EV
         * şartı vardı. Yeni model başlangıçta veri kaynakları
         * arasında temkinli davrandığı için bu eşik fazla sertti
         * ve neredeyse bütün seçimler OYNAMA'ya düşüyordu.
         *
         * Yeni eşikler:
         * OYNA    -> güven >= 68, edge >= %3, EV >= %3
         * SINIRDA -> güven >= 55, edge >= %1, EV >= 0
         *
         * Bu, "yüksek oran = OYNA" anlamına gelmez.
         * Modelin piyasa karşısında gerçek pozitif avantajı
         * olması hâlâ zorunludur.
         */
        if (
            confidence >= 68 &&
            edge >= 0.03 &&
            ev >= 0.03
        ) {
            return Karar.OYNA
        }

        if (
            confidence >= 55 &&
            edge >= 0.01 &&
            ev >= 0.0
        ) {
            return Karar.SINIRDA
        }

        return Karar.OYNAMA
    }

    private fun decisionExplanation(
        decision: Karar,
        edge: Double,
        ev: Double,
        confidence: Int
    ): String {

        return when (decision) {
            Karar.OYNA ->
                "Model ile piyasa arasında anlamlı pozitif avantaj var. Güven: $confidence/100."

            Karar.SINIRDA ->
                "Pozitif avantaj var ancak güçlü karar seviyesi için sınırlı. Güven: $confidence/100."

            Karar.OYNAMA ->
                "Model avantajı yeterli değil veya beklenen değer düşük. Güven: $confidence/100."

            Karar.VERI_YETERSIZ ->
                "Karar vermek için yeterli veri bulunmuyor."
        }
    }

    fun yuzde(value: Double): String {
        return String.format(
            Locale.US,
            "%.1f%%",
            value * 100.0
        )
    }

    fun oranFormat(value: Double): String {
        return String.format(
            Locale.US,
            "%.2f",
            value
        )
    }

    fun edgeFormat(value: Double): String {
        val sign = if (value > 0.0) "+" else ""

        return String.format(
            Locale.US,
            "%s%.1f%%",
            sign,
            value * 100.0
        )
    }

    fun evFormat(value: Double): String {
        val sign = if (value > 0.0) "+" else ""

        return String.format(
            Locale.US,
            "%s%.1f%%",
            sign,
            value * 100.0
        )
    }

    fun guvenFormat(value: Int): String {
        return "$value/100"
    }

    fun enIyiSecimleriGetir(
        sonuc: MacAnalizSonucu,
        limit: Int = 10
    ): List<AnalizSonucu> {

        return sonuc.marketler
            .flatMap { marketSonucu ->
                marketSonucu.secimler.filter { secim ->
                    secim.marketId == marketSonucu.market.i &&
                            secim.secimNo != null &&
                            marketSonucu.market.o.any {
                                it.no == secim.secimNo
                            } &&
                            secim.oran > 1.0 &&
                            secim.gelmeOlasiligi > 0.0
                }
            }
            .sortedWith(
                compareByDescending<AnalizSonucu> {
                    it.gelmeOlasiligi
                }
                    .thenByDescending {
                        it.guvenPuani
                    }
                    .thenByDescending {
                        it.ev ?: Double.NEGATIVE_INFINITY
                    }
            )
            .take(limit.coerceAtLeast(1))
    }

    fun marketEnGucluSecim(
        sonuc: MarketAnalizSonucu
    ): AnalizSonucu? {

        return sonuc.secimler
            .filter { secim ->
                secim.marketId == sonuc.market.i &&
                        secim.secimNo != null &&
                        sonuc.market.o.any {
                            it.no == secim.secimNo
                        } &&
                        secim.oran > 1.0 &&
                        secim.gelmeOlasiligi > 0.0
            }
            .maxByOrNull {
                it.gelmeOlasiligi
            }
    }

    fun olasilikFarki(
        probability1: Double,
        probability2: Double
    ): Double {
        return abs(probability1 - probability2)
    }

    fun yuzdePuani(
        probability: Double
    ): Double {
        return probability * 100.0
    }

    fun piyasaOlasilikToplami(
        market: IddaaMarket
    ): Double {
        return market.o
            .filter { it.odd > 1.0 }
            .sumOf {
                piyasaOlasiligi(
                    market = market,
                    outcome = it
                )
            }
    }
}
