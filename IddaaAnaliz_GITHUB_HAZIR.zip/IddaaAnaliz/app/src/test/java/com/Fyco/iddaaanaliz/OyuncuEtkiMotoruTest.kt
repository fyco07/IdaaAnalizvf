package com.Fyco.iddaaanaliz

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OyuncuEtkiMotoruTest {
    @Test
    fun high_usage_attacker_scores_above_low_usage_bench_player() {
        val star = OyuncuEtkiVerisi(
            oyuncuAdi = "Star",
            pozisyon = OyuncuPozisyonu.FORVET,
            dakikaOrtalamasi = 82.0,
            macSayisi = 20,
            ilkOnBirSayisi = 18,
            gol = 12.0,
            asist = 6.0,
            isabetliSut = 24.0,
            durum = OyuncuDurumTipi.SAKAT
        )
        val bench = star.copy(
            oyuncuAdi = "Bench",
            dakikaOrtalamasi = 28.0,
            macSayisi = 10,
            ilkOnBirSayisi = 1,
            gol = 0.0,
            asist = 0.0,
            isabetliSut = 1.0
        )

        val s = OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, star)
        val b = OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, bench)

        assertTrue(s.etkiSkoru > b.etkiSkoru)
        assertTrue(s.takimHucumEtkisi > b.takimHucumEtkisi)
    }

    @Test
    fun unknown_status_does_not_apply_absence_effect() {
        val player = OyuncuEtkiVerisi(
            oyuncuAdi = "Unknown",
            pozisyon = OyuncuPozisyonu.FORVET,
            dakikaOrtalamasi = 80.0,
            macSayisi = 10,
            ilkOnBirSayisi = 9,
            gol = 5.0,
            durum = OyuncuDurumTipi.BELIRSIZ
        )

        val result = OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, player)
        assertEquals(0.0, result.toplamEtki, 0.0001)
    }

    @Test
    fun score_uses_rate_not_raw_goal_total() {
        val lowMinute = OyuncuEtkiVerisi(
            oyuncuAdi = "LowMinutes",
            pozisyon = OyuncuPozisyonu.FORVET,
            dakikaOrtalamasi = 45.0,
            macSayisi = 20,
            ilkOnBirSayisi = 10,
            gol = 10.0,
            asist = 2.0,
            isabetliSut = 18.0,
            durum = OyuncuDurumTipi.SAKAT
        )
        val highMinute = lowMinute.copy(
            oyuncuAdi = "HighMinutes",
            dakikaOrtalamasi = 82.0,
            macSayisi = 20,
            ilkOnBirSayisi = 18
        )

        val low = OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, lowMinute)
        val high = OyuncuEtkiMotoru.etkiHesapla(SporTuru.FUTBOL, highMinute)

        assertTrue(high.etkiSkoru > low.etkiSkoru)
    }
}
