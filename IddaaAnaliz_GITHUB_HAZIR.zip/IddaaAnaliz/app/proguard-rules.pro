# Project-specific R8/ProGuard rules.
# V20 model code does not require additional keep rules at this time.
