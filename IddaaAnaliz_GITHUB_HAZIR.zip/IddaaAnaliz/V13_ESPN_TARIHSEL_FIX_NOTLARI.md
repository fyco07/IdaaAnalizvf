V13 ESPN TARİHSEL İLERLEME FIX

Kritik hata düzeltildi: V12'de ESPNHistoryWorker her yeni Worker çalışmasında
lastEmptyScanVersion != PARSER_VERSION koşuluna giriyor ve KEY_NEXT_OFFSET'i 0'a
çekiyordu. Bu nedenle 7 günlük parça tamamlandıktan sonra sonraki Worker tekrar
0. günden başlıyor; ekran 1/365 -> 6/365 -> 1/365 döngüsüne giriyordu.

V13:
- parserVersionApplied ayrı tutuluyor.
- Parser sürümü değiştiğinde sıfırlama sadece bir kez yapılıyor.
- Sonraki Worker'larda saved nextOffset korunuyor.
- Retry aynı offset'ten devam ediyor.
- Room'daki mevcut tarihsel maçlar silinmiyor.
- Market/model kodlarına dokunulmadı.
