# V30 FINAL KADRO FIX

- versionCode 45 / versionName 1.0-V30-FINAL-KADRO
- Kadro sağlayıcı artık gelecek maç eşleştirmesi için önce yerel ESPN tarihsel DB'den takım ID + lig çözüyor.
- Scoreboard lookup yalnızca tarihsel indexte takım bulunamazsa fallback.
- Roster/injury/leader istekleri takım başına paralel.
- Güçlüler ikinci turunda gerçek eksik oyuncu bulunduğunda kadro modeli yeniden çalıştırılıyor ve `kadroUygulanan` sayaçta gerçekten uygulanan yeniden hesabı sayıyor.
- Yeni log alanları: `KADRO_TAKIM_INDEX_HAZIR`, `KADRO_MODEL_HAZIR`, `KADRO_ETKI_UYGULANIYOR`, `KADRO_2_TUR_TAMAMLANDI`.
- Oyuncu verisi uydurulmaz; gerçek ESPN roster/injury verisi yoksa lambda değişmez.
