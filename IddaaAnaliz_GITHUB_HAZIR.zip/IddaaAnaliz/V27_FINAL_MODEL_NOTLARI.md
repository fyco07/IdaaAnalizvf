# V27 FINAL MODEL

- Version code: 42
- Version name: 1.0-V27-FINAL-MODEL
- Merkezi futbol modelinde latent ELO/attack/defense/form yapısı korunur.
- Takım için 0-100 gösterim puanı latent bileşenlerin dağılımından türetilir; ELO ile aynı şey değildir.
- Maç detayına takım puanı, ELO, hücum/savunma, form 5/10/20, model kalitesi ve örneklem özeti eklendi.
- Oyuncu etkisi, gerçek oyuncu/kadro verisi girildiğinde ortak lambda katmanında uygulanır; oyuncu yokken veri uydurulmaz.
- Oyuncu etkisi ve kadro düzeltmesi için model logları eklendi.
- Güçlü seçimlerin probability/confidence/edge/EV ayrımı korunur.
- ESPN/SofaScore ayrımı V26'daki gibi: aktif futbol tahmin zinciri merkezi havuz üzerinden çalışır; SofaScore aktif sonuç kaynağı değildir.
- Full Gradle build bu ortamda Gradle dağıtım DNS erişimi olmadığı için çalıştırılamadı.
