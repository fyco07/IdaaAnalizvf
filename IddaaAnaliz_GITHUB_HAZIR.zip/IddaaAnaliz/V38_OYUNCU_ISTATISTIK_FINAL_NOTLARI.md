# V38 – Oyuncu İstatistik Final Fix

Son telefondaki logda sorun artık netti: takım roster'ı mevcut olsa da oyuncu istatistik kanıtı 0–1 seviyesinde kalıyor, bu yüzden kadro kalite sinyali merkezi modele anlamlı katkı vermiyordu.

## Yapılan düzeltmeler

- Roster verisi 8 saatlik kalıcı Room havuzunda tutulmaya devam eder; her maçta roster yeniden indirilmez.
- Maç günü sakatlık/ceza/durum kontrolü ayrı TTL ile yenilenir.
- Yerel havuzdaki istatistik kanıtı yetersizse (en az 6 oyuncu veya roster'ın %25'i), yalnızca istatistik zenginleştirme tetiklenir; roster yeniden çekilmez.
- Soccer ESPN Core için birincil istatistik yolu sezon-scope:
  `v2/sports/soccer/leagues/{league}/seasons/{year}/athletes/{id}/statistics`
  ve `/statistics/0`.
- İstatistik cevabı `$ref` taşıyorsa gerçek statistics nesnesi takip edilir.
- Aynı sezon roster yenilenirken mevcut Room istatistikleri korunur; yeni roster cevabı metrik içermese bile eski istatistikler sıfırlanmaz.
- Sezon değişirse eski sezon satırları doğrudan taşınmaz.
- Kısmi istatistik başarısı olsa bile 6 saatlik retry kilidi uygulanır; böylece her maçta yeniden yüzlerce ESPN çağrısı yapılmaz.
- Düz JSON istatistik map'leri (`G`, `A`, `MIN`, `GP`, `GS`, `SH`, `ST`, `SV`, `GA`, `xG`, `xA`) de parse edilir.
- `KADRO_MODEL_BAGLANDI` -> merkezi lambda zinciri korunur; oyuncu kalite düzeltmesi gerçek kanıt bulunduğunda uygulanır.
- Güvenli/temiz statik uyarılar: deprecated `Locale("tr","TR")` kullanımları dönüştürüldü, kullanılmayan JsonParser importu temizlendi.

## Beklenen loglar

`OYUNCU_ISTATISTIK_HAVUZA_YAZILDI team=... source=ESPN_CORE_SEASON`

`KADRO_MODEL_HAZIR ... kaliteKanit=...`

`KADRO_MODEL_BAGLANDI ... kaliteDeltaA=... kaliteDeltaD=...`

`MERKEZI_LAMBDA ... squad=...`

## Build notu

Çalışma ortamında Gradle 9.5.0 dağıtımının services.gradle.org üzerinden indirilmesi DNS nedeniyle mümkün olmadığı için tam Android Gradle build'i burada doğrulanamadı. Kotlin dosyası bağımlılıksız parse kontrolünde sözdizimi hatası üretmedi; gerçek Android build'i Android Studio/Codespaces'te yapılmalıdır.
