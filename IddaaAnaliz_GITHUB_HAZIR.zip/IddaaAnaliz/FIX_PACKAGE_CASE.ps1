# Script is intended to be copied to the Android project root, or run from it.
# If the script is inside this patch folder, pass the project root explicitly.
param(
    [string]$ProjectRoot = ""
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Get-Location).Path
}

$srcRoot = Join-Path $ProjectRoot 'app\src\main\java'
if (-not (Test-Path $srcRoot)) {
    throw "app\src\main\java bulunamadı: $srcRoot`nProjeyi proje kökünden çalıştırın."
}

$old = 'com.Fyco.iddaaanaliz'
$new = 'com.fyco.iddaaanaliz'
$changed = New-Object System.Collections.Generic.List[string]

Get-ChildItem -Path $srcRoot -Recurse -Filter *.kt -File | ForEach-Object {
    $path = $_.FullName
    $text = Get-Content -LiteralPath $path -Raw -Encoding UTF8
    $original = $text

    # IMPORTANT: only package/import directives are changed.
    # Runtime strings, applicationId, URLs, logs and other literals are untouched.
    $text = [regex]::Replace($text, '(?m)^(\s*package\s+)' + [regex]::Escape($old) + '(?=\b)', '$1' + $new)
    $text = [regex]::Replace($text, '(?m)^(\s*import\s+)' + [regex]::Escape($old) + '(?=\b)', '$1' + $new)

    if ($text -ne $original) {
        $backup = "$path.bak_pkgcase"
        if (-not (Test-Path $backup)) {
            Copy-Item -LiteralPath $path -Destination $backup
        }
        Set-Content -LiteralPath $path -Value $text -Encoding UTF8 -NoNewline
        $changed.Add($path)
    }
}

Write-Host "PACKAGE CASE FIX tamamlandı."
Write-Host "Değiştirilen dosya sayısı: $($changed.Count)"
$changed | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "applicationId/build.gradle.kts/AndroidManifest.xml değiştirilmedi."
Write-Host "Yedekler: *.bak_pkgcase"
Write-Host ""
Write-Host "Ardından Android Studio'da Sync Project with Gradle Files ve Rebuild Project çalıştırın."
