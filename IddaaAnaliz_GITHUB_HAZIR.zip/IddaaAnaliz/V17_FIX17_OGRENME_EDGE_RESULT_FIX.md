# V17 FIX17 — Öğrenme / Edge / Sonuç Eşleştirme

Bu sürüm, kullanıcının verdiği proje ZIP'i doğrudan temel alınarak hazırlanmıştır. Çalışan veri akışlarına, manuel YENİLE davranışına ve mevcut model/merkezi havuz yapısına dokunulmadan hedefli düzeltmeler yapılmıştır.

## Yapılan düzeltmeler

### 1. Futbolda öğrenilmiş kalibrasyon artık gerçek nihai olasılığa giriyor
Önceki sürümde futbol için `ogrenilmisOlasilik` bilinçli olarak `null` bırakılıyordu ve nihai futbol olasılığı doğrudan ESPN/Kendi Modeli'nden alınıyordu. FIX17'de yeterli sonuç oluştuğunda öğrenilmiş kalibrasyon futbol seçimlerine de uygulanıyor.

Kalibrasyon etkisi çözülmüş sonuç sayısına göre kademeli:
- 100–199: %15
- 200–499: %25
- 500–999: %35
- 1000–2499: %45
- 2500+: %50

100 çözülmüş sonuçtan önce mevcut ham model davranışı korunur.

### 2. Outcome karışması düzeltildi
Kalibrasyon eğitimi aynı marketteki tüm seçimleri tek havuzda kullanmıyordu. Örneğin MS1/MSX/MS2 kayıtları birbirinin sonucunu etkileyebiliyordu. FIX17'de seçim numarası/selection da segmente katılıyor. Böylece MS1 yalnızca MS1 geçmişinden, Alt ise Alt geçmişinden öğrenir.

### 3. Kalibrasyon hesabı telefon için sınırlandı
Her segmentte 5000'den fazla kayıt eğitimde kullanılmaz. Eğitim 18 iterasyona indirildi ve 24 segmentlik LRU model önbelleği eklendi. Amaç, öğrenme açıldığında cihazda gereksiz CPU/GC baskısı oluşturmamaktır.

### 4. Ham final olasılığı kalibratöre doğru gönderiliyor
Kalibratör artık mevcut tahminin gerçek ham final olasılığını ve ham güven puanını giriş olarak alıyor. Önceki kodda futbol final olasılığı kalibratöre hiç gönderilmiyordu; bazı yollar da `guvenPuani=0` kullanıyordu.

### 5. Sonuç kayıtlarında market başlığı güvenceye alındı
Yeni tahmin kayıtlarında market başlığı boş gelirse market nesnesinden tekrar çözülüyor. Bu, sonuç çözümleyicinin marketi tanıyıp doğru sonuca çevirebilmesine yardımcı oluyor.

### 6. Eski bozuk kayıtlar için güvenli fallback
Market başlığı boş olan eski kayıtlar için sadece güvenle tanınabilen `MAÇ SONUCU` ve `KARŞILIKLI GOL` türleri yeniden çıkarılıyor. Ev/deplasman ayrımı bilinmeyen eski Alt/Üst kayıtları yanlış sonuçlandırılmıyor.

### 7. SofaScore takım eşleştirmesi iyileştirildi
FC/FK/SC/Club ve Women/K gibi genel ekler eşleştirme anahtarından çıkarılıyor. U21/U19 gibi yaş kategorileri korunuyor. Bu, özellikle isimleri sağlayıcılar arasında farklı gelen maçların bulunma şansını artırıyor.

### 8. İzlenebilirlik logu eklendi
Yeterli veri oluştuğunda Logcat'te `KALIBRASYON_UYGULANDI` satırı görülür. Bu satır ham olasılığı, öğrenilmiş olasılığı, kullanılan kalibrasyon ağırlığını ve nihai olasılığı gösterir.

## Korunan davranışlar

- Manuel `YENİLE` butonu korunmuştur.
- Otomatik bülten yenileme eklenmemiştir.
- Mevcut ESPN 365 günlük model eğitimi korunmuştur.
- Mevcut Poisson/skor dağılımı korunmuştur.
- Mevcut güçlü seçim filtreleri korunmuştur.
- Mevcut merkezi veri havuzu korunmuştur.
- APK/proje veri taşıma davranışında değişiklik yapılmamıştır.
