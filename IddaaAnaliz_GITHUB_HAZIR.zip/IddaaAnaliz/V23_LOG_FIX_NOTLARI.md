# V23 Log Fix

- Surum: 1.0-V23-FINAL-LOGFIX / versionCode 38
- ESPN sonuc gunleri icin ortak success/failure cache ve 15 dk backoff.
- Result resolver gercekten ESPN-only; SofaScore endpoint kullanmaz.
- Tahmin sonuc worker periyodu acilista immediate worker ile cakismamasi icin 30 dk ilk gecikmeli.
- Market config yoksa bilinen futbol t/st marketleri fallback adiyla cozulur; ozellikle st=101 toplam Alt/Ust.
- Merkezi futbol tahmincisi takimlari guvenli merkezi alias index'i ile bulur.
- Mac analiz cache'i kaydet/disVeri bayraklarindan bagimsiz deterministik sonuclarda kullanilir.
- Gunluk Gucluler cache imzasina model createdAt dahil edildi.
- Iddaa sonuclari merkezi sonuc havuzuna source=ESPN olarak yazilir.

- Kullanılmayan SofaScoreVeriSaglayici ve ProgSportApi sınıfları kaldırıldı; canlı üretim kaynağı yalnız İddaa/ESPN.
