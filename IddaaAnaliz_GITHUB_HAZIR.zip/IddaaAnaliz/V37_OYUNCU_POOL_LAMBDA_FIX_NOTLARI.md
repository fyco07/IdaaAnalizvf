# V37 – Oyuncu havuzu + lambda bağlantı düzeltmesi

## Kök neden
V36 kodunda oyuncu kalite düzeltmesi merkezi lambda fonksiyonuna geçiriliyordu; ancak canlı testte ESPN 403/DNS hatası olduğunda kalıcı yerel roster havuzu her zaman bulunamıyordu. Ayrıca havuz anahtarı lig/season metnine bağlı olduğundan aynı ESPN teamId için anahtar değişirse eski roster görülemiyordu.

## Düzeltmeler
- Room DAO'ya `teamId` bazlı roster/meta sorguları eklendi.
- Exact cacheKey bulunamazsa aynı ESPN teamId'nin son bilinen roster'ı kullanılır.
- Season uyumluluğu dört haneli sezon yılı üzerinden geriye dönük uyumlu hale getirildi.
- Roster ağ çağrısı 403/DNS ile başarısız olursa, varsa eski yerel roster korunur ve `KADRO_STALE_POOL_TEAMID_FALLBACK` loglanır.
- Başarısız maç-kadro cache'inin 10 dakika boyunca sıfır veriyi kilitlemesi kaldırıldı (`FAILURE_TTL_MS=0`).
- Oyuncu roster verisi hâlâ 8 saatte bir yenilenir; maç günü sakatlık/ceza kontrolü 20 dakikalık TTL ile ayrı tutulur.
- V36'daki oyuncu kalite deltasının `MatchModelAdjustments` üzerinden `MerkeziFutbolModelHavuzu.lambdalar(..., adjustments)` ile merkezi lambda'ya girişi korunur.

## Beklenen test
Manchester City–Sunderland gibi daha önce roster'ı alınmış bir takımda ESPN tekrar 403/DNS verse bile:
1. `KADRO_POOL_TEAMID_FALLBACK` veya `KADRO_STALE_POOL_TEAMID_FALLBACK` görülmeli,
2. `KADRO_MODEL_HAZIR coverage` sıfıra düşmemeli,
3. `KADRO_MODEL_BAGLANDI` logunda kadro sayıları >0 olmalı,
4. `KADRO_KALITE` logu gelmeli,
5. `MERKEZI_LAMBDA` satırındaki `squad=` değeri veri gerçekten kalite farkı üretiyorsa 0.000/0.000 olmamalı.

Sahte oyuncu veya sahte sakatlık üretilmez.
