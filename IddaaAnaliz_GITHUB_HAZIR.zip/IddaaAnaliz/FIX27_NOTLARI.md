# V17 FIX27 - Sonuç Zinciri Doğrudan Başlatma

Bu sürümde sonuç çözümlemesi MainActivity.onCreate içinde lifecycleScope + Dispatchers.IO ile doğrudan başlatılır.

Yeni teşhis logları:
- FIX27_ACTIVITY_ONCREATE version=1.0-FIX27
- FIX27_DOGRUDAN_SONUC_BASLADI
- FIX27_DOGRUDAN_SONUC_BITTI ...
- FIX27_DOGRUDAN_SONUC_HATASI

LaunchedEffect içindeki sonuç tetikleme kaldırıldı; WorkManager periyodik sonuç zinciri ve manuel YENİLE davranışı korunmuştur.
Bülten otomatik yenileme eklenmemiştir.
