# V7 – Gerçek Güçlü Seçim Filtresi

Bu sürüm V6'nın üzerine, mevcut çalışan akışı bozmadan yalnızca iki kritik güvenlik katmanı ekler:

- Günün Güçlüleri: model olasılığı >= %80, güven >= 80, en az 50 tarihsel örneklemi temsil eden güven seviyesi, Edge >= %5, EV >= %5.
- Model-piyasa aşırı ayrışması: model-piyasa farkı %30'dan büyükse güçlü seçim kilitlenmez. Bu kontrol model olasılığını değiştirmez.
- Günlük güçlü seçimler en fazla 30 kayıt; sıralama model olasılığı + güven odaklıdır.
- Eski kilitli kayıtlar silinmez; yeni güçlü kalite filtresini geçmeyenler ekranda “Günün Güçlüleri” olarak gösterilmez.
- Futbolda iki takımın ESPN ratingi eşleşmiyorsa maç için model tahmini üretilmez.
- Kategori etiketi bulunan takım adlarında token/fuzzy eşleşme tamamen engellenir; böylece U19/U21/Kadın/B/II/MG gibi kategoriler başka takıma bağlanmaz.
- Fuzzy eşleşme eşiği 0.92, adaylar arası minimum fark 0.05 yapıldı.
- Veri havuzundan silme işlemi eklenmedi.
