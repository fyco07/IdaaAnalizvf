# IddaaAnaliz V6

Bu sürüm V5 üzerine hazırlanmıştır.

## V6 ana değişiklikleri
- "EN GÜÇLÜ 10" kaldırıldı; ekran adı "GÜNÜN GÜÇLÜLERİ".
- Günün tüm futbol + basketbol maçları ayrıntılı analize girer.
- MacAnalizServisi artık yalnızca ilk 10 olasılığı değil, tüm geçerli market seçimlerini öğrenme geçmişine aday olarak tutar.
- Günün Güçlüleri sabit sayıda değildir; gerçek value sinyali kadar seçim gösterir.
- Seçim mantığı ham kazanma olasılığı yerine karar + edge + EV + güven birlikte kullanır.
- 1.06 gibi çok düşük oranlar otomatik olarak güçlü seçim sayılmaz; çok yüksek oranlar ise yalnızca oran yüksek diye elenmez.
- Seçim ilk üretildiğinde `eventId + marketId + secimNo` kimliğiyle kilitlenir.
- Yenileme sırasında kilitli seçimin oranı/olasılığı/açıklaması değiştirilmez.
- Kartta EDGE, EV, fair oran ve "NEDEN SEÇİLDİ?" açıklaması gösterilir.
- Sonuç çözüldüğünde mevcut öğrenme kaydı üzerinden KAZANDI/KAYBETTİ gösterilebilir.

## Önemli
Bu ortamda Gradle 9.5 dağıtımı önbellekte bulunmadığı için APK derlemesi yapılamadı; internet erişimi olmadan `services.gradle.org` üzerinden Gradle indirme başarısız oluyor. Bu nedenle teslim edilen dosya kaynak kod V6 paketidir. Mevcut APK'nın bytecode'unu doğrudan değiştirilmiş APK olarak yeniden paketlemek yerine kaynak üzerinden temiz derleme yapılması tercih edildi.
