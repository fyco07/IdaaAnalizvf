# V33 – Oyuncu modeli / puanlama düzeltmesi

## Amaç
V32'de kadro takım eşleşmesi düzeltilmişti. V33 bu kez oyuncu verisinin gerçekten modele girmesi ve oyuncu puanının tutarlı hesaplanması üzerine kuruldu.

## Düzeltilenler
- ESPN roster çıktısı doğrudan oyuncu istatistikleri içeriyorsa APP/SUB/G/A/SH/ST/SV/GA benzeri alanlar oyuncu bazında toplanıyor.
- `teams/{id}?enable=roster` ikinci roster kaynağı olarak kullanılıyor.
- Liderler endpoint'i roster içindeki eksik istatistikleri tamamlamak için yalnızca gözlenen değerlerle birleştiriliyor.
- ESPN pozisyon kısaltmaları G/D/M/F, GK/DF/MF/FW gibi biçimleri destekliyor.
- APP + SUB varsa ilk 11 oranı `starts = APP - SUB` üzerinden türetiliyor; dakika verisi yoksa dakika uydurulmuyor.
- Oyuncu puanı mutlak gol/asist toplamına göre değil; kullanım + ilk 11 oranı + pozisyona uygun, maç başına/per-90 üretim kanıtına göre hesaplanıyor.
- Veri yoksa oyuncuya otomatik 50/70/90 gibi puan atanmıyor.
- `BELIRSIZ` sakatlık durumu artık otomatik yokluk sayılmıyor.
- Eksik oyuncu etkisi takımın aynı pozisyondaki gözlenen oyuncularına göre replacement-aware hesaplanıyor; yedek oyuncunun yokluğu yıldız oyuncu kadar cezalandırılmıyor.
- Oyuncu kadrosu değiştiğinde analiz cache fingerprint'i de değişiyor.
- Detay ekranında oyuncu sayısı ve eksik/şüpheli sayısı gösteriliyor.

## Loglar
- `KADRO_VERI_DETAY`
- `KADRO_MODEL_HAZIR`
- `OYUNCU_ETKI`
- `KADRO_LAMBDA_DUZELTMESI`

## Sürüm
- versionCode: 48
- versionName: `1.0-V34-OYUNCU-DATA-SLUG-FIX`
