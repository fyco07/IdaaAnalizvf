# V15 Bitirme Düzeltmeleri

- Güçlüler filtresi artık genel `Karar.OYNA` kararına bağlı değil; model olasılığı + güven + örneklem + pozitif Edge/EV + model/piyasa aşırı ayrışma kontrolü ile bağımsız değerlendirilir.
- Takım eşleşmesinde yalnızca deterministic exact/unique aliases kullanılır. Fuzzy/token similarity yoktur. U19/U21/Women/(K) gibi kategori işaretleri alias üretiminde korunur; çakışan alias yayınlanmaz.
- Merkezi snapshot aynı kalır; mevcut hazır snapshot geçici rebuild ile ezilmez.
- Normal tarihsel veriler ve tahminler silinmez.
