# V17 FIX4 — Temiz kurulum

Bu sürümde `MerkeziVeriHavuzu` için TEK gerçek tanım vardır:

`app/src/main/java/com/Fyco/iddaaanaliz/MerkeziVeriHavuzu.kt`

Paket:
`com.Fyco.iddaaanaliz`

`merkezi` paketinde yalnızca geriye dönük uyumluluk için `MerkeziVeriHavuzuCompat.kt` vardır ve bu dosya `typealias` kullanır; ikinci bir `object` tanımlamaz.

## ÖNEMLİ
Önceki V16/V17 klasörünün üzerine dosya kopyalamayın. Android Studio'da yeni, boş bir klasöre bu ZIP'i açın.

Eski proje klasörünü kullanacaksanız, şu eski dosya mutlaka silin:
`app/src/main/java/com/Fyco/iddaaanaliz/merkezi/MerkeziVeriHavuzu.kt`

Bu dosya önceki hatalı sürümde yanlışlıkla `package com.Fyco.iddaaanaliz` bildirimiyle bulunabiliyordu ve root `MerkeziVeriHavuzu` ile redeclaration oluşturuyordu.

Temiz kurulumdan sonra:
1. Sync Project with Gradle Files
2. Build > Clean Project
3. Build > Rebuild Project
