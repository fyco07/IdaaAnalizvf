# V34 R3 Build Fix

- Fixed compile error: `Unresolved reference: hasFootballProduction` in `OyuncuEtkiMotoru.kt`.
- Restored the helper and included xG/xA as valid football production evidence.
- versionCode: 50
- versionName: 1.0-V34-OYUNCU-DATA-SLUG-FIX-R3
- This is a compile fix only; no player scoring weights were changed in this R3 patch.
