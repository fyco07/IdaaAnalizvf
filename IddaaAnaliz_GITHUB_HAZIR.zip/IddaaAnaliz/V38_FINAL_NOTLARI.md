# V38 – Oyuncu havuzu + market gösterim düzeltmesi

- Kalıcı ESPN oyuncu havuzu metası takım indeksine dahil edildi; tarihsel maç kaydı yoksa da daha önce kaydedilmiş roster adıyla bulunabilir.
- Pool status sorgusu eski cacheKey için doğru meta cacheKey üzerinden okunuyor.
- Oyuncu dönüşümünde xG/xA artık kaybolmuyor.
- Market detail/strong selection UI artık analiz sırasında hesaplanan sabit market başlığını kullanıyor.
- Aynı semantik market birden fazla marketId ile geldiyse sadece gösterim adaylarında tek karta indiriliyor; ham market kayıtları ve öğrenme verisi silinmiyor.
- Gereksiz cache/IDE uyarılarından bazıları temizlendi.
