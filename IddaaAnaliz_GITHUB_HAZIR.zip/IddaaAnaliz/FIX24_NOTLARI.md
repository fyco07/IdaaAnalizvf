# İddaaAnaliz V17 FIX24

## Düzeltilen konu
Gönderilen projede güncel sonuç zinciri kaynak kodunda bulunmasına rağmen `app/build` altında 11 Eylül tarihli eski APK vardı. Bu APK, 12 Eylül'de eklenen FIX23 sonuç zinciri kodunu içermiyordu.

## Bu paket
- Güncel kaynak kodunu içerir.
- Stale `app/build` çıktıları paketten çıkarılmıştır; eski APK yanlışlıkla kullanılmaz.
- `TahminSonucArkaPlanPlanlayici` içinde WorkManager + uygulama canlıyken bağımsız in-process sonuç taraması korunmuştur.
- Uygulama başlangıcında sonuç zinciri başlatılır.
- Günün Güçlüleri analizi sonunda sonuç taraması yeniden tetiklenir.
- Saatlik WorkManager sonuç taraması yedek olarak korunur.
- Sonuç çözülünce `Tuttu/Kaybetti` ve Faz 10 kalibrasyon tetiklenir.
- Bülten otomatik yenileme eklenmemiştir; mevcut manuel `YENİLE` davranışı korunmuştur.
- `versionName = 1.0-FIX24` olarak işaretlenmiştir.

## Önemli
Bu çalışma ortamında Gradle 9.5.0 dağıtımı yerelde bulunmadığı için APK'yı burada yeniden derlemek mümkün olmadı; Gradle wrapper çevrimdışı derlemede dağıtımı internetten indirmeye çalıştı. Bu nedenle pakette APK yoktur. Android Studio'da projeyi açıp `app > assembleDebug` ile APK'yı güncel kaynaklardan üretmek gerekir.
