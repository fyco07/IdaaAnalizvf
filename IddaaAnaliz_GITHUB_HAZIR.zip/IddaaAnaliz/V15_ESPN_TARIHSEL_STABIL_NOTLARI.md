# V15 - ESPN Tarihsel Stabilizasyon

Bu sürümde yalnızca ESPN tarihsel veri zincirine dokunuldu. Mevcut market, tahmin, Edge/EV ve ana ekran mantığı değiştirilmedi.

## Düzeltilenler
- Tarihsel Worker normal başlangıçta `nextOffset` değerini artık sıfırlamaz.
- Başarıyla DB'ye yazılan gün `nextOffset` ile kalıcı olarak kaydedilir.
- `6/365 -> 7/365` şeklinde devam eder; normal retry/restart sırasında `1/365`e dönmez.
- Eski `parserVersionApplied / lastEmptyScanVersion` ilerlemeyi sıfırlayan mantık Worker'dan çıkarıldı.
- Eski sürümün tam tarama bloklama bayrağı varsa yalnızca tam tarama başarısızlığı sonrası bir defalık temizlenir.
- ESPN bağlantısında primary `site.api.espn.com` yanında `site.web.api.espn.com` fallback eklendi.
- IOException ve 5xx için hostlar sırayla tekrar deneniyor.
- ESPN JSON parser takım/competition/status alanlarında güvenli tip kontrolü yapıyor.
- Takım ID'si `team.id` yoksa competitor `id` alanından alınabiliyor.
- Her gün DB yazıldıktan sonra benzersiz takım sayısı hesaplanıp durum kartına/loga yazılıyor.
- Room'daki mevcut event ID primary key yapısı korunuyor; tekrar çekilen maçlar duplicate yerine güncelleniyor.

## Bilinçli olarak değiştirilmedi
- Kendi Modeli matematiği
- Poisson/Kolmogorov market üretimi
- Market tutarlılık katmanı
- Edge/EV
- Günün Güçlüleri seçim mantığı
- UI font/tema

## Build
Bu ortamda Gradle 9.5 dağıtımı `services.gradle.org` DNS erişimi olmadığı için gerçek Android compile yapılamadı. Değiştirilen Kotlin dosyalarında statik parantez kontrolü temizdir.
