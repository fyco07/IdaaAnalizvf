# FIX29 — Sonuç zinciri

- MainActivity onCreate/onResume sonuç taramasını doğrudan başlatır.
- 120 saniyelik tekrar kilidi vardır.
- Üst çubuğa SONUÇ butonu eklenmiştir.
- YENİLE korunmuştur; bülten otomatik yenilenmez.
- UI'daki tahmin performansı mevcut canlı okuma ile sonuçları günceller.
- versionName 1.0-FIX29 / versionCode 29.
