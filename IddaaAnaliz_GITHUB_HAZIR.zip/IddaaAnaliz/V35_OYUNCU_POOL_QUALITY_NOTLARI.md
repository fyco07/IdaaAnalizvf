# V35 — Oyuncu havuzu + kadro kalite bağlantısı

## Ne değişti?

### 1. Oyuncu verisi artık kalıcı yerel havuzda
- ESPN roster ve lider/istatistik verileri Room içindeki `espn_oyuncu_havuzu` tablosuna kaydedilir.
- Takım roster'ı **6 saatte bir** yenilenir; uygulama her maçta oyuncu listesini baştan indirmez.
- Uygulama kapanıp açılsa da oyuncu havuzu korunur.

### 2. Maç günü durumları ayrı tutulur
- Sakat, cezalı, şüpheli, dinlendiriliyor ve kadro dışı durumları `espn_oyuncu_durum_cache` içinde tutulur.
- Durum kontrolü **20 dakikalık** önbellek ile yapılır.
- `suspend`, `suspended`, `red card` ve ceza/suspension ifadeleri cezalıya çevrilir.
- Durum endpoint'i çalışmazsa eski durum otomatik olarak yeni maça uygulanmaz; güvenli olarak eksik listesi boş bırakılır.

### 3. Transfer/satılma kontrolü
- Transfer için ayrı bir tahmin girdisi uydurulmaz.
- Roster yenilendiğinde ESPN oyuncu ID kümesinin imzası eski havuzla karşılaştırılır.
- Eklenen/çıkarılan oyuncu sayısı loglanır (`KADRO_ROSTER_DEGISIKLIK`).
- Böylece takım değiştiren oyuncu roster'dan çıktığında yerel havuzdan da çıkar.

### 4. Oyuncu kalite skoru modele bağlandı
- Mevcut roster'ın pozisyon-ağırlıklı genel/hücum/savunma kalite özeti hesaplanır.
- Bu sinyal Merkezi Model'in Poisson lambda hesabına küçük, kontrollü log-delta olarak bağlanır.
- Takım Elo/ratinginin yerine geçmez.
- Eksik oyuncu varsa ayrıca replacement-aware eksik oyuncu düzeltmesi uygulanır.
- Günün Güçlüleri ikinci turunda gerçek roster verisi bulunan aday maç, eksik olmasa bile oyuncu kalite sinyaliyle yeniden analiz edilir.
- Aynı oyuncu hem normal roster kalitesinde hem de eksik oyuncu kaybında çift cezalandırılmaz; mevcut roster kalite hesabı OYNAYACAK durumdaki oyuncuları kullanır.

### 5. UI
Kadro kartında artık:
- Kadro kalite
- Kalite kanıtı
- Oyuncu havuzunun yerel olduğu
- Roster yenileme aralığı
- Sakatlık/ceza durum kontrolü
bilgileri gösterilir.

## Beklenen loglar

Başarılı yerel havuz kullanımı:

`KADRO_HAVUZDAN_OKUNDU ... durumFresh=true`

Sadece maç-günü durum yenilemesi:

`KADRO_DURUM_SADECE_YENILENDI`

Roster değişikliği:

`KADRO_ROSTER_DEGISIKLIK`

Oyuncu kalitesinin ana modele bağlanması:

`KADRO_KALITE`
`KADRO_MODEL_BAGLANDI`

Merkezi lambda içinde `squad=` alanı artık roster kalite sinyalini de içerebilir. Bu alan hâlâ küçük ve kontrollüdür.

## Veritabanı

Room sürümü 3 -> 4'e yükseltildi ve mevcut kullanıcı verisini silmemesi için `MIGRATION_3_4` eklendi.
