# V22 Build / Log Audit — 2026-09-19

## Implemented from latest runtime log
- Raised Android version to code 37 / `1.0-V22-FINAL-DYNAMIC` so an installed old FIX34 build is unambiguous.
- Fixed the market-config failure path observed in the log: `get_market_config` may temporarily fail with DNS errors. Market config is now persisted in SharedPreferences and reused across app restarts.
- Added a two-minute failure backoff so a single DNS outage cannot cause a market-config request for every one of the 1152 football matches.
- The live bülten prepares market config once before the central scan.
- The central football predictor now falls back to safe market-title inference for recognizable markets (match result, BTTS, double chance) when official config is unavailable, so a whole match is not discarded just because config lookup failed.
- Removed direct ON_CREATE/ON_RESUME result scans from MainActivity. WorkManager is the single automatic result-check chain; the manual result button still enqueues the same unique work.
- Removed the second automatic result-check trigger after Günün Güçlüleri finishes.
- Result settlement path is ESPN-only. SofaScore fallback network calls are no longer used by the active settlement pipeline. Legacy SofaScore classes remain only for source compatibility and old data/schema compatibility.

## Static checks
- No remaining `startResultCheck` references in MainActivity.
- Version fields match V22.
- ZIP archive integrity checked with `unzip -t`.
- Source tree contains the patched files and V22 audit note.

## Full Android build limitation
A full `:app:assembleDebug` could not be executed in this environment because the Gradle wrapper distribution (`gradle-9.5.0-bin.zip`) is not cached locally and this environment cannot resolve `services.gradle.org`.
Therefore this package is source-validated but not claimed to have a locally reproduced Android Gradle build.
