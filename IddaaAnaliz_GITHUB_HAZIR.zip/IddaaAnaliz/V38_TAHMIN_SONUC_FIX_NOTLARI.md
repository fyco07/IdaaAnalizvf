# V38 – Tahmin Sonuçlandırma Fix

## Bulgular
- 2026-09-22 testinde model taraması 214/214 maç analiz etmiş ve 8 value aday üretmiş.
- Tahmin sonuçlandırma ekranında 26 bekleyen tahmin vardı.
- Sonuç sağlayıcı `resolved=0 unresolved=26` dönüyor; örneğin Manchester City-Sunderland için `SONUC_BULUNAMADI` oluşuyordu.
- Ağ tarafında ESPN DNS/cache hataları görüldü; bu nedenle sadece uzak scoreboard'a güvenmek 0 sonuç üretiyordu.

## V38 değişiklikleri
1. Tahmin `eventId` ile önce doğrudan yerel ESPN tarihsel DB'den aranıyor.
2. Event ID bulunmazsa yerel DB'de takım + tarih eşleşmesi yapılıyor.
3. Eski DB kayıtlarında `baslangic` alanı saniye veya milisaniye olabilecek şekilde her iki epoch birimi aynı sorguda destekleniyor.
4. Yerel eşleşme başarısız olursa mevcut ESPN uzak fallback korunuyor.
5. Sonuç bulunamadığında tahmin KAYBETTİ yapılmıyor; beklemede kalıyor.

## Beklenen loglar
- `SONUC_LOCAL_EVENT_ESLESME event=...`
- veya `SONUC_LOCAL_TAKIM_TARIH_ESLESME event=...`
- ardından `SONUC_MAC_BULUNDU`
- ardından `TAHMİN_SONUCU_İŞLENDİ`

## Ayrı konu
"GEÇERLİ BİR MARKET ANALİZİ OLUŞTURULAMADI" ekranı, seçilen maç için uygulamanın kullanabildiği geçerli oran bulunmadığını ifade eder; bu sonuçlandırma motorundan ayrı bir piyasa/oran veri problemidir.
