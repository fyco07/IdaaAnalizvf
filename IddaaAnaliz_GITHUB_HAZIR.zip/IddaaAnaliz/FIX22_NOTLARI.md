# V17 FIX22 – Sonuç Eşleştirme Stabilizasyonu

- SofaScore sonuç gün önbelleği 5 dakikalık TTL ile sınırlandı. Eski sürümde ilk alınan gün listesi uygulama açık kaldığı sürece kalabildiği için sonuçlar saatlik kontrolde tazelenmeyebiliyordu.
- Takım adlarında tek harfli baş harfler (`A. Petrzalka`, `E. Cottbus` gibi) eşleştirmeden çıkarıldı.
- Ortak takım adının bir tarafı diğerinin tamamını kapsıyorsa daha güçlü eşleşme skoru veriliyor.
- Sonuç taramasında bulunan sonuç havuzu miktarı `SONUC_HAVUZU` loguyla görünür hale getirildi.
- Mevcut 5.000 kayıtlık geri dönük sonuç taraması ve günlük komşu tarih taraması korunuyor.
- YENİLE butonu / otomatik bülten yenileme davranışı değiştirilmedi.
