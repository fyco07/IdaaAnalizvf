# MERKEZI MODEL V9

Bu sürüm V8'in üzerine canlı futbol analiz zincirini gerçekten merkezi hale getirir.

## Canlı futbol zinciri
IDDAA + ESPN tarihsel veri -> Merkezi Veri Havuzu -> tamamlanmış geçmiş maçlar -> takım ratingi -> form -> rakip gücü -> lambda -> Poisson/skor dağılımı -> market olasılıkları -> Edge/EV/karar.

## Kritik düzeltmeler
- MacAnalizServisi canlı futbol yolunda ESPNKendiModelTahmincisi çağırmaz.
- Yeni merkezi `MerkeziFutbolTahmincisi` doğrudan kullanılır.
- Canlı takım eşleşmesi merkezi `merkezi_team` tablosunda sport=FUTBOL + exact normalizedName ile yapılır.
- Fuzzy/token takım eşleştirmesi canlı modelden çıkarılmıştır.
- Takımlardan biri merkezi havuzda/merkezi model snapshot'ında yoksa maç model dışı kalır.
- Takım geçmişi Merkezi Veri Havuzu'ndaki `merkezi_match + merkezi_result` üzerinden kurulur.
- Rating; Elo, zaman ağırlıklı hücum/savunma, son 5/10 form, gol farkı ve rakip Elo gücünü kullanır.
- Oran/Edge/EV takım ratingini ve model olasılığını üretmez; yalnızca sonradan ekonomik değerlendirmedir.
- Eski ESPN model sınıfları geriye dönük uyumluluk için projede tutulabilir, ancak canlı futbol tahmininin girdisi değildir.
- Normal yenileme geçmiş merkezi veriyi silmez.

## Yeni doğrulama logları
- `MERKEZI_MODEL_HAZIR`
- `MERKEZI_MODEL TAKIM_MODEL`
- `MERKEZI_MODEL MERKEZI_MAC_BATCH`
- `MERKEZI_MODEL MODEL_DISARIDA ... sebep=MERKEZI_TAKIM_ESLESME_EKSİK`

## Build
Bu ortamda Gradle 9.5 dağıtımı için internet erişimi bulunmadığından APK build doğrulaması yapılamadı.
