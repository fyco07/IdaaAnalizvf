# V32 – Kadro takım eşleştirme düzeltmesi

Ekrandaki Toluca–Santos örneğinde ESPN kadro kapsamı %0 görünüyordu. Ana neden, İddaa adındaki `Deportivo Toluca` ile ESPN tarihsel verisindeki `Toluca` adının aynı alias kümesine girmemesiydi.

Bu sürümde:
- `Deportivo Toluca -> Toluca` deterministik aliası eklendi.
- `Universidad X` benzeri yaygın ön ekler için kontrollü alias üretildi.
- Tarihsel eşleşme bulunamazsa aday sayıları loglanıyor.
- Aynı lig + farklı ESPN takım ID'si şartı korunuyor; rastgele takım eşleşmesi yapılmıyor.
- Gerçek ESPN eksik oyuncu verisi yoksa `kadroUygulanan` yapay olarak artırılmıyor.

Beklenen Toluca–Santos testinde önce `KADRO_TAKIM_INDEX_HAZIR`, ardından `KADRO_MODEL_HAZIR ... source=ESPN_HISTORY_TEAM_INDEX` görülmeli. Roster/injury uçları veri döndürürse kapsam %50 veya %100 olacaktır; eksik oyuncu satırı gerçekten varsa `KADRO_ETKI_UYGULANIYOR` ve `kadroUygulanan>0` görülecektir.
