# V25 – Result + Market Config Fix

## Sürüm
- versionCode: 40
- versionName: 1.0-V25-ESPN-LOCAL-RESULTFIX

## 1) Sonuç zinciri
- Aktif sonuç sağlayıcı: `ESPNSonucSaglayici`.
- `SofascoreSonucSaglayici` yalnızca source-compatibility bridge olarak bırakıldı; HTTP yapmaz.
- Futbol sonuçlarında `espn_tarihsel_maclar` yerel DB'si önceliklidir.
- Yerel futbol sonuçları bulunduğu sürece uzak ESPN isteği yapılmaz.
- Yerel eşleşme bulunamayan kayıtlar için uzak ESPN yalnızca benzersiz spor+tarih kümeleri üzerinden fallback olarak denenir.
- Sonuç worker'ı ağ bağlantısı koşuluna bağlı değildir; yerel futbol sonuçları internet olmadan da çözülebilir.
- Sonuçlar kaynak olarak `ESPN` yazılır.

## 2) Market config
- `get_market_config` otomatik analiz zincirinden çıkarıldı ve `IddaaApi` içindeki endpoint tanımı da kaldırıldı.
- `IddaaMarketConfigRepository.hazirla()` artık yalnızca SharedPreferences/disk cache yükler.
- Günün Güçlüleri taraması sırasında market config DNS/HTTP retry'si yapılmaz.
- Resmî config yoksa mevcut deterministik `t/st/sov` fallback isimleri kullanılır.

## 3) Runtime doğrulama işaretleri
Uygulama açılışında beklenen loglar:
- `V25_BOOT version=1.0-V25-ESPN-LOCAL-RESULTFIX code=40`
- `V25_ACTIVITY_ONCREATE ... code=40`

Sonuç zincirinde beklenen loglar:
- `SONUC_KAYNAGI_ACTIVE provider=ESPN_ONLY localFootballHistory=true`
- `RESULT_LOCAL_QUERY ... local=N`
- `SONUC_ESPN_FINAL source=LOCAL_THEN_ESPN ...`

V25 kaynaklarında aktif SofaScore sonuç URL/logu ve otomatik `get_market_config` çağrısı bulunmamalıdır.
