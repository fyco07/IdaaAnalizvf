# V36 Oyuncu Lambda Baglantisi

- Kadro verisi mevcutken analiz sonucu cache'den dönmez; kadro-aware analiz yeniden hesaplanır.
- Oyuncu roster kalitesi ev/deplasman tarafında bağımsız hesaplanır; bir tarafın istatistik kanıtı eksik olsa bile diğer tarafın sinyali sıfırlanmaz.
- Oyuncu kalite delta'ları küçük log-rate düzeltmeleri olarak doğrudan merkezi lambda katmanına girer.
- 50 nötr oyuncu kalite referansıdır; oyuncu kalitesi uydurulmaz, sadece gözlenen kaliteyi rate ölçeğine çevirmek için kullanılır.
- ESPN leaders parser root.leaders dışında iç içe leaders/categories/stats/statistics yapılarında da athlete/player + value çiftlerini tarar.
- Mevcut Room roster/stats havuzu korunur; V36 yeni schema eklemez.
- VersionCode 54, versionName 1.0-V36-OYUNCU-LAMBDA-BAGLANTI.
