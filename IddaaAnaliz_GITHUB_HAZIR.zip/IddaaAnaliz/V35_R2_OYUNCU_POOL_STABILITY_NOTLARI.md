# V35 R2 – Oyuncu Havuzu / ESPN 403 Dayanıklılık Düzeltmesi

## Tespit
Manchester City–Sunderland detayında ESPN takım uçları 403 döndüğünde mevcut kod doğrudan `coverage=0`, `players=0` üretiyordu. Aynı taramada başka takımların kadro verileri `coverage=100` olarak alınabiliyordu.

## Düzeltme
- ESPN roster/leaders/team/injury çağrıları global `Semaphore(2)` ile sınırlandı; 36 maçlık taramada endpoint fırtınası azaltıldı.
- Ağ çağrısı 403/timeout nedeniyle başarısız olduğunda, Room'da daha önce saklanmış roster varsa artık eski roster silinmiyor ve `KADRO_STALE_POOL_FALLBACK` ile kullanılmaya devam ediyor.
- Stale roster fallback'te güncel sakatlık/ceza durumu doğrulanmamışsa eski status `aktif eksik` olarak kullanılmıyor; `missing` boş tutuluyor.
- Başarılı roster geldiğinde yine Room'a kaydediliyor. Sonraki maçlarda roster TTL dolana kadar ağdan tekrar çekilmiyor.

## Beklenen davranış
1. İlk kez görülen takım + ağ başarılı: roster indirilir ve Room'a yazılır.
2. Roster TTL içindeyse: Room'dan okunur.
3. Roster TTL dolmuş + ağ başarılı: roster yenilenir ve Room'a yazılır.
4. Roster TTL dolmuş + ağ 403/timeout: eski roster kullanılır, uygulama `coverage=0` olmaktan kaçınır; yalnızca güncel durum doğrulanmadıysa eksik oyuncu etkisi uygulanmaz.
5. Sakatlık/ceza verisi ayrı ve daha sık yenilenir.

## Sınır
İlk kez görülen ve hiç yerel roster verisi olmayan bir takım için ESPN endpoint'i tamamen 403 verirse oyuncu listesi üretilemez. Bu durumda sahte oyuncu verisi yaratılmaz ve `coverage=0` kalabilir.
