# V17 – Merkezi 10 Fazlı Pipeline

Bu sürüm V16 üzerindeki çalışan akışları koruyarak merkezi veri katmanını gerçek bir karar pipeline'ına bağlar.

## Faz 1
Android Studio + Kotlin + Room + Retrofit + Coroutines + Compose mevcut yapı korunur.

## Faz 2
Merkezi Room havuzu: Match, Team, League, Season, Market, Odds, SourceData, Result, Prediction.

## Faz 3
İddaa bülteni Match/Team/Market/Odds/SourceData tablolarına yazılır.

## Faz 4
ESPN tarihsel maçları merkezi Match/Team/League/Season/Result/SourceData tablolarına aktarılır.

## Faz 5
ProgSport verisi SourceData olarak aynı maç kimliği altında tutulur.

## Faz 6
Takım profili motoru genel/lig/sezon/ev/deplasman/son5/10/20 pencerelerini üretir. Tarihsel örneklem merkezi sonuç havuzundan gelir.

## Faz 7
Poisson skor dağılımı, koşullu olasılık, bağımsız olay hesabı ve Bayes yardımcıları tek olasılık katmanında bulunur. Futbolda MS/KG/Üst-Alt/ilk yarı/takım golü desteklenir.

## Faz 8
Piyasa olasılığı no-vig ile normalize edilir. İddaa oranı model olasılığına doğrudan ağırlık vermez; benchmark olarak Edge/EV hesabında kullanılır.

## Faz 9
MacAnalizServisi tamamlandıktan sonra merkezi pipeline aynı maçı tekrar analiz ederek yeterli tarihsel örneklem varsa Poisson modelini kullanır; desteklenmeyen marketlerde mevcut çalışan model güvenli fallback'tir. Tahminler merkezi Prediction tablosuna yazılır.

## Faz 10
Tahmin → gerçek sonuç → Brier hatası → kalibrasyon. Sonuç worker'ı SofaScore sonucu geldiğinde merkezi Result tablosunu da günceller; saatlik KalibrasyonWorker bekleyen merkezi tahminleri sonuçlandırır.

## Güvenlik / karar mantığı
Favori olmayan seçimler sırf oran avantajı nedeniyle yapay biçimde yüksek güven almaz. Güven; model olasılığı, tarihsel örneklem kapsamı ve pozitif edge ile sınırlı biçimde yükseltilir.

## Paket uyumluluğu
`MerkeziVeriHavuzu` gerçek implementasyonu artık `com.Fyco.iddaaanaliz` kök paketindedir. Eski sürümlerde `com.Fyco.iddaaanaliz.merkezi.MerkeziVeriHavuzu` olarak import edilmiş dosyalar için typealias uyumluluk köprüsü bırakılmıştır.
