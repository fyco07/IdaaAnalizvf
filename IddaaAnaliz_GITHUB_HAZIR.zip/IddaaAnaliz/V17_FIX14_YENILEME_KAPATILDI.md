# V17 FIX14 — Yenileme tamamen kapatıldı

- Otomatik 3 dakikalık yenileme kaldırıldı.
- Manuel `YENİLE` butonu kaldırıldı.
- Bülten ve Günün Güçlüleri analizi yalnızca uygulama açılışında (`LaunchedEffect(Unit)`) bir kez çalışır.
- Uygulama açık kaldığı sürece yeni bülten çekilmez ve güçlü maçlar baştan analiz edilmez.
- Uygulama kapatılıp yeniden açıldığında başlangıç yüklemesi yeniden yapılır.
