# V10 Build Fix 2

Düzeltilen derleme sorunları:

- AnalizMotoru.calculateConfidence çağrıları imza ile uyumlu `modelProbability` adıyla düzeltildi.
- MerkeziFutbolModelHavuzu Snapshot `teams` map dönüş tipi düzeltildi; Pair sızıntısı kaldırıldı.
- MacAnalizServisi ve MerkeziVeriHavuzu için `MerkeziFutbolModelHavuzu` importları eklendi.
- MerkeziFutbolTahmincisi içinde KolmogorovOlasilikKatmani referansları tam nitelikli hale getirildi.

Amaç mevcut V10 merkezi model akışını bozmadan yalnızca derleme kaynaklı kırıkları kapatmaktır.
