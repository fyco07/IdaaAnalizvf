# V24 RESULT FIX

## Sürüm
- versionName: `1.0-V24-FINAL-RESULTFIX`
- versionCode: `39`

## Sonuç zinciri
- Aktif sonuç çözücü: `ESPNSonucSaglayici`
- `SofascoreSonucSaglayici` yalnızca geriye dönük API uyumluluğu için no-network bridge'dir.
- `SofaScoreTarihselVeriWorker` no-op; eski WorkManager kayıtları ağ isteği yapamaz.
- Eski genel `TarihselVeriWorker` da no-op; aktif tarihsel zincir yalnızca `ESPNHistoryWorker`.
- Uygulama açılışında eski SofaScore/legacy unique work adları ve worker tag'leri iptal edilir.

## Sonuç bulma
- Futbol için önce yerel `espn_tarihsel_maclar` Room tablosu aranır.
- Bugün/dün veya yerel veri yoksa ESPN uzak scoreboard çağrısı yapılır.
- ESPN uzak çağrısı `site.api.espn.com` + `site.web.api.espn.com` çift host fallback ile çalışır.
- Sport/league/date bazında 10 dk başarı cache'i ve 15 dk hata backoff'u korunur.
- Aynı anahtar için Mutex ile eşzamanlı tekrar çağrılar engellenir.
- Sonuç bulunamadı logları event bazında tekilleştirilir; 4054 market kaydı aynı maç için log spam üretmez.

## Model / güçlü seçim
- Merkezi futbol modeli kullanılır.
- Team-name alias eşleştirme ile `P. Thistle`, `C Glogow` gibi baş harfli İddaa adları için deterministic alias uygulanır.
- Merkezi model minimum takım örneklemi 1'den itibaren analiz üretebilir; Günün Güçlüleri için ayrı örneklem filtresi korunur.
- Paylaşılan Poisson/Dixon-Coles dağılımından market olasılıkları üretilir.
- Probability / confidence / edge / EV ayrı metriklerdir.
- Günün Güçlüleri 1191 maçlık evreni tarayıp adayları dinamik toplar.

## Kontrol
- V24 kaynaklarında `api.sofascore.com`, `SONUC_HTTP_ISTEK` ve `SONUC_HTTP_HATASI` bulunmuyor.
- Değiştirilen Kotlin dosyalarında bağımsız `kotlinc` parse kontrolünde syntax hatası çıkmadı.
- Tam Android Gradle build bu ortamda çalıştırılamadı: Gradle 9.5 dağıtımı ve Android SDK yerel olarak mevcut değil; ağ erişimi de dağıtımı indiremedi.

## Telefonda beklenen başlangıç logu
`V24_BOOT version=1.0-V24-FINAL-RESULTFIX code=39 CENTRAL_MODEL_ONLY=true`
