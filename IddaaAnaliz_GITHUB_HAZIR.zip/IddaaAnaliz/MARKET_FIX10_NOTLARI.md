# MARKET FIX10

Amaç: Maç detayında Maç Sonucu, Çifte Şans ve Karşılıklı Gol marketlerinin Alt/Üst kadar görünmemesine neden olan market sınıflandırma ve outcome eşleştirme açıklarını kapatmak.

Düzeltmeler:
- Maç Sonucu beraberlik outcome değerinde `0`, `x`, `0.0`, `beraberlik`, `draw` desteği.
- `st=720` ve saf `Var/Yok` yapısındaki bağımsız KG marketi için doğrudan BTTS olasılık dalı.
- Çifte Şans başlık bulunamadığında `1X/X2/12` outcome yapısından da tanıma.
- Config başlığı eksik/genel olduğunda güvenli outcome şekline göre canonical market başlığı.
- Alt/Üst, Handikap, Takım Golü ve mevcut kombine dallarının matematiğine dokunulmadı.
- Merkezi Poisson/skor dağılımı değiştirilmedi.
