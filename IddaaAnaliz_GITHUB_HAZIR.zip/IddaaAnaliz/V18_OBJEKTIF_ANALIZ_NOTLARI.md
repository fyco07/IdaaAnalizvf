# V18 – Objektif Analiz Süzgeci

Bu sürümde çalışan İDDAA + ESPN + merkezi havuz akışı korunur.

## Model tarafı
- Futbol Poisson modeli yalnızca iki takım için de ESPN ratingi bulunduğunda çalışır.
- Her iki takımın da en az 5 tarihsel ESPN maçı bulunmalıdır.
- Eksik takım ratingi 0 kabul edilmez.
- ESPN eğitiminde validation setinden seçilen `kalibrasyonAlpha` skor dağılımına uygulanmaya devam eder.
- Aktif futbol analizinde ikinci `OgrenmeMotoru` çevrimiçi kalibrasyon karışımı kullanılmaz; böylece çözülmüş tahminler canlı olasılığı geri besleyemez.

## Güven
- Güven olasılığın büyüklüğünden üretilmez.
- Güven yalnızca iki takımın minimum tarihsel örneklem büyüklüğünden türetilir.
- Oran, Edge ve EV güvene bonus vermez.

## Piyasa tarafı
- İDDAA oranı yalnızca no-vig piyasa benchmarkıdır.
- `Edge = model - no-vig`
- `EV = model * oran - 1`
- Edge/EV model olasılığını değiştirmez.

## Günün Güçlüleri
- OYNA için model/veri güveni + pozitif Edge + pozitif EV gerekir.
- Oran bandına göre farklı bonus uygulanmaz.
- Uzun oran, sadece yüksek EV ürettiği için otomatik olarak öne alınmaz.

## Kaynak izolasyonu
- Aktif canlı analizde ProgSport ve SofaScore çağrısı yapılmaz.
- Eski sınıflar geriye dönük uyumluluk için projede tutulabilir; tarihsel/merkezi veri akışı silinmez.
