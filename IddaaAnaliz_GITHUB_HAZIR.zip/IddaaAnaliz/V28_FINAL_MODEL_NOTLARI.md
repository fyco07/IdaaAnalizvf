# V28 FINAL MODEL

- Version code: 43
- Version name: 1.0-V28-FINAL-MODEL
- Merkezi futbol modeli: latent ELO + hücum/savunma + venue + form5/10/20 + trend + rakip gücü + öğrenilmiş lig bağlamı.
- Takım 0-100 puanı latent modelden ayrı, gösterim amaçlı dağılımsal dönüşümdür.
- İDDAA resmi bülteni canlı market kaynağıdır; ESPN tarihsel sonuç + maç günü kadro/sakatlık yardımcı kaynağıdır. SofaScore aktif zincirde değildir.
- Oyuncu modeli artık maç analizi çağrısından önce gerçek ESPN kadro/sakatlık verisi varsa beslenebilir; oyuncu performans sinyali ESPN team leaders verisinden bulunduğunda oyuncu puanı oluşturulur. Veri yoksa puan/etki uydurulmaz.
- Oyuncu etkisi ortak lambda katmanında uygulanır; marketler sonradan ayrı ayrı düzeltilmez.
- Günün Güçlüleri iki aşamalıdır: tüm bülten temel model taraması, ardından üst futbol adaylarında kadro/sakatlık ikinci geçişi. Yeni kadro etkisi sonucu sıralama değişebilir.
- Takım adlarında benzersiz tek-token aliaslar collision-safe olarak kullanılabilir; belirsiz aliaslar elenir.
- Analiz cache fingerprintine oyuncu listesi de dahil edilmiştir; kadro değişince eski model sonucu kullanılmaz.
- Detay ekranında takım puanı ve mevcut gerçek ESPN eksikleri/oyuncu etkisi gösterilir.
- Başlangıçtaki ağır öğrenme init çağrısı MainActivity'den çıkarıldı; Application katmanındaki init korunur.
- Bu ortamda Gradle 9.5 dağıtımı indirilemediği için APK derlemesi doğrulanamadı (services.gradle.org DNS).
