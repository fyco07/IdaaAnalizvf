# Merkezi Mimari V16

Bu sürüm mevcut çalışan akışları sökmeden yeni merkezi veri katmanını ekler.

## Fazlar
1. Android Studio / Kotlin / Room / Retrofit / Coroutines / Compose mevcut altyapı korunur.
2. `MerkeziVeritabani`: Match, Team, League, Season, Market, Odds, SourceData, Result, Prediction.
3. İddaa bülteni merkezi havuza yazılır.
4. ESPN tarihsel sonuçları mevcut ESPN DB'den merkezi havuza senkronlanır.
5. ProgSport eşleşmeleri merkezi SourceData olarak saklanır.
6. `TakimProfilMotoru`: genel, lig, sezon, ev, deplasman, son 5/10/20.
7. `OlasilikMotoruV2`: ortak skor uzayı, Poisson, koşullu olasılık ve Bayes.
8. `BahisMatematigi`: no-vig, fair odds, edge, EV.
9. `TahminMotoruV2`: MS, KG, Alt/Üst tahmin sözleşmesi. Mevcut `MacAnalizServisi` de merkezi Prediction kaydı oluşturur.
10. `KalibrasyonMotoru` + saatlik `KalibrasyonWorker`: sonuç geldikçe Brier hatası kaydı.

## Koruma
- Eski ESPN/SofaScore/Iddaa analiz zincirleri kaldırılmadı.
- Merkezi havuz ek bir katman olarak çalışır; merkezi senkron başarısız olursa eski ekran/analiz akışı devam eder.
- İddaa oranı model olasılığına dönüştürülüp tekrar modele sokulmaz; piyasa benchmarkıdır.

## Derleme doğrulaması
Ortamda Gradle dağıtımı indirmek için internet erişimi olmadığı için tam `assembleDebug` çalıştırılamadı. Yeni saf Kotlin olasılık/bahis/kalibrasyon motorları `kotlinc` ile başarıyla derlendi. Android/Room/KSP tam derlemesi Android Studio'nun yerel Gradle ortamında yapılmalıdır.
