# V26 – ESPN Sonuç Eşleştirme Fix

V25 logunda ESPN yerel sonuç DB'sinin gerçekten dolu olduğu görüldü (`local=612`, `local=366`), ancak `eslesen=0` kalıyordu.

Kök neden: `TahminKaydi.macZamani` UNIX saniye, `ESPNTarihselMac.baslangic` UNIX milisaniye tutuluyor. Sonuç eşleştiricide iki değer doğrudan çıkarılıyordu. Bu nedenle isim eşleşse bile zaman farkı saatlerce/büyüklükte görünerek güçlü isim eşleşmeleri eleniyordu.

V26'da `epochSeconds()` ile sonuç başlangıcı saniyeye normalize edildi. Böylece:
- Aynı eventId varsa doğrudan skor 100 korunur.
- Takım isimleri eşleştiğinde zaman puanı artık doğru birimle hesaplanır.
- 1 saat <= 20 puan, 2 saat <= 16, 4 saat <= 12, 8 saat <= 6 zaman katkısı korunur.
- Güçlü isim eşleşmesi + zaman dışı kayıt kombinasyonu yanlışlıkla elenmeye devam eder; belirsiz eşleşmeler otomatik zorlanmaz.

Ayrıca sürüm kimliği code 41'e yükseltildi ve başlangıç marker'ları V26 olarak değiştirildi.
