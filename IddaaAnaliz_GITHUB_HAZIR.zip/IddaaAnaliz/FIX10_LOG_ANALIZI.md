FIX10 – 11.09.2026

Log sonucu:
- ESPN model hazır: ratingDB=4347, meta=true.
- Merkezi DB yazımı başarılı: mac=23510, sonuc=22234, tahmin=399.
- İddaa bülteni merkezi DB'ye başarılı: futbol 1252 maç, basketbol 22 maç.
- Günün Güçlüleri taramasının 1274 maçta ağır SofaScore/ProgSport çağrılarına girmesi yavaşlık oluşturuyordu.
- Merkezi pipeline bazı maçlarda üst coroutine iptal olduğunda kayıt atlıyordu.

FIX10:
1) Günün Güçlüleri taramasında disVeriKullan=false hızlı yol.
2) Merkezi tahmin/pipeline DB yazımı NonCancellable + IO ile korunuyor.
3) Model hazırken ESPN repository 3 saniyelik gereksiz refresh döngüsü durduruldu; 10 saniyelik ve yalnızca model hazır değilse refresh var.
4) Normal detay analizi eski dış veri davranışını koruyor.
