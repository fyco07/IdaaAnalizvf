# V10 BUILD FIX

Bu paket, V10'da Android Studio derlemesinde görülen Kotlin hatalarını düzeltir.

Düzeltilenler:
- AnalizMotoru `calculateConfidence` named argument uyumsuzluğu.
- MerkeziFutbolModelHavuzu `teams` map tip uyuşmazlığı.
- MerkeziFutbolTahmincisi `KolmogorovOlasilikKatmani` importu.
- IddaaAnalizApplication eksik `android.util.Log` importu.
- ESPNModelDurum eksik `modelMeta` yerel değeri.

Merkezi mimari korunur:
İDDAA + ESPN tarihsel aktarımı -> Merkezi Veri Havuzu -> takım ratingi/form/rakip gücü -> merkezi Poisson -> market olasılığı.

Normal analiz sırasında tarihsel veri silme işlemi eklenmemiştir.

Build doğrulaması bu ortamda Gradle dağıtımı indirilemediği için yapılamadı.
