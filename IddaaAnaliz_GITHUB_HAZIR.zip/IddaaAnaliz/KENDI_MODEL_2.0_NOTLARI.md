# Kendi Modeli 2.0

## Veri akışı

ESPN 365 günlük futbol geçmişi -> Room -> takım hücum/savunma ratingleri -> beklenen goller -> Poisson skor uzayı -> Kolmogorov tutarlılık -> kalibrasyon -> canlı maç olasılıkları -> İddaa no-vig benchmark -> Edge/EV -> karar.

## Modelin kuralları

- İddaa oranı Kendi Modeli 2.0'nın eğitim girdisi değildir.
- İddaa yalnızca piyasanın benchmarkı olarak edge ve EV hesaplarında kullanılır.
- Futbolda nihai model olasılığı Kendi Modeli + varsa ProgSport üzerinden oluşturulur.
- ESPN modelinin ağırlığı başlangıçta %70, ProgSport %30'dur; İddaa %0'dır.
- Güven puanı Edge/EV ile şişirilmez.
- 1/X/2, KG ve Alt/Üst olasılıkları ayrı ayrı uydurulmaz; aynı skor dağılımından türetilir.
- Skor uzayı normalize edilir; negatif olasılık kabul edilmez ve toplam 1'e zorlanır.
- Eğitimde son 365 gün kullanılır ve yakın maçlara recency ağırlığı verilir.
- Takım hücum/savunma ratingleri rakip gücü düzeltilerek iteratif biçimde öğrenilir.
- Son %20 tarihsel veri kalibrasyon için ayrılır; alpha değeri Brier skoruyla seçilir; ardından ratingler 365 günün tamamıyla yeniden eğitilir.

## Kaynaklardan uygulanan fikirler

Mathletics:
- takım ratingleri,
- hücum/savunma ayrımı,
- ev avantajı,
- beklenen skor/gol üzerinden olasılık üretimi,
- Poisson dağılımı.

Trading Bases:
- gerçekleşen sonuç ile sürdürülebilir performansı ayırma,
- aşırı/şans kaynaklı sonuçların etkisini sınırlama.

The Logic of Sports Betting:
- decimal oran -> break-even 1/oran,
- piyasa fiyatını model olasılığından ayırma,
- güçlü piyasanın benchmark olarak değerlendirilmesi,
- value'nun model ile fiyat arasındaki farktan çıkarılması.

Kolmogorov:
- P(E) >= 0,
- P(Omega) = 1,
- ayrık olaylarda toplamsallık.
