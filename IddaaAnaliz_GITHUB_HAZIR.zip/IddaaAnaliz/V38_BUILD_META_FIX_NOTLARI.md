# V38 – Build/meta and player-pool stability fix

## Build error fixed
- Removed the fragile named argument `meta = ...` at the stale-pool fallback call. The call is positional so it cannot fail on a local parameter-name mismatch with `Unresolved reference: meta`.
- Simplified the unreachable/redundant null-flow check around roster/injury data.

## Warnings cleaned where directly related
- Removed unused MAX_CACHE constant in ESPNKadroSaglayici.
- Removed unused JsonElement.asJsonObjectOrNull helper.
- Removed unused saturating helper in OyuncuEtkiMotoru.
- Removed redundant `!injuryFresh` condition.

## Data safety
- When falling back to a roster stored under an older cache key, injury status rows are now read from the same fallbackMeta.cacheKey instead of the new cache key.
- Persistent roster remains authoritative when ESPN roster requests fail; no fake player/stat/injury data is generated.

VersionCode: 56
VersionName: 1.0-V38-OYUNCU-BUILD-META-FIX
