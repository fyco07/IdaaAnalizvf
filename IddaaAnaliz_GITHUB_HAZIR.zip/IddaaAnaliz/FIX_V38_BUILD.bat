@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0FIX_V38_BUILD.ps1" -Build
if errorlevel 1 (
  echo.
  echo DERLEME HATA VERDI. Ekrandaki ILK Kotlin hatasini paylas.
  pause
  exit /b 1
)
echo.
echo V38 DERLEME BASARILI.
pause
