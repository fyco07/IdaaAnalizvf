# V39 BUILD TYPE FIX

Derleme hatası düzeltildi: `MerkeziFutbolTahmincisi.kt` içindeki handikap beraberlik hesabında `sc.first + line` bir `Double`, `sc.second` ise `Int` olduğundan `Double == Int` karşılaştırması yapılıyordu.

Yeni hesap: iki taraf `Double` a çevrilip mutlak fark `1e-9` eşiğiyle karşılaştırılıyor. Böylece hem tam sayı hem de kesirli handikap çizgileri tip güvenli biçimde işleniyor; model mantığı değiştirilmedi.

VersionCode: 57
VersionName: 1.0-V39-BUILD-TYPE-FIX
