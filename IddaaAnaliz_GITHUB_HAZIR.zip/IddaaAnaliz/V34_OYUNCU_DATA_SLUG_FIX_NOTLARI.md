# V34 – Oyuncu verisi + ESPN lig slug + puanlama düzeltmesi

## Bu sürümde tespit edilen gerçek kök neden
V30 test logunda kadro modeli için tarihsel takım index'i hazırlanıyor (`KADRO_TAKIM_INDEX_HAZIR`), ancak kadro endpoint çağrılarında kullanılan `league` alanı bazı kayıtlarda ESPN'in `season.slug` değerinden geliyor.

Örnek:
- yanlış routing değeri: `2026-27-english-premier-league`
- ESPN Site API'nin beklediği lig slug'ı: `eng.1`

ESPN Site API takım/kadro uçları `.../sports/soccer/{league}/teams/{id}/roster` ve `.../injuries` biçimindedir. ESPN API dokümantasyonunda Premier League için `eng.1`, LaLiga için `esp.1`, Serie A için `ita.1`, Ligue 1 için `fra.1`, Turkish Super Lig için `tur.1` gibi slug'lar kullanılır.

## V34 değişiklikleri
1. `ESPNHistoryWorker` artık mümkün olduğunda `competition.league.slug` değerini `ESPNTarihselMac.lig` alanına yazar. `season.slug` yalnızca geriye dönük fallback olarak kalır.
2. `ESPNKadroSaglayici` mevcut eski DB kayıtlarını runtime'da gerçek ESPN lig slug'larına dönüştürür. Böylece mevcut 31k+ tarihsel kayıtı silmeye gerek kalmaz.
3. Yaygın ligler için kontrollü teknik routing eşlemesi eklendi: EPL, Championship, LaLiga, Bundesliga, Serie A/B, Ligue 1/2, Eredivisie, Premiership, Primeira Liga, Super Lig, Eliteserien, Liga MX, Libertadores ve diğer yaygın ligler.
4. Kadro endpoint hataları artık sessizce yutulmuyor; `KADRO_ENDPOINT_HATASI` logları hangi endpointin hangi HTTP/ağ hatası ile başarısız olduğunu gösteriyor.
5. Oyuncu üretim metriklerine ESPN JSON'da mevcutsa xG/xA alanları ekleniyor.
6. Oyuncu 0–100 puanında per-90 hesabı düzeltildi. Önceki sürümde `dakikaOrtalamasi` toplam dakika gibi kullanıldığı için per-90 hesaplaması bozulabiliyordu. V34 önce toplam gözlenen dakikayı türetip per-90 hesaplıyor ve küçük örneklemi shrinkage ile bastırıyor.
7. Oyuncu önemi; kullanım/maç süresi + ilk 11 rolü + pozisyona uygun üretim kanıtından oluşuyor. 1–2 kısa maçta yüksek üretim otomatik olarak 90+ puan üretmiyor.
8. Eksik oyuncu etkisi hâlâ replacement-aware; gerçek eksik oyuncu verisi yoksa lambda değiştirilmez.

## Beklenen test logları
Kadro veri yolu düzgün çalıştığında örnek akış:

`KADRO_TAKIM_INDEX_HAZIR ...`

`KADRO_MODEL_HAZIR ... leagueHome=eng.1 leagueAway=eng.1 ...`

`KADRO_VERI_DETAY team=Manchester City ... roster=true ...`

`KADRO_VERI_DETAY team=Sunderland ... roster=true ...`

Gerçek eksik oyuncu raporu yoksa `kadroUygulanan=0` kalması normaldir; sahte eksik oyuncu üretilmez.

## Sürüm
- versionCode: 49
- versionName: `1.0-V34-OYUNCU-DATA-SLUG-FIX`


### R2 cache fingerprint düzeltmesi
`MacAnalizServisi` oyuncu fingerprint'i artık oyuncu ID, maç/ilk 11 sayısı, ilk 11 oranı, xG/xA, şut, isabetli şut, kurtarış ve yenen gol metriklerini de içeriyor. Böylece önce coverage=0 ile oluşmuş analiz cache'i sonradan ESPN kadro/istatistik verisi geldiğinde aynen kullanılmıyor; analiz yeniden hesaplanıyor.
