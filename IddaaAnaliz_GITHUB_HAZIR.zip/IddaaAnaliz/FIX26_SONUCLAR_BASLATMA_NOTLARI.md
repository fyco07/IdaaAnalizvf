# V17 FIX26 – Sonuç Zinciri Başlatma Fix

Bu sürümde sonuç taraması yalnızca Application/WorkManager başlatma sırasına bağlı değildir.

## Eklenen tanı noktaları
- `FIX26_APPLICATION_ONCREATE`
- `SONUC_ZINCIRI_BASLATILDI`
- `FIX26_UI_BASLADI`
- `FIX26_UI_SONUC_TARAMA_TETIKLENDI`
- `FIX26_UI_SONUC_TARAMA_HATASI`
- Mevcut `SONUC_INPROCESS_*` ve `WORKER_*` logları korunmuştur.

## Başlatma modeli
Uygulama açıldığında hem Application hem MainActivity tarafından sonuç tarama tetiklenebilir. `TahminSonucArkaPlanPlanlayici` içindeki `AtomicBoolean` aynı anda iki gerçek taramanın çalışmasını engeller.

## Korunan davranış
- Bülten otomatik yenileme yok.
- Manuel `YENİLE` korunur.
- Saatlik WorkManager sonuç taraması korunur.
- Sonuçlar SofaScore üzerinden mevcut çözümleyiciye verilir.
